package com.bixiaoqu.app;

import android.content.Context;
import android.content.SharedPreferences;

/** 本地设置项（全部走 SharedPreferences，无第三方依赖） */
public final class Prefs {

    static final String NAME = "bxq_settings";

    public static final int DEC_AUTO = 0;
    public static final int DEC_HW = 1;
    public static final int DEC_COMPAT = 2;
    public static final int DEC_LOW = 3;

    public static final String[] DEC_NAMES = {"自动（推荐）", "硬解（DASH）", "兼容（合流）", "兼容 360p"};

    static SharedPreferences sp(Context c) {
        return c.getSharedPreferences(NAME, Context.MODE_PRIVATE);
    }

    // ===== 主题（v4.10.0）=====
    public static final int THEME_SYSTEM = 0;   // 跟随系统
    public static final int THEME_DARK = 1;     // 强制深色
    public static final int THEME_LIGHT = 2;    // 强制浅色

    public static int themeMode(Context c) {
        return sp(c).getInt("theme_mode", THEME_DARK);
    }

    public static void setThemeMode(Context c, int v) {
        sp(c).edit().putInt("theme_mode", v).apply();
    }

    /** 推荐页是否双列（默认单列，保持旧版观感） */
    public static boolean twoColumn(Context c) {
        return sp(c).getBoolean("two_column", false);
    }

    public static void setTwoColumn(Context c, boolean v) {
        sp(c).edit().putBoolean("two_column", v).apply();
    }

    /** 是否显示开屏动画（默认开） */
    public static boolean splash(Context c) {
        return sp(c).getBoolean("splash", true);
    }

    public static void setSplash(Context c, boolean v) {
        sp(c).edit().putBoolean("splash", v).apply();
    }

    /** 默认解码方式：0 自动 / 1 硬解 / 2 兼容合流（高码率单文件） / 3 兼容 360p */
    public static int decoder(Context c) {
        int v = sp(c).getInt("decoder", DEC_AUTO);
        return (v < 0 || v > 3) ? DEC_AUTO : v;
    }

    public static void setDecoder(Context c, int v) {
        sp(c).edit().putInt("decoder", v).apply();
    }

    public static String decoderName(int v) {
        switch (v) {
            case DEC_HW: return "硬解（1080p）";
            case DEC_COMPAT: return "兼容（合流，绕开 DASH）";
            case DEC_LOW: return "兼容模式（360p 合流）";
            default: return "自动（推荐）";
        }
    }

    /** 播放器默认是否开弹幕 */
    public static boolean danmaku(Context c) {
        return sp(c).getBoolean("danmaku", true);
    }

    public static void setDanmaku(Context c, boolean v) {
        sp(c).edit().putBoolean("danmaku", v).apply();
    }

    // ---- 【v4.8】弹幕样式：颜色 / 透明度 / 字号 ----

    /** 弹幕颜色：0 = 跟随弹幕自带颜色（B站彩色弹幕），否则为 0xRRGGBB */
    public static int dmColor(Context c) {
        return sp(c).getInt("dm_color", 0) & 0xFFFFFF;
    }

    public static void setDmColor(Context c, int v) {
        sp(c).edit().putInt("dm_color", v & 0xFFFFFF).apply();
    }

    /** 弹幕不透明度百分比（10~100） */
    public static int dmAlpha(Context c) {
        int v = sp(c).getInt("dm_alpha", 100);
        return v < 10 ? 10 : (v > 100 ? 100 : v);
    }

    public static void setDmAlpha(Context c, int v) {
        sp(c).edit().putInt("dm_alpha", Math.max(10, Math.min(100, v))).apply();
    }

    /** 弹幕字号百分比（60~180） */
    public static int dmSize(Context c) {
        int v = sp(c).getInt("dm_size", 100);
        return v < 60 ? 60 : (v > 180 ? 180 : v);
    }

    public static void setDmSize(Context c, int v) {
        sp(c).edit().putInt("dm_size", Math.max(60, Math.min(180, v))).apply();
    }

    // ---- 【v4.10.6】弹幕更多调节：速度 / 显示区域 / 密度 ----

    /** 滚动速度百分比（50~200，100 = 标准） */
    public static int dmSpeed(Context c) {
        int v = sp(c).getInt("dm_speed", 100);
        return v < 50 ? 50 : (v > 200 ? 200 : v);
    }

    public static void setDmSpeed(Context c, int v) {
        sp(c).edit().putInt("dm_speed", Math.max(50, Math.min(200, v))).apply();
    }

    /** 弹幕铺满的高度占屏幕比例（40~100） */
    public static int dmArea(Context c) {
        int v = sp(c).getInt("dm_area", 100);
        return v < 40 ? 40 : (v > 100 ? 100 : v);
    }

    public static void setDmArea(Context c, int v) {
        sp(c).edit().putInt("dm_area", Math.max(40, Math.min(100, v))).apply();
    }

    /** 同屏最多几条（10~80） */
    public static int dmDensity(Context c) {
        int v = sp(c).getInt("dm_density", 40);
        return v < 10 ? 10 : (v > 80 ? 80 : v);
    }

    public static void setDmDensity(Context c, int v) {
        sp(c).edit().putInt("dm_density", Math.max(10, Math.min(80, v))).apply();
    }

    /** 竖屏视频全屏时是否做「高度适配 + 左右虚化」优化 */
    public static boolean portraitOptimize(Context c) {
        return sp(c).getBoolean("portrait_opt", true);
    }

    public static void setPortraitOptimize(Context c, boolean v) {
        sp(c).edit().putBoolean("portrait_opt", v).apply();
    }

    /** 记住上次播放倍速（默认 1x） */
    public static float speed(Context c) {
        float v = sp(c).getFloat("speed", 1f);
        return (v < 0.4f || v > 3f) ? 1f : v;
    }

    public static void setSpeed(Context c, float v) {
        sp(c).edit().putFloat("speed", v).apply();
    }

    // ------------------------------------------------------------ 清晰度

    public static final int Q_AUTO = 0;
    public static final int Q_4K = 1;
    public static final int Q_2K = 2;
    public static final int Q_1080P60 = 3;
    public static final int Q_1080P = 4;
    public static final int Q_720P = 5;
    public static final int Q_480P = 6;
    public static final int Q_360P = 7;

    public static final String[] Q_NAMES = {
            "自动（最高可用）", "4K 超清", "2K 超清", "1080P60", "1080P", "720P", "480P", "360P"
    };

    /** 清晰度选项（默认自动） */
    public static int quality(Context c) {
        int v = sp(c).getInt("quality", Q_AUTO);
        return (v < 0 || v >= Q_NAMES.length) ? Q_AUTO : v;
    }

    public static void setQuality(Context c, int v) {
        sp(c).edit().putInt("quality", v).apply();
    }

    public static String qualityName(int v) {
        return (v >= 0 && v < Q_NAMES.length) ? Q_NAMES[v] : Q_NAMES[0];
    }

    /** 该档位对应的目标高度（px），自动/4K/2K 返回 0 表示「尽量高」 */
    public static int qualityHeight(int v) {
        switch (v) {
            case Q_4K: return 2160;
            case Q_2K: return 1440;
            case Q_1080P60: return 1080;
            case Q_1080P: return 1080;
            case Q_720P: return 720;
            case Q_480P: return 480;
            case Q_360P: return 360;
            default: return 0;
        }
    }

    /** 该档位请求 playurl 时用的 qn */
    public static int qualityQn(int v) {
        switch (v) {
            case Q_4K: return 120;
            case Q_2K: return 116;      // B 站无原生 2K，取 1080P60 高码位，实际按分辨率挑
            case Q_1080P60: return 116;
            case Q_1080P: return 80;
            case Q_720P: return 64;
            case Q_480P: return 32;
            case Q_360P: return 16;
            default: return 120;        // 自动也请求最高，尽量让接口把 4K 一起返回
        }
    }

    // ------------------------------------------------------------ 推荐流

    /** 推荐列表翻页/换批计数，保证每次刷新请求不同的分页，内容自然不同 */
    public static int recSeed(Context c) {
        return sp(c).getInt("rec_seed", 0);
    }

    public static int bumpRecSeed(Context c) {
        int v = recSeed(c) + 1;
        sp(c).edit().putInt("rec_seed", v % 100000).apply();
        return v;
    }

    // ------------------------------------------------------------ 彩蛋：跳一跳

    /** 跳一跳历史最高分 */
    public static int jumpBest(Context c) {
        return sp(c).getInt("jump_best", 0);
    }

    public static void setJumpBest(Context c, int v) {
        if (v > jumpBest(c)) sp(c).edit().putInt("jump_best", v).apply();
    }

    /** 某档难度的历史最高分（简单/中等/困难 分开记录） */
    public static int jumpBestAt(Context c, int diff) {
        return sp(c).getInt("jump_best_" + diff, 0);
    }

    public static void setJumpBestAt(Context c, int diff, int v) {
        if (v > jumpBestAt(c, diff)) {
            sp(c).edit().putInt("jump_best_" + diff, v).apply();
        }
    }

    /** 上次选择的难度：0 简单 / 1 中等 / 2 困难 */
    public static int jumpDifficulty(Context c) {
        return sp(c).getInt("jump_diff", 1);
    }

    public static void setJumpDifficulty(Context c, int d) {
        sp(c).edit().putInt("jump_diff", d).apply();
    }

    private Prefs() { }
}
