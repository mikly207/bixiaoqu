package com.bixiaoqu.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;

import org.json.JSONObject;

/**
 * 扫码登录：展示官方网页端二维码，确认后保存登录 Cookie。
 * 凭据双通道解析（Set-Cookie + 跳转 URL 参数），任一通道有效即可。
 */
public class LoginActivity extends Activity {

    ImageView qrView;
    TextView status;
    Handler ui = new Handler(Looper.getMainLooper());
    volatile boolean polling = false;
    String currentKey = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        MainActivity.applyTheme(this);
        buildUi();
        refreshQr();
    }

    void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(MainActivity.C_BG);
        int pad = (int) (getResources().getDisplayMetrics().density * 20);
        root.setPadding(pad, pad, pad, pad);
        root.setGravity(Gravity.CENTER_HORIZONTAL);

        TextView title = new TextView(this);
        title.setText("扫码登录 B 站");
        title.setTextColor(MainActivity.C_FG);
        title.setTextSize(18);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        root.addView(title);

        TextView sub = new TextView(this);
        sub.setText("用 B 站 App 扫码确认。登录后可看高清、缓存 320k。\n" +
                "凭据保存在本机 App 私有目录，不会上传。");
        sub.setTextColor(MainActivity.C_SUB);
        sub.setTextSize(12);
        sub.setPadding(0, (int) (pad * 0.6), 0, 0);
        root.addView(sub);

        qrView = new ImageView(this);
        LinearLayout.LayoutParams qp = new LinearLayout.LayoutParams(
                (int) (pad * 11), (int) (pad * 11));
        qp.topMargin = (int) (pad * 0.8);
        root.addView(qrView, qp);

        status = new TextView(this);
        status.setText("正在生成二维码…");
        status.setTextColor(MainActivity.C_ACC);
        status.setTextSize(14);
        status.setGravity(Gravity.CENTER);
        status.setPadding(0, (int) (pad * 0.8), 0, 0);
        root.addView(status);

        Button refresh = new Button(this);
        refresh.setText("刷新二维码");
        refresh.setTextColor(Color.WHITE);
        refresh.setBackgroundColor(MainActivity.C_CARD);
        refresh.setAllCaps(false);
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        rp.topMargin = (int) (pad * 0.8);
        root.addView(refresh, rp);
        refresh.setOnClickListener(new android.view.View.OnClickListener() {
            @Override public void onClick(android.view.View v) { refreshQr(); }
        });

        setContentView(root);
    }

    void runUi(java.lang.Runnable r) {
        ui.post(new Runnable() { @Override public void run() { r.run(); } });
    }

    void refreshQr() {
        polling = false;
        new Thread(new Runnable() { @Override public void run() {
            try {
                JSONObject data = BiliApi.qrcodeGenerate();
                currentKey = data.getString("qrcode_key");
                String url = data.getString("url");
                final Bitmap bmp = makeQr(url, 600);
                runUi(new Runnable() { @Override public void run() {
                    qrView.setImageBitmap(bmp);
                    status.setText("请用 B 站 App 扫码");
                } });
                startPolling();
            } catch (final Exception e) {
                runUi(new Runnable() { @Override public void run() {
                    status.setText("二维码生成失败：" + e.getMessage());
                } });
            }
        } }).start();
    }

    void startPolling() {
        if (polling) return;
        polling = true;
        new Thread(new Runnable() { @Override public void run() {
            long start = System.currentTimeMillis();
            while (polling && System.currentTimeMillis() - start < 180_000) {
                try {
                    Thread.sleep(1500);
                    if (!polling) return;
                    JSONObject r = BiliApi.qrcodePoll(currentKey);
                    int code = r.getInt("code");
                    JSONObject data = r.getJSONObject("data");
                    if (code == 0) {
                        // 凭据双通道：① Set-Cookie（httpGet 已收集）② data.url 跳转参数
                        String url = data.optString("url", "");
                        final String sessdata = firstNonEmpty(
                                param(url, "SESSDATA"), BiliApi.COOKIES.get("SESSDATA"));
                        final String jct = firstNonEmpty(
                                param(url, "bili_jct"), BiliApi.COOKIES.get("bili_jct"));
                        final String uid = firstNonEmpty(
                                param(url, "DedeUserID"), BiliApi.COOKIES.get("DedeUserID"));
                        if (sessdata.isEmpty()) {
                            final String dbg = "url=" + (url.isEmpty() ? "(无)" :
                                    url.substring(0, Math.min(80, url.length())));
                            runUi(new Runnable() { @Override public void run() {
                                status.setText("登录返回缺少凭据，请刷新重试\n" + dbg);
                            } });
                            polling = false;
                            return;
                        }
                        SharedPreferences sp = getSharedPreferences("bili_login", MODE_PRIVATE);
                        sp.edit().putString("SESSDATA", sessdata)
                                .putString("bili_jct", jct)
                                .putString("DedeUserID", uid)
                                .putLong("login_time", System.currentTimeMillis())
                                .apply();
                        BiliApi.setLoginCookie(sessdata, jct, uid);
                        polling = false;
                        runUi(new Runnable() { @Override public void run() {
                            Toast.makeText(LoginActivity.this, "登录成功 ✓", Toast.LENGTH_SHORT).show();
                            finish();
                        } });
                        return;
                    } else if (code == 86038) {
                        runUi(new Runnable() { @Override public void run() {
                            status.setText("二维码已过期，请点「刷新二维码」");
                        } });
                        polling = false;
                        return;
                    } else if (code == 86090) {
                        runUi(new Runnable() { @Override public void run() {
                            status.setText("已扫码，请在手机上确认 ✓");
                        } });
                    } else if (code == 86101) {
                        runUi(new Runnable() { @Override public void run() {
                            status.setText("等待扫码…");
                        } });
                    }
                } catch (InterruptedException ie) {
                    return;
                } catch (Exception e) {
                    // 网络抖动，继续轮询
                }
            }
            if (polling) {
                polling = false;
                runUi(new Runnable() { @Override public void run() {
                    status.setText("超时，请点「刷新二维码」");
                } });
            }
        } }).start();
    }

    static String firstNonEmpty(String a, String b) {
        return (a != null && !a.isEmpty()) ? a : (b == null ? "" : b);
    }

    static String param(String url, String key) {
        for (String seg : url.split("&")) {
            int eq = seg.indexOf('=');
            if (eq <= 0) continue;
            String k = seg.substring(0, eq);
            int ks = k.lastIndexOf('?');
            if (ks >= 0) k = k.substring(ks + 1);
            if (!k.equals(key)) continue;
            String v = seg.substring(eq + 1);
            try {
                return java.net.URLDecoder.decode(v.replace("+", "%2B"), "UTF-8");
            } catch (Exception e) {
                return v;
            }
        }
        return "";
    }

    @SuppressLint("HotSpot")
    static Bitmap makeQr(String content, int size) {
        try {
            BitMatrix m = new QRCodeWriter()
                    .encode(content, BarcodeFormat.QR_CODE, size, size);
            Bitmap bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
            int[] row = new int[size];
            for (int y = 0; y < size; y++) {
                for (int x = 0; x < size; x++) {
                    row[x] = m.get(x, y) ? Color.BLACK : Color.WHITE;
                }
                bmp.setPixels(row, 0, size, 0, y, size, 1);
            }
            return bmp;
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    protected void onDestroy() {
        polling = false;
        super.onDestroy();
    }
}
