#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
重建三国演义的章节切分数据。

问题：原构建脚本按 "第001回"（阿拉伯数字）切章，而正文里实际用的
是中文数字 "第一回"，导致：
  - 第 1~119 回正文为空（每回只有 58~64 字节 = 一行标题）
  - 全部 60 万字正文被塞进第 120 回

修复：从第 120 回的 body 里取出完整正文，按中文数字回目重新切成 120 回。
"""
import gzip
import json
import os
import re
import struct
import sys

BOOKS_DIR = os.path.dirname(os.path.abspath(__file__))
KEY = "sanguoyanyi"

CN = {'一': 1, '二': 2, '三': 3, '四': 4, '五': 5, '六': 6,
      '七': 7, '八': 8, '九': 9, '零': 0, '〇': 0, '两': 2}


def cn2int(s):
    total = 0
    num = 0
    for ch in s:
        if ch in CN:
            num = CN[ch]
        elif ch == '十':
            total += (num or 1) * 10
            num = 0
        elif ch == '百':
            total += (num or 1) * 100
            num = 0
    return total + num


def read_records(raw):
    """按 BookStore 的记录格式顺序解析整本。"""
    p = 0
    recs = []
    n = len(raw)
    while p + 2 <= n:
        tl = raw[p] | (raw[p + 1] << 8)
        p += 2
        if p + tl > n:
            break
        title = raw[p:p + tl].decode('utf-8', 'replace')
        p += tl
        if p + 4 > n:
            break
        bl = struct.unpack('<i', raw[p:p + 4])[0]
        p += 4
        if bl < 0 or p + bl > n:
            break
        body = raw[p:p + bl].decode('utf-8', 'replace')
        p += bl
        recs.append((title, body))
    return recs


def main():
    gz_path = os.path.join(BOOKS_DIR, KEY + '.bin.gz')
    idx_path = os.path.join(BOOKS_DIR, KEY + '.idx.json')

    raw = gzip.open(gz_path, 'rb').read()
    recs = read_records(raw)
    print('原记录数: %d' % len(recs))

    # 第 120 回的 body 承载了全书正文
    last_title, last_body = recs[-1]
    lines = last_body.split('\n')
    # 首行是 "第120回 ..." 的标题行（与其它 119 条记录的 body 首行同构）
    full = '\n'.join(lines[1:])

    # 回目标记：行首两个全角空格 + 第X回 + 全角空格 + 标题
    pat = re.compile(r'(?m)^　　第([一二三四五六七八九十百零〇两]+)回　(.+)$')
    ms = list(pat.finditer(full))
    if len(ms) != 120:
        print('ERROR: 回目标记数 %d != 120' % len(ms))
        return 1

    # 校验序号连续
    for i, m in enumerate(ms):
        v = cn2int(m.group(1))
        if v != i + 1:
            print('ERROR: 第 %d 个标记序号为 %d' % (i + 1, v))
            return 1

    chapters = []
    for i, m in enumerate(ms):
        start = m.start()
        end = ms[i + 1].start() if i + 1 < len(ms) else len(full)
        seg = full[start:end]
        # 去掉行首两个全角空格，得到与其它书一致的 "第一回 标题" 标题行
        seg_lines = seg.split('\n')
        seg_lines[0] = seg_lines[0].replace('　　', '', 1)
        # 标题用半角空格分隔（其它三本的口径：'第一回 灵根育孕源流出 心性修持大道生'）
        head = seg_lines[0]
        head = head.replace('　', ' ')
        title = head.strip()
        seg_lines[0] = title
        body = '\n'.join(seg_lines)
        chapters.append((title, body))

    # 写新二进制
    out = bytearray()
    offsets = []
    for title, body in chapters:
        tb = title.encode('utf-8')
        bb = body.encode('utf-8')
        offsets.append((len(out), len(tb) + 2 + len(bb) + 4))
        out += struct.pack('<H', len(tb))
        out += tb
        out += struct.pack('<i', len(bb))
        out += bb

    with gzip.open(gz_path, 'wb', 9) as f:
        f.write(bytes(out))

    total_chars = sum(len(b) for _, b in chapters)
    idx = {
        'key': KEY,
        'totalChars': total_chars,
        'chapterCount': len(chapters),
        'chapters': [
            {'n': i + 1, 't': t, 'off': offsets[i][0], 'len': offsets[i][1]}
            for i, (t, _) in enumerate(chapters)
        ],
    }
    with open(idx_path, 'w', encoding='utf-8') as f:
        json.dump(idx, f, ensure_ascii=False, indent=1)

    print('重建完成: %d 回, %d 字, 原始 %d 字' % (
        len(chapters), total_chars, len(full)))
    print('最短回 %d 字, 最长回 %d 字' % (
        min(len(b) for _, b in chapters),
        max(len(b) for _, b in chapters)))
    return 0


if __name__ == '__main__':
    sys.exit(main())
