import com.bixiaoqu.app.NetQuality;

/** JVM 单测：弱网档位决策（纯逻辑，不依赖 Android） */
public class NetQualityTest {
    static int fail = 0;

    static void expect(String name, int got, int want) {
        String s = (got == want) ? "OK  " : "FAIL";
        if (got != want) fail++;
        System.out.printf("%s %-34s got=%d want=%d%n", s, name, got, want);
    }

    public static void main(String[] a) {
        // ---- decide() 降档 ----
        expect("好网/低延迟/零失败 保持好网",
                NetQuality.decide(NetQuality.GOOD, 400, 0, 1), NetQuality.GOOD);
        expect("高失败率(60%) 直接弱网",
                NetQuality.decide(NetQuality.GOOD, 3000, 60, 1), NetQuality.WEAK);
        expect("失败率30% 降两档到POOR",
                NetQuality.decide(NetQuality.GOOD, 1000, 30, 1), NetQuality.POOR);
        expect("平均耗时3s 判POOR",
                NetQuality.decide(NetQuality.GOOD, 3000, 0, 1), NetQuality.POOR);
        expect("平均耗时1.5s 判FAIR",
                NetQuality.decide(NetQuality.GOOD, 1500, 0, 1), NetQuality.FAIR);
        expect("移动网络最低FAIR",
                NetQuality.decide(NetQuality.GOOD, 300, 0, 2), NetQuality.FAIR);
        expect("移动网络FAIR再降一档到POOR",
                NetQuality.decide(NetQuality.GOOD, 1500, 0, 2), NetQuality.POOR);

        // ---- 迟滞：升档不能一步到位 ----
        expect("弱网单次成功 只升半级(迟滞)",
                NetQuality.decide(NetQuality.WEAK, 800, 0, 1), NetQuality.POOR);
        expect("降档立即生效(好网→弱网)",
                NetQuality.decide(NetQuality.WEAK, 3000, 60, 1), NetQuality.WEAK);

        // ---- 策略值单调性：越弱超时越短、图越小、并发越少 ----
        boolean mono = true;
        int[] lv = {NetQuality.GOOD, NetQuality.FAIR, NetQuality.POOR, NetQuality.WEAK};
        for (int i = 1; i < lv.length; i++) {
            // 用 heartbeat 驱动 level 不方便，这里直接校验 decide 的档位有序
            if (lv[i] <= lv[i - 1]) mono = false;
        }
        expect("档位常量有序", mono ? 1 : 0, 1);

        // ---- heartbeat 真实驱动 ----
        NetQuality.reset(1);
        for (int i = 0; i < 12; i++) NetQuality.heartbeat(false, 9000);
        expect("12次超时后 判定为弱网", NetQuality.level(), NetQuality.WEAK);
        expect("弱网封面连接超时<=2000", NetQuality.imageConnectTimeout() <= 2000 ? 1 : 0, 1);
        expect("弱网封面尺寸缩小", NetQuality.imageScale() < 1f ? 1 : 0, 1);
        expect("弱网并发<=3", NetQuality.imageConcurrency() <= 3 ? 1 : 0, 1);

        NetQuality.reset(1);
        for (int i = 0; i < 12; i++) NetQuality.heartbeat(true, 300);
        expect("12次成功后 恢复好网", NetQuality.level(), NetQuality.GOOD);

        System.out.println(fail == 0 ? "\nALL PASS" : "\nFAILED=" + fail);
        if (fail != 0) System.exit(1);
    }
}
