/**
 * 【v4.57】愤怒的小鸟 · 抛物线一致性 + 射程可达性验证
 *
 * 验证目标：
 *   1. **预测线画的落点 == 小鸟真实落点**（旧版预测线用解析解、真实飞行
 *      用欧拉积分，两者对不上，玩家照线打必然偏）；
 *   2. **射程能打到塔**（塔在弹弓右侧约 1187px 处）；
 *   3. **帧率无关**（30/60/120fps 落点一致）。
 *
 * 这里的常量与积分器与 GameBird.java 保持严格一致。
 */
public class BirdTrajectoryTest {

    // ---- 与 GameBird.java 保持一致的常量 ----
    static final float G_DP = 1100f;
    static final float DRAG = 0.16f;
    static final float MAX_PULL_DP = 130f;
    static final float POWER = 8.3f;
    static final float SUB_STEP = 1f / 240f;
    static final int SUB_MAX = 24;

    static float dens = 3f;
    static float gAcc = G_DP * dens;
    static float maxPull = MAX_PULL_DP * dens;

    // ---- GameBird.integrate 等价实现 ----
    static void integrate(float[] s, float h) {
        s[3] += gAcc * h;
        float damp = 1f - DRAG * h;
        if (damp < 0f) damp = 0f;
        s[2] *= damp;
        s[3] *= damp;
        s[0] += s[2] * h;
        s[1] += s[3] * h;
    }

    // ---- GameBird.launchVelocity 等价实现（pullX/pullY = 小鸟相对弹弓的偏移）----
    static void launchVelocity(float pullX, float pullY, float[] out) {
        float d = (float) Math.hypot(pullX, pullY);
        if (d > maxPull) {
            pullX = pullX / d * maxPull;
            pullY = pullY / d * maxPull;
            d = maxPull;
        }
        if (d < 0.001f) { out[0] = 0; out[1] = 0; return; }
        float t = d / maxPull;
        float speed = POWER * d * (0.72f + 0.34f * t);
        out[0] = -pullX / d * speed;
        out[1] = -pullY / d * speed;
    }

    /** 预测：连续积分到落地 */
    static float predictLanding(float bx, float by, float vx, float vy, float groundY, float birdR) {
        float[] st = new float[]{bx, by, vx, vy};
        for (int i = 0; i < 500000; i++) {
            integrate(st, SUB_STEP);
            if (st[1] > groundY - birdR) return st[0];
        }
        return st[0];
    }

    /** 真实飞行：按帧率分帧 + 子步长累加器（与 GameBird.step 严格一致） */
    static float simulateLanding(float bx, float by, float vx, float vy, float groundY,
                                 float birdR, int fps) {
        float[] st = new float[]{bx, by, vx, vy};
        long frameMs = 1000L / fps;
        float stepAcc = 0f;
        for (int frame = 0; frame < 20000; frame++) {
            stepAcc += frameMs / 1000f;
            int guard = 0;
            while (stepAcc >= SUB_STEP && guard++ < SUB_MAX) {
                stepAcc -= SUB_STEP;
                integrate(st, SUB_STEP);
                if (st[1] > groundY - birdR) return st[0];
            }
            if (stepAcc > SUB_STEP) stepAcc = 0f;
        }
        return st[0];
    }

    /** 飞行统计：射程 / 飞行时间 / 最高点 */
    static float[] flightStats(float bx, float by, float vx, float vy, float groundY, float birdR) {
        float[] st = new float[]{bx, by, vx, vy};
        float t = 0, minY = by, apex = 0;
        for (int i = 0; i < 500000; i++) {
            integrate(st, SUB_STEP);
            t += SUB_STEP;
            if (st[1] < minY) { minY = st[1]; apex = t; }
            if (st[1] > groundY - birdR) break;
        }
        return new float[]{st[0] - bx, t, by - minY, apex};
    }

    public static void main(String[] args) {
        // 平板几何（2560px 宽，密度 3）
        float W = 2560f;
        float slingX = W * 0.16f;
        float groundY = 1400f;
        float slingY = groundY - 104f * dens;
        float birdR = 11f * dens;
        float towerX = W * 0.62f;

        System.out.println("=== 愤怒的小鸟 · 抛物线验证 ===");
        System.out.printf("密度=%.1f  重力=%.0f px/s²  最大拖拽=%.0f px  塔距=%.0f px%n",
                dens, gAcc, maxPull, towerX - slingX);

        int fail = 0;
        float maxErr = 0;

        // ---- 1. 一致性 ----
        System.out.println();
        System.out.println("【1】预测线 vs 真实落点");
        System.out.printf("%-18s %-11s %-11s %-11s %-9s%n", "拉拽偏移", "预测落点", "实际落点", "误差px", "仰角");
        System.out.println("------------------------------------------------------------");

        // 玩家会把鸟拖到左下方：(pullX<0, pullY>0) → 发射方向右上
        float[][] pulls = {
                {-90, 30}, {-120, 40}, {-150, 60}, {-180, 90}, {-220, 120},
                {-260, 150}, {-300, 190}, {-340, 220}, {-380, 260}, {-390, 280},
                {-140, 20}, {-200, 30},
        };

        for (float[] p : pulls) {
            float[] vel = new float[2];
            launchVelocity(p[0], p[1], vel);
            float bx = slingX + p[0], by = slingY + p[1];

            float predicted = predictLanding(bx, by, vel[0], vel[1], groundY, birdR);
            float actual60 = simulateLanding(bx, by, vel[0], vel[1], groundY, birdR, 60);
            float e30 = Math.abs(simulateLanding(bx, by, vel[0], vel[1], groundY, birdR, 30) - actual60);
            float e120 = Math.abs(simulateLanding(bx, by, vel[0], vel[1], groundY, birdR, 120) - actual60);

            float err = Math.abs(predicted - actual60);
            maxErr = Math.max(maxErr, Math.max(err, Math.max(e30, e120)));
            float angle = (float) Math.toDegrees(Math.atan2(-vel[1], vel[0]));
            System.out.printf("(%6.0f,%6.0f)%9s%11.1f%11.1f%11.2f   %5.1f°  [30fps %.2f 120fps %.2f]%n",
                    p[0], p[1], "", predicted, actual60, err, angle, e30, e120);

            if (err > 2f || e30 > 2f || e120 > 2f) fail++;
        }
        System.out.printf("最大误差：%.3f px%n", maxErr);

        // ---- 2. 射程可达性 ----
        System.out.println();
        System.out.println("【2】射程 / 弹道（塔在右侧 1187px 处）");
        System.out.printf("%-18s %-9s %-9s %-9s %-9s %-9s%n",
                "拉拽偏移", "射程px", "飞行s", "最高px", "达峰s", "落点距塔");
        System.out.println("------------------------------------------------------------");

        float maxRange = 0;
        for (float[] p : pulls) {
            float[] vel = new float[2];
            launchVelocity(p[0], p[1], vel);
            float bx = slingX + p[0], by = slingY + p[1];
            float[] fs = flightStats(bx, by, vel[0], vel[1], groundY, birdR);
            float landing = bx + fs[0];
            maxRange = Math.max(maxRange, fs[0]);
            float delta = landing - towerX;
            System.out.printf("(%6.0f,%6.0f)%9s%9.0f%9.2f%9.0f%9.2f%9.0f%n",
                    p[0], p[1], "", fs[0], fs[1], fs[2], fs[3], delta);
        }
        System.out.printf("最大射程：%.0f px（需要 ≥ %.0f px 才能打到塔）%n",
                maxRange, towerX - slingX);
        if (maxRange < towerX - slingX) {
            System.out.println("  !! 最大射程不足，塔打不到");
            fail++;
        }

        // ---- 2b. 扫掠整个拖拽空间，确认存在命中塔的解 ----
        float bestErr = 1e9f;
        float bestPx = 0, bestPy = 0;
        for (float px = -390; px <= -20; px += 5) {
            for (float py = 0; py <= 390; py += 5) {
                float[] vel = new float[2];
                launchVelocity(px, py, vel);
                if (vel[0] <= 0) continue;
                float bx = slingX + px, by = slingY + py;
                float land = predictLanding(bx, by, vel[0], vel[1], groundY, birdR);
                float e = Math.abs(land - towerX);
                if (e < bestErr) { bestErr = e; bestPx = px; bestPy = py; }
            }
        }
        System.out.printf("扫掠解：拖拽(%.0f,%.0f) → 落点误差 %.1f px%n", bestPx, bestPy, bestErr);
        if (bestErr > 30f) {
            System.out.println("  !! 拖拽空间内找不到能命中塔的解");
            fail++;
        }

        // ---- 3. 弹道合理性 ----
        System.out.println();
        System.out.println("【3】弹道合理性");
        for (float[] p : new float[][]{{-90, 30}, {-390, 280}, {-340, 100}}) {
            float[] vel = new float[2];
            launchVelocity(p[0], p[1], vel);
            float bx = slingX + p[0], by = slingY + p[1];
            float[] fs = flightStats(bx, by, vel[0], vel[1], groundY, birdR);
            System.out.printf("拉拽(%.0f,%.0f) → 射程 %.0fpx, 飞行 %.2fs, 最高 %.0fpx, 达峰 %.2fs%n",
                    p[0], p[1], fs[0], fs[1], fs[2], fs[3]);
            if (fs[1] < 0.3f || fs[1] > 12f) { System.out.println("  !! 飞行时间异常"); fail++; }
            if (fs[0] < 150f) { System.out.println("  !! 射程过短"); fail++; }
            // 方向必须向右
            if (vel[0] <= 0) { System.out.println("  !! 水平初速方向错误"); fail++; }
        }

        System.out.println();
        if (fail == 0) {
            System.out.println("RESULT: PASS — 预测线与真实飞行一致；射程可达塔；方向正确");
        } else {
            System.out.println("RESULT: FAIL — " + fail + " 项不符");
            System.exit(1);
        }
    }
}
