#!/bin/bash
# 哔小趣 · 捐赠校验服务 一键部署打包
#
# 用法：
#   bash 一键部署打包.sh                      # 自动用本机局域网 IP（手机同一 WiFi 即可用）
#   bash 一键部署打包.sh https://donate.xxx.com # 指定正式域名
#
# 作用：生成密钥 → 写入 App 内置配置 → 编译双 APK
# 终端用户无需任何配置，扫码捐赠即自动开通。
set -e
D="$(cd "$(dirname "$0")" && pwd)"

# ---------- 选地址：没给参数就用本机局域网 IP ----------
if [ -n "${1:-}" ]; then
  URL="${1%/}"
else
  LAN="$(ipconfig getifaddr en0 2>/dev/null || hostname -I 2>/dev/null | awk '{print $1}')"
  LAN="${LAN:-127.0.0.1}"
  URL="http://$LAN:8788"
fi

# 定位 App 源码（本脚本可放在 捐赠校验服务/ 或 源码包根目录）
for S in "$D/../.." "$D/.." "$D"; do
  [ -d "$S/app" ] && [ -d "$S/app_phone" ] && SRC="$(cd "$S" && pwd)" && break
done
[ -n "${SRC:-}" ] || { echo "找不到 app/ 源码目录"; exit 1; }

# ---------- 1. 密钥 ----------
mkdir -p "$D/keys"
if [ ! -f "$D/keys/donate_priv.pem" ]; then
  node -e "
const {generateKeyPairSync}=require('crypto'),fs=require('fs');
const {publicKey,privateKey}=generateKeyPairSync('rsa',{modulusLength:2048,
  publicKeyEncoding:{type:'spki',format:'der'},privateKeyEncoding:{type:'pkcs8',format:'pem'}});
fs.writeFileSync('$D/keys/donate_priv.pem',privateKey);
fs.writeFileSync('$D/keys/donate_pub.der',publicKey);"
  echo "✓ 已生成密钥 keys/donate_priv.pem（私钥勿外传）"
fi

# ---------- 2. 写入内置配置 ----------
PUB=$(node -e "console.log(require('fs').readFileSync('$D/keys/donate_pub.der').toString('base64'))")
for T in app app_phone; do
  F="$SRC/$T/src/com/bixiaoqu/app/DonateConfig.java"
  [ -f "$F" ] || continue
  node -e "
const fs=require('fs');const f='$F';let s=fs.readFileSync(f,'utf8');
s=s.replace(/(public static final String SERVER_URL = \")[^\"]*(\")/, '\$1$URL\$2');
s=s.replace(/(public static final String PUB_KEY_B64 = \")[^\"]*(\")/, '\$1$PUB\$2');
fs.writeFileSync(f,s);"
  echo "✓ $T 已写入内置配置"
done

# ---------- 3. 打包 ----------
for T in app app_phone; do
  [ -f "$SRC/$T/build.sh" ] || continue
  ( cd "$SRC/$T" && bash build.sh >/tmp/bxq_$T.log 2>&1 ) \
    && echo "✓ $T 构建完成" \
    || { echo "✗ $T 构建失败："; tail -20 /tmp/bxq_$T.log; exit 1; }
done

# ---------- 4. 取管理员令牌 ----------
TOK=""
[ -f "$D/data.json" ] && TOK="$(node -e "try{console.log(require('./$D/data.json').admin_token||'')}catch(e){console.log('')}" 2>/dev/null || true)"

cat <<EOF

==============================================
 ✅ 打包完成
==============================================
 App 内置服务地址 : $URL

 ① 启动服务（保持这个窗口开着）
    cd $D && ADMIN_TOKEN=你的强口令 node server.js

 ② 打开核销后台
    $URL/admin
$( [ -n "$TOK" ] && echo "    管理员令牌：$TOK" || echo "    管理员令牌：你启动服务时设置的那个" )

 ③ 用户付款后，二选一开通：
    · 用户点过「我已支付，申请开通」→ 后台订单列表点「核销」
    · 用户没点过 → 让他把「设备 ID」发你，粘贴到后台「手动开通」面板点「立即开通」

 ④ 分发 APK：用户无需任何配置，扫码捐赠即自动开通。

 提示：局域网地址仅同一 WiFi 下可用；正式发布请用域名 + HTTPS。
       私钥 keys/donate_priv.pem 勿外传、勿提交 Git。
==============================================
EOF
