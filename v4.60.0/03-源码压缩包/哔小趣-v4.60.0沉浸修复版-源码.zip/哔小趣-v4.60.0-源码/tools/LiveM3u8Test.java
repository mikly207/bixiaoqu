import com.bixiaoqu.app.LiveProxy;

/** 【v4.40 实验版】直播 m3u8 分片改写纯逻辑单测（不依赖 Android） */
public class LiveM3u8Test {
    static int pass = 0, fail = 0;
    static void ck(String name, boolean ok) {
        if (ok) { pass++; System.out.println("  PASS " + name); }
        else { fail++; System.out.println("  FAIL " + name); }
    }

    public static void main(String[] args) {
        System.out.println("=== LiveM3u8Test ===");
        String base = "https://d1--cn-gotcha104.bilivideo.com/live-bvc/976190/live_x.m3u8?expires=123";

        // 1) 相对路径解析为绝对 URL
        ck("相对分片解析", LiveProxy.absolute("seg-1.ts", base)
                .equals("https://d1--cn-gotcha104.bilivideo.com/live-bvc/976190/seg-1.ts"));
        ck("绝对路径保持", LiveProxy.absolute("https://cdn.bilivideo.com/a.ts", base)
                .equals("https://cdn.bilivideo.com/a.ts"));

        // 2) 完整播放列表改写：相对分片被包成本地代理 /seg
        String pl = "#EXTM3U\n#EXT-X-VERSION:3\n#EXT-X-TARGETDURATION:3\n"
                + "#EXTINF:3.0,\nlive_x-100.ts\n#EXTINF:3.0,\nlive_x-101.ts\n#EXT-X-ENDLIST\n";
        String rw = LiveProxy.rewrite(pl, base);
        ck("改写后分片数=2", rw.contains("/seg?u=") && count(rw, "/seg?u=") == 2);
        ck("改写保留 EXT-X-ENDLIST", rw.contains("#EXT-X-ENDLIST"));
        ck("改写保留头部", rw.startsWith("#EXTM3U"));
        // 分片 URL 作为 u= 参数被整体编码：CDN 主机名与 path 编码后应可见
        ck("分片指向原CDN", rw.contains("cn-gotcha104") && rw.contains("976190"));
        ck("分片URL已编码(https编码特征)", rw.contains("%3A%2F%2F"));

        // 3) 参数编解码往返
        ck("URL编码往返", LiveProxy.dec(LiveProxy.enc(base)).equals(base));

        System.out.println("结果: " + pass + " PASS / " + fail + " FAIL");
        if (fail > 0) System.exit(1);
    }

    static int count(String s, String sub) {
        int n = 0, i = 0;
        while ((i = s.indexOf(sub, i)) >= 0) { n++; i += sub.length(); }
        return n;
    }
}
