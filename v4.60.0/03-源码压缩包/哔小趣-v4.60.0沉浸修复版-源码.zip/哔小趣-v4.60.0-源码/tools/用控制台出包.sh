#!/bin/bash
# =============================================================================
# 用「作者控制台 App」显示的地址 + 公钥，给主 App 出包
# =============================================================================
# 用法：
#   bash 用控制台出包.sh <控制台显示的地址> <控制台显示的公钥>
#   例：bash 用控制台出包.sh http://192.168.1.5:8788 MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8A...
#
# 控制台 App 在作者手机上运行，把核验服务开在作者手机的内网地址上；
# 用户的主 App 要连的就是这个地址。
# =============================================================================
set -e
URL="${1:?请填控制台显示的连接地址，例如 http://192.168.1.5:8788}"
PUB="${2:?请填控制台显示的公钥（点公钥那行可复制）}"
URL="${URL%/}"

D="$(cd "$(dirname "$0")" && pwd)"
for S in "$D/../.." "$D/.." "$D"; do
  [ -d "$S/app" ] && [ -d "$S/app_phone" ] && SRC="$(cd "$S" && pwd)" && break
done
[ -n "${SRC:-}" ] || { echo "找不到 app/ 源码目录"; exit 1; }

echo "▸ 写入内置配置"
for T in app app_phone; do
  F="$SRC/$T/src/com/bixiaoqu/app/DonateConfig.java"
  [ -f "$F" ] || continue
  python3 - "$F" "$URL" "$PUB" <<'PYEOF'
import re, sys
path, url, pub = sys.argv[1], sys.argv[2], sys.argv[3]
s = open(path, encoding='utf-8').read()
s = re.sub(r'(public static final String SERVER_URL = ")[^"]*(")',
           lambda m: m.group(1) + url + m.group(2), s, count=1)
s = re.sub(r'(public static final String PUB_KEY_B64 = ")[^"]*(")',
           lambda m: m.group(1) + pub + m.group(2), s, count=1)
open(path, 'w', encoding='utf-8').write(s)
print("  ✓ " + path)
PYEOF
done

echo "▸ 编译打包"
for T in app app_phone; do
  [ -f "$SRC/$T/build.sh" ] || continue
  ( cd "$SRC/$T" && bash build.sh >/tmp/bxq_$T.log 2>&1 ) \
    && echo "  ✓ $T 构建完成" \
    || { echo "  ✗ $T 构建失败："; tail -20 /tmp/bxq_$T.log; exit 1; }
done

cat <<TXT

==============================================
 ✅ 主 App 出包完成
==============================================
 连接地址 : $URL

 接下来：
  1. 把 APK 发给用户（平板版 哔小趣.apk / 手机版 哔小趣-手机版.apk）
  2. 用户扫码付款 → 点「我已支付，申请开通」
  3. 你的控制台 App 会立刻响铃 + 弹窗提醒 → 点「立即开通」
  4. 用户约 3 秒后即可登录

 提示：地址必须是你手机在局域网里的地址，用户手机要和你连同一个 WiFi。
       正式发布建议部署到域名 + HTTPS（也可用 server.js）。
==============================================
TXT
