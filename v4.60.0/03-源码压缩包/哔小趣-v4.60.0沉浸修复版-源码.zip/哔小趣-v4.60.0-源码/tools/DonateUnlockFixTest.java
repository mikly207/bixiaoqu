/**
 * 【v4.47】回归测试：修复「没捐款点一下按钮就能登录」的前端自证漏洞。
 *
 * 背景：v4.46 为解决"用户要填配置"的问题引入了「宽松模式」——
 *      作者未部署服务端时，点「我已支付，申请开通」就直接写本地凭证放行。
 *      这等于把 v4.45 修掉的前端自证漏洞又打开了：
 *      用户没付一分钱，点一下按钮就能登录（截图里显示"支付宝捐赠 1 元"）。
 *
 * 本版已彻底删除该模式。本测试确保：
 *   1. 客户端不存在任何本地置成功的路径（宽松标记 / 迁移逻辑全部消失）；
 *   2. 只有服务端 RSA 签名凭证才能放行；
 *   3. 伪造签名、改缓存、自造凭证一律被拒；
 *   4. v4.46 遗留的宽松凭证全部失效。
 */
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.Signature;

import com.bixiaoqu.app.DonateApi;

public class DonateUnlockFixTest {

    static int passed = 0, failed = 0;

    static void check(String name, boolean ok) {
        if (ok) { passed++; System.out.println("  ✓ " + name); }
        else { failed++; System.out.println("  ✗ " + name); }
    }

    static String sign(PrivateKey priv, String payload) throws Exception {
        Signature s = Signature.getInstance("SHA256withRSA");
        s.initSign(priv);
        s.update(payload.getBytes("UTF-8"));
        return DonateApi.bytesToHex(s.sign());
    }

    public static void main(String[] args) throws Exception {
        System.out.println("=== DonateUnlockFixTest（v4.47 没付款点一下就能登录）===");

        long now = 1_700_000_000_000L;
        long exp = now + 3600_000L;
        String dev = "drealuser01";

        // ================= 1) 只有服务端签名才能放行 =================
        System.out.println("\n-- 1) 唯一合法路径：服务端签名 --");
        KeyPairGenerator g = KeyPairGenerator.getInstance("RSA");
        g.initialize(2048);
        KeyPair kp = g.generateKeyPair();
        String pubB64 = java.util.Base64.getEncoder().encodeToString(kp.getPublic().getEncoded());

        String receipt = DonateApi.canonical(dev, "10086", true, 1, "wechat", "ORD1", now, exp);
        String sig = sign(kp.getPrivate(), receipt);

        check("服务端签名凭证放行",
                DonateApi.isUnlocked(receipt, sig, exp, dev, pubB64, now));

        // ================= 2) 前端自证一律被拒 =================
        System.out.println("\n-- 2) 前端自证一律被拒 --");

        check("随便填的签名不放行（v4.46 的 \"relaxed\"）",
                !DonateApi.isUnlocked(receipt, "relaxed", exp, dev, pubB64, now));
        check("空签名不放行",
                !DonateApi.isUnlocked(receipt, "", exp, dev, pubB64, now));
        check("null 签名不放行",
                !DonateApi.isUnlocked(receipt, null, exp, dev, pubB64, now));

        String forgedPaid = receipt.replaceFirst("\\|1\\|1\\|", "|0|1|");
        check("篡改 paid 位不放行",
                !DonateApi.isUnlocked(forgedPaid, sig, exp, dev, pubB64, now));

        String forgedAmt = receipt.replaceFirst("\\|1\\|1\\|", "|1|99|");
        check("篡改金额不放行",
                !DonateApi.isUnlocked(forgedAmt, sig, exp, dev, pubB64, now));

        KeyPair other = g.generateKeyPair();
        String otherPub = java.util.Base64.getEncoder().encodeToString(other.getPublic().getEncoded());
        check("用非服务端公钥不放行",
                !DonateApi.isUnlocked(receipt, sig, exp, dev, otherPub, now));
        check("空公钥不放行",
                !DonateApi.isUnlocked(receipt, sig, exp, dev, "", now));

        // 自签凭证：攻击者自己造一对密钥并自签
        KeyPair fake = g.generateKeyPair();
        String fakeSig = sign(fake.getPrivate(), receipt);
        check("自签凭证（用服务端公钥验）不放行",
                !DonateApi.isUnlocked(receipt, fakeSig, exp, dev, pubB64, now));

        check("空凭证不放行",
                !DonateApi.isUnlocked("", sig, exp, dev, pubB64, now));
        check("null 凭证不放行",
                !DonateApi.isUnlocked(null, sig, exp, dev, pubB64, now));

        check("过期凭证不放行",
                !DonateApi.isUnlocked(receipt, sig, exp, dev, pubB64, exp + 1));
        check("expiresAt=0 不放行",
                !DonateApi.isUnlocked(receipt, sig, 0L, dev, pubB64, now));

        // ================= 3) v4.46 宽松凭证残留必须失效 =================
        System.out.println("\n-- 3) v4.46 遗留的宽松凭证已失效 --");
        String legacy1 = "v1|" + dev + "|relaxed|1|1|wechat||" + now + "|" + exp;
        check("v4.46 宽松凭证不再放行（需重新确认）",
                !DonateApi.isUnlocked(legacy1, "relaxed", exp, dev, pubB64, now));
        String legacy2 = "v1|relaxed|" + dev + "||1|1|wechat||" + now + "|" + exp;
        check("字段顺序错的老宽松凭证不再放行",
                !DonateApi.isUnlocked(legacy2, "relaxed", exp, dev, pubB64, now));

        // ================= 3.5) 服务端签的「未支付」凭证也必须被拒 =================
        System.out.println("\n-- 3.5) 服务端签的未支付凭证（paid=0）必须被拒 --");
        // 服务端对未支付订单同样会签发凭证（签名是真的、自洽性也成立），
        // 若判定不检查 paid 位，就会被误判成「已开通」—— 这正是本次要堵的漏洞。
        String unpaidReceipt = DonateApi.canonical(dev, "", false, 0, "", "", now, exp);
        String unpaidSig = sign(kp.getPrivate(), unpaidReceipt);
        check("服务端签的未支付凭证 → 不放行（paid=0）",
                !DonateApi.isUnlocked(unpaidReceipt, unpaidSig, exp, dev, pubB64, now));
        // 对照：同样字段但 paid=1 且同样由服务端签名 → 放行
        String paidReceipt = DonateApi.canonical(dev, "10086", true, 1, "wechat", "ORD1", now, exp);
        check("对照：服务端签的已支付凭证 → 放行（paid=1）",
                DonateApi.isUnlocked(paidReceipt, sign(kp.getPrivate(), paidReceipt), exp, dev, pubB64, now));

        // ================= 4) 客户端已无宽松模式代码 =================
        System.out.println("\n-- 4) 客户端已无任何本地置成功代码 --");
        boolean hasRelaxed = false;
        try {
            Class<?> c = DonateApi.class;
            for (java.lang.reflect.Method m : c.getDeclaredMethods()) {
                String n = m.getName().toLowerCase();
                if (n.contains("relax") || n.contains("migratelegacy")) hasRelaxed = true;
            }
            for (java.lang.reflect.Field f : c.getDeclaredFields()) {
                if (f.getName().toUpperCase().contains("RELAXED")) hasRelaxed = true;
            }
        } catch (Throwable ignore) { }
        check("DonateApi 已无宽松模式方法/字段", !hasRelaxed);

        System.out.println("\n通过 " + passed + " / 失败 " + failed);
        if (failed > 0) System.exit(1);
    }
}
