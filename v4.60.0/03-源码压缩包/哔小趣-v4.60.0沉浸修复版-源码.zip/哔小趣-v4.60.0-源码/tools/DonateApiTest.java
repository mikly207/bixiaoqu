/**
 * 【v4.45】捐赠状态服务端校验 —— 纯逻辑单测。
 *
 * 覆盖重点（对应「前端自证成功」恶性 bug 的修复）：
 *   1. 规范化 payload 与服务端 canonical() 规则一致；
 *   2. 服务端私钥签出的凭证能被公钥验签通过；
 *   3. **篡改任何字段（paid / amount / 设备 / 过期时间）后验签必失败**；
 *   4. 过期凭证一律判为不可信；
 *   5. 别的设备的凭证不能用于本机；
 *   6. hex 编解码可逆。
 *
 * 不依赖 Android 运行时（只用 java.security / java.util），可在 JVM 直接跑。
 */
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.Signature;
import java.security.spec.X509EncodedKeySpec;
import java.security.KeyFactory;
import java.util.Base64;

import com.bixiaoqu.app.DonateApi;

public class DonateApiTest {

    static int passed = 0, failed = 0;

    static void check(String name, boolean ok) {
        if (ok) { passed++; System.out.println("  ✓ " + name); }
        else { failed++; System.out.println("  ✗ " + name); }
    }

    static String sign(PrivateKey priv, String payload) throws Exception {
        Signature s = Signature.getInstance("SHA256withRSA");
        s.initSign(priv);
        s.update(payload.getBytes("UTF-8"));
        return DonateApi.bytesToHex(s.sign());
    }

    public static void main(String[] args) throws Exception {
        System.out.println("=== DonateApiTest（v4.45 服务端校验）===");

        // 生成测试密钥对（模拟服务端密钥）
        KeyPairGenerator g = KeyPairGenerator.getInstance("RSA");
        g.initialize(2048);
        KeyPair kp = g.generateKeyPair();
        String pubB64 = Base64.getEncoder().encodeToString(kp.getPublic().getEncoded());

        long now = 1_700_000_000_000L;
        String dev = "dtest123";
        String uid = "10086";

        // ---------- 1) canonical 格式 ----------
        String c = DonateApi.canonical(dev, uid, true, 10, "wechat", "ORD1", now, now + 3600_000L);
        check("canonical 字段顺序与分隔符正确",
                ("v1|dtest123|10086|1|10|wechat|ORD1|" + now + "|" + (now + 3600_000L)).equals(c));

        // 未支付时 paid 位为 0
        String c0 = DonateApi.canonical(dev, "", false, 0, "", "", now, now + 600_000L);
        check("canonical 未支付时 paid=0 且空字段留空",
                c0.startsWith("v1|dtest123||0|0|||"));

        // ---------- 2) 正常验签通过 ----------
        String sig = sign(kp.getPrivate(), c);
        DonateApi.Status st = new DonateApi.Status();
        st.deviceId = dev; st.uid = uid; st.paid = true; st.amount = 10;
        st.method = "wechat"; st.orderId = "ORD1";
        st.issuedAt = now; st.expiresAt = now + 3600_000L;
        st.receipt = c; st.sign = sig;
        check("服务端签名凭证验签通过",
                DonateApi.isTrusted(st, dev, pubB64, now));

        // ---------- 3) 篡改字段必失败 ----------
        // 3a. 把 paid 从 1 改成 0（假装没付）
        String tamperedPaid = c.replace("|1|10|", "|0|10|");
        check("篡改 paid 位后验签失败",
                !DonateApi.verify(tamperedPaid, sig, pubB64));

        // 3b. 把金额从 10 改成 1
        String tamperedAmt = c.replace("|1|10|", "|1|1|");
        check("篡改金额后验签失败",
                !DonateApi.verify(tamperedAmt, sig, pubB64));

        // 3c. 改设备 ID
        String tamperedDev = c.replace("dtest123", "dhacker9");
        check("篡改设备 ID 后验签失败",
                !DonateApi.verify(tamperedDev, sig, pubB64));

        // 3d. 延长有效期
        String tamperedExp = c.replace(String.valueOf(now + 3600_000L), String.valueOf(now + 999999_999L));
        check("篡改过期时间后验签失败",
                !DonateApi.verify(tamperedExp, sig, pubB64));

        // 3e. 换一把公钥（不是服务端签发的那把）
        KeyPair other = g.generateKeyPair();
        String otherPub = Base64.getEncoder().encodeToString(other.getPublic().getEncoded());
        check("用非服务端公钥验签失败",
                !DonateApi.verify(c, sig, otherPub));

        // 3f. 空签名 / 空公钥
        check("空签名不可信", !DonateApi.verify(c, "", pubB64));
        check("空公钥不可信", !DonateApi.verify(c, sig, ""));

        // ---------- 4) receipt 内容与字段不一致 → 不可信 ----------
        // 构造一个「签名正确但字段被换」的凭证：sign 对应 paid=1，但状态对象写 paid=false
        DonateApi.Status mismatch = new DonateApi.Status();
        mismatch.deviceId = dev; mismatch.uid = uid; mismatch.paid = false; mismatch.amount = 10;
        mismatch.method = "wechat"; mismatch.orderId = "ORD1";
        mismatch.issuedAt = now; mismatch.expiresAt = now + 3600_000L;
        mismatch.receipt = c; mismatch.sign = sig;
        check("receipt 与状态字段不一致时判为不可信",
                !DonateApi.isTrusted(mismatch, dev, pubB64, now));

        // ---------- 5) 过期凭证不可信 ----------
        check("已过期凭证判为不可信",
                !DonateApi.isTrusted(st, dev, pubB64, now + 3600_000L + 1));
        // expiresAt 缺失（0）→ 必须判为不可信，否则凭证可被无限期复用
        DonateApi.Status noExp = new DonateApi.Status();
        noExp.deviceId = dev; noExp.uid = uid; noExp.paid = true; noExp.amount = 10;
        noExp.method = "wechat"; noExp.orderId = "ORD1";
        noExp.issuedAt = now; noExp.expiresAt = 0L;
        String cNoExp = DonateApi.canonical(dev, uid, true, 10, "wechat", "ORD1", now, 0L);
        noExp.receipt = cNoExp;
        noExp.sign = sign(kp.getPrivate(), cNoExp);
        check("expiresAt=0（无有效期）的凭证判为不可信",
                !DonateApi.isTrusted(noExp, dev, pubB64, now));

        // ---------- 6) 设备归属校验 ----------
        check("他人设备的凭证不能用于本机",
                !DonateApi.isTrusted(st, "dother99", pubB64, now));

        // ---------- 7) hex 编解码可逆 ----------
        byte[] bytes = new byte[]{0x00, 0x01, (byte) 0x7f, (byte) 0x80, (byte) 0xff, 0x2a};
        String hex = DonateApi.bytesToHex(bytes);
        check("hex 编码长度正确", hex.length() == bytes.length * 2);
        check("hex 编解码可逆",
                java.util.Arrays.equals(bytes, DonateApi.hexToBytes(hex)));

        // ---------- 8) canonical 与服务端完全一致的对照向量 ----------
        // 服务端实现：['v1',device_id,uid,paid?'1':'0',amount,method,order_id,issued_at,expires_at].join('|')
        check("canonical 与服务端 join('|') 规则逐字段一致",
                c.equals("v1" + "|" + dev + "|" + uid + "|" + "1" + "|" + 10 + "|" + "wechat"
                        + "|" + "ORD1" + "|" + now + "|" + (now + 3600_000L)));

        System.out.println("通过 " + passed + " / 失败 " + failed);
        if (failed > 0) System.exit(1);
    }
}
