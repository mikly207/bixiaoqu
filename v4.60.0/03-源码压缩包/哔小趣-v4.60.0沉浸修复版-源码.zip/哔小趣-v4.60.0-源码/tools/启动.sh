#!/bin/bash
# =============================================================================
# 哔小趣 · 作者一键部署（部署 + 出包 + 启动，一条命令全搞定）
# =============================================================================
#
# 用法：
#   bash 启动.sh                     # 局域网模式：手机连同一 WiFi 即可用
#   bash 启动.sh https://donate.com  # 正式模式：填自己的域名（HTTPS）
#
# 做完这四件事：
#   1. 生成服务端 RSA 密钥对（私钥只留本机）
#   2. 把「服务地址 + 公钥」写进 App，编译出平板版/手机版 APK
#   3. 后台启动服务端（关掉本窗口即停止）
#   4. 打印核销后台地址与管理员令牌
#
# 之后你只需要做一件事：用户在 App 里付款 → 把设备 ID 发你 → 后台点「立即开通」
# =============================================================================
set -e
D="$(cd "$(dirname "$0")" && pwd)"

G=""; Y=""; R=""; B=""; N=""
if [ -t 1 ]; then G="\033[32m"; Y="\033[33m"; R="\033[31m"; B="\033[36m"; N="\033[0m"; fi
ok(){ printf "%sOK%s %s\n" "$G" "$N" "$1"; }
warn(){ printf "%s!%s %s\n" "$Y" "$N" "$1"; }
die(){ printf "%sX%s %s\n" "$R" "$N" "$1"; exit 1; }
step(){ printf "\n%s> %s%s\n" "$B" "$1" "$N"; }

command -v node >/dev/null 2>&1 || die "未找到 node，请先安装 Node.js 16+"

# 定位 server.js（脚本可能在 tools/、捐赠校验服务/ 或源码根目录）
SRVJS=""
for C in "$D/server.js" "$D/../捐赠校验服务/server.js" "$D/../server.js"; do
  [ -f "$C" ] && SRVJS="$C" && break
done
[ -n "$SRVJS" ] || die "找不到 server.js（请把本脚本放在 捐赠校验服务/ 目录）"
SRVDIR="$(cd "$(dirname "$SRVJS")" && pwd)"

# ---------- 选服务地址 ----------
if [ -n "${1:-}" ]; then
  URL="${1%/}"; MODE="正式模式"
else
  LAN="$(ipconfig getifaddr en0 2>/dev/null || hostname -I 2>/dev/null | awk '{print $1}')"
  LAN="${LAN:-127.0.0.1}"
  URL="http://$LAN:8788"; MODE="局域网模式（手机需连同一 WiFi）"
fi

# ---------- 定位源码 ----------
for S in "$D/../.." "$D/.." "$D"; do
  [ -d "$S/app" ] && [ -d "$S/app_phone" ] && SRC="$(cd "$S" && pwd)" && break
done
[ -n "${SRC:-}" ] || die "找不到 app/ 源码目录（请把本脚本放在 捐赠校验服务/ 目录下）"

echo "=============================================="
echo " 哔小趣 · 作者一键部署"
echo "=============================================="
echo " 服务地址 : $URL"
echo " 运行模式 : $MODE"

# ---------- 1. 密钥 ----------
step "1/4 生成服务端密钥"
KEYDIR="$SRVDIR/keys"
mkdir -p "$KEYDIR"
if [ -f "$KEYDIR/donate_priv.pem" ]; then
  ok "复用已有密钥 $KEYDIR/donate_priv.pem"
else
  node -e "
const {generateKeyPairSync}=require('crypto'),fs=require('fs');
const {publicKey,privateKey}=generateKeyPairSync('rsa',{modulusLength:2048,
  publicKeyEncoding:{type:'spki',format:'der'},privateKeyEncoding:{type:'pkcs8',format:'pem'}});
fs.writeFileSync('$KEYDIR/donate_priv.pem',privateKey);
fs.writeFileSync('$KEYDIR/donate_pub.der',publicKey);"
  ok "已生成 $KEYDIR/donate_priv.pem（私钥只在本机，勿外传）"
fi

# ---------- 2. 写入配置并出包 ----------
step "2/4 写入 App 内置配置并编译打包"
PUB=$(node -e "console.log(require('fs').readFileSync('$KEYDIR/donate_pub.der').toString('base64'))")
for T in app app_phone; do
  F="$SRC/$T/src/com/bixiaoqu/app/DonateConfig.java"
  [ -f "$F" ] || continue
  node -e "
const fs=require('fs');const f='$F';let s=fs.readFileSync(f,'utf8');
s=s.replace(/(public static final String SERVER_URL = \")[^\"]*(\")/, '\$1$URL\$2');
s=s.replace(/(public static final String PUB_KEY_B64 = \")[^\"]*(\")/, '\$1$PUB\$2');
fs.writeFileSync(f,s);"
  ok "$T 已写入服务地址与公钥"
done
for T in app app_phone; do
  [ -f "$SRC/$T/build.sh" ] || continue
  ( cd "$SRC/$T" && bash build.sh >/tmp/bxq_$T.log 2>&1 ) \
    && ok "$T 构建完成" \
    || { die "$T 构建失败，日志 /tmp/bxq_$T.log"; tail -15 /tmp/bxq_$T.log; }
done

# ---------- 3. 管理员令牌 ----------
step "3/4 准备管理员令牌"
if [ -f "$SRVDIR/data.json" ]; then
  TOK="$(node -e "try{console.log(require('$SRVDIR/data.json').admin_token||'')}catch(e){console.log('')}" 2>/dev/null || true)"
  [ -n "$TOK" ] && ok "沿用已有管理员令牌"
fi
if [ -z "${TOK:-}" ]; then
  TOK="$(node -e "console.log(require('crypto').randomBytes(12).toString('hex'))")"
  ok "已生成新的管理员令牌"
fi

# ---------- 4. 启动服务 ----------
step "4/4 启动服务端"
export ADMIN_TOKEN="$TOK"
export PAY_SECRET="${PAY_SECRET:-$TOK}"
echo "  正在启动…（关掉本窗口即停止服务）"
echo
node "$SRVJS" &
SRV=$!
sleep 2
kill -0 $SRV 2>/dev/null || die "服务端启动失败"

cat <<EOF

${C_G}==============================================${C_0}
${C_G} ✅ 全部就绪${C_0}
${C_G}==============================================${C_0}

 ${C_B}核销后台（手机浏览器打开这个）${C_0}
   ${C_B}$URL/admin${C_0}
   管理员令牌：${C_B}$TOK${C_0}

 ${C_B}APK 位置${C_0}
   平板版：$SRC/../哔小趣.apk
   手机版：$SRC/../哔小趣-手机版.apk

 ${C_B}你现在只需要做一件事${C_0}
   用户付款后 → 让他把「设备 ID」发你 → 在后台「手动开通」面板粘贴 → 点「立即开通」
   （用户获取方式：App → 点登录 → 点去捐赠解锁 → 点「我已支付，申请开通」→ 弹窗可复制设备 ID）

 ${C_B}另一种情况${C_0}
   用户点过申请 → 后台订单列表里会出现这笔订单 → 点「核销」即可

${C_Y}提示：局域网地址仅同一 WiFi 下可用；正式发布请用域名 + HTTPS。${C_0}
${C_Y}      私钥 keys/donate_priv.pem 勿外传、勿提交 Git。${C_0}

 按 Ctrl+C 停止服务

EOF

trap 'echo; echo "服务已停止"; kill $SRV 2>/dev/null; exit 0' INT TERM
wait $SRV
