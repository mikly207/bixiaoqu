import com.bixiaoqu.app.LiveProxy;

/** 【v4.41】直播代理健壮性纯逻辑单测（多线程/代际/线路，不依赖 Android） */
public class LiveProxyRobustnessTest {
    static int pass = 0, fail = 0;
    static void ck(String name, boolean ok) {
        if (ok) { pass++; System.out.println("  PASS " + name); }
        else { fail++; System.out.println("  FAIL " + name); }
    }

    public static void main(String[] args) throws Exception {
        System.out.println("=== LiveProxyRobustnessTest ===");

        // 1) 参数解析：u= 遇 & 正确截断，不被 u2/g 污染
        String req = "GET /seg?u=https%3A%2F%2Fcdn.bili.com%2Fa.ts&g=3 HTTP/1.1";
        String u = LiveProxy.param(req, "u=");
        ck("u=参数遇&截断不被g污染", u != null && u.equals("https://cdn.bili.com/a.ts"));
        String g = LiveProxy.param(req, "g=");
        ck("g=参数正确解析", "3".equals(g));

        // 2) 多线路收集：u + u2 + u3
        String req2 = "GET /m3u8?u=URL1&u2=URL2&u3=URL3&g=1 HTTP/1.1";
        String[] urls = LiveProxy.collectUrls(req2);
        ck("多线路收集=3条", urls.length == 3);
        ck("线路顺序正确", urls[0].equals("URL1") && urls[2].equals("URL3"));

        // 3) 分片改写带代际标记 &g=，旧代际地址可被区分
        String seg = LiveProxy.rewrite("#EXTM3U\n#EXTINF:3,\na.ts\n",
                "https://cdn.bili.com/live/x.m3u8");
        ck("改写分片带 /seg?u=", seg.contains("/seg?u="));
        ck("改写分片带 &g= 代际", seg.contains("&g="));

        // 4) 并发代际读取：newGeneration 后 generation 单调递增（模拟退出再进）
        LiveProxy p = LiveProxy.get();
        int g0 = p.generation();
        int g1 = p.newGeneration();
        int g2 = p.newGeneration();
        ck("代际单调递增", g1 > g0 && g2 > g1);

        // 5) 并发读写 generation 不抛异常（模拟多线程混用）
        final boolean[] err = {false};
        Thread[] ts = new Thread[8];
        for (int i = 0; i < ts.length; i++) {
            ts[i] = new Thread(new Runnable() {
                @Override public void run() {
                    for (int j = 0; j < 200; j++) {
                        try { p.generation(); LiveProxy.enc("x" + j); LiveProxy.dec("eA=="); }
                        catch (Throwable e) { err[0] = true; }
                    }
                }
            });
            ts[i].start();
        }
        for (Thread t : ts) t.join();
        ck("8线程并发1600次无异常", !err[0]);

        System.out.println("结果: " + pass + " PASS / " + fail + " FAIL");
        if (fail > 0) System.exit(1);
    }
}
