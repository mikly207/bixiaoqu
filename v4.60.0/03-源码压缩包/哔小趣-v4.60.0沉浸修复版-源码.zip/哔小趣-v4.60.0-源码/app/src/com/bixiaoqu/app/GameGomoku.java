package com.bixiaoqu.app;

import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.MotionEvent;

/**
 * 五子棋：15×15。
 * 【v4.55】三种模式：人机对战 / 本地双人同屏 / 局域网联机（无需服务器）。
 * 电脑走子用「先看自己能不能五连 → 再看对手有没有五连 → 否则启发式评分」三段式。
 */
public class GameGomoku extends GameView {

    static final int N = 15;
    static final int EMPTY = 0, BLACK = 1, WHITE = 2;
    static final int MODE_AI = 0, MODE_LOCAL = 1, MODE_NET = 2;

    // ---- 局域网桥接（由 GameLanActivity 写入，本类消费一次）----
    static GameNet pendingNet;
    static boolean pendingHost;
    static GameGomoku active;   // 当前实例，供网络回调驱动 UI

    int[][] b = new int[N][N];
    int cell, ox, oy;
    int turn = BLACK;
    boolean thinking;
    float thinkT;
    int lastR = -1, lastC = -1;
    String status = "";
    int win = 0;
    int mode = MODE_AI;
    int myColor = BLACK;         // 联机时本机执子颜色
    GameNet net;

    public GameGomoku(Context c) {
        super(c);
        gameId = "gomoku";
        gameTitle = "五子棋";
    }

    @Override protected boolean showHud() { return false; }

    @Override protected void reset() {
        // 消费桥接：有网络则进联机模式
        if (pendingNet != null) {
            net = pendingNet;
            myColor = pendingHost ? BLACK : WHITE;
            mode = MODE_NET;
            pendingNet = null;
        }
        active = this;
        for (int r = 0; r < N; r++) for (int c = 0; c < N; c++) b[r][c] = EMPTY;
        cell = Math.min(W - dp(30), H - dp(120)) / N;
        ox = (W - cell * N) / 2;
        oy = (H - cell * N) / 2 + dp(6);
        turn = BLACK;
        thinking = false;
        thinkT = 0;
        lastR = lastC = -1;
        win = 0;
        score = 0;
        if (mode == MODE_NET) {
            status = myColor == BLACK ? "你执黑 · 等待对手" : "你执白 · 等待对手落子";
        } else if (mode == MODE_LOCAL) {
            status = "双人同屏 · 黑方先手";
        } else {
            status = "你执黑先行 · 长按切换模式";
        }
    }

    /** 切换模式菜单（长按触发）。 */
    void showModeDialog() {
        String[] items = {"人机对战", "本地双人同屏", "局域网联机…"};
        new AlertDialog.Builder(getContext())
                .setTitle("选择对战模式")
                .setItems(items, new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface d, int which) {
                        if (which == 0) setMode(MODE_AI);
                        else if (which == 1) setMode(MODE_LOCAL);
                        else {
                            if (net != null) { net.close(); net = null; }
                            getContext().startActivity(new Intent(getContext(), GameLanActivity.class));
                        }
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    void setMode(int m) {
        if (net != null && m != MODE_NET) { net.close(); net = null; }
        mode = m;
        tipT = 2500;
        reset();
    }

    boolean in(int r, int c) { return r >= 0 && r < N && c >= 0 && c < N; }

    @Override protected void step(int dt) {
        if (thinking) {
            thinkT += dt;
            if (thinkT > 260) { thinking = false; aiMove(); }
        }
    }

    @Override protected void paint(Canvas c) {
        backdrop(c, 0xFF141A16, 0x222E7D6B);

        float l = ox - dp(6), t = oy - dp(6);
        float r = ox + cell * N + dp(6), btm = oy + cell * N + dp(6);
        box(c, l, t, r, btm, 0xFF3A3126, dp(12));
        frame(c, l, t, r, btm, 0x33FFFFFF, dp(12), dp(1));

        pLine.setStrokeWidth(dp(1));
        pLine.setColor(0x77D9C7A3);
        for (int i = 0; i < N; i++) {
            float p = ox + i * cell + cell / 2f;
            c.drawLine(p, oy + cell / 2f, p, oy + cell / 2f + (N - 1) * cell, pLine);
            c.drawLine(ox + cell / 2f, p, ox + cell / 2f + (N - 1) * cell, p, pLine);
        }
        int[][] stars = {{3,3},{3,11},{11,3},{11,11},{7,7}};
        pFill.setColor(0xAA3A3126);
        for (int[] s : stars) {
            c.drawCircle(ox + s[1] * cell + cell / 2f, oy + s[0] * cell + cell / 2f,
                    cell * 0.13f, pFill);
        }

        for (int rr = 0; rr < N; rr++) {
            for (int cc = 0; cc < N; cc++) {
                if (b[rr][cc] == EMPTY) continue;
                drawStone(c, ox + cc * cell + cell / 2f, oy + rr * cell + cell / 2f,
                        cell * 0.42f, b[rr][cc]);
            }
        }
        if (lastR >= 0) {
            float cx = ox + lastC * cell + cell / 2f;
            float cy = oy + lastR * cell + cell / 2f;
            glowCircle(c, cx, cy, cell * 0.1f, 0xFFFB7299, 0x66FB7299);
        }

        String modeName = mode == MODE_AI ? "人机" : (mode == MODE_LOCAL ? "双人同屏" : "联机");
        box(c, dp(10), dp(10), dp(10) + dp(72), dp(36), 0x77000000, dp(10));
        label(c, modeName, dp(18), dp(27), 12, 0xFFFB7299, Paint.Align.LEFT);

        label(c, status, W / 2f, oy + cell * N + dp(30), 12,
                thinking ? 0xFFFB7299 : 0xFFC8CDD6, Paint.Align.CENTER);
        tip(c, "长按切换模式（人机 / 双人 / 联机）");
    }

    private void drawStone(Canvas c, float cx, float cy, float rad, int who) {
        pFill.setStyle(Paint.Style.FILL);
        pFill.setColor(0x66000000);
        c.drawCircle(cx + dp(1.2f), cy + dp(1.6f), rad, pFill);
        if (who == BLACK) {
            pFill.setColor(0xFF1B1D22);
            c.drawCircle(cx, cy, rad, pFill);
            pFill.setColor(0x44FFFFFF);
            c.drawCircle(cx - rad * 0.3f, cy - rad * 0.35f, rad * 0.3f, pFill);
        } else {
            pFill.setColor(0xFFF2F4F8);
            c.drawCircle(cx, cy, rad, pFill);
            pFill.setColor(0x22000000);
            c.drawCircle(cx + rad * 0.25f, cy + rad * 0.3f, rad * 0.55f, pFill);
        }
    }

    @Override protected String overTitle() {
        if (mode == MODE_NET) {
            return win == myColor ? "你赢了！" : (win == EMPTY ? "平局" : "对手赢了");
        }
        if (mode == MODE_LOCAL) {
            return win == BLACK ? "黑方胜！" : (win == WHITE ? "白方胜！" : "平局");
        }
        return win == BLACK ? "你赢了！" : (win == WHITE ? "电脑赢了" : "平局");
    }

    long downT;
    float downX, downY;
    @Override protected boolean touch(MotionEvent e) {
        int a = e.getActionMasked();
        if (a == MotionEvent.ACTION_DOWN) {
            downT = System.currentTimeMillis();
            downX = e.getX(); downY = e.getY();
            return true;
        }
        if (a == MotionEvent.ACTION_UP) {
            if (System.currentTimeMillis() - downT > 650
                    && Math.abs(e.getX() - downX) < dp(12)
                    && Math.abs(e.getY() - downY) < dp(12)) {
                showModeDialog();
                return true;
            }
            return handlePlace(e.getX(), e.getY());
        }
        return true;
    }

    boolean handlePlace(float x, float y) {
        if (over) return true;
        if (mode == MODE_AI && (thinking || turn != BLACK)) return true;
        if (mode == MODE_NET && turn != myColor) return true;

        int cc = (int) ((x - ox - cell / 2f) / cell + 0.5f);
        int rr = (int) ((y - oy - cell / 2f) / cell + 0.5f);
        if (!in(rr, cc) || b[rr][cc] != EMPTY) return true;

        int who = (mode == MODE_NET) ? myColor : turn;
        place(rr, cc, who);
        if (win != 0 || over) return true;

        if (mode == MODE_NET && net != null) {
            net.send("MOVE," + rr + "," + cc);
            status = "等待对手落子…";
        } else if (mode == MODE_AI) {
            turn = WHITE;
            thinking = true;
            thinkT = 0;
            status = "电脑思考中…";
        } else {
            turn = (turn == BLACK) ? WHITE : BLACK;
            status = (turn == BLACK) ? "黑方落子" : "白方落子";
        }
        return true;
    }

    void place(int r, int c, int who) {
        b[r][c] = who;
        lastR = r; lastC = c;
        if (checkWin(r, c, who)) {
            win = who;
            score = (mode == MODE_AI) ? (who == BLACK ? 100 : 0) : 100;
            status = "五连！";
            gameOver();
            if (mode == MODE_NET && net != null) net.send("WIN," + who);
            return;
        }
        boolean full = true;
        for (int rr = 0; rr < N && full; rr++)
            for (int cc = 0; cc < N; cc++) if (b[rr][cc] == EMPTY) { full = false; break; }
        if (full) {
            win = 0;
            status = "棋盘满了，平局";
            gameOver();
            if (mode == MODE_NET && net != null) net.send("DRAW");
        }
    }

    boolean checkWin(int r, int c, int who) {
        int[][] dirs = {{0,1},{1,0},{1,1},{1,-1}};
        for (int[] d : dirs) {
            int cnt = 1;
            for (int s = 1; s <= 4; s++) {
                int rr = r + d[0]*s, cc = c + d[1]*s;
                if (in(rr,cc) && b[rr][cc] == who) cnt++; else break;
            }
            for (int s = 1; s <= 4; s++) {
                int rr = r - d[0]*s, cc = c - d[1]*s;
                if (in(rr,cc) && b[rr][cc] == who) cnt++; else break;
            }
            if (cnt >= 5) return true;
        }
        return false;
    }

    // ---- 网络回调（静态桥接，主线程调用）----
    static void netMessage(String line) {
        GameGomoku g = active;
        if (g == null || g.mode != MODE_NET) return;
        String[] p = line.split(",");
        try {
            if (p.length == 3 && "MOVE".equals(p[0])) {
                int r = Integer.parseInt(p[1]), c = Integer.parseInt(p[2]);
                if (in(g, r, c) && g.b[r][c] == EMPTY) {
                    g.place(r, c, g.myColor == BLACK ? WHITE : BLACK);
                    if (g.win == 0 && !g.over) {
                        g.turn = g.myColor;
                        g.status = "轮到你落子";
                    }
                }
            } else if (p.length == 2 && "WIN".equals(p[0])) {
                g.win = Integer.parseInt(p[1]);
                g.status = "对手五连";
                g.gameOver();
            } else if ("DRAW".equals(p[0])) {
                g.win = 0; g.status = "平局"; g.gameOver();
            } else if ("RESET".equals(p[0])) {
                g.reset();
            }
        } catch (Throwable ignore) {}
    }
    static boolean in(GameGomoku g, int r, int c) { return r >= 0 && r < N && c >= 0 && c < N; }
    static void netConnected(boolean host) {
        GameGomoku g = active;
        if (g != null) { g.status = host ? "对手已连接，你执黑先行" : "已连接，等待黑方落子"; }
    }
    static void netDisconnected() {
        GameGomoku g = active;
        if (g != null) { g.status = "对手已断开，可长按切换模式"; }
    }

    // ------------------------------------------------------------ 电脑
    void aiMove() {
        if (over) return;
        int[] p = findPoint(WHITE);
        if (p == null) p = findPoint(BLACK);
        if (p == null) {
            int bestV = -1;
            for (int r = 0; r < N; r++) {
                for (int c = 0; c < N; c++) {
                    if (b[r][c] != EMPTY) continue;
                    if (!nearStone(r, c, 2)) continue;
                    int v = (int) (scoreAt(r, c, WHITE) * 1.15f + scoreAt(r, c, BLACK));
                    if (v > bestV) { bestV = v; p = new int[]{r, c}; }
                }
            }
        }
        if (p == null) {
            int mid = N / 2;
            for (int d = 0; d < N; d++) {
                int r = mid + (d % 2 == 0 ? d / 2 : -d / 2);
                if (in(r, mid) && b[r][mid] == EMPTY) { p = new int[]{r, mid}; break; }
            }
        }
        if (p == null) { p = new int[]{0, 0}; }
        place(p[0], p[1], WHITE);
        if (win == 0 && !over) {
            turn = BLACK;
            status = "轮到你落子";
        }
    }

    int[] findPoint(int who) {
        for (int r = 0; r < N; r++) {
            for (int c = 0; c < N; c++) {
                if (b[r][c] != EMPTY) continue;
                b[r][c] = who;
                boolean w = checkWin(r, c, who);
                b[r][c] = EMPTY;
                if (w) return new int[]{r, c};
            }
        }
        return null;
    }

    boolean nearStone(int r, int c, int rad) {
        for (int dr = -rad; dr <= rad; dr++) {
            for (int dc = -rad; dc <= rad; dc++) {
                int rr = r + dr, cc = c + dc;
                if (in(rr, cc) && b[rr][cc] != EMPTY) return true;
            }
        }
        return false;
    }

    int scoreAt(int r, int c, int who) {
        int[][] dirs = {{0,1},{1,0},{1,1},{1,-1}};
        int total = 0;
        for (int[] d : dirs) total += lineScore(r, c, d[0], d[1], who);
        return total;
    }

    int lineScore(int r, int c, int dr, int dc, int who) {
        int cnt = 1, open = 0;
        for (int s = -1; s <= 1; s += 2) {
            int rr = r + dr * s, cc = c + dc * s;
            while (in(rr, cc) && b[rr][cc] == who) {
                cnt++;
                rr += dr * s;
                cc += dc * s;
            }
            if (in(rr, cc) && b[rr][cc] == EMPTY) open++;
        }
        if (cnt >= 5) return 1000000;
        if (cnt == 4) return open == 2 ? 100000 : (open == 1 ? 12000 : 0);
        if (cnt == 3) return open == 2 ? 8000 : (open == 1 ? 900 : 0);
        if (cnt == 2) return open == 2 ? 600 : (open == 1 ? 120 : 0);
        if (cnt == 1) return open == 2 ? 40 : 8;
        return 0;
    }
}
