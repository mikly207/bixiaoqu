package com.bixiaoqu.app;

/**
 * 【v4.59】弱网质量档位 —— 全局统一的"当前网络好不好"决策中心。
 *
 * 背景：此前每个模块各自拍脑袋定超时（封面 4s/8s、直播 API 15s/30s、
 * 取流 6s/9s），互不感知。弱网下要么全部一起超时把线程堵死，
 * 要么每张失败封面都被反复重试 —— 表现为"封面转不出来、直播窗口半天没内容"。
 *
 * 现在把网络档位收敛成一处，所有模块读同一份判定：
 *   · 探测：进程内记录最近若干次封面/API 请求的成功率与耗时；
 *   · 决策：连续失败或高延迟 → 降档（短超时、小图、少并发、用缓存）；
 *   · 恢复：连续成功 → 升档（恢复正常超时与清晰度）。
 *
 * 纯 Java 逻辑，可在 JVM 单测（heartbeat/decide 不依赖 Android）。
 */
public final class NetQuality {

    /** 档位：0 好网 → 3 弱网 */
    public static final int GOOD = 0;
    public static final int FAIR = 1;
    public static final int POOR = 2;
    public static final int WEAK = 3;

    /** 滑动窗口大小 */
    static final int WINDOW = 12;

    /** 最近 WINDOW 次请求：耗时(ms) 与 是否超时/失败 */
    private static final long[] COST = new long[WINDOW];
    private static final boolean[] FAILED = new boolean[WINDOW];
    private static int cursor = 0;
    private static int filled = 0;

    /** 当前档位（单调平滑，避免一次抖动就剧烈降档） */
    private static volatile int level = GOOD;

    /** 网络类型：0 未知/有线，1 WiFi，2 移动数据 */
    private static volatile int netType = 0;
    public static void setNetType(int t) { netType = t; }
    public static int netType() { return netType; }

    private NetQuality() { }

    /**
     * 档位变化回调（由 Android 桥接层注册）：档位降/升时同步并发闸门。
     * 放在纯 Java 类里用一个可注入的钩子，避免本类依赖 Android，保持可单测。
     */
    private static volatile Runnable onLevelChanged;
    public static void setOnLevelChanged(Runnable r) { onLevelChanged = r; }

    /** 心跳里档位若发生变化，通知Android侧同步闸门 */
    private static void notifyChanged(int before, int after) {
        if (before != after && onLevelChanged != null) {
            try { onLevelChanged.run(); } catch (Throwable ignore) { }
        }
    }

    /**
     * 记一次请求结果。成功耗时与失败都进窗口。
     * @param ok  是否成功
     * @param ms  耗时（毫秒），失败时也填实际等待时间
     */
    public static synchronized void heartbeat(boolean ok, long ms) {
        if (ms < 0) ms = 0;
        COST[cursor] = ms;
        FAILED[cursor] = !ok;
        cursor = (cursor + 1) % WINDOW;
        if (filled < WINDOW) filled++;
        int before = level;
        level = decide(level, summarizeCost(), failPercent(), netType);
        notifyChanged(before, level);
    }

    /** 纯逻辑：由"上一档 + 平均耗时 + 失败率 + 网络类型"推出新档（带迟滞）。 */
    public static int decide(int prev, long avgMs, int failPct, int type) {
        int target;
        // 失败率优先：超过一半失败直接判弱网；四分之一失败降两档
        if (failPct >= 50) target = WEAK;
        else if (failPct >= 25) target = POOR;
        else if (avgMs >= 2500) target = POOR;
        else if (avgMs >= 1200) target = FAIR;
        else target = GOOD;

        // 移动网络天然比 WiFi 脆弱：至少 FAIR，且弱判定时再降一档
        if (type == 2) {
            if (target == GOOD) target = FAIR;
            else if (target == FAIR) target = POOR;
        }
        // 迟滞：升档要更谨慎（一次成功不能立刻满血），降档立即生效
        if (target < prev) {
            // 只在样本足够且明显变好时升一级，防止来回抖动
            if (failPct <= 10 && avgMs < 900) target = prev - 1;
            else target = prev;
        }
        if (target < GOOD) target = GOOD;
        if (target > WEAK) target = WEAK;
        return target;
    }

    /** 窗口内平均耗时 */
    static synchronized long summarizeCost() {
        if (filled == 0) return 0;
        long sum = 0;
        for (int i = 0; i < filled; i++) sum += COST[i];
        return sum / filled;
    }

    /** 窗口内失败百分比 0~100 */
    static synchronized int failPercent() {
        if (filled == 0) return 0;
        int bad = 0;
        for (int i = 0; i < filled; i++) if (FAILED[i]) bad++;
        return bad * 100 / filled;
    }

    public static int level() { return level; }

    public static boolean isWeak() { return level >= POOR; }

    /** 重置（网络切换时调用，避免用旧网络的统计误导新网络） */
    public static synchronized void reset(int newType) {
        cursor = 0; filled = 0;
        for (int i = 0; i < WINDOW; i++) { COST[i] = 0; FAILED[i] = false; }
        netType = newType;
        level = (newType == 2) ? FAIR : GOOD;
    }

    // ------------------------------------------------------------ 各模块读取的"策略值"

    /** 封面下载：连接超时（弱网短，快速放弃换下一张） */
    public static int imageConnectTimeout() {
        switch (level) {
            case WEAK:  return 1800;
            case POOR:  return 2500;
            case FAIR:  return 3200;
            default:    return 4000;
        }
    }

    /** 封面下载：读取超时（弱网短，避免单张图堵住整条队列） */
    public static int imageReadTimeout() {
        switch (level) {
            case WEAK:  return 3500;
            case POOR:  return 5000;
            case FAIR:  return 6500;
            default:    return 8000;
        }
    }

    /** 直播 / API 请求超时（弱网快速失败，界面先出缓存再后台刷新） */
    public static int apiConnectTimeout() {
        switch (level) {
            case WEAK:  return 4000;
            case POOR:  return 6000;
            default:    return 10000;
        }
    }

    public static int apiReadTimeout() {
        switch (level) {
            case WEAK:  return 6000;
            case POOR:  return 9000;
            default:    return 15000;
        }
    }

    /** 封面请求尺寸系数：弱网用小图（>=1 表示按原尺寸，<1 缩小） */
    public static float imageScale() {
        switch (level) {
            case WEAK:  return 0.55f;
            case POOR:  return 0.70f;
            case FAIR:  return 0.85f;
            default:    return 1f;
        }
    }

    /** 弱网下封面并发上限（避免十几条连接一起抢带宽） */
    public static int imageConcurrency() {
        switch (level) {
            case WEAK:  return 3;
            case POOR:  return 4;
            case FAIR:  return 6;
            default:    return 8;
        }
    }

    /**
     * 失败 URL 的负缓存时长（毫秒）：弱网下失败后短时间内不再重复请求同一张图，
     * 防止用户来回滑动时反复打到同一张必失败的封面、堵死线程池。
     */
    public static long failedUrlTtl() {
        switch (level) {
            case WEAK:  return 30000L;
            case POOR:  return 15000L;
            default:    return 5000L;
        }
    }
}
