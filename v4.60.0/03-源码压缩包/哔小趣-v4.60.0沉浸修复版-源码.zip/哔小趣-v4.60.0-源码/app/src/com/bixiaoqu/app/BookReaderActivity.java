package com.bixiaoqu.app;

import android.app.Activity;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

/**
 * 【v4.57】四大名著内置阅读器（完整全文版 · 翻页逻辑全面重做）。
 *
 * ============================ 上一版的问题 ============================
 *   1. **整章一次性 setText**：一章正文 6000+ 字全部塞进一个 TextView，
 *      长章节（如水浒某些回 4 万字）会明显卡顿；
 *   2. **点击翻章与滚动阅读打架**：ScrollView 上挂了 OnTouchListener，
 *      只要抬手时 x 在左右 28%/72% 就翻章 —— 玩家想滑动看正文，
 *      手一抬就跳到下一章，非常恼人；
 *   3. **翻章用 smoothScrollTo(0,0)**：从长章节底部平滑滚回顶部要好几秒，
 *      语义也完全错了（翻章应该是瞬移到章首）；
 *   4. **字号/护眼/阅读位置不持久化**：每次打开都回到默认值；
 *   5. **没有进度反馈**：不知道读到哪、这一章多长、还剩多少；
 *   6. **目录弹窗一次建 120+ 个 TextView**，低端机打开会顿；
 *   7. 章节加载在子线程，但 `BookStore.chapter()` 会把整本书解压进内存，
 *      翻章时若缓存被系统回收会长时间白屏。
 *
 * ============================ 这一版改了什么 ============================
 *
 * 【1. 分段渲染】
 *   正文按段落切成块，分批 append 到同一个 SpannableStringBuilder，
 *   每批之间让出一帧 —— 长章节不再卡，界面保持可响应。
 *
 * 【2. 滚动与翻章彻底分离】
 *   · 滚动阅读：纯 ScrollView，不做任何翻章拦截；
 *   · 翻章：只在**底部工具条**或**顶部章节条**点按，或
 *     「滑动到顶再继续下拉 / 滑到底再继续上滑」时翻页（带阈值和防抖）；
 *   · 删掉了原来那个「点击左右 28% 就翻章」的 OnTouchListener。
 *
 * 【3. 章节切换正确】
 *   翻章 = 瞬时 scrollTo(0,0)，不再用 smoothScrollTo。
 *
 * 【4. 全量设置持久化**
 *   字号、护眼模式、每本书的**章节号 + 章内滚动位置**全部存 SharedPreferences，
 *   下次打开原样恢复。
 *
 * 【5. 进度反馈**
 *   · 顶部显示「当前回 / 总回数」+ 细进度条；
 *   · 底部显示本章字数与全书完成度百分比。
 *
 * 【6. 目录性能优化**
 *   目录用 ListView（复用条目）而不是一次建 120+ 个 View，
 *   并自动滚动到当前章。
 *
 * 【7. 预取下一章**
 *   读完本章时后台预取下一章，翻章不再等待。
 */
public class BookReaderActivity extends Activity {

    private String bookKey;
    private String bookName;
    private BookStore.Book book;

    private LinearLayout root;
    private TextView tvTitle;
    private TextView tvChapter;
    private View progressBar;
    private ScrollView scroll;
    private TextView tvBody;
    private TextView tvFooter;
    private LinearLayout bottomBar;

    private int curChapter = 1;
    private int fontSp = 17;
    private int eyeMode = 0;   // 0=白 1=米黄 2=绿

    private final Handler ui = new Handler(Looper.getMainLooper());
    private static final String PREF = "bxq_book_read";

    /** 滑动翻章的防抖：同一章内不重复触发 */
    private long lastTurnAt = 0;
    private static final long TURN_COOLDOWN = 400;

    /** 后台预取的下一章 */
    private Thread prefetchThread;

    private static final int[] EYE_BG = {0xFFF6F7F9, 0xFFF5EEDC, 0xFFDDE8D6};
    private static final int[] EYE_FG = {0xFF1F2328, 0xFF3A3222, 0xFF243019};

    // ---------------------------------------------------------------- 生命周期

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        bookKey = getIntent().getStringExtra("key");
        if (bookKey == null || bookKey.isEmpty()) bookKey = "xiyouji";
        book = BookStore.load(this, bookKey);
        if (book == null) { finish(); return; }
        bookName = nameOf(bookKey);

        // 恢复上次的字号与护眼模式（全局共享）
        android.content.SharedPreferences sp = getSharedPreferences(PREF, MODE_PRIVATE);
        fontSp = sp.getInt("font", 17);
        if (fontSp < 14) fontSp = 14;
        if (fontSp > 26) fontSp = 26;
        eyeMode = sp.getInt("eye", 0);
        if (eyeMode < 0 || eyeMode > 2) eyeMode = 0;

        buildUi();

        // 恢复阅读位置（章节 + 章内滚动偏移）
        int lastCh = sp.getInt(bookKey + "_ch", 1);
        curChapter = (lastCh >= 1 && lastCh <= book.chapterCount) ? lastCh : 1;
        final int restoreY = sp.getInt(bookKey + "_y", 0);

        // 【v4.58】后台预热整本书（gzip 解压），首次翻章不必等待
        new Thread(new Runnable() {
            @Override public void run() { BookStore.warmup(getApplicationContext(), bookKey); }
        }).start();

        loadChapter(curChapter, restoreY);
    }

    @Override protected void onPause() {
        super.onPause();
        saveProgress();
        if (prefetchThread != null) {
            prefetchThread.interrupt();
            prefetchThread = null;
        }
    }

    /** 退出/切后台时把当前章节与滚动位置写回 */
    private void saveProgress() {
        try {
            android.content.SharedPreferences sp = getSharedPreferences(PREF, MODE_PRIVATE);
            int y = 0;
            try { y = scroll == null ? 0 : scroll.getScrollY(); } catch (Throwable ignore) { }
            sp.edit()
                    .putInt("font", fontSp)
                    .putInt("eye", eyeMode)
                    .putInt(bookKey + "_ch", curChapter)
                    .putInt(bookKey + "_y", y)
                    .apply();
        } catch (Throwable ignore) { }
    }

    private String nameOf(String key) {
        if ("xiyouji".equals(key)) return "西游记";
        if ("sanguoyanyi".equals(key)) return "三国演义";
        if ("hongloumeng".equals(key)) return "红楼梦";
        if ("shuihuzhuan".equals(key)) return "水浒传";
        return "名著";
    }

    // ---------------------------------------------------------------- UI

    private void buildUi() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(EYE_BG[eyeMode]);
        root.setLayoutParams(new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // ---- 顶栏 ----
        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(12), dp(10), dp(12), dp(8));
        top.setBackgroundColor(0x22000000);

        tvTitle = new TextView(this);
        tvTitle.setText(bookName);
        tvTitle.setTextColor(EYE_FG[eyeMode]);
        tvTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17);
        tvTitle.setTypeface(null, Typeface.BOLD);
        top.addView(tvTitle, new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        top.addView(btn("目录", new View.OnClickListener() {
            @Override public void onClick(View v) { showCatalog(); }
        }));
        top.addView(btn("A", new View.OnClickListener() {
            @Override public void onClick(View v) {
                // 改字号会让内容高度突变，短暂屏蔽自动翻章，避免误跳
                ignoreScroll = true;
                fontSp = fontSp >= 26 ? 14 : fontSp + 2;
                tvBody.setTextSize(TypedValue.COMPLEX_UNIT_SP, fontSp);
                ui.post(new Runnable() {
                    @Override public void run() {
                        ui.post(new Runnable() {
                            @Override public void run() { ignoreScroll = false; }
                        });
                    }
                });
                saveProgress();
            }
        }));
        top.addView(btn("护眼", new View.OnClickListener() {
            @Override public void onClick(View v) {
                eyeMode = (eyeMode + 1) % 3;
                applyEye();
                saveProgress();
            }
        }));
        root.addView(top);

        // ---- 章节标题 + 进度条 ----
        LinearLayout chapRow = new LinearLayout(this);
        chapRow.setOrientation(LinearLayout.VERTICAL);

        tvChapter = new TextView(this);
        tvChapter.setTextColor(EYE_FG[eyeMode]);
        tvChapter.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        tvChapter.setPadding(dp(16), dp(4), dp(16), dp(3));
        chapRow.addView(tvChapter);

        progressBar = new View(this);
        LinearLayout.LayoutParams pbp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(2));
        pbp.leftMargin = dp(16);
        pbp.rightMargin = dp(16);
        chapRow.addView(progressBar, pbp);
        root.addView(chapRow);

        // ---- 正文 ----
        // 用自定义 ScrollView 监听滚动（onScrollChanged 在所有 API 都有；
        // setOnScrollChangeListener 是 API 23 才有的，低版本会崩）
        scroll = new ReaderScrollView(this);
        scroll.setFillViewport(true);
        scroll.setVerticalScrollBarEnabled(false);
        tvBody = new TextView(this);
        tvBody.setTextColor(EYE_FG[eyeMode]);
        tvBody.setTextSize(TypedValue.COMPLEX_UNIT_SP, fontSp);
        tvBody.setLineSpacing(dp(6), 1.28f);
        tvBody.setPadding(dp(16), dp(8), dp(16), dp(30));
        scroll.addView(tvBody, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(scroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        // 滑到底时自动进入下一章（带阈值与冷却，不干扰正常阅读）
        ((ReaderScrollView) scroll).setOnScrollListener(new ReaderScrollView.OnScroll() {
            @Override public void onScrolled(int sy) {
                handleScroll(sy);
            }
        });

        // ---- 底部信息条 ----
        tvFooter = new TextView(this);
        tvFooter.setTextColor(EYE_FG[eyeMode]);
        tvFooter.setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f);
        tvFooter.setPadding(dp(16), dp(2), dp(16), dp(2));
        root.addView(tvFooter);

        // ---- 底栏 ----
        bottomBar = new LinearLayout(this);
        bottomBar.setOrientation(LinearLayout.HORIZONTAL);
        bottomBar.setGravity(Gravity.CENTER);
        bottomBar.setPadding(dp(10), dp(6), dp(10), dp(10));
        bottomBar.setBackgroundColor(0x22000000);
        bottomBar.addView(btn("上一章", new View.OnClickListener() {
            @Override public void onClick(View v) { prevChapter(); }
        }));
        bottomBar.addView(btn("章节目录", new View.OnClickListener() {
            @Override public void onClick(View v) { showCatalog(); }
        }));
        bottomBar.addView(btn("下一章", new View.OnClickListener() {
            @Override public void onClick(View v) { nextChapter(); }
        }));
        root.addView(bottomBar);

        setContentView(root);
    }

    private TextView btn(String text, View.OnClickListener l) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(EYE_FG[eyeMode]);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(14), dp(7), dp(14), dp(7));
        t.setBackgroundColor(0x33FFFFFF);
        t.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(dp(3), 0, dp(3), 0);
        t.setLayoutParams(lp);
        return t;
    }

    private void applyEye() {
        root.setBackgroundColor(EYE_BG[eyeMode]);
        tvTitle.setTextColor(EYE_FG[eyeMode]);
        tvChapter.setTextColor(EYE_FG[eyeMode]);
        tvBody.setTextColor(EYE_FG[eyeMode]);
        tvFooter.setTextColor(EYE_FG[eyeMode]);
    }

    // ---------------------------------------------------------------- 章节加载

    /** 单调递增的请求令牌：只有最新一次加载的回调可以落地 */
    private int loadToken = 0;
    /** 换章/改字号期间内容高度会突变，暂时屏蔽"滑到底自动翻章" */
    private boolean ignoreScroll;

    /**
     * 加载一章（v4.58 重写）。
     *
     * 【修复 v4.57 的致命竞态】旧版只在异步回调里写 curChapter，
     * 而回调又用 `curChapter != target` 判过期 —— 导致每次切章
     * 都被自己的回调丢弃，正文永远停在"正在载入"，标题与正文脱节。
     * 现在：请求发出时立即同步状态与标题，用独立 token 判过期。
     *
     * 【修复加载缓慢】旧版分段渲染每批 sleep(12ms)，四万字要 300ms+，
     * 还多起一个线程。现在一次性 setText —— 实测比分段更快且无竞态。
     */
    private void loadChapter(int no, int restoreY) {
        final int target = no;
        final int token = ++loadToken;
        final int y = restoreY;

        // 立即同步状态与标题，不再等异步回调
        curChapter = target;
        ignoreScroll = true;
        tvChapter.setText("第 " + target + " 回　（载入中…）");
        tvBody.setText("正在载入第 " + target + " 回…");
        updateChrome(target, 0, 0);
        try { scroll.scrollTo(0, 0); } catch (Throwable ignore) { }

        new Thread(new Runnable() {
            @Override public void run() {
                final BookStore.Chapter ch = BookStore.chapter(
                        getApplicationContext(), bookKey, target);
                ui.post(new Runnable() {
                    @Override public void run() {
                        if (token != loadToken) return;   // 用户已翻到别章，丢弃旧结果
                        if (ch == null) {
                            tvBody.setText("这一回加载失败，请返回重试。");
                            return;
                        }
                        curChapter = target;
                        tvChapter.setText(ch.title + "　（" + target + "/"
                                + book.chapterCount + "）");
                        tvBody.setText(ch.body);
                        updateChrome(target, ch.body.length(), ch.body.length());
                        if (y > 0) {
                            tvBody.post(new Runnable() {
                                @Override public void run() {
                                    if (token == loadToken) {
                                        try { scroll.scrollTo(0, y); }
                                        catch (Throwable ignore) { }
                                    }
                                }
                            });
                        }
                        // 等布局稳定后再恢复滚动翻章检测
                        ui.post(new Runnable() {
                            @Override public void run() {
                                ui.post(new Runnable() {
                                    @Override public void run() { ignoreScroll = false; }
                                });
                            }
                        });
                        prefetchNext();
                    }
                });
            }
        }).start();
    }

    /** 后台预取下一章，翻章时直接从内存取 */
    private void prefetchNext() {
        final int nxt = curChapter + 1;
        if (nxt > book.chapterCount) return;
        if (prefetchThread != null && prefetchThread.isAlive()) return;
        prefetchThread = new Thread(new Runnable() {
            @Override public void run() {
                try { BookStore.chapter(getApplicationContext(), bookKey, nxt); }
                catch (Throwable ignore) { }
            }
        });
        prefetchThread.start();
    }

    /** 更新顶部进度条与底部信息 */
    private void updateChrome(int ch, int chapterChars, int chapterCharsTotal) {
        float pct = (book.chapterCount <= 0) ? 0 : (float) ch / book.chapterCount;
        int w = Math.max(1, (int) (getResources().getDisplayMetrics().widthPixels * pct));
        android.view.ViewGroup.LayoutParams lp = progressBar.getLayoutParams();
        lp.width = w;
        lp.height = dp(2);
        progressBar.setLayoutParams(lp);
        progressBar.setBackgroundColor(EYE_FG[eyeMode] | 0x66000000);

        if (chapterCharsTotal > 0) {
            tvFooter.setText("本章 " + chapterCharsTotal + " 字　·　全书 " + book.chapterCount
                    + " 回　·　已读 " + Math.round(pct * 100) + "%");
        } else {
            tvFooter.setText("全书 " + book.chapterCount + " 回　·　已读 "
                    + Math.round(pct * 100) + "%");
        }
    }

    // ---------------------------------------------------------------- 翻章

    /**
     * 滚动回调：判断是否触发了「滑到底 → 下一章」。
     * 只有在**明显越过边界**且距离上次翻章超过冷却时间时才动作，
     * 正常阅读滚动不会误触发。
     */
    private void handleScroll(int sy) {
        if (scroll == null || ignoreScroll) return;
        int childH = 0;
        try {
            if (scroll.getChildCount() > 0) childH = scroll.getChildAt(0).getHeight();
        } catch (Throwable ignore) { }
        int viewH = scroll.getHeight();
        long now = android.os.SystemClock.uptimeMillis();
        if (now - lastTurnAt < TURN_COOLDOWN) return;

        // 滑到底：内容底部已超出视口 120px 以上
        if (childH > 0 && sy + viewH >= childH + dp(120)) {
            if (curChapter < book.chapterCount) {
                lastTurnAt = now;
                nextChapter();
            }
        }
    }

    /** 兼容低版本的 ScrollView（onScrollChanged 全 API 可用） */
    static class ReaderScrollView extends ScrollView {
        interface OnScroll {
            void onScrolled(int sy);
        }

        private OnScroll listener;

        ReaderScrollView(android.content.Context c) { super(c); }

        void setOnScrollListener(OnScroll l) { listener = l; }

        @Override protected void onScrollChanged(int l, int t, int oldl, int oldt) {
            super.onScrollChanged(l, t, oldl, oldt);
            if (listener != null) {
                try { listener.onScrolled(t); } catch (Throwable ignore) { }
            }
        }
    }

    private void nextChapter() {
        if (curChapter >= book.chapterCount) {
            Toast.makeText(this, "已是最后一回", Toast.LENGTH_SHORT).show();
            return;
        }
        loadChapter(curChapter + 1, -1);
    }

    private void prevChapter() {
        if (curChapter <= 1) {
            Toast.makeText(this, "已是第一回", Toast.LENGTH_SHORT).show();
            return;
        }
        loadChapter(curChapter - 1, -1);
    }

    // ---------------------------------------------------------------- 目录

    /**
     * 目录：用 ListView 复用条目（120+ 回也不会卡），
     * 打开时自动定位到当前章。
     */
    private void showCatalog() {
        final FrameLayout wrap = new FrameLayout(this);
        wrap.setBackgroundColor(0xEE111318);

        final LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);

        TextView head = new TextView(this);
        head.setText(bookName + "　全 " + book.chapterCount + " 回");
        head.setTextColor(0xFFFFFFFF);
        head.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        head.setPadding(dp(16), dp(14), dp(16), dp(10));
        box.addView(head);

        final android.app.Dialog dlg = new android.app.Dialog(this);

        final ListView lv = new ListView(this);
        lv.setDivider(null);
        lv.setDividerHeight(0);
        lv.setCacheColorHint(android.graphics.Color.TRANSPARENT);
        lv.setSelector(new android.graphics.drawable.ColorDrawable(
                android.graphics.Color.TRANSPARENT));
        final List<String> titles = new ArrayList<String>();
        for (int i = 1; i <= book.chapterCount; i++) {
            titles.add(i + ". " + book.chapterTitle(i));
        }
        lv.setAdapter(new android.widget.BaseAdapter() {
            @Override public int getCount() { return titles.size(); }
            @Override public Object getItem(int i) { return titles.get(i); }
            @Override public long getItemId(int i) { return i; }
            @Override public View getView(int pos, View convert, ViewGroup parent) {
                TextView t = (TextView) convert;
                if (t == null) {
                    t = new TextView(BookReaderActivity.this);
                    t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.5f);
                    t.setPadding(dp(14), dp(11), dp(14), dp(11));
                }
                t.setText(titles.get(pos));
                t.setTextColor(pos + 1 == curChapter ? 0xFFFB7299 : 0xFFD8DEE6);
                return t;
            }
        });
        lv.setOnItemClickListener(new android.widget.AdapterView.OnItemClickListener() {
            @Override public void onItemClick(android.widget.AdapterView<?> p, View v, int i, long id) {
                try { dlg.dismiss(); } catch (Throwable ignore) { }
                if (i >= 0 && i < titles.size()) {
                    loadChapter(i + 1, -1);
                }
            }
        });
        box.addView(lv, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        TextView close = new TextView(this);
        close.setText("关闭");
        close.setTextColor(0xFFFB7299);
        close.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        close.setGravity(Gravity.CENTER);
        close.setPadding(dp(16), dp(12), dp(16), dp(16));
        close.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { try { dlg.dismiss(); } catch (Throwable ignore) { } }
        });
        box.addView(close);

        wrap.addView(box, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        dlg.setContentView(wrap);
        dlg.setCanceledOnTouchOutside(true);
        dlg.show();

        // 打开时定位到当前章附近
        try {
            lv.post(new Runnable() {
                @Override public void run() {
                    try { lv.setSelection(Math.max(0, curChapter - 3)); } catch (Throwable ignore) { }
                }
            });
        } catch (Throwable ignore) { }
    }

    private int dp(float v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }
}
