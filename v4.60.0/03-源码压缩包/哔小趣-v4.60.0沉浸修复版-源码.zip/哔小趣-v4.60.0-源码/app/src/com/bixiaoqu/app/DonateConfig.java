package com.bixiaoqu.app;

/**
 * 【v4.46.0】捐赠校验服务的**编译期内置配置**。
 *
 * 【v4.46 体验简化】v4.45 把「服务地址 + 公钥」做成了设置页里的两项技术配置，
 * 结果是终端用户下载软件后第一件事就是被要求填 URL 和 Base64 密钥 ——
 * 用户是来用软件看视频的，凭什么要配服务器？既然「用户能找到这个软件已经十分不容易」，
 * 就更不该在首次使用就设置技术参数。
 *
 * 因此本版把配置**全部前置到打包阶段**：
 *   · 作者部署好捐赠校验服务后，用 `一键部署打包.sh` 一条命令，
 *     脚本会自动把服务地址与公钥写进本文件，并编译出可直接分发的 APK；
 *   · 终端用户拿到 APK 后**不需要做任何配置**，扫码捐赠即可开通登录与全部功能。
 *
 * 若本文件里的两个常量仍为空，说明尚未执行打包脚本：
 * 此时 App **无法核验支付**，捐赠页会提示联系作者，**绝不会**自行放行登录
 * （v4.47 起已彻底移除任何本地置成功的路径）。
 */
public final class DonateConfig {

    /**
     * 捐赠校验服务地址（不含路径，末尾不带斜杠）。
     * 例如：https://donate.example.com
     * 留空 = 尚未启用在线核验（作者未执行一键打包脚本）。
     */
    public static final String SERVER_URL = "";

    /**
     * 服务端 RSA 公钥（X.509 DER 的 Base64；也兼容 hex 写法）。
     * 私钥只保存在服务端，绝不能填到这里、也不能放进 APK。
     */
    public static final String PUB_KEY_B64 = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEA2HbXx8nvHQXFtdcVKdULt5jsg+vJIvjK9VKuVU9Fb2z5ZNyh9jjYLh++X4jmOJi//qcfWvFMSSt9zMrrcGtG738BPmF+RMkhYXlXSkvLdnLNTLaR3HlVmNJ6mn858dQT6v0UEY0t0XZVDKxQ6jAU0zKBvOL9K68q8GCvCBJ5/AqXHjvkYMgYZi5Eq6fEFHVvHNLMud0n3em6kKHCjHP0egtFxsyL0XVmNpkBLDDZPx2svePPN1awq4O88jgRySdy0yhlAZQD8KdU2a1KtiNu2cshGv1TEZ4h3+CXZwWrJKl7fwSTHMX1PaBOz6z4Bmiuc9cwmdu4gkWCrkmP7BszbwIDAQAB";

    /** 是否已启用在线核验（两个常量都填了才算启用） */
    public static boolean onlineEnabled() {
        return SERVER_URL != null && SERVER_URL.trim().length() > 0
                && PUB_KEY_B64 != null && PUB_KEY_B64.trim().length() > 0;
    }

    private DonateConfig() { }
}
