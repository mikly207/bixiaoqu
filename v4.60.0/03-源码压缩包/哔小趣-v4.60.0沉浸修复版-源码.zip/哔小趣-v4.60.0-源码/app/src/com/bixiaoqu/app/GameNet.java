package com.bixiaoqu.app;

import android.os.Handler;
import android.os.Looper;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * 【v4.55】局域网对战框架（纯 TCP 直连 + UDP 广播发现，零服务器）。
 * 供五子棋等回合制游戏复用：
 *  · 主机 host()：开 TCP 监听 + UDP 广播自己的 IP；
 *  · 客户端 discover()：UDP 发现局域网内的主机；
 *  · join(ip)：TCP 连上主机；
 *  · send(line)/回调 onMessage：以「行」为单位的文本协议（如 MOVE,7,7）。
 * 所有网络操作在子线程，回调切回主线程。
 */
public class GameNet {
    public static final int TCP_PORT = 45990;
    public static final int UDP_PORT = 45991;
    private static final Charset UTF8 = Charset.forName("UTF-8");

    public interface Listener {
        void onMessage(String line);
        void onConnected(boolean host);
        void onDisconnected();
        void onHostFound(String ip, String deviceName);
    }

    final Handler main = new Handler(Looper.getMainLooper());
    final Listener listener;
    volatile Socket socket;
    volatile OutputStream out;
    volatile BufferedReader in;
    final AtomicBoolean running = new AtomicBoolean(false);

    private Thread readThread, udpThread, broadcastThread, acceptThread;
    private DatagramSocket udp;
    private ServerSocket server;

    public GameNet(Listener l) { this.listener = l; }

    /** 是否是本机（用于过滤自己广播的主机）。 */
    public static String localIp() {
        try {
            List<String> ips = new ArrayList<String>();
            java.util.Enumeration<java.net.NetworkInterface> nis =
                    java.net.NetworkInterface.getNetworkInterfaces();
            while (nis.hasMoreElements()) {
                java.net.NetworkInterface ni = nis.nextElement();
                if (!ni.isUp() || ni.isLoopback() || ni.isVirtual()) continue;
                java.util.Enumeration<InetAddress> as = ni.getInetAddresses();
                while (as.hasMoreElements()) {
                    InetAddress a = as.nextElement();
                    if (a instanceof java.net.Inet4Address && !a.isLoopbackAddress()) {
                        String h = a.getHostAddress();
                        if (h != null && !h.startsWith("169.254")) return h;
                    }
                }
            }
        } catch (Throwable ignore) {}
        return null;
    }

    /** 作为主机：开 TCP 监听并 UDP 广播；accept 到第一个客户端即建立连接（本机执黑）。 */
    public boolean host(final String deviceName) {
        try {
            server = new ServerSocket(TCP_PORT);
            running.set(true);
            acceptThread = new Thread(new Runnable() { @Override public void run() {
                try {
                    Socket s = server.accept();
                    bind(s, true);
                } catch (Throwable e) { fail(); }
            }}, "gamenet-accept");
            acceptThread.setDaemon(true);
            acceptThread.start();
            startBroadcast(deviceName);
            return true;
        } catch (Throwable e) { return false; }
    }

    private void startBroadcast(final String deviceName) {
        broadcastThread = new Thread(new Runnable() { @Override public void run() {
            try {
                DatagramSocket bs = new DatagramSocket();
                bs.setBroadcast(true);
                byte[] data = ("BXQ5|" + (deviceName == null ? "玩家" : deviceName)).getBytes(UTF8);
                InetAddress bc = InetAddress.getByName("255.255.255.255");
                while (running.get()) {
                    try {
                        DatagramPacket p = new DatagramPacket(data, data.length, bc, UDP_PORT);
                        bs.send(p);
                        Thread.sleep(1000);
                    } catch (Throwable ignore) { break; }
                }
                bs.close();
            } catch (Throwable ignore) {}
        }}, "gamenet-broadcast");
        broadcastThread.setDaemon(true);
        broadcastThread.start();
    }

    /** 发现局域网主机；发现结果通过 listener.onHostFound 回调（去重）。持续监听。 */
    public void discover() {
        stopDiscover();
        udpThread = new Thread(new Runnable() { @Override public void run() {
            try {
                udp = new DatagramSocket(null);
                udp.setReuseAddress(true);
                udp.bind(new java.net.InetSocketAddress(UDP_PORT));
                byte[] buf = new byte[256];
                final Map<String, String> seen = new LinkedHashMap<String, String>();
                while (running.get() || udp != null) {
                    DatagramPacket p = new DatagramPacket(buf, buf.length);
                    try { udp.receive(p); } catch (Throwable e) { break; }
                    String msg = new String(p.getData(), 0, p.getLength(), UTF8).trim();
                    if (!msg.startsWith("BXQ5|")) continue;
                    String ip = p.getAddress().getHostAddress();
                    String name = msg.substring(5);
                    String old = seen.get(ip);
                    if (old == null || !old.equals(name)) {
                        seen.put(ip, name);
                        final String fip = ip, fn = name;
                        main.post(new Runnable() { @Override public void run() {
                            if (listener != null) listener.onHostFound(fip, fn);
                        }});
                    }
                }
            } catch (Throwable ignore) {}
        }}, "gamenet-discover");
        udpThread.setDaemon(true);
        running.set(true);
        udpThread.start();
    }

    public void stopDiscover() {
        if (udp != null) { try { udp.close(); } catch (Throwable ignore) {} udp = null; }
        if (udpThread != null) { udpThread.interrupt(); udpThread = null; }
    }

    /** 连接主机（本机执白）。 */
    public boolean join(String ip) {
        try {
            Socket s = new Socket(ip, TCP_PORT);
            bind(s, false);
            stopDiscover();
            stopBroadcast();
            return true;
        } catch (Throwable e) { return false; }
    }

    private void stopBroadcast() {
        running.set(false);
        if (broadcastThread != null) { broadcastThread.interrupt(); broadcastThread = null; }
        if (server != null) { try { server.close(); } catch (Throwable ignore) {} server = null; }
    }

    private void bind(final Socket s, final boolean isHost) {
        socket = s;
        try {
            out = s.getOutputStream();
            in = new BufferedReader(new InputStreamReader(s.getInputStream(), UTF8));
        } catch (Throwable e) { fail(); return; }
        main.post(new Runnable() { @Override public void run() {
            if (listener != null) listener.onConnected(isHost);
        }});
        readThread = new Thread(new Runnable() { @Override public void run() {
            try {
                String line;
                while ((line = in.readLine()) != null) {
                    final String f = line;
                    main.post(new Runnable() { @Override public void run() {
                        if (listener != null) listener.onMessage(f);
                    }});
                }
            } catch (Throwable ignore) { fail(); }
        }}, "gamenet-read");
        readThread.setDaemon(true);
        readThread.start();
    }

    public void send(String line) {
        try {
            if (out != null) { out.write((line + "\n").getBytes(UTF8)); out.flush(); }
        } catch (Throwable e) { fail(); }
    }

    void fail() {
        main.post(new Runnable() { @Override public void run() {
            if (listener != null) listener.onDisconnected();
        }});
    }

    /** 彻底关闭所有连接与监听。 */
    public void close() {
        running.set(false);
        stopDiscover();
        if (socket != null) { try { socket.close(); } catch (Throwable ignore) {} socket = null; }
        if (server != null) { try { server.close(); } catch (Throwable ignore) {} server = null; }
        if (readThread != null) { readThread.interrupt(); readThread = null; }
        if (acceptThread != null) { acceptThread.interrupt(); acceptThread = null; }
        if (broadcastThread != null) { broadcastThread.interrupt(); broadcastThread = null; }
    }
}
