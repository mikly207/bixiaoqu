package com.bixiaoqu.app;

/**
 * 【v4.59】NetQuality 的 Android 桥接层。
 *
 * 把网络类型读取、广播监听、定时同步这些 Android 依赖单独放这里，
 * 让 NetQuality 本体保持纯 Java —— 于是核心决策逻辑可以在 JVM 上单测，
 * 不必为了跑一个 decide() 去 link 整个 android.jar。
 */
public final class NetQualityAndroid {

    private NetQualityAndroid() { }

    /** 应用启动时调用：读当前网络类型 + 注册切换监听 + 定时同步并发闸门 */
    public static void init(android.content.Context ctx) {
        if (ctx == null) return;
        final android.content.Context app = ctx.getApplicationContext();
        NetQuality.setNetType(currentType(app));
        // 档位变化 → 同步 ImgLoader 并发闸门
        NetQuality.setOnLevelChanged(new Runnable() {
            @Override public void run() {
                try { ImgLoader.applyQuality(); } catch (Throwable ignore) { }
            }
        });
        try { ImgLoader.applyQuality(); } catch (Throwable ignore) { }

        final android.os.Handler h = new android.os.Handler(android.os.Looper.getMainLooper());
        try {
            android.content.IntentFilter f = new android.content.IntentFilter(
                    android.net.ConnectivityManager.CONNECTIVITY_ACTION);
            app.registerReceiver(new android.content.BroadcastReceiver() {
                @Override public void onReceive(android.content.Context c, android.content.Intent i) {
                    int t = currentType(app);
                    if (t != NetQuality.netType()) {
                        NetQuality.reset(t);              // 清统计 + 按网络类型设初值
                        try { ImgLoader.applyQuality(); } catch (Throwable ignore) { }
                    }
                }
            }, f);
        } catch (Throwable ignore) { }

        // 周期性同步闸门（心跳已在各请求里驱动档位，这里只兜底）
        h.postDelayed(new Runnable() {
            @Override public void run() {
                try { ImgLoader.applyQuality(); } catch (Throwable ignore) { }
                h.postDelayed(this, 5000);
            }
        }, 5000);
    }

    /** 读取当前网络类型：1 WiFi / 2 移动 / 0 其它 */
    static int currentType(android.content.Context ctx) {
        try {
            android.net.ConnectivityManager cm = (android.net.ConnectivityManager)
                    ctx.getSystemService(android.content.Context.CONNECTIVITY_SERVICE);
            if (cm == null) return 0;
            android.net.NetworkInfo ni = cm.getActiveNetworkInfo();
            if (ni == null || !ni.isConnected()) return 0;
            int t = ni.getType();
            return t == android.net.ConnectivityManager.TYPE_WIFI ? 1
                    : (t == android.net.ConnectivityManager.TYPE_MOBILE ? 2 : 0);
        } catch (Throwable e) {
            return 0;
        }
    }
}
