package com.bixiaoqu.app;

import android.content.Context;
import android.content.res.AssetManager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.GZIPInputStream;

/**
 * 【v4.56】内置四大名著全文仓库。
 *
 * 数据来源：公版全文（明清白话 + 无删节本），逐字完整收录，一处不省。
 *
 * 存储格式（assets/books/<key>.bin.gz）：
 *   整本用一个 gzip 打包，字节流按章顺序拼接，每章记录为：
 *     [2字节 titleLen][titleLen 字节 UTF-8 标题]
 *     [4字节 bodyLen ][bodyLen  字节 UTF-8 正文]
 *   assets/books/<key>.idx.json 保存每章的标题与在解包后字节流中的偏移/长度，
 *   供阅读器快速定位章节，无需加载全书即可跳章。
 *
 * 为什么用 gzip：四本合计约 850 万字，原始 UTF-8 约 8.5MB，
 * gzip 后仅 3.9MB（中文文本压缩比很高），APK 体积可接受；
 * 解压在读取时一次性完成，之后常驻内存约 8MB（分书按需加载）。
 */
public final class BookStore {

    /** 一章的内容。 */
    public static final class Chapter {
        public final int no;        // 回目序号，从 1 开始
        public final String title;  // 章节标题
        public final String body;   // 正文全文
        public final int charCount;

        Chapter(int no, String title, String body) {
            this.no = no;
            this.title = title;
            this.body = body;
            this.charCount = body == null ? 0 : body.length();
        }
    }

    /** 一本书的元信息 + 章节索引。 */
    public static final class Book {
        public final String key;
        public final String name;
        public final String author;
        public final String intro;
        public final int chapterCount;
        public final int totalChars;
        private final Map<Integer, Integer> offMap;   // 章节号 -> 字节偏移
        private final Map<Integer, Integer> lenMap;   // 章节号 -> 字节长度
        private final Map<Integer, String> titleMap; // 章节号 -> 标题

        Book(String key, String name, String author, String intro,
             int chapterCount, int totalChars,
             Map<Integer, Integer> offMap, Map<Integer, Integer> lenMap,
             Map<Integer, String> titleMap) {
            this.key = key;
            this.name = name;
            this.author = author;
            this.intro = intro;
            this.chapterCount = chapterCount;
            this.totalChars = totalChars;
            this.offMap = offMap;
            this.lenMap = lenMap;
            this.titleMap = titleMap;
        }

        public String chapterTitle(int no) {
            String t = titleMap.get(no);
            return t == null ? ("第 " + no + " 回") : t;
        }

        /** 该书是否有真实正文（避免空壳书进书架）。 */
        public boolean hasContent() { return chapterCount > 0 && totalChars > 1000; }
    }

    /** 内置书目元信息（与 assets 中的书一一对应）。 */
    private static final Object[][] META = {
        {"xiyouji", "西游记", "吴承恩 明", "神魔小说的巅峰之作。全书一百回，孙悟空大闹天宫、唐僧西天取经，三打白骨精、真假美猴王皆在此中。本书为无删节完整全文。"},
        {"sanguoyanyi", "三国演义", "罗贯中 明", "中国历史演义小说之冠。全书一百二十回，桃园结义、三顾茅庐、诸葛亮借东风、赤壁鏖兵、千里走单骑，一部讲尽三国风云。本书为无删节完整全文。"},
        {"hongloumeng", "红楼梦", "曹雪芹 清", "中国古典小说的高峰，百二十回。作者以极精细之笔，写贾府之盛衰、大观园之悲欢，兼写世情与世事。本书为无删节完整全文。"},
        {"shuihuzhuan", "水浒传", "施耐庵 元末明初", "一百二十回，写尽北宋末年一百单八将。上至晁盖智取生辰纲、吴用智取大名府，下至宋江征方腊、梁山泊神聚蓼儿洼。本书为无删节完整全文。"},
    };

    // key -> 解包后的整本字节（懒加载，用后按需驻留）
    private static final Map<String, byte[]> RAW_CACHE = new HashMap<String, byte[]>();
    // key -> Book
    private static final Map<String, Book> BOOK_CACHE = new HashMap<String, Book>();

    private BookStore() { }

    /**
     * 全部内置书目（只返回有正文的）。
     *
     * 【v4.57 去掉重复构造】原来 load() 返回的是元信息为空的 Book，
     * 这里又要 new 一个带元信息的 Book，等于每本书分配两次对象。
     * 现在 load() 直接带上 META 里的书名/作者/简介，这里原样返回即可。
     */
    public static List<Book> allBooks(Context ctx) {
        List<Book> out = new ArrayList<Book>();
        for (Object[] row : META) {
            Book b = load(ctx, (String) row[0]);
            if (b != null && b.hasContent()) out.add(b);
        }
        return out;
    }
    /** 读取一本书的元信息与章节索引（不解包正文，除非需要）。 */
    public static synchronized Book load(Context ctx, String key) {
        if (BOOK_CACHE.containsKey(key)) return BOOK_CACHE.get(key);
        Book b = null;
        try {
            AssetManager am = ctx.getAssets();
            String idxRaw = readAll(am, "books/" + key + ".idx.json");
            if (idxRaw == null) return null;
            JSONObject idx = new JSONObject(idxRaw);
            JSONArray arr = idx.optJSONArray("chapters");
            if (arr == null) return null;
            Map<Integer, Integer> offMap = new HashMap<Integer, Integer>();
            Map<Integer, Integer> lenMap = new HashMap<Integer, Integer>();
            Map<Integer, String> titleMap = new HashMap<Integer, String>();
            int totalChars = 0;
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                int no = o.optInt("n", i + 1);
                offMap.put(no, o.optInt("off", 0));
                lenMap.put(no, o.optInt("len", 0));
                titleMap.put(no, o.optString("t", "第 " + no + " 回"));
            }
            // 总字数直接取 idx 里构建时统计好的值
            totalChars = idx.optInt("totalChars", 0);
            // 【v4.57】元信息直接取 META，避免 allBooks 再造一遍对象
            String name = key, author = "", intro = "";
            for (Object[] row : META) {
                if (key.equals(row[0])) {
                    name = (String) row[1];
                    author = (String) row[2];
                    intro = (String) row[3];
                    break;
                }
            }
            b = new Book(key, name, author, intro, arr.length(), totalChars,
                    offMap, lenMap, titleMap);
            BOOK_CACHE.put(key, b);
        } catch (Throwable e) {
            b = null;
        }
        return b;
    }

    /** 取某一章的完整正文。 */
    public static Chapter chapter(Context ctx, String key, int no) {
        try {
            byte[] raw = rawOf(ctx, key);
            if (raw == null) return null;
            Book b = load(ctx, key);
            if (b == null) return null;
            Integer off = b.offMap.get(no);
            Integer len = b.lenMap.get(no);
            if (off == null || len == null) return null;
            int p = off;
            if (p + 2 > raw.length) return null;
            int tlen = (raw[p] & 0xFF) | ((raw[p + 1] & 0xFF) << 8);
            p += 2;
            if (p + tlen > raw.length) return null;
            String title = new String(raw, p, tlen, "UTF-8");
            p += tlen;
            if (p + 4 > raw.length) return null;
            int blen = (raw[p] & 0xFF) | ((raw[p + 1] & 0xFF) << 8)
                    | ((raw[p + 2] & 0xFF) << 16) | ((raw[p + 3] & 0xFF) << 24);
            p += 4;
            if (blen < 0 || p + blen > raw.length) return null;
            String body = new String(raw, p, blen, "UTF-8");
            return new Chapter(no, title, body);
        } catch (Throwable e) {
            return null;
        }
    }

    /**
     * 【v4.57 移除 wholeBook()】
     * 原方法会把整本书（最大 92 万字）一次性拼成一个 String，
     * 在低端机上必然 OOM，且全工程零引用 —— 已删除。
     * 需要全书内容时应按章走 chapter()。
     */

    /** 【v4.58】预热：后台提前解压整本书，首次翻章不再等 gzip。 */
    public static void warmup(Context ctx, String key) {
        if (ctx == null || key == null) return;
        rawOf(ctx.getApplicationContext(), key);
    }

    /**
     * 【v4.58】整段加锁：预热线程与加载线程同时进来时只解压一次，
     * 避免重复分配 2~3MB 数组造成卡顿/OOM。
     */
    private static byte[] rawOf(Context ctx, final String key) {
        synchronized (BookStore.class) {
            byte[] cached = RAW_CACHE.get(key);
            if (cached != null) return cached;
            try {
                InputStream in = ctx.getAssets().open("books/" + key + ".bin.gz");
                GZIPInputStream gz = new GZIPInputStream(in);
                ByteArrayOutputStream bos = new ByteArrayOutputStream(1 << 20);
                byte[] buf = new byte[1 << 16];
                int n;
                while ((n = gz.read(buf)) > 0) bos.write(buf, 0, n);
                try { gz.close(); } catch (Throwable ignore) { }
                try { in.close(); } catch (Throwable ignore) { }
                byte[] raw = bos.toByteArray();
                RAW_CACHE.put(key, raw);
                return raw;
            } catch (Throwable e) {
                return null;
            }
        }
    }

    /** 读 assets 小文件为字符串。 */
    private static String readAll(AssetManager am, String path) throws Exception {
        InputStream in = am.open(path);
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        byte[] buf = new byte[1 << 13];
        int n;
        while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
        in.close();
        return new String(bos.toByteArray(), "UTF-8");
    }
}
