package com.bixiaoqu.app;

import android.app.Activity;
import android.graphics.Color;
import android.os.Build;
import android.view.View;
import android.view.Window;

import java.util.WeakHashMap;

/**
 * 【v4.60】沉浸式系统栏。
 *
 * <p>背景：Manifest 用系统默认 Theme.DeviceDefault.NoActionBar，全工程从未设置
 * statusBarColor / navigationBarColor。Android 10+ 手势导航下，底部那条"小白条"
 * 区域因此一直是系统浅白色，与深色主题完全脱节；播放页退出全屏后还会露出一块白底。</p>
 *
 * <p>这里统一做四件事：</p>
 * <ol>
 *   <li>状态栏 / 导航栏背景色跟随页面底色 C_BG；</li>
 *   <li>API 29+ 关闭系统强制对比层 —— 这是"即使设了深色导航栏，手势条仍被涂成半透明白"的直接原因；</li>
 *   <li>导航栏分割线透明；</li>
 *   <li>浅色主题下让状态栏 / 导航栏图标变深色，保证可读。</li>
 * </ol>
 *
 * <p>刻意<b>不</b>设置任何 LAYOUT_* flag，避免干扰 PlayActivity / LiveActivity 的全屏沉浸；
 * 只记下"常规图标明暗"，供退出全屏时通过 {@link #restore(Activity)} 恢复。</p>
 *
 * <p>所有系统 API 用反射 / 数值常量调用，保证在 android-22 bootclasspath 下可编译，
 * 运行时按版本生效。</p>
 */
public final class ImmersiveBars {

    /** View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR（API 23+），数值常量避免编译期依赖 */
    private static final int FLAG_LIGHT_STATUS = 0x00002000;
    /** View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR（API 26+） */
    private static final int FLAG_LIGHT_NAV = 0x00001000;

    /** 每个 Activity 在非全屏状态下应使用的 systemUiVisibility（图标明暗） */
    private static final WeakHashMap<Activity, Integer> BASE_FLAGS =
            new WeakHashMap<Activity, Integer>();

    private ImmersiveBars() { }

    /**
     * 应用沉浸式系统栏。
     *
     * @param a    当前 Activity
     * @param bg   页面底色（通常传 MainActivity.C_BG）
     * @param dark true=深色主题（深底浅色图标），false=浅色主题（浅底深色图标）
     */
    public static void apply(Activity a, int bg, boolean dark) {
        if (a == null) return;
        try {
            Window w = a.getWindow();
            if (w == null) return;

            // 1) 状态栏 / 导航栏与页面同色
            w.setStatusBarColor(bg);
            w.setNavigationBarColor(bg);

            // 2) 分割线透明（API 28+）
            if (Build.VERSION.SDK_INT >= 28) {
                invoke(w, "setNavigationBarDividerColor", Color.TRANSPARENT);
            }

            // 3) 关键：关闭手势条强制对比层（API 29+），否则小白条区域仍被涂半透明白
            if (Build.VERSION.SDK_INT >= 29) {
                invoke(w, "setNavigationBarContrastEnforced", false);
            }

            // 4) 图标明暗
            int flags = 0;
            if (!dark) {
                if (Build.VERSION.SDK_INT >= 23) flags |= FLAG_LIGHT_STATUS;
                if (Build.VERSION.SDK_INT >= 26) flags |= FLAG_LIGHT_NAV;
            }
            BASE_FLAGS.put(a, Integer.valueOf(flags));

            // 只在当前不是全屏时才落地图标明暗，避免打断正在播放的全屏沉浸
            View decor = w.getDecorView();
            int cur = decor.getSystemUiVisibility();
            int full = View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION;
            if ((cur & full) == 0) {
                decor.setSystemUiVisibility(flags);
            }
        } catch (Throwable ignore) { }
    }

    /** 退出全屏后恢复常规图标明暗（不动背景色，避免白条回归）。 */
    public static void restore(Activity a) {
        if (a == null) return;
        try {
            Integer f = BASE_FLAGS.get(a);
            a.getWindow().getDecorView().setSystemUiVisibility(f == null ? 0 : f.intValue());
        } catch (Throwable ignore) { }
    }

    /** 反射调用 Window 上的单参数 void 方法，参数类型由实参自动决定。 */
    private static void invoke(Window w, String name, Object arg) {
        try {
            Class<?> type = arg instanceof Boolean ? boolean.class : int.class;
            w.getClass().getMethod(name, type).invoke(w, arg);
        } catch (Throwable ignore) { }
    }
}
