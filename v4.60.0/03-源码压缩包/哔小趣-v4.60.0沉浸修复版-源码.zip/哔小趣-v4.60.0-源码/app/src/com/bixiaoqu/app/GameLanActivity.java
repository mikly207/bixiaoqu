package com.bixiaoqu.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.widget.EditText;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

/**
 * 【v4.55】五子棋局域网对战入口：创建房间 / 发现的主机列表 / 手动输入 IP。
 * 建立连接后把 GameNet 交给 GameGomoku.pendingNet，然后 finish 回到游戏厅由用户点五子棋进入。
 */
public class GameLanActivity extends Activity {
    GameNet net;
    final List<String> ips = new ArrayList<String>();
    final List<String> names = new ArrayList<String>();
    LinearLayout hostList;
    TextView status;

    int dp(float v) { return (int) (getResources().getDisplayMetrics().density * v + 0.5f); }

    GradientDrawable round(int color, float rad) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(rad * getResources().getDisplayMetrics().density);
        return g;
    }

    TextView txt(String s, int color, float size, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextColor(color);
        t.setTextSize(size);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        MainActivity.applyTheme(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(MainActivity.C_BG);
        root.setPadding(dp(16), dp(16), dp(16), dp(16));

        TextView title = txt("五子棋 · 局域网对战", MainActivity.C_FG, 20, true);
        root.addView(title);
        status = txt("两台设备连同一 WiFi 即可对战，无需服务器 / 流量", MainActivity.C_SUB, 12, false);
        status.setPadding(0, dp(6), 0, dp(12));
        root.addView(status);

        Button create = new Button(this);
        create.setText("创建房间（本机执黑，等待对手）");
        create.setTextColor(Color.WHITE);
        create.setTextSize(14);
        create.setBackground(round(0xFFFB7299, 10));
        create.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { createRoom(); }
        });
        root.addView(create, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(46)));

        TextView hint = txt("或 加入下面发现的房间：", MainActivity.C_SUB, 12, false);
        hint.setPadding(0, dp(16), 0, dp(6));
        root.addView(hint);

        hostList = new LinearLayout(this);
        hostList.setOrientation(LinearLayout.VERTICAL);
        ScrollView sc = new ScrollView(this);
        sc.addView(hostList);
        root.addView(sc, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        Button manual = new Button(this);
        manual.setText("手动输入对方 IP 加入");
        manual.setTextColor(MainActivity.C_FG);
        manual.setTextSize(13);
        manual.setBackground(round(MainActivity.C_CARD, 10));
        manual.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { manualJoin(); }
        });
        root.addView(manual, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(42)));

        setContentView(root);
        startDiscover();
    }

    void startDiscover() {
        net = new GameNet(new GameNet.Listener() {
            @Override public void onMessage(String line) { }
            @Override public void onConnected(boolean host) { }
            @Override public void onDisconnected() {
                runOnUiThread(new Runnable() { @Override public void run() {
                    Toast.makeText(GameLanActivity.this, "对手断开连接", Toast.LENGTH_SHORT).show();
                }});
            }
            @Override public void onHostFound(final String ip, final String name) {
                runOnUiThread(new Runnable() { @Override public void run() { addHost(ip, name); }});
            }
        });
        net.discover();
    }

    void addHost(final String ip, String name) {
        if (ips.contains(ip)) return;
        ips.add(ip); names.add(name);
        TextView row = txt("🟢 " + name + "  ·  " + ip, MainActivity.C_FG, 14, false);
        row.setPadding(dp(12), dp(12), dp(12), dp(12));
        row.setBackground(round(MainActivity.C_CARD, 10));
        row.setPadding(dp(12), dp(14), dp(12), dp(14));
        row.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { joinHost(ip); }
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = dp(8);
        hostList.addView(row, lp);
    }

    void createRoom() {
        GameNet n = new GameNet(gameListener(true));
        if (!n.host(android.os.Build.MODEL)) {
            Toast.makeText(this, "创建失败，请确认已开启 WiFi", Toast.LENGTH_SHORT).show();
            return;
        }
        GameGomoku.pendingNet = n;
        GameGomoku.pendingHost = true;
        Toast.makeText(this, "房间已创建，等待对手加入…", Toast.LENGTH_SHORT).show();
        finish();
    }

    void joinHost(String ip) {
        GameNet n = new GameNet(gameListener(false));
        if (!n.join(ip)) {
            Toast.makeText(this, "连接失败，请检查 IP 与网络", Toast.LENGTH_SHORT).show();
            return;
        }
        GameGomoku.pendingNet = n;
        GameGomoku.pendingHost = false;
        Toast.makeText(this, "已连接，你执白", Toast.LENGTH_SHORT).show();
        finish();
    }

    void manualJoin() {
        final EditText et = new EditText(this);
        et.setHint("例如 192.168.1.23");
        et.setTextColor(MainActivity.C_FG);
        et.setSingleLine(true);
        new AlertDialog.Builder(this)
                .setTitle("输入主机 IP")
                .setView(et)
                .setPositiveButton("连接", new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface d, int w) {
                        String ip = et.getText().toString().trim();
                        if (ip.isEmpty()) return;
                        joinHost(ip);
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    GameNet.Listener gameListener(final boolean host) {
        return new GameNet.Listener() {
            @Override public void onMessage(String line) { GameGomoku.netMessage(line); }
            @Override public void onConnected(boolean h) { GameGomoku.netConnected(h); }
            @Override public void onDisconnected() { GameGomoku.netDisconnected(); }
            @Override public void onHostFound(String ip, String name) { }
        };
    }

    @Override protected void onDestroy() {
        // 只停止「发现」用的 net；真正对战的 net 交给 GameGomoku 持有
        if (net != null) { net.close(); net = null; }
        super.onDestroy();
    }
}
