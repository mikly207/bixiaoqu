package com.bixiaoqu.app;

import android.app.Activity;
import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.MediaController;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * 【v4.43 实验版】内嵌直播页 —— 全部在 App 内播放，不跳转第三方浏览器。
 *
 * 【v4.43 精简】直播是体验版，本页只保证「能流畅看直播」这一件事：
 *  - 列表态：顶栏（返回 + 标题 + 画质）+ 分区横滑 + 直播间两列网格
 *  - 播放态：全屏视频（TxVideoView 硬解 m3u8，经 LiveProxy 补 Referer）
 *     · 顶部极简栏：返回 + 房间标题 + 画质切换（标清/高清/2K）+ 缩放切换（铺满/适应）
 *     · 无主播栏 / 无榜单 / 无礼物 / 无弹幕 / 无挂件 —— 界面保持干净
 *  - 画面缩放：铺满（裁切不留黑边）/ 适应（完整显示）两档循环，点按画面呼出控制条
 *
 * 保留 v4.41 全部稳定性：代际隔离 + 序号隔离 + 有限重连 + 多线路择优。
 * 移除：演示视频、实时弹幕 WebSocket、点赞/关注/礼物/发弹幕等写操作接口调用。
 * 全部纯 Java 动态建 UI，兼容 minSdk 22；与平板/手机版共用（Activity 不区分目标）。
 */
public class LiveActivity extends Activity {

    final Handler ui = new Handler(Looper.getMainLooper());
    int dp(float v) { return (int) (getResources().getDisplayMetrics().density * v + 0.5f); }

    // ---- 主题（跟随 App）----
    int C_BG = 0xFF16181d, C_FG = 0xFFe8eaf0, C_SUB = 0xFF9aa0ab,
            C_ACC = 0xFFfb7299, C_CARD = 0xFF1f2229;
    int appliedStamp = -1;

    // ---- 分区/房间数据 ----
    static class Zone { int parent, area; String name; Zone(int p, int a, String n) { parent = p; area = a; name = n; } }
    static class Room {
        long roomId; String title, uname, cover; long online, uid;
        Room(long r, String t, String u, String c, long o) { roomId = r; title = t; uname = u; cover = c; online = o; }
    }
    final List<Zone> zones = new ArrayList<>();
    final List<Room> rooms = new ArrayList<>();
    int zoneIndex = 0;
    int page = 1;

    // 【v4.43】画质三档：标清 / 高清 / 2K（qn 越大越清晰）
    final int[] QNS = {64, 80, 10000};
    final String[] QN_LABEL = {"标清", "高清", "2K"};
    int qnIndex = 1;   // 默认高清

    // ---- 视图 ----
    LinearLayout root;
    LinearLayout zoneBar;
    GridView grid;
    RoomAdapter adapter;
    View listLayer;
    View playLayer;
    TextView qualityBtn;
    TextView loadingTip;

    // ---- 播放器 ----
    LiveProxy proxy;
    TxVideoView video;
    MediaController mc;
    boolean playing = false;
    Room curRoom;
    TextView playQualityBtn;     // 播放态画质按钮
    TextView playScaleBtn;       // 播放态缩放按钮
    TextView playFullBtn;        // v4.51 播放态全屏按钮
    boolean fullscreen = false;  // v4.51 是否处于全屏（横屏 + 隐藏系统栏）
    android.widget.FrameLayout videoBox;  // 视频容器（缩放即改它的 LayoutParams）
    final String[] SCALE_LABEL = {"铺满", "适应", "小窗"};
    int scaleMode = 0;           // 0 铺满 / 1 适应(完整) / 2 小窗
    TextView playTitle;

    // ---- 【v4.41 稳定性】----
    final java.util.concurrent.atomic.AtomicInteger playSeq =
            new java.util.concurrent.atomic.AtomicInteger(0);  // 播放请求序号，防旧回调
    int retryCount = 0;                  // 断流重连次数（有上限，防无限重连卡死）
    static final int MAX_RETRY = 3;
    boolean userPaused = false;          // 用户主动暂停（不触发重连）

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        MainActivity.applyTheme(this);
        syncTheme();
        appliedStamp = MainActivity.themeStampOf(this);
        try {
            setContentView(buildList());
        } catch (Throwable e) {
            TextView tv = new TextView(this);
            tv.setText("直播页加载失败：\n" + android.util.Log.getStackTraceString(e));
            tv.setTextColor(Color.WHITE);
            tv.setPadding(dp(24), dp(60), dp(24), dp(24));
            setContentView(tv);
        }
        proxy = LiveProxy.get();
        loadZones();
    }

    void syncTheme() {
        try {
            C_BG = MainActivity.C_BG; C_FG = MainActivity.C_FG; C_SUB = MainActivity.C_SUB;
            C_ACC = MainActivity.C_ACC; C_CARD = MainActivity.C_CARD;
        } catch (Throwable ignore) {}
    }

    @Override protected void onResume() {
        super.onResume();
        if (appliedStamp != MainActivity.themeStampOf(this)) recreate();
    }

    @Override public void onBackPressed() {
        // v4.51 全屏时先退出全屏，再按一次才退出直播间
        if (playing && fullscreen) { exitFullscreen(); return; }
        if (playing) { exitPlayer(); return; }
        super.onBackPressed();
    }

    @Override protected void onDestroy() {
        releasePlayer();
        super.onDestroy();
    }

    // ============================================================ 列表 UI

    View buildList() {
        FrameLayout frame = new FrameLayout(this);
        frame.setBackgroundColor(C_BG);

        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(C_BG);
        frame.addView(root, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // 顶栏
        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(6), dp(10), dp(10), dp(10));
        ImageView back = Ic.view(this, "back", C_FG, 22);
        back.setPadding(dp(8), dp(6), dp(10), dp(6));
        back.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { finish(); } });
        top.addView(back, new LinearLayout.LayoutParams(dp(44), dp(44)));
        TextView title = new TextView(this);
        title.setText("直播");
        title.setTextColor(C_FG);
        title.setTextSize(19);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        top.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        qualityBtn = qualityChip(QN_LABEL[qnIndex]);
        qualityBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showQualityDialog(false); }
        });
        top.addView(qualityBtn, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(top, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // 分区横滑
        android.widget.HorizontalScrollView zs = new android.widget.HorizontalScrollView(this);
        zs.setHorizontalScrollBarEnabled(false);
        zoneBar = new LinearLayout(this);
        zoneBar.setOrientation(LinearLayout.HORIZONTAL);
        zoneBar.setPadding(dp(8), dp(2), dp(8), dp(8));
        zs.addView(zoneBar, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(zs, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // 提示
        loadingTip = new TextView(this);
        loadingTip.setTextColor(C_SUB);
        loadingTip.setTextSize(13);
        loadingTip.setGravity(Gravity.CENTER);
        loadingTip.setPadding(dp(12), dp(6), dp(12), dp(6));
        root.addView(loadingTip, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // 房间网格
        grid = new GridView(this);
        grid.setNumColumns(2);
        grid.setHorizontalSpacing(dp(8));
        grid.setVerticalSpacing(dp(10));
        grid.setPadding(dp(8), dp(2), dp(8), dp(16));
        grid.setBackgroundColor(C_BG);
        grid.setSelector(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
        adapter = new RoomAdapter();
        grid.setAdapter(adapter);
        grid.setOnItemClickListener(new android.widget.AdapterView.OnItemClickListener() {
            @Override public void onItemClick(android.widget.AdapterView<?> p, View v, int pos, long id) {
                if (pos < rooms.size()) openPlayer(rooms.get(pos));
            }
        });
        root.addView(grid, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        listLayer = root;
        return frame;
    }

    GradientDrawable round(int color, float rdp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(rdp));
        return g;
    }

    /** FrameLayout 定位参数（gravity + 外边距），兼容 minSdk 22 */
    FrameLayout.LayoutParams flp(int w, int h, int gravity, int leftDp, int topDp) {
        FrameLayout.LayoutParams p = new FrameLayout.LayoutParams(w, h, gravity);
        p.leftMargin = dp(leftDp);
        p.topMargin = dp(topDp);
        return p;
    }

    TextView qualityChip(String label) {
        TextView t = new TextView(this);
        t.setText("画质 " + label);
        t.setTextColor(Color.WHITE);
        t.setTextSize(14);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setPadding(dp(12), dp(7), dp(12), dp(7));
        // v4.50.1: 实心强调色 + 白字加粗，画质入口一眼可见
        t.setBackground(round(C_ACC, 16));
        return t;
    }

    String fmtNum(long n) {
        if (n >= 10000) return String.format("%.1f万", n / 10000f);
        return String.valueOf(n);
    }

    // ============================================================ 数据加载

    void loadZones() {
        new Thread(NetPrio.wrap(new Runnable() { @Override public void run() {
            long t0 = System.currentTimeMillis();
            try {
                JSONArray arr = BiliApi.liveAreas();
                NetQuality.heartbeat(arr != null && arr.length() > 0,
                        System.currentTimeMillis() - t0);
                final List<Zone> zs = new ArrayList<>();
                zs.add(new Zone(0, 0, "推荐"));
                if (arr != null) {
                    for (int i = 0; i < arr.length(); i++) {
                        JSONObject o = arr.optJSONObject(i);
                        if (o == null) continue;
                        int pid = o.optInt("id");
                        String pname = o.optString("name");
                        JSONArray sub = o.optJSONArray("list");
                        int lim = Math.min(sub == null ? 0 : sub.length(), 6);
                        for (int j = 0; j < lim; j++) {
                            JSONObject so = sub.optJSONObject(j);
                            int aid = so.optInt("id");
                            String aname = so.optString("name");
                            zs.add(new Zone(pid, aid, aname.isEmpty() ? pname : aname));
                        }
                    }
                }
                ui.post(new Runnable() { @Override public void run() { applyZones(zs); } });
            } catch (final Throwable e) {
                ui.post(new Runnable() { @Override public void run() {
                    List<Zone> zs = new ArrayList<>();
                    zs.add(new Zone(0, 0, "推荐"));
                    applyZones(zs);
                    loadingTip.setText("分区加载失败，已使用推荐流：" + e.getMessage());
                } });
            }
            NetQuality.heartbeat(false, System.currentTimeMillis() - t0);
        } }, NetPrio.VIDEO)).start();
    }

    void applyZones(List<Zone> zs) {
        zones.clear(); zones.addAll(zs);
        zoneBar.removeAllViews();
        for (int i = 0; i < zones.size(); i++) {
            final int idx = i;
            TextView t = new TextView(this);
            t.setText(zones.get(i).name);
            t.setTextSize(14);
            t.setPadding(dp(12), dp(6), dp(12), dp(6));
            t.setTag(i);
            t.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) {
                if (zoneIndex == idx) return;
                zoneIndex = idx; page = 1; refreshZoneStyle(); loadRooms(true);
            } });
            zoneBar.addView(t, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        }
        refreshZoneStyle();
        loadRooms(true);
    }

    void refreshZoneStyle() {
        for (int i = 0; i < zoneBar.getChildCount(); i++) {
            TextView t = (TextView) zoneBar.getChildAt(i);
            boolean on = i == zoneIndex;
            t.setTextColor(on ? C_ACC : C_SUB);
            t.setTypeface(on ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
            t.setBackground(on ? round((C_ACC & 0x00FFFFFF) | 0x22FFFFFF, 13) : null);
        }
    }

    /** 【v4.52】把房间 JSON 数组落到列表（loadRooms 与并行预热共用同一解析路径）。 */
    void applyRoomArray(JSONArray arr, boolean reset) {
        if (arr == null) { loadingTip.setText(reset ? "该分区暂无直播间，试试其他分区" : "没有更多了"); return; }
        if (reset) rooms.clear();
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.optJSONObject(i);
            if (o == null) continue;
            long rid = o.optLong("roomid");
            String title = o.optString("title");
            String uname = o.optString("uname");
            String cover = o.optString("user_cover");
            if (cover.isEmpty()) cover = o.optString("cover");
            long online = o.optLong("online");
            long uid = o.optLong("uid");
            Room r = new Room(rid, title, uname, cover, online);
            r.uid = uid;
            rooms.add(r);
        }
        adapter.notifyDataSetChanged();
        loadingTip.setText("");
    }

    /** 【v4.59】进程内房间缓存：key=分区+页，弱网失败时先出缓存，避免加载窗口空白 */
    static final android.util.LruCache<String, JSONArray> ROOM_CACHE =
            new android.util.LruCache<String, JSONArray>(12);

    void loadRooms(final boolean reset) {
        if (zones.isEmpty()) return;
        final Zone z = zones.get(zoneIndex);
        if (reset) { page = 1; rooms.clear(); adapter.notifyDataSetChanged(); }
        loadingTip.setText("正在加载直播间…");
        final int p = page;
        final String cacheKey = z.parent + "_" + z.area + "_" + p;
        // 接入 NetPrio(VIDEO)：直播列表与取流同属主链路，优先于封面/后台
        new Thread(NetPrio.wrap(new Runnable() { @Override public void run() {
            long t0 = System.currentTimeMillis();
            try {
                final JSONArray arr = BiliApi.liveRooms(z.parent, z.area, p);
                NetQuality.heartbeat(arr != null && arr.length() > 0,
                        System.currentTimeMillis() - t0);
                if (arr != null && arr.length() > 0) ROOM_CACHE.put(cacheKey, arr);
                ui.post(new Runnable() { @Override public void run() {
                    if (arr == null || arr.length() == 0) {
                        showRoomsOrCache(cacheKey, reset);
                        return;
                    }
                    applyRoomArray(arr, reset);
                } });
            } catch (final Throwable e) {
                final JSONArray cached = ROOM_CACHE.get(cacheKey);
                NetQuality.heartbeat(false, System.currentTimeMillis() - t0);
                ui.post(new Runnable() { @Override public void run() {
                    // 弱网失败：先显示上次成功的列表，窗口不再空白
                    if (cached != null && cached.length() > 0 && applyRoomArrayQuiet(cached, reset)) {
                        loadingTip.setText("网络较弱，显示上次内容");
                    } else {
                        loadingTip.setText("加载失败：" + e.getMessage() + "（点此重试）");
                        loadingTip.setOnClickListener(new View.OnClickListener() {
                            @Override public void onClick(View v) { loadRooms(true); }
                        });
                    }
                } });
            }
        } }, NetPrio.VIDEO)).start();
    }

    /** 失败时尝试用缓存填充；成功返回 true */
    boolean showRoomsOrCache(String cacheKey, boolean reset) {
        JSONArray cached = ROOM_CACHE.get(cacheKey);
        return applyRoomArrayQuiet(cached, reset);
    }

    /** applyRoomArray 的不改提示版本（返回是否有有效数据） */
    boolean applyRoomArrayQuiet(JSONArray arr, boolean reset) {
        if (arr == null || arr.length() == 0) return false;
        if (reset) rooms.clear();
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.optJSONObject(i);
            if (o == null) continue;
            long rid = o.optLong("roomid");
            String title = o.optString("title");
            String uname = o.optString("uname");
            String cover = o.optString("user_cover");
            if (cover.isEmpty()) cover = o.optString("cover");
            long online = o.optLong("online");
            long uid = o.optLong("uid");
            Room r = new Room(rid, title, uname, cover, online);
            r.uid = uid;
            rooms.add(r);
        }
        adapter.notifyDataSetChanged();
        return true;
    }

    void loadMore() {
        page++;
        loadRooms(false);
    }

    // ============================================================ 房间网格适配器

    class RoomAdapter extends BaseAdapter {
        @Override public int getCount() { return rooms.size(); }
        @Override public Object getItem(int i) { return rooms.get(i); }
        @Override public long getItemId(int i) { return rooms.get(i).roomId; }

        @Override public View getView(int i, View cv, ViewGroup parent) {
            Holder h;
            View v = cv;
            if (v == null) {
                v = new LinearLayout(LiveActivity.this);
                LinearLayout card = (LinearLayout) v;
                card.setOrientation(LinearLayout.VERTICAL);
                card.setBackground(round(C_CARD, 10));
                card.setPadding(0, 0, 0, dp(8));

                FrameLayout coverWrap = new FrameLayout(LiveActivity.this);
                h = new Holder();
                h.cover = new ImageView(LiveActivity.this);
                h.cover.setScaleType(ImageView.ScaleType.CENTER_CROP);
                h.cover.setBackgroundColor(0xFF2a2e37);
                coverWrap.addView(h.cover, new FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, dp(100)));
                h.online = new TextView(LiveActivity.this);
                h.online.setTextColor(Color.WHITE);
                h.online.setTextSize(11);
                h.online.setBackground(round(0x99000000, 8));
                h.online.setPadding(dp(6), dp(2), dp(6), dp(2));
                coverWrap.addView(h.online, new FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                        Gravity.BOTTOM | Gravity.END));
                card.addView(coverWrap, new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, dp(100)));

                h.title = new TextView(LiveActivity.this);
                h.title.setTextColor(C_FG);
                h.title.setTextSize(13);
                h.title.setMaxLines(2);
                h.title.setEllipsize(android.text.TextUtils.TruncateAt.END);
                h.title.setPadding(dp(8), dp(6), dp(8), 0);
                card.addView(h.title, new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
                h.uname = new TextView(LiveActivity.this);
                h.uname.setTextColor(C_SUB);
                h.uname.setTextSize(11);
                h.uname.setMaxLines(1);
                h.uname.setEllipsize(android.text.TextUtils.TruncateAt.END);
                h.uname.setPadding(dp(8), dp(2), dp(8), 0);
                card.addView(h.uname, new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
                v.setTag(h);
            } else h = (Holder) v.getTag();
            Room r = rooms.get(i);
            ImgLoader.load(h.cover, r.cover, 360, 200);
            h.title.setText(r.title);
            h.uname.setText("UP " + r.uname);
            h.online.setText("● " + fmtNum(r.online));
            if (i == rooms.size() - 1 && rooms.size() >= 10 && page < 50) loadMore();
            return v;
        }
        class Holder { ImageView cover; TextView title, uname, online; }
    }

    // ============================================================ 画质 / 缩放

    /** 画质选择：标清 / 高清 / 2K。inPlayer=true 时切换后立即重连当前房间。 */
    void showQualityDialog(final boolean inPlayer) {
        new android.app.AlertDialog.Builder(this)
                .setTitle("直播画质")
                .setSingleChoiceItems(QN_LABEL, qnIndex, new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface d, int which) {
                        qnIndex = which;
                        qualityBtn.setText("画质 " + QN_LABEL[qnIndex]);
                        if (playQualityBtn != null) playQualityBtn.setText("画质 " + QN_LABEL[qnIndex]);
                        d.dismiss();
                        Toast.makeText(LiveActivity.this, "画质：" + QN_LABEL[qnIndex], Toast.LENGTH_SHORT).show();
                        // 【v4.43 流畅度】播放中选画质：复用当前播放器直接重连，不重建页面
                        if (inPlayer && playing && curRoom != null) openPlayer(curRoom);
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    /** 画面缩放：铺满 / 适应 / 小窗 三档循环。用 FrameLayout 尺寸 + gravity 实现，零依赖。 */
    void toggleScale() {
        scaleMode = (scaleMode + 1) % SCALE_LABEL.length;
        if (playScaleBtn != null) playScaleBtn.setText(SCALE_LABEL[scaleMode]);
        applyVideoScale();
        Toast.makeText(this, "画面：" + SCALE_LABEL[scaleMode], Toast.LENGTH_SHORT).show();
    }

    // ============================================================ v4.51 全屏播放
    /** 进入全屏：横屏 + 隐藏系统栏 + 视频铺满；与缩放档位互不干扰，退出后恢复原档位。 */
    void enterFullscreen() {
        if (fullscreen) return;
        fullscreen = true;
        try { setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE); } catch (Throwable ignore) {}
        hideSystemBars();
        if (videoBox != null) {
            videoBox.setLayoutParams(new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        }
        if (playFullBtn != null) playFullBtn.setText("退出全屏");
        Toast.makeText(this, "全屏播放 · 点「退出全屏」或按返回键恢复", Toast.LENGTH_SHORT).show();
    }

    /** 退出全屏：回竖屏 + 显示系统栏 + 按当前缩放档位重新布局。 */
    void exitFullscreen() {
        if (!fullscreen) return;
        fullscreen = false;
        try { setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT); } catch (Throwable ignore) {}
        showSystemBars();
        if (playFullBtn != null) playFullBtn.setText("全屏");
        applyVideoScale();
    }

    void hideSystemBars() {
        try {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        } catch (Throwable ignore) {}
    }

    void showSystemBars() {
        // 【v4.60】恢复沉浸态图标明暗
        try { ImmersiveBars.restore(this); }
        catch (Throwable ignore) {}
    }

    /**
     * 按档位调整视频容器尺寸（居中，按 16:9 计算，避免拉伸变形）。
     *  · 铺满：MATCH_PARENT，画面裁切不留黑边
     *  · 适应：完整显示 16:9 画面，上下留黑边
     *  · 小窗：屏宽 62% 的 16:9 悬浮窗，居中
     */
    void applyVideoScale() {
        if (videoBox == null || video == null) return;
        // v4.51 全屏态始终铺满，不被缩放档位覆盖
        if (fullscreen) {
            videoBox.setLayoutParams(new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            return;
        }
        int screenW = getResources().getDisplayMetrics().widthPixels;
        int screenH = getResources().getDisplayMetrics().heightPixels;
        FrameLayout.LayoutParams lp;
        if (scaleMode == 0) {
            lp = new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        } else if (scaleMode == 1) {
            int w = screenW;
            int h = (int) (w * 9f / 16f);
            if (h > screenH) { h = screenH; w = (int) (h * 16f / 9f); }
            lp = new FrameLayout.LayoutParams(w, h, Gravity.CENTER);
        } else {
            int w = (int) (screenW * 0.62f);
            int h = (int) (w * 9f / 16f);
            lp = new FrameLayout.LayoutParams(w, h, Gravity.CENTER);
        }
        videoBox.setLayoutParams(lp);
        videoBox.setBackgroundColor(Color.BLACK);
    }

    // ============================================================ 播放

    /**
     * 【v4.41】打开直播间：请求序号隔离 + 代际隔离 + 多线路。
     * 旧请求（比如快速连点两个房间 / 播放中切画质）的回调会被序号拦下，不会污染当前播放。
     * 【v4.43 流畅度】去掉了弹幕 WebSocket 连接与主播详情请求：切房间只做「取流 → 起播」一件事。
     */
    void openPlayer(final Room room) {
        if (!proxy.available()) { Toast.makeText(this, "直播代理启动失败", Toast.LENGTH_SHORT).show(); return; }
        final int seq = playSeq.incrementAndGet();   // 本次请求的序号
        proxy.newGeneration();                       // 关闭上一场直播的遗留连接，释放线程
        curRoom = room;
        retryCount = 0;
        if (playLayer == null) {
            playLayer = buildPlayer();
            ((FrameLayout) findViewById(android.R.id.content)).addView(playLayer, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        }
        playLayer.setVisibility(View.VISIBLE);
        loadingTip.setText("正在获取直播流…");
        // 【v4.43 流畅度】起播前先停旧解码器，避免切房间时两个解码器抢资源导致卡死
        if (video != null) { try { video.stopPlayback(); } catch (Throwable ignore) {} }
        // v4.51 取流线程接入 NetPrio(VIDEO)：进程级优先级真正生效，取址优先拿 CPU 且不抢 UI
        new Thread(NetPrio.wrap(new Runnable() { @Override public void run() {
            long t0 = System.currentTimeMillis();
            try {
                final String[] urls = BiliApi.livePlayUrls(room.roomId, QNS[qnIndex]);
                NetQuality.heartbeat(urls != null && urls.length > 0,
                        System.currentTimeMillis() - t0);
                ui.post(new Runnable() { @Override public void run() {
                    if (seq != playSeq.get()) return;   // 已被更新的请求取代，丢弃
                    if (urls == null || urls.length == 0) {
                        loadingTip.setText("该直播间未开播或暂不可播，换一个试试");
                        return;
                    }
                    startPlay(proxy.wrap(urls), room);
                } });
            } catch (final Throwable e) {
                NetQuality.heartbeat(false, System.currentTimeMillis() - t0);
                ui.post(new Runnable() { @Override public void run() {
                    if (seq != playSeq.get()) return;
                    loadingTip.setText("获取直播流失败：" + e.getMessage());
                } });
            }
        } }, NetPrio.VIDEO)).start();
    }

    void startPlay(String localUrl, final Room room) {
        playing = true;
        userPaused = false;
        loadingTip.setText("");
        if (playTitle != null) playTitle.setText(room.title != null && !room.title.isEmpty() ? room.title : "直播间");
        if (playQualityBtn != null) playQualityBtn.setText("画质 " + QN_LABEL[qnIndex]);
        applyVideoScale();

        video.setVisibility(View.VISIBLE);
        try { video.reset(); } catch (Throwable ignore) {}
        video.setVideoPath(localUrl);
        mc.show(3500);
        try {
            video.start();
        } catch (Throwable e) {
            Toast.makeText(this, "播放启动失败：" + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    // ============================================================ 播放层 UI（极简）

    View buildPlayer() {
        FrameLayer fl = new FrameLayer(this);
        fl.setBackgroundColor(Color.BLACK);

        // 视频容器（缩放改它的尺寸）
        videoBox = new android.widget.FrameLayout(this);
        videoBox.setBackgroundColor(Color.BLACK);
        fl.addView(videoBox, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        video = new TxVideoView(this);
        videoBox.addView(video, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        mc = new MediaController(this);
        mc.setAnchorView(video);
        mc.setMediaPlayer(video.innerView());

        // 顶部极简栏：返回 + 房间标题 + 画质 + 缩放（渐变黑底）
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(6), dp(6), dp(8), dp(6));
        bar.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0xBB000000, 0x00000000}));
        ImageView back = Ic.view(this, "back", Color.WHITE, 20);
        back.setPadding(dp(6), dp(4), dp(6), dp(4));
        back.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { exitPlayer(); } });
        bar.addView(back, new LinearLayout.LayoutParams(dp(36), dp(36)));

        playTitle = new TextView(this);
        playTitle.setText(curRoom != null ? curRoom.title : "直播间");
        playTitle.setTextColor(Color.WHITE);
        playTitle.setTextSize(14);
        playTitle.setTypeface(Typeface.DEFAULT_BOLD);
        playTitle.setMaxLines(1);
        playTitle.setEllipsize(android.text.TextUtils.TruncateAt.END);
        bar.addView(playTitle, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        playQualityBtn = qualityChip(QN_LABEL[qnIndex]);
        playQualityBtn.setTextColor(Color.WHITE);
        playQualityBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showQualityDialog(true); }
        });
        bar.addView(playQualityBtn, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        playScaleBtn = new TextView(this);
        playScaleBtn.setText(SCALE_LABEL[scaleMode]);
        playScaleBtn.setTextColor(Color.WHITE);
        playScaleBtn.setTextSize(12);
        playScaleBtn.setPadding(dp(8), dp(5), dp(8), dp(5));
        playScaleBtn.setBackground(round(0x44000000, 12));
        playScaleBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { toggleScale(); }
        });
        bar.addView(playScaleBtn, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // v4.51 全屏按钮：实心高亮，点一下横屏全屏，再点（或返回键）退出
        playFullBtn = new TextView(this);
        playFullBtn.setText("全屏");
        playFullBtn.setTextColor(Color.WHITE);
        playFullBtn.setTextSize(12);
        playFullBtn.setTypeface(Typeface.DEFAULT_BOLD);
        playFullBtn.setPadding(dp(10), dp(5), dp(10), dp(5));
        playFullBtn.setBackground(round(C_ACC, 12));
        playFullBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (fullscreen) exitFullscreen(); else enterFullscreen();
            }
        });
        bar.addView(playFullBtn, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        fl.addView(bar, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP));

        video.setOnPreparedListener(new android.media.MediaPlayer.OnPreparedListener() {
            @Override public void onPrepared(android.media.MediaPlayer mp) { mc.show(3500); }
        });
        video.setOnErrorListener(new android.media.MediaPlayer.OnErrorListener() {
            @Override public boolean onError(android.media.MediaPlayer mp, int what, int extra) {
                if (!playing || userPaused) return true;
                retryCount++;
                if (retryCount > MAX_RETRY) {
                    // 有限重连：彻底放弃并给明确出路，避免无限重连把线程/解码器耗尽
                    Toast.makeText(LiveActivity.this, "直播流多次中断，请换个直播间", Toast.LENGTH_LONG).show();
                    exitPlayer();
                    return true;
                }
                Toast.makeText(LiveActivity.this,
                        "直播流中断，正在重连（" + retryCount + "/" + MAX_RETRY + "）…", Toast.LENGTH_SHORT).show();
                ui.postDelayed(new Runnable() {
                    @Override public void run() {
                        if (playing && curRoom != null) openPlayer(curRoom);
                    }
                }, 800 * retryCount);
                return true;
            }
        });
        return fl;
    }

    /** 视频层容器：拦截点击以呼出 MediaController */
    static class FrameLayer extends FrameLayout {
        LiveActivity act;
        FrameLayer(LiveActivity a) { super(a); act = a; setClickable(true); }
        @Override public boolean onTouchEvent(android.view.MotionEvent e) {
            if (act.mc != null) act.mc.show();
            return super.onTouchEvent(e);
        }
    }

    void exitPlayer() {
        // 先让所有异步回调失效，避免退出后旧请求又把播放器拉起来
        playSeq.incrementAndGet();
        releasePlayer();
        if (playLayer != null) playLayer.setVisibility(View.GONE);
        playing = false;
        retryCount = 0;
        loadingTip.setText("");
        // v4.51 退出直播间时复位全屏态与系统栏
        if (fullscreen) { fullscreen = false; showSystemBars(); if (playFullBtn != null) playFullBtn.setText("全屏"); }
        // 竖屏回到列表
        try { setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT); } catch (Throwable ignore) {}
    }

    void releasePlayer() {
        if (video != null) {
            try { video.stopPlayback(); } catch (Throwable ignore) {}
            try { video.setVisibility(View.GONE); } catch (Throwable ignore) {}
        }
    }
}
