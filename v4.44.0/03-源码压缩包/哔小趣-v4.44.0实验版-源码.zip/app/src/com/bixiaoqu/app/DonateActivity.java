package com.bixiaoqu.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

/**
 * 【v4.44】捐赠页 —— 捐赠后解锁登录。
 *
 * 说明文字由需求方给定；金额档位：1 / 5 / 10 / 100 元 + 自定义（最低 1 元）。
 * 收款码为需求方提供的微信 / 支付宝静态收款码（裁剪自原图，保留四角定位符与白边）。
 * 由于是个人静态收款码，App 无法收到官方支付回调，故采用「用户支付后自行确认激活」：
 * 用户扫码付款成功 → 点「我已完成支付」→ 二次确认 → 本地写入捐赠凭证 → 解锁登录。
 */
public class DonateActivity extends Activity {

    final int[] AMOUNTS = {1, 5, 10, 100};
    int selectedAmount = 1;          // 当前选中金额（元），自定义时为用户输入值
    boolean customSelected = false;  // 是否处于自定义金额
    String method = "wechat";        // wechat | alipay

    int C_BG = 0xFF16181d, C_CARD = 0xFF1f2229, C_FG = 0xFFe8eaf0,
            C_SUB = 0xFF9aa0ab, C_ACC = 0xFFfb7299;
    int appliedStamp = -1;

    LinearLayout amountRow;
    TextView[] amountViews = new TextView[4];
    TextView customBtn;
    ImageView qrImage;
    TextView payHint;
    TextView wechatTab, alipayTab;
    TextView stateText;

    int dp(float v) { return (int) (getResources().getDisplayMetrics().density * v + 0.5f); }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        MainActivity.applyTheme(this);
        syncTheme();
        appliedStamp = MainActivity.themeStampOf(this);
        setContentView(build());
    }

    void syncTheme() {
        try {
            C_BG = MainActivity.C_BG; C_CARD = MainActivity.C_CARD;
            C_FG = MainActivity.C_FG; C_SUB = MainActivity.C_SUB; C_ACC = MainActivity.C_ACC;
        } catch (Throwable ignore) {}
    }

    @Override protected void onResume() {
        super.onResume();
        if (appliedStamp != MainActivity.themeStampOf(this)) recreate();
    }

    GradientDrawable round(int color, float rdp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(rdp));
        return g;
    }

    View build() {
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(C_BG);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(12), dp(16), dp(28));

        // ---- 顶栏 ----
        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        ImageView back = Ic.view(this, "back", C_FG, 22);
        back.setPadding(dp(6), dp(6), dp(10), dp(6));
        back.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { finish(); }
        });
        top.addView(back, new LinearLayout.LayoutParams(dp(40), dp(44)));
        TextView title = new TextView(this);
        title.setText("支持我们");
        title.setTextColor(C_FG);
        title.setTextSize(19);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        top.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        root.addView(top, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // ---- 已解锁状态条（已捐赠时显示）----
        stateText = new TextView(this);
        stateText.setTextSize(12.5f);
        stateText.setPadding(dp(12), dp(10), dp(12), dp(10));
        stateText.setBackground(round(C_CARD, 10));
        if (Prefs.donated(this)) {
            String m = "微信".equals(Prefs.donateMethod(this)) ? "微信" : "支付宝";
            stateText.setText("✓ 感谢你的支持 · 已通过" + m + "捐赠 "
                    + Prefs.donateAmount(this) + " 元，登录已解锁");
            stateText.setTextColor(0xFF5FD08A);
        } else {
            stateText.setText("尚未解锁登录 · 最低 1 元捐赠即可解锁全部功能");
            stateText.setTextColor(C_ACC);
        }
        root.addView(stateText, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // ---- 说明文字（需求方给定原文）----
        final String desc = "这款软件投入了海量资源与精力打磨，无广告商业化。为持续承载服务、维护更新，"
                + "设置最低1元捐赠，捐赠后即可正常登录使用，您的每一份支持都十分珍贵";
        TextView descTv = new TextView(this);
        descTv.setText(desc);
        descTv.setTextColor(C_FG);
        descTv.setTextSize(14.5f);
        descTv.setLineSpacing(dp(5), 1f);
        descTv.setPadding(dp(14), dp(14), dp(14), dp(14));
        descTv.setBackground(round(C_CARD, 12));
        root.addView(descTv, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // ---- 金额选择 ----
        TextView amountTitle = new TextView(this);
        amountTitle.setText("选择捐赠金额（最低 1 元）");
        amountTitle.setTextColor(C_SUB);
        amountTitle.setTextSize(13);
        amountTitle.setPadding(dp(2), dp(18), dp(2), dp(8));
        root.addView(amountTitle, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        amountRow = new LinearLayout(this);
        amountRow.setOrientation(LinearLayout.HORIZONTAL);
        for (int i = 0; i < AMOUNTS.length; i++) {
            final int idx = i;
            TextView t = amountChip(AMOUNTS[i] + " 元");
            t.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    customSelected = false;
                    selectedAmount = AMOUNTS[idx];
                    refreshAmountChips();
                }
            });
            amountViews[i] = t;
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            if (i > 0) lp.leftMargin = dp(8);
            amountRow.addView(t, lp);
        }
        root.addView(amountRow, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        customBtn = amountChip("自定义");
        customBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showCustomAmountDialog(); }
        });
        LinearLayout.LayoutParams cbp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        cbp.topMargin = dp(10);
        root.addView(customBtn, cbp);

        // ---- 支付方式 Tab ----
        TextView payTitle = new TextView(this);
        payTitle.setText("选择支付方式，扫码捐赠");
        payTitle.setTextColor(C_SUB);
        payTitle.setTextSize(13);
        payTitle.setPadding(dp(2), dp(20), dp(2), dp(10));
        root.addView(payTitle, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout tabs = new LinearLayout(this);
        tabs.setOrientation(LinearLayout.HORIZONTAL);
        wechatTab = payTab("微信支付", 0xFF07C160);
        alipayTab = payTab("支付宝", 0xFF1677FF);
        wechatTab.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { switchMethod("wechat"); }
        });
        alipayTab.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { switchMethod("alipay"); }
        });
        tabs.addView(wechatTab, new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        alipayTab.setPadding(dp(10), dp(10), dp(10), dp(10));
        LinearLayout.LayoutParams atp = new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        atp.leftMargin = dp(10);
        tabs.addView(alipayTab, atp);
        root.addView(tabs, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // ---- 收款码卡片 ----
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackgroundColor(Color.WHITE);
        card.setPadding(dp(18), dp(18), dp(18), dp(18));
        qrImage = new ImageView(this);
        qrImage.setScaleType(ImageView.ScaleType.FIT_CENTER);
        qrImage.setAdjustViewBounds(true);
        card.addView(qrImage, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(300)));
        payHint = new TextView(this);
        payHint.setTextColor(0xFF333333);
        payHint.setTextSize(12.5f);
        payHint.setGravity(Gravity.CENTER);
        payHint.setPadding(0, dp(10), 0, 0);
        card.addView(payHint, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        LinearLayout.LayoutParams ccp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        ccp.topMargin = dp(12);
        root.addView(card, ccp);

        // ---- 支付说明 ----
        TextView tip = new TextView(this);
        tip.setText("支付方式：打开对应 App 扫码 → 支付" + selectedAmount + " 元 → 回到本页点下方按钮完成激活");
        tip.setTextColor(C_SUB);
        tip.setTextSize(11.5f);
        tip.setGravity(Gravity.CENTER);
        tip.setPadding(dp(4), dp(14), dp(4), dp(4));
        root.addView(tip, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // ---- 确认按钮 ----
        TextView confirm = new TextView(this);
        confirm.setText("我已完成支付，解锁登录");
        confirm.setTextColor(Color.WHITE);
        confirm.setTextSize(15);
        confirm.setTypeface(Typeface.DEFAULT_BOLD);
        confirm.setGravity(Gravity.CENTER);
        confirm.setPadding(dp(12), dp(14), dp(12), dp(14));
        confirm.setBackground(round(C_ACC, 12));
        confirm.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { confirmPaid(); }
        });
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        cp.topMargin = dp(16);
        root.addView(confirm, cp);

        // ---- 底部小字 ----
        TextView foot = new TextView(this);
        foot.setText("捐赠凭证仅保存在本机，用于解锁登录，不涉及任何账号隐私");
        foot.setTextColor(C_SUB);
        foot.setTextSize(10.5f);
        foot.setGravity(Gravity.CENTER);
        foot.setPadding(0, dp(14), 0, 0);
        root.addView(foot, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        sv.addView(root, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        refreshAmountChips();
        switchMethod(method);
        return sv;
    }

    TextView amountChip(String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(13.5f);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(6), dp(11), dp(6), dp(11));
        return t;
    }

    void refreshAmountChips() {
        for (int i = 0; i < amountViews.length; i++) {
            boolean on = !customSelected && selectedAmount == AMOUNTS[i];
            amountViews[i].setTextColor(on ? Color.WHITE : C_FG);
            amountViews[i].setBackground(round(on ? C_ACC : C_CARD, 10));
        }
        customBtn.setText(customSelected ? ("自定义 " + selectedAmount + " 元") : "自定义");
        customBtn.setTextColor(customSelected ? Color.WHITE : C_FG);
        customBtn.setBackground(round(customSelected ? C_ACC : C_CARD, 10));
    }

    TextView payTab(String text, int brand) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(14);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(10), dp(11), dp(10), dp(11));
        t.setTag(brand);
        return t;
    }

    void switchMethod(String m) {
        method = m;
        boolean wc = "wechat".equals(m);
        int active = wc ? 0xFF07C160 : 0xFF1677FF;
        wechatTab.setTextColor(wc ? Color.WHITE : 0xFF07C160);
        wechatTab.setBackground(round(wc ? active : 0x2207C160, 10));
        alipayTab.setTextColor(wc ? 0xFF1677FF : Color.WHITE);
        alipayTab.setBackground(round(wc ? 0x221677FF : active, 10));

        int rid = getResources().getIdentifier(
                wc ? "donate_wechat_qr" : "donate_alipay_qr", "drawable", getPackageName());
        if (rid != 0) qrImage.setImageResource(rid);
        payHint.setText(wc ? "打开微信扫一扫 · 捐赠 " + selectedAmount + " 元"
                : "打开支付宝扫一扫 · 捐赠 " + selectedAmount + " 元");
    }

    void showCustomAmountDialog() {
        final EditText et = new EditText(this);
        et.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        et.setHint("输入金额（元，最低 1 元）");
        et.setTextColor(C_FG);
        et.setHintTextColor(C_SUB);
        new AlertDialog.Builder(this)
                .setTitle("自定义捐赠金额")
                .setView(et)
                .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        String s = et.getText().toString().trim();
                        int v;
                        try { v = (int) Math.floor(Double.parseDouble(s)); }
                        catch (Throwable e) { v = 0; }
                        if (v < 1) {
                            Toast.makeText(DonateActivity.this, "金额不能低于 1 元", Toast.LENGTH_SHORT).show();
                            return;
                        }
                        customSelected = true;
                        selectedAmount = v;
                        refreshAmountChips();
                        switchMethod(method);
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    void confirmPaid() {
        if (selectedAmount < 1) {
            Toast.makeText(this, "请先选择至少 1 元的金额", Toast.LENGTH_SHORT).show();
            return;
        }
        String way = "wechat".equals(method) ? "微信" : "支付宝";
        new AlertDialog.Builder(this)
                .setTitle("确认已完成支付？")
                .setMessage("请确认你已通过" + way + "扫码支付 " + selectedAmount
                        + " 元。\n\n确认后将解锁登录功能。感谢你的支持！")
                .setPositiveButton("已支付，确认解锁", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        Prefs.setDonated(DonateActivity.this, selectedAmount, method);
                        Toast.makeText(DonateActivity.this, "感谢支持！登录已解锁", Toast.LENGTH_LONG).show();
                        stateText.setText("✓ 感谢你的支持 · 已通过"
                                + ("wechat".equals(method) ? "微信" : "支付宝") + "捐赠 "
                                + selectedAmount + " 元，登录已解锁");
                        stateText.setTextColor(0xFF5FD08A);
                        setResult(RESULT_OK);
                    }
                })
                .setNegativeButton("还没支付", null)
                .show();
    }
}
