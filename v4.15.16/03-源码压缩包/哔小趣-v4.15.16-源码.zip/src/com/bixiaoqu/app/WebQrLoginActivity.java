package com.bixiaoqu.app;

import android.app.Activity;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.Date;

/**
 * 【v4.15.16】官方扫码页 + 页内放大，不再自己重画二维码。
 *
 * 上一版（v4.15.15）的问题：从官方页面 DOM 取二维码链接 → 用 ZXing 本地重画。
 * 只要链接没取到（选择器变了 / title 不存 URL）或编码失败，屏幕就是一片白框。
 *
 * 本版换思路：**页面里的二维码长什么样，就放大显示什么样**。
 *  WebView 可见、桌面 UA 打开官方登录页（官网自己生成码、自己轮询、自己管会话），
 *  注入一段 JS 把页面中的二维码 <img>/<canvas> 克隆到一个全屏遮罩里放大居中。
 *  克隆的图每 1.5 秒与源元素同步一次，官方换码时屏幕上的码也跟着换。
 *
 * 这样做的好处：
 *  1) 二维码是官网自己渲染的，我们不做编码，不存在「编码失败」这一环；
 *  2) 取不到元素时遮罩不插入，官方页面本身仍然可见，用户照样能扫；
 *  3) 会话与轮询全在官网页面里，Cookie 天然完整（含 DedeUserID__ckMd5 / sid）。
 */
public class WebQrLoginActivity extends Activity {

    static final String DESKTOP_UA =
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                    + "(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36";

    static final String LOGIN_URL = "https://passport.bilibili.com/login";

    /** 找到页面里的二维码元素 → 全屏遮罩放大 → 之后每次调用只做源/副本同步 */
    static final String JS_QR =
            "(function(){try{"
                    + "var st=window.__bxqQr;"
                    + "if(st&&st.sync){st.sync();return 'sync';}"
                    + "function pick(){"
                    + "var sels=['.login-scan__qrcode img','.login-scan__qrcode canvas',"
                    + "'[class*=qrcode] img','[class*=qrcode] canvas',"
                    + "'[class*=scan] img','[class*=scan] canvas','canvas','img'];"
                    + "for(var s=0;s<sels.length;s++){var list=document.querySelectorAll(sels[s]);"
                    + "for(var i=0;i<list.length;i++){var el=list[i];"
                    + "var w=el.clientWidth||el.width||0,h=el.clientHeight||el.height||0;"
                    + "if(!w||!h)continue;"
                    + "if(w<110||h<110)continue;"
                    + "if(Math.abs(w-h)>Math.max(24,w*0.3))continue;"
                    + "return el;}}return null;}"
                    + "var el=pick();if(!el)return 'none';"
                    + "var vw=document.documentElement.clientWidth||window.innerWidth||360;"
                    + "var vh=document.documentElement.clientHeight||window.innerHeight||640;"
                    + "var total=Math.round(Math.min(vw*0.88,vh*0.62));"
                    + "if(total<260)total=260;"
                    + "var pad=Math.round(total*0.085);"
                    + "var size=total-pad*2;"
                    + "var wrap=document.createElement('div');wrap.id='bxqQrWrap';"
                    + "wrap.style.cssText='position:fixed;left:0;top:0;width:100%;height:100%;"
                    + "z-index:2147483647;background:#0f0f12;display:-webkit-box;display:flex;"
                    + "-webkit-box-align:center;align-items:center;"
                    + "-webkit-box-pack:center;justify-content:center;';"
                    + "var box=document.createElement('div');"
                    + "box.style.cssText='background:#ffffff;padding:'+pad+'px;border-radius:12px;';"
                    + "var im=document.createElement('img');im.setAttribute('alt','');"
                    + "im.style.cssText='display:block;width:'+size+'px;height:'+size+'px;';"
                    + "var s0=(el.tagName==='CANVAS')?el.toDataURL('image/png'):(el.currentSrc||el.src||'');"
                    + "if(s0)im.src=s0;"
                    + "box.appendChild(im);wrap.appendChild(box);document.body.appendChild(wrap);"
                    + "window.__bxqQr={el:el,im:im,sig:s0?(''+s0.length+s0.slice(0,24)):'',sync:function(){"
                    + "try{var s=(el.tagName==='CANVAS')?el.toDataURL('image/png'):(el.currentSrc||el.src||'');"
                    + "var g=s?(''+s.length+s.slice(0,24)):'';"
                    + "if(g&&g!==window.__bxqQr.sig){window.__bxqQr.sig=g;im.src=s;}"
                    + "}catch(e){}}};"
                    + "return 'ok:'+size;"
                    + "}catch(e){return 'err:'+e;}})()";

    /** 撤掉遮罩，露出官方原始页面（可改用短信 / 密码登录） */
    static final String JS_SHOW_PAGE =
            "(function(){try{var w=document.getElementById('bxqQrWrap');"
                    + "if(w&&w.parentNode)w.parentNode.removeChild(w);"
                    + "window.__bxqQr=null;return 'ok';}catch(e){return 'err';}})()";

    LinearLayout root;
    TextView tip;
    WebView wv;
    Handler ui = new Handler(Looper.getMainLooper());

    boolean done = false;
    boolean masked = false;      // 遮罩是否已挂上（决定提示文案）
    boolean probing = false;     // 防止出现两条探针循环
    int probeCount = 0;
    int cookieTries = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            build();
        } catch (Throwable e) {
            fallback(e);
        }
    }

    void build() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF0F0F12);
        root.setGravity(Gravity.CENTER_HORIZONTAL);

        TextView head = new TextView(this);
        head.setText("扫码登录 B 站");
        head.setTextColor(Color.WHITE);
        head.setTextSize(17);
        head.setGravity(Gravity.CENTER);
        head.setPadding(0, 40, 0, 8);
        root.addView(head);

        tip = new TextView(this);
        tip.setText("正在打开 B 站官方扫码页…");
        tip.setTextColor(Color.parseColor("#fb7299"));
        tip.setTextSize(12);
        tip.setGravity(Gravity.CENTER);
        tip.setPadding(24, 0, 24, 8);
        root.addView(tip);

        // 官方页面本体：可见、占满中间，遮罩在页面内部铺满这块区域
        wv = new WebView(this);
        wv.setBackgroundColor(0xFF0F0F12);
        try {
            WebSettings s = wv.getSettings();
            s.setJavaScriptEnabled(true);
            s.setDomStorageEnabled(true);
            s.setUserAgentString(DESKTOP_UA);
            s.setUseWideViewPort(false);
            s.setLoadWithOverviewMode(true);
            s.setSupportZoom(false);
            s.setBuiltInZoomControls(false);
            s.setDisplayZoomControls(false);
            s.setCacheMode(WebSettings.LOAD_DEFAULT);
            if (android.os.Build.VERSION.SDK_INT >= 21) {
                try { s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW); } catch (Throwable ignore) { }
            }
        } catch (Throwable ignore) { }

        CookieManager.getInstance().setAcceptCookie(true);
        if (android.os.Build.VERSION.SDK_INT >= 21) {
            try { CookieManager.getInstance().setAcceptThirdPartyCookies(wv, true); } catch (Throwable ignore) { }
        }

        wv.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                try { probeCount = 0; startProbe(); } catch (Throwable ignore) { }
                try { checkCookie(); } catch (Throwable ignore) { }
            }

            @Override
            public void onReceivedError(WebView view, int code, String desc, String url) {
                try {
                    if (tip != null) tip.setText("页面加载失败：" + desc + "\n点「换一张」重试，或「短信登录」");
                } catch (Throwable ignore) { }
            }
        });

        LinearLayout.LayoutParams wp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
        root.addView(wv, wp);

        TextView hint = new TextView(this);
        hint.setText("请用 B 站 App 扫码，确认后自动登录");
        hint.setTextColor(0xFFB9B9C0);
        hint.setTextSize(12);
        hint.setGravity(Gravity.CENTER);
        hint.setPadding(24, 8, 24, 4);
        root.addView(hint);

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER);

        Button again = new Button(this);
        again.setText("换一张");
        again.setTextColor(Color.WHITE);
        again.setBackgroundColor(0xFF2B2B2B);
        again.setAllCaps(false);
        again.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { reload(); }
        });
        bar.addView(again);

        Button page = new Button(this);
        page.setText("完整页面");
        page.setTextColor(Color.parseColor("#fb7299"));
        page.setBackgroundColor(Color.TRANSPARENT);
        page.setAllCaps(false);
        page.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showFullPage(); }
        });
        bar.addView(page);

        Button sms = new Button(this);
        sms.setText("短信登录");
        sms.setTextColor(Color.parseColor("#fb7299"));
        sms.setBackgroundColor(Color.TRANSPARENT);
        sms.setAllCaps(false);
        sms.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                startActivity(new android.content.Intent(
                        WebQrLoginActivity.this, WebViewLoginActivity.class));
                finish();
            }
        });
        bar.addView(sms);

        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        bp.setMargins(0, 0, 0, 18);
        root.addView(bar, bp);

        setContentView(root);
        wv.loadUrl(LOGIN_URL);

        ui.postDelayed(new Runnable() { @Override public void run() { checkCookie(); } }, 900);
        ui.postDelayed(new Runnable() { @Override public void run() { startProbe(); } }, 1200);
    }

    void startProbe() {
        if (probing) return;
        probing = true;
        probe();
    }

    /** 每 1.2 秒跑一次页面脚本：没遮罩就建，有就同步；找不到元素继续等 */
    void probe() {
        if (done || wv == null) return;
        if (probeCount++ > 400) return;
        try {
            wv.evaluateJavascript(JS_QR, new android.webkit.ValueCallback<String>() {
                @Override public void onReceiveValue(String v) {
                    String r = unwrap(v);
                    if (r != null && r.startsWith("ok")) {
                        masked = true;
                        if (tip != null) tip.setText("请用 B 站 App 扫码，3 分钟内有效");
                    } else if (r != null && r.startsWith("err")) {
                        if (tip != null) tip.setText("二维码放大失败，可直接扫下方页面");
                    } else if (!masked && probeCount > 10 && tip != null) {
                        tip.setText("页面二维码未就绪，可点「完整页面」直接扫");
                    }
                }
            });
        } catch (Throwable ignore) { }
        ui.postDelayed(new Runnable() { @Override public void run() { probe(); } }, 1200);
    }

    void showFullPage() {
        try {
            wv.evaluateJavascript(JS_SHOW_PAGE, null);
        } catch (Throwable ignore) { }
        masked = false;
        if (tip != null) tip.setText("官方页面已展开，可直接扫码或改用短信登录");
    }

    void reload() {
        done = false;
        masked = false;
        probeCount = 0;
        if (tip != null) tip.setText("正在刷新二维码…");
        try { if (wv != null) wv.loadUrl(LOGIN_URL); } catch (Throwable ignore) { }
        ui.postDelayed(new Runnable() { @Override public void run() { checkCookie(); } }, 900);
    }

    /** 每 1.2 秒查 Cookie，出现 SESSDATA 即整套取走 */
    void checkCookie() {
        if (done) return;
        if (cookieTries++ > 600) return;
        try {
            String best = "";
            String[] domains = {"https://www.bilibili.com/", "https://passport.bilibili.com/",
                    "https://account.bilibili.com/"};
            for (String d : domains) {
                try {
                    String one = CookieManager.getInstance().getCookie(d);
                    if (one != null && one.length() > best.length()) best = one;
                } catch (Throwable ignore) { }
            }
            if (best.contains("SESSDATA=")) {
                String sess = cookieVal(best, "SESSDATA");
                if (!sess.isEmpty()) { finishLogin(best, sess); return; }
            }
        } catch (Throwable ignore) { }
        ui.postDelayed(new Runnable() { @Override public void run() { checkCookie(); } }, 1200);
    }

    void finishLogin(final String cookieHeader, final String sessdata) {
        done = true;
        try {
            final String jct = cookieVal(cookieHeader, "bili_jct");
            final String uid = cookieVal(cookieHeader, "DedeUserID");
            BiliApi.addCookie(cookieHeader);
            BiliApi.setLoginCookie(sessdata, jct, uid);
            String full = BiliApi.exportLoginCookie();
            SharedPreferences sp = getSharedPreferences("bili_login", MODE_PRIVATE);
            sp.edit().putString("SESSDATA", sessdata)
                    .putString("bili_jct", jct)
                    .putString("DedeUserID", uid)
                    .putString("full_cookie", full.isEmpty() ? cookieHeader : full)
                    .putLong("login_time", System.currentTimeMillis())
                    .apply();
            if (tip != null) tip.setText("登录成功，正在同步账号…");
        } catch (Throwable ignore) { }

        new Thread(new Runnable() { @Override public void run() {
            String name = "";
            for (int i = 0; i < 4; i++) {
                try {
                    org.json.JSONObject nav = BiliApi.navInfo();
                    name = nav.optString("uname", "");
                    if (!name.isEmpty()) break;
                } catch (Throwable ignore) { }
                try { Thread.sleep(900); } catch (InterruptedException ignore) { }
            }
            final String fName = name;
            ui.post(new Runnable() { @Override public void run() {
                if (isFinishing()) return;
                Toast.makeText(WebQrLoginActivity.this,
                        "登录成功 ✓" + (fName.isEmpty() ? "" : " " + fName), Toast.LENGTH_SHORT).show();
                finish();
            } });
        } }, "bxq-qr-verify").start();
    }

    /** 兜底界面：不闪退，把异常原因直接写在屏幕上 */
    void fallback(Throwable e) {
        String stack = android.util.Log.getStackTraceString(e);
        try {
            File dir = getExternalFilesDir(null);
            if (dir == null) dir = getFilesDir();
            PrintWriter pw = new PrintWriter(new FileWriter(new File(dir, "crash.txt"), true));
            pw.println("=== " + new Date() + " WebQrLoginActivity.build");
            pw.println(stack);
            pw.println();
            pw.close();
        } catch (Throwable ignore) { }

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setBackgroundColor(0xFF0F0F12);
        box.setPadding(28, 60, 28, 28);

        String brief = stack;
        String[] lines = stack.split("\n");
        if (lines.length > 7) {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < 7; i++) sb.append(lines[i]).append('\n');
            brief = sb.toString();
        }
        TextView t = new TextView(this);
        t.setText("扫码页打开失败（已避免闪退）\n\n" + brief);
        t.setTextColor(Color.WHITE);
        t.setTextSize(14);
        box.addView(t);

        Button b = new Button(this);
        b.setText("用短信验证码登录");
        b.setAllCaps(false);
        b.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                startActivity(new android.content.Intent(
                        WebQrLoginActivity.this, WebViewLoginActivity.class));
                finish();
            }
        });
        box.addView(b);

        Button cp = new Button(this);
        cp.setText("复制错误详情");
        cp.setAllCaps(false);
        cp.setTag(stack);
        cp.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                try {
                    android.content.ClipboardManager cm =
                            (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                    cm.setPrimaryClip(android.content.ClipData.newPlainText(
                            "bxq-crash", String.valueOf(v.getTag())));
                    Toast.makeText(WebQrLoginActivity.this, "已复制，可直接粘贴发我",
                            Toast.LENGTH_SHORT).show();
                } catch (Throwable ignore) { }
            }
        });
        box.addView(cp);
        setContentView(box);
    }

    static String unwrap(String v) {
        if (v == null || v.equals("null")) return "";
        try { return new org.json.JSONArray("[" + v + "]").getString(0); }
        catch (Throwable ignore) { return v; }
    }

    static String cookieVal(String header, String key) {
        if (header == null) return "";
        for (String pair : header.split(";")) {
            pair = pair.trim();
            int eq = pair.indexOf('=');
            if (eq > 0 && pair.substring(0, eq).equals(key)) return pair.substring(eq + 1);
        }
        return "";
    }

    @Override
    public void onBackPressed() { finish(); }

    @Override
    protected void onDestroy() {
        done = true;
        try { ui.removeCallbacksAndMessages(null); } catch (Throwable ignore) { }
        if (wv != null) {
            try { wv.stopLoading(); wv.destroy(); } catch (Throwable ignore) { }
            wv = null;
        }
        super.onDestroy();
    }
}
