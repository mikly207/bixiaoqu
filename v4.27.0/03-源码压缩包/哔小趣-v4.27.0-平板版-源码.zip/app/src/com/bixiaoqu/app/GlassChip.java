package com.bixiaoqu.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;
import android.widget.ImageView;
import android.widget.LinearLayout;

/**
 * 【v4.25.0】薄玻璃片材质：控制条上的胶囊按钮、圆形按钮。
 *
 * 【为什么旧版一眼就是塑料】
 *   旧版胶囊背景是 0x992A2F3A → 0x8C1D2129 —— 60% 不透明的深灰蓝实色块，
 *   外加一圈 1px 白描边。实色块 + 描边 = 塑料按钮的三个特征，一个不落。
 *   v4.24.0 把实色去掉了，却又铺了一层 0x28 → 0x14 的乳白雾，
 *   等于换成「磨砂塑料」—— 仍然是均匀的一片白，依然没有光学。
 *
 * 【真玻璃长什么样】
 *   玻璃片的身体几乎是「没有颜色」的，它的形状全靠边缘几道光学撑起来：
 *     ① 上缘高光、下缘渐弱 —— 不是均匀一圈白描边；
 *     ② 高光内侧一道细暗线 —— 这是玻璃的厚度；
 *     ③ 左冷右暖的一点色散 —— 塑料不会有；
 *     ④ 左上角一处更亮的反射热点；
 *     ⑤ 下沿被托起的一线反光。
 *   身体只留极淡的一层乳白（让文字能压住底下的画面）+ 极细的颗粒。
 *
 * 【v4.26.0】圆钮玻璃补上「三明治厚度」
 *   面板（GlassPanel）的边缘已经是「外亮线 → 暗线 → 内表面反射」三层，
 *   但圆钮（播放/更多/全屏）还只有两层 —— 材质一对比就会露馅。
 *   这一版给圆钮补上第三层：暗线内侧一道更细更淡的内表面反射，
 *   圆钮于是也从「一圈描边」变成「一片有厚度的玻璃片」。
 *
 * 【v4.27.0】与玻璃面板同步：边框收窄 + 进一步去塑料感
 *   ① 描边全面收窄：0.55~1.2dp → 0.38~0.75dp。
 *      旧版多层描边叠加后接近 2dp 厚，那正是塑料边框的观感。
 *   ② 边缘高光从「垂直渐变（上强下弱）」改成「左上径向衰减」——
 *      圆形没有长边可依托，若还按上下渐变，下半圈会留一道明显的暗弧，
 *      看起来就是半截描边。径向衰减让高光自然绕着左上走一圈、
 *      到右下方彻底消失，形状全靠光学撑住而不是靠一圈线。
 *   ③ 身体更透：乳白雾 0x12/0x08 → 0x0A/0x04；
 *      底缘聚暗 0x24 → 0x14（原来那圈暗把圆钮的下半圈「坐」在地上，像实心按钮）。
 *
 * 本类只画上面这些；主体颜色保持透明；
 * API22 起可用，没有 RenderScript、没有 RenderEffect、没有额外线程。
 */
public class GlassChip extends Drawable {

    private final Paint pFill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pEdge = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pHot = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pInner = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pDisp = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pSpec = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pInner2 = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF box = new RectF();
    private final RectF inset = new RectF();
    private final Path clipPath = new Path();
    private final float den;

    /** 圆角（px）；circle=true 时忽略 */
    private final float radiusPx;
    private final boolean circle;
    /** 浅色主题：玻璃发灰、发暗（白雾换黑雾、白边换暗边） */
    private final boolean light;

    private boolean pressed;
    private int alpha = 255;

    // 着色器按尺寸缓存：静止时零开销，按下态也不重建
    private int shW, shH;
    private Shader shFog, shEdge, shHot, shInner, shDisp, shSpec, shFoot, shFootL, shInner2;

    public GlassChip(Context c, float radiusDp, boolean circle, boolean light) {
        den = c.getResources().getDisplayMetrics().density;
        radiusPx = radiusDp * den;
        this.circle = circle;
        this.light = light;
        pEdge.setStyle(Paint.Style.STROKE);
        pHot.setStyle(Paint.Style.STROKE);
        pInner.setStyle(Paint.Style.STROKE);
        pDisp.setStyle(Paint.Style.STROKE);
        pSpec.setStyle(Paint.Style.STROKE);
        pInner2.setStyle(Paint.Style.STROKE);
    }

    // ------------------------------------------------------------ 工厂

    /** 胶囊形玻璃片（按钮） */
    public static GlassChip pill(Context c, float radiusDp) {
        return new GlassChip(c, radiusDp, false, false);
    }

    /** 浅色主题下的胶囊 */
    public static GlassChip pillLight(Context c, float radiusDp) {
        return new GlassChip(c, radiusDp, false, true);
    }

    /** 正圆玻璃片（播放 / 全屏 / 更多） */
    public static GlassChip round(Context c) {
        return new GlassChip(c, 0, true, false);
    }

    /**
     * 玻璃圆钮图标：图标本体缩到 76%，四周留白由背景的柔光补足，
     * 视觉上比「图标塞满一个深色圆饼」轻得多。
     */
    public static ImageView icon(Context c, String name, int sizeDp) {
        ImageView v = new ImageView(c);
        float d = c.getResources().getDisplayMetrics().density;
        int px = (int) (sizeDp * d + 0.5f);
        v.setBackground(round(c));
        v.setScaleType(ImageView.ScaleType.CENTER);
        int pad = (int) (px * 0.22f);
        v.setPadding(pad, pad, pad, pad);
        int r = Ic.id(c, name);
        if (r != 0) v.setImageResource(r);
        v.setColorFilter(0xFFFFFFFF);
        v.setLayoutParams(new LinearLayout.LayoutParams(px, px));
        return v;
    }

    // ------------------------------------------------------------ 状态

    @Override
    public boolean isStateful() {
        return true;
    }

    @Override
    protected boolean onStateChange(int[] s) {
        boolean p = false;
        for (int i = 0; i < s.length; i++) {
            if (s[i] == android.R.attr.state_pressed) {
                p = true;
                break;
            }
        }
        if (p != pressed) {
            pressed = p;
            invalidateSelf();
        }
        return true;
    }

    @Override
    protected void onBoundsChange(Rect b) {
        shW = 0;   // 尺寸变了，着色器缓存作废
        super.onBoundsChange(b);
    }

    // ------------------------------------------------------------ 绘制

    @Override
    public void draw(Canvas cv) {
        final Rect b = getBounds();
        final int w = b.width(), h = b.height();
        if (w <= 0 || h <= 0) return;

        if (circle) {
            final float s = Math.min(w, h);
            box.set(b.left + (w - s) / 2f, b.top + (h - s) / 2f,
                    b.left + (w + s) / 2f, b.top + (h + s) / 2f);
        } else {
            box.set(b);
        }
        final float r = circle ? box.width() / 2f : Math.min(radiusPx, box.width() / 2f);

        if (w != shW || h != shH) {
            shW = w;
            shH = h;
            if (light) {
                shFog = new LinearGradient(0, box.top, 0, box.bottom,
                        0x0E000000, 0x06000000, Shader.TileMode.CLAMP);
                // 【v4.27.0】浅色主题同样改成左上径向衰减：原来垂直渐变让下半圈
                // 留一道明显暗弧，胶囊看起来像「半截描边」。
                shEdge = new RadialGradient(box.left + box.width() * 0.26f,
                        box.top - box.height() * 0.18f, box.width() * 0.95f,
                        0x3C000000, 0x08000000, Shader.TileMode.CLAMP);
                shHot = new RadialGradient(box.left + box.width() * 0.22f,
                        box.top - box.height() * 0.16f, box.height() * 1.5f,
                        0x20000000, 0x00000000, Shader.TileMode.CLAMP);
                shInner = new RadialGradient(box.left + box.width() * 0.26f,
                        box.top - box.height() * 0.18f, box.width() * 0.9f,
                        0x1E000000, 0x06000000, Shader.TileMode.CLAMP);
                shDisp = new LinearGradient(box.left, 0, box.right, 0,
                        new int[]{0x18003366, 0x00000000, 0x18663311},
                        new float[]{0f, 0.5f, 1f}, Shader.TileMode.CLAMP);
                shSpec = new LinearGradient(0, box.top, 0, box.top + 2.6f * den,
                        0x26000000, 0x00000000, Shader.TileMode.CLAMP);
                shFoot = new LinearGradient(0, box.bottom - h * 0.55f, 0, box.bottom,
                        0x00000000, 0x0A000000, Shader.TileMode.CLAMP);
                // 【v4.26.0】内表面二次反射：暗线内侧一道更细更淡的亮线，
                // 让圆钮边缘成为「外亮线 → 暗线 → 内亮线」的三 sandwich 厚度。
                shInner2 = new LinearGradient(0, box.top, 0, box.bottom,
                        0x34FFFFFF, 0x0CFFFFFF, Shader.TileMode.CLAMP);
            } else {
                // ① 身体：极淡的乳白雾，只够把底下的画面「化开」一点
                // 【v4.27.0】0x12/0x08 → 0x0A/0x04 —— 更透
                shFog = new LinearGradient(0, box.top, 0, box.bottom,
                        0x0AFFFFFF, 0x04FFFFFF, Shader.TileMode.CLAMP);
                // ② 边缘高光：【v4.27.0】垂直渐变 → 左上径向衰减。
                //    圆形没有长边，若按上下渐变，下半圈会剩一道明显的暗弧，
                //    整颗圆钮看上去像「半截描边」。径向衰减让高光绕左上走一圈、
                //    到右下彻底消失 —— 形状由光学撑住，不由一圈线撑住。
                shEdge = new RadialGradient(box.left + box.width() * 0.26f,
                        box.top - box.height() * 0.18f, box.width() * 0.95f,
                        0xB4FFFFFF, 0x10FFFFFF, Shader.TileMode.CLAMP);
                // ③ 高光热点：左上角一处更亮的反射
                shHot = new RadialGradient(box.left + box.width() * 0.2f,
                        box.top - box.height() * 0.2f, box.height() * 2.2f,
                        0x60FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP);
                // ④ 接触暗线：玻璃的厚度（同样改成径向，跟随高光一起转过去）
                shInner = new RadialGradient(box.left + box.width() * 0.26f,
                        box.top - box.height() * 0.18f, box.width() * 0.9f,
                        0x28000000, 0x06000000, Shader.TileMode.CLAMP);
                // ⑤ 边缘色散：左冷右暖
                shDisp = new LinearGradient(box.left, 0, box.right, 0,
                        new int[]{0x30A9D8FF, 0x00FFFFFF, 0x2CFFC79A},
                        new float[]{0f, 0.5f, 1f}, Shader.TileMode.CLAMP);
                // ⑥ 顶棱高光（只在左上更亮）
                shSpec = new LinearGradient(0, box.top, 0, box.top + 3.0f * den,
                        0xA8FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP);
                // ⑦ 底缘聚暗：【v4.27.0】0x24 → 0x14
                //    原来那圈暗把圆钮下半圈「坐」在地上，看着像一颗实心按钮。
                shFoot = new LinearGradient(0, box.bottom - h * 0.55f, 0, box.bottom,
                        0x00000000, 0x14000000, Shader.TileMode.CLAMP);
                shFootL = new LinearGradient(box.left + w * 0.12f, 0, box.right - w * 0.12f, 0,
                        new int[]{0x00FFFFFF, 0x46FFFFFF, 0x00FFFFFF},
                        new float[]{0f, 0.5f, 1f}, Shader.TileMode.CLAMP);
                // 【v4.26.0】内表面二次反射（深色主题）
                shInner2 = new LinearGradient(0, box.top, 0, box.bottom,
                        0x30FFFFFF, 0x0AFFFFFF, Shader.TileMode.CLAMP);
            }
        }

        // ---- 主体：极淡的雾 + 底缘暗（都被圆角裁掉）
        clipPath.reset();
        clipPath.addRoundRect(box, r, r, Path.Direction.CW);
        final int sc = cv.save();
        cv.clipPath(clipPath);
        pFill.setAlpha(alpha);
        pFill.setShader(shFog);
        cv.drawRect(box, pFill);
        pFill.setShader(shFoot);
        cv.drawRect(box, pFill);
        pFill.setShader(null);
        cv.restoreToCount(sc);

        // ---- 边缘折射：内缩一道亮线（径向衰减，不再是半截描边）
        final float in = Math.max(1f, den * 0.85f);
        inset.set(box.left + in, box.top + in, box.right - in, box.bottom - in);
        pEdge.setAlpha(alpha);
        pEdge.setStrokeWidth(Math.max(1f, den * 0.75f));
        pEdge.setShader(shEdge);
        cv.drawRoundRect(inset, Math.max(0f, r - in), Math.max(0f, r - in), pEdge);
        // 左上高光热点
        pHot.setAlpha(alpha);
        pHot.setStrokeWidth(Math.max(1f, den * 0.75f));
        pHot.setShader(shHot);
        cv.drawRoundRect(inset, Math.max(0f, r - in), Math.max(0f, r - in), pHot);
        pEdge.setShader(null);
        pHot.setShader(null);

        // ---- 接触暗线：高光内侧紧挨的一道细暗线，玻璃的厚度就在这一笔
        final float iw = Math.max(1f, den * 0.7f);
        inset.set(box.left + den * 1.5f, box.top + den * 1.5f,
                box.right - den * 1.5f, box.bottom - den * 1.5f);
        pInner.setAlpha(alpha);
        pInner.setStrokeWidth(iw);
        pInner.setShader(shInner);
        cv.drawRoundRect(inset, Math.max(0f, r - den * 1.5f),
                Math.max(0f, r - den * 1.5f), pInner);
        pInner.setShader(null);

        // ---- 【v4.26.0】内表面二次反射：暗线内侧一道更细更淡的亮线。
        // 圆钮的边缘于是也是「外亮线 → 暗线 → 内亮线」三层，
        // 与玻璃面板同一套材质语言，不会一个厚一个薄。
        final float i2w = Math.max(0.5f, den * 0.42f);
        inset.set(box.left + den * 2.8f, box.top + den * 2.8f,
                box.right - den * 2.8f, box.bottom - den * 2.8f);
        pInner2.setAlpha(alpha);
        pInner2.setStrokeWidth(i2w);
        pInner2.setShader(shInner2);
        cv.drawRoundRect(inset, Math.max(0f, r - den * 2.8f),
                Math.max(0f, r - den * 2.8f), pInner2);
        pInner2.setShader(null);

        // ---- 边缘色散：左冷右暖，塑料永远没有
        final float dw = Math.max(1f, den * 0.6f);
        inset.set(box.left + den * 2.3f, box.top + den * 2.3f,
                box.right - den * 2.3f, box.bottom - den * 2.3f);
        pDisp.setAlpha(alpha);
        pDisp.setStrokeWidth(dw);
        pDisp.setShader(shDisp);
        cv.drawRoundRect(inset, Math.max(0f, r - den * 2.3f),
                Math.max(0f, r - den * 2.3f), pDisp);
        pDisp.setShader(null);

        // ---- 顶棱：一道更亮的细线，玻璃感主要来自这一笔
        final float sp = Math.max(0.5f, den * 0.4f);
        inset.set(box.left + sp, box.top + sp, box.right - sp, box.bottom - sp);
        pSpec.setAlpha(alpha);
        pSpec.setStrokeWidth(Math.max(1f, den * 0.6f));
        pSpec.setShader(shSpec);
        cv.drawRoundRect(inset, Math.max(0f, r - sp), Math.max(0f, r - sp), pSpec);
        pSpec.setShader(null);

        // ---- 底缘反光：玻璃片下沿被地面反射托起的一线亮
        if (!light) {
            final float fh = Math.max(1f, den * 0.8f);
            pSpec.setAlpha(alpha);
            pSpec.setShader(shFootL);
            cv.drawRect(box.left + box.width() * 0.12f, box.bottom - fh - 0.5f,
                    box.right - box.width() * 0.12f, box.bottom - 0.5f, pSpec);
            pSpec.setShader(null);
        }

        // ---- 按下：整片玻璃吸一口光（不是变实色，是变亮）
        if (pressed) {
            pFill.setShader(null);
            pFill.setColor(light ? 0x12000000 : 0x18FFFFFF);
            cv.drawRoundRect(box, r, r, pFill);
        }
    }

    @Override
    public int getOpacity() {
        return android.graphics.PixelFormat.TRANSLUCENT;
    }

    /**
     * 玻璃片的颜色来自边缘光学（暗线 + 亮线 + 高光），不接受外部整体染色，
     * 否则会把通透的玻璃压成一块实色 —— 那正是要去掉的塑料感。
     */
    @Override
    public void setColorFilter(android.graphics.ColorFilter cf) {
        // no-op
    }

    @Override
    public void setAlpha(int a) {
        if (alpha != a) {
            alpha = a;
            invalidateSelf();
        }
    }
}
