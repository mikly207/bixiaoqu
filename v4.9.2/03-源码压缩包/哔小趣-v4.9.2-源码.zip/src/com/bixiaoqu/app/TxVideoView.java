package com.bixiaoqu.app;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.widget.FrameLayout;

/**
 * 视频显示控件（SurfaceView + MediaPlayer）。
 *
 * 【v4.9.2 换回 SurfaceView】
 * v4.9 / v4.9.1 用的是 TextureView，在部分设备上出现「有声音、画面全黑」：
 * 解码正常、进度正常、音频正常，但一帧都没画到屏幕上。
 * 这不是解码问题，而是 TextureView 的渲染通道没接上（SurfaceTexture 缓冲区尺寸、
 * 绑定时机、以及部分定制系统上 TextureView + MediaPlayer 的兼容性问题）。
 * 降清晰度自然无效 —— 换多低的档位都还是同一条渲染通道。
 *
 * SurfaceView 是系统 VideoView 的实现方式，MediaPlayer.setDisplay(holder) 是
 * Android 上最成熟稳定的视频输出路径。代价是它位于独立图层，父容器做位移时
 * 画面跟随会晚 1~2 帧（Android 7+ 已支持变换，跟手时略有滞后但不影响使用）。
 *
 * 【对外接口与 VideoView 完全一致】
 * setVideoPath / start / pause / seekTo / getCurrentPosition / getDuration /
 * isPlaying / stopPlayback / setOnPreparedListener / setOnErrorListener
 */
public class TxVideoView extends FrameLayout implements SurfaceHolder.Callback {

    final SurfaceView sv;
    MediaPlayer mp;
    String pendingPath;
    boolean prepared = false;
    /** 是否已经真正渲染出画面（MEDIA_INFO_VIDEO_RENDERING_START） */
    boolean firstFrame = false;
    boolean startWhenReady = false;
    /** SurfaceHolder 是否已就绪（surfaceCreated 之后为 true） */
    boolean holderReady = false;
    int videoW = 0, videoH = 0;
    MediaPlayer.OnPreparedListener onPrepared;
    MediaPlayer.OnErrorListener onError;
    final Handler ui = new Handler(Looper.getMainLooper());

    public TxVideoView(Context c) {
        super(c);
        setBackgroundColor(0xFF000000);
        sv = new SurfaceView(c);
        sv.setLayoutParams(new FrameLayout.LayoutParams(
                LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
        addView(sv);
        sv.getHolder().addCallback(this);
    }

    // ------------------------------------------------------------ 对外接口（与 VideoView 对齐）

    public void setVideoPath(String path) {
        if (path == null || path.isEmpty()) return;
        releasePlayer();
        pendingPath = path;
        prepared = false;
        firstFrame = false;
        startWhenReady = true;
        if (holderReady) {
            openPlayer();
        }
        // holder 未就绪时等 surfaceCreated 回调再建流（此时建流必然没有渲染目标）
    }

    public void start() {
        startWhenReady = true;
        MediaPlayer p = mp;
        if (p != null && prepared) {
            try { p.start(); } catch (Throwable ignore) { }
        }
    }

    public void pause() {
        MediaPlayer p = mp;
        if (p != null) {
            try { if (p.isPlaying()) p.pause(); } catch (Throwable ignore) { }
        }
    }

    public void seekTo(int ms) {
        MediaPlayer p = mp;
        if (p != null) {
            try { p.seekTo(ms); } catch (Throwable ignore) { }
        }
    }

    public int getCurrentPosition() {
        MediaPlayer p = mp;
        if (p == null) return 0;
        try { return p.getCurrentPosition(); } catch (Throwable e) { return 0; }
    }

    public int getDuration() {
        MediaPlayer p = mp;
        if (p == null || !prepared) return 0;
        try { return p.getDuration(); } catch (Throwable e) { return 0; }
    }

    public boolean isPlaying() {
        MediaPlayer p = mp;
        if (p == null) return false;
        try { return p.isPlaying(); } catch (Throwable e) { return false; }
    }

    public void stopPlayback() {
        pendingPath = null;
        releasePlayer();
    }

    public void setOnPreparedListener(MediaPlayer.OnPreparedListener l) {
        onPrepared = l;
    }

    public void setOnErrorListener(MediaPlayer.OnErrorListener l) {
        onError = l;
    }

    /** 是否已经渲染出第一帧（画面自检看门狗用） */
    public boolean hasRenderedFrame() {
        if (firstFrame) return true;
        // 部分设备不回调 MEDIA_INFO_VIDEO_RENDERING_START，
        // 用「已开始播放且进度已推进」兜底判断，避免看门狗误报。
        MediaPlayer p = mp;
        if (p != null && prepared) {
            try {
                if (p.isPlaying() && p.getCurrentPosition() > 800) return true;
            } catch (Throwable ignore) { }
        }
        return false;
    }

    /** 重新把播放器挂到当前 SurfaceHolder 上（画面丢失时兜底） */
    public void rebindSurface() {
        MediaPlayer p = mp;
        if (p != null && holderReady) {
            try { p.setDisplay(sv.getHolder()); } catch (Throwable ignore) { }
        }
    }

    // ------------------------------------------------------------ 内部

    void releasePlayer() {
        MediaPlayer p = mp;
        mp = null;
        prepared = false;
        if (p != null) {
            try { p.setDisplay(null); } catch (Throwable ignore) { }
            try { p.reset(); } catch (Throwable ignore) { }
            try { p.release(); } catch (Throwable ignore) { }
        }
    }

    /**
     * 建流。MediaPlayer 必须在主线程创建（回调绑定主线程 Looper），
     * setDataSource 对 http 会同步做 DNS/TCP 握手 —— 放子线程，避免卡住 UI 帧。
     * 注意：setDisplay 必须在 prepare 之前完成，这是 SurfaceView 出画面的前提。
     */
    void openPlayer() {
        final String path = pendingPath;
        if (path == null || !holderReady) return;
        final MediaPlayer p = new MediaPlayer();
        mp = p;
        try {
            p.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MOVIE).build());
        } catch (Throwable ignore) { }
        // ★ 关键：先挂显示目标，再 prepare。顺序反了就是「有声音没画面」。
        try { p.setDisplay(sv.getHolder()); } catch (Throwable ignore) { }
        p.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override public void onPrepared(MediaPlayer m) {
                prepared = true;
                if (startWhenReady) {
                    try { m.start(); } catch (Throwable ignore) { }
                }
                MediaPlayer.OnPreparedListener l = onPrepared;
                if (l != null) l.onPrepared(m);
            }
        });
        p.setOnErrorListener(new MediaPlayer.OnErrorListener() {
            @Override public boolean onError(MediaPlayer m, int what, int extra) {
                prepared = false;
                MediaPlayer.OnErrorListener l = onError;
                if (l != null) return l.onError(m, what, extra);
                return true;
            }
        });
        p.setOnVideoSizeChangedListener(new MediaPlayer.OnVideoSizeChangedListener() {
            @Override public void onVideoSizeChanged(MediaPlayer m, int w, int h) {
                videoW = w;
                videoH = h;
                requestLayout();
            }
        });
        p.setOnInfoListener(new MediaPlayer.OnInfoListener() {
            @Override public boolean onInfo(MediaPlayer m, int what, int extra) {
                // 第一帧真正上屏的信号 —— 比轮询进度准确得多
                if (what == MediaPlayer.MEDIA_INFO_VIDEO_RENDERING_START) firstFrame = true;
                return false;
            }
        });
        new Thread(new Runnable() { @Override public void run() {
            try {
                p.setDataSource(getContext(), Uri.parse(path));
                p.prepareAsync();
            } catch (final Throwable e) {
                ui.post(new Runnable() { @Override public void run() {
                    MediaPlayer.OnErrorListener l = onError;
                    if (l != null) l.onError(p, MediaPlayer.MEDIA_ERROR_UNKNOWN, 0);
                } });
            }
        } }, "tx-open").start();
    }

    // ------------------------------------------------------------ SurfaceHolder 回调

    @Override public void surfaceCreated(SurfaceHolder h) {
        holderReady = true;
        MediaPlayer p = mp;
        if (p != null && prepared) {
            // 从后台回来 / 收起后重新显示：把已在播的实例重新挂上去
            try { p.setDisplay(h); return; } catch (Throwable ignore) { }
        }
        if (pendingPath != null && mp == null) openPlayer();
    }

    @Override public void surfaceChanged(SurfaceHolder h, int format, int w, int hh) {
        MediaPlayer p = mp;
        if (p != null && prepared) {
            try { p.setDisplay(h); } catch (Throwable ignore) { }
        }
    }

    @Override public void surfaceDestroyed(SurfaceHolder h) {
        holderReady = false;
        MediaPlayer p = mp;
        if (p != null) {
            // 只解绑，不释放 —— 页面回到前台时还能接着放
            try { p.setDisplay(null); } catch (Throwable ignore) { }
        }
    }

    // ------------------------------------------------------------ 尺寸：与 VideoView 一致地保持宽高比

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int width = getDefaultSize(videoW, widthMeasureSpec);
        int height = getDefaultSize(videoH, heightMeasureSpec);
        if (videoW > 0 && videoH > 0) {
            if (width > 0 && height > 0) {
                int wSpecSize = MeasureSpec.getSize(widthMeasureSpec);
                int hSpecSize = MeasureSpec.getSize(heightMeasureSpec);
                width = height * videoW / videoH;
                if (width > wSpecSize) {
                    width = wSpecSize;
                    height = width * videoH / videoW;
                } else if (height > hSpecSize) {
                    height = hSpecSize;
                    width = height * videoW / videoH;
                }
            }
        }
        setMeasuredDimension(width, height);
    }
}
