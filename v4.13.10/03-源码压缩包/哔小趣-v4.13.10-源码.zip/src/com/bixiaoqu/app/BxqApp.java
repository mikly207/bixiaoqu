package com.bixiaoqu.app;

import android.app.Application;
import android.content.Context;

/**
 * 应用入口：在最早的 attachBaseContext 阶段安装崩溃黑匣子。
 * 目的：即使 Activity 创建失败（主题/资源/类加载异常），也能在
 * Android/data/com.bixiaoqu.app/files/crash.txt 留下完整堆栈。
 */
public class BxqApp extends Application {

    public static final String VERSION = "v4.13.10";

    @Override
    protected void attachBaseContext(Context base) {
        // 【v3.9 播放提速修复】强制走 IPv4 栈。
        // 现象：5G/WiFi 下 DNS 优先返回 IPv6(2409:8c20::/32 等)，而 B 站 CDN 的 IPv6
        // 线路在不少运营商网络里不通，Java 的 HttpURLConnection 没有 Happy Eyeballs
        // 快速回退机制，会一直等到 connectTimeout(15s) 才失败 —— 这就是「打开很慢、
        // 有概率打不开」的根因。设为 true 后 InetAddress 只返回 A 记录（IPv4），
        // 从源头绕开 IPv6，连接通常几百毫秒内建立。必须尽早设置，在网络栈初始化前生效。
        try {
            System.setProperty("java.net.preferIPv4Stack", "true");
            System.setProperty("java.net.preferIPv6Addresses", "false");
            // 播放机频繁解析同一批 CDN 域名，缩短缓存失效带来的重复解析开销
            java.security.Security.setProperty("networkaddress.cache.ttl", "60");
            java.security.Security.setProperty("networkaddress.cache.negative.ttl", "5");
        } catch (Throwable ignore) { }
        super.attachBaseContext(base);
        try {
            CrashHandler.install(base.getExternalFilesDir(null), base.getFilesDir());
            String abi = "unknown";
            try { abi = android.os.Build.SUPPORTED_ABIS[0]; } catch (Throwable ignore) { }
            CrashHandler.note("boot", "attachBaseContext OK  sdk="
                    + android.os.Build.VERSION.SDK_INT + "  abi=" + abi
                    + "  model=" + android.os.Build.MODEL
                    + "  ipv4Stack=" + System.getProperty("java.net.preferIPv4Stack"));
        } catch (Throwable ignore) { }
    }

    @Override
    public void onCreate() {
        super.onCreate();
        try { ImgLoader.init(getCacheDir()); } catch (Throwable ignore) { }
        CrashHandler.note("boot", "Application.onCreate OK");
        // 【v4.13.6 起播提速】后台预热设备指纹 + WBI mixinKey。
        // 这两个是 playurl(WBI 签名) 的前置网络往返，如果不预热，首次点视频时
        // 必须串行等「首页 Cookie → finger/spi → nav」三步走完才能真正请求播放地址，
        // 在 5G 下这就是「点开要等好几秒」的一大来源。放到启动后台线程提前做完，
        // 用户点播放时直接命中进程内缓存。
        new Thread(new Runnable() { @Override public void run() {
            try { BiliApi.initFinger(); } catch (Throwable ignore) { }
            try { BiliApi.navMixinKey(); } catch (Throwable ignore) { }
        } }, "bxq-warmup") {{
            setPriority(Thread.NORM_PRIORITY - 1);   // 后台预热，不抢 UI/播放线程资源
        }}.start();
    }
}
