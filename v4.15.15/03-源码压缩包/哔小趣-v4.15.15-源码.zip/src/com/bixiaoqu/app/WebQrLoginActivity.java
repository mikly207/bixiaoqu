package com.bixiaoqu.app;

import android.app.Activity;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.Date;

/**
 * 【v4.15.15】官方扫码页套用（极简稳健版）。
 *
 * 做法：隐藏 WebView 用桌面 UA 打开 B 站官方登录页，页面自己生成并轮询二维码；
 * 我们从 DOM 取出二维码承载的链接，用 ZXing 本地重画一张高清码显示在屏幕上。
 *
 * 本版重点在「不闪退」：
 *  1) onCreate 全程 try/catch，任何异常都降级成可读提示 + 写 crash.txt，绝不退出进程；
 *  2) 去掉 FrameLayout 覆盖层与 weight 布局，改用最朴素的自上而下布局；
 *  3) 二维码生成放后台线程，避免主线程 OOM / 掉帧；
 *  4) WebView 只用最小必要 API，1px 大小挂在视图树里保证 JS 定时器照常跑。
 */
public class WebQrLoginActivity extends Activity {

    static final String DESKTOP_UA =
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                    + "(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36";

    static final String LOGIN_URL = "https://passport.bilibili.com/login";

    /** 取二维码承载的登录链接：官方页把它放在二维码节点的 title 上 */
    static final String JS_URL =
            "(function(){try{"
            + "var i=document.querySelector('.login-scan__qrcode img');"
            + "if(!i){return '';}"
            + "var t=i.getAttribute('title')||'';"
            + "if(!t&&i.parentNode&&i.parentNode.getAttribute){t=i.parentNode.getAttribute('title')||'';}"
            + "if(!t&&i.closest){var p=i.closest('[title]');if(p){t=p.getAttribute('title')||'';}}"
            + "return (t&&t.indexOf('http')===0)?t:'';"
            + "}catch(e){return '';}})()";

    LinearLayout root;
    ImageView qrView;
    TextView tip;
    WebView wv;
    Handler ui = new Handler(Looper.getMainLooper());

    boolean done = false;
    int grabTries = 0;
    int cookieTries = 0;
    String lastUrl = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            build();
        } catch (Throwable e) {
            fallback(e);
        }
    }

    void build() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF0F0F12);
        root.setGravity(Gravity.CENTER_HORIZONTAL);

        TextView head = new TextView(this);
        head.setText("扫码登录 B 站");
        head.setTextColor(Color.WHITE);
        head.setTextSize(17);
        head.setGravity(Gravity.CENTER);
        head.setPadding(0, 40, 0, 8);
        root.addView(head);

        tip = new TextView(this);
        tip.setText("正在打开 B 站官方扫码页…");
        tip.setTextColor(Color.parseColor("#fb7299"));
        tip.setTextSize(12);
        tip.setGravity(Gravity.CENTER);
        tip.setPadding(24, 0, 24, 10);
        root.addView(tip);

        qrView = new ImageView(this);
        qrView.setScaleType(ImageView.ScaleType.FIT_CENTER);
        qrView.setBackgroundColor(Color.WHITE);
        LinearLayout.LayoutParams qp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
        qp.setMargins(24, 0, 24, 0);
        root.addView(qrView, qp);

        TextView hint = new TextView(this);
        hint.setText("请用 B 站 App 扫码\n扫码后在手机上点「确认登录」");
        hint.setTextColor(0xFFE8E8EA);
        hint.setTextSize(13);
        hint.setGravity(Gravity.CENTER);
        hint.setLineSpacing(6, 1f);
        hint.setPadding(24, 10, 24, 4);
        root.addView(hint);

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER);

        Button again = new Button(this);
        again.setText("换一张码");
        again.setTextColor(Color.WHITE);
        again.setBackgroundColor(0xFF2B2B2B);
        again.setAllCaps(false);
        again.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { reload(); }
        });
        bar.addView(again);

        Button plain = new Button(this);
        plain.setText("用官网登录");
        plain.setTextColor(Color.parseColor("#fb7299"));
        plain.setBackgroundColor(Color.TRANSPARENT);
        plain.setAllCaps(false);
        plain.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                startActivity(new android.content.Intent(
                        WebQrLoginActivity.this, WebViewLoginActivity.class));
            }
        });
        bar.addView(plain);

        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        bp.setMargins(0, 4, 0, 24);
        root.addView(bar, bp);

        // 隐藏的搬运工 WebView：只负责加载官方页 + 跑它自己的二维码轮询
        wv = new WebView(this);
        WebSettings s = wv.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setUserAgentString(DESKTOP_UA);
        CookieManager.getInstance().setAcceptCookie(true);
        if (android.os.Build.VERSION.SDK_INT >= 21) {
            try { CookieManager.getInstance().setAcceptThirdPartyCookies(wv, true); } catch (Throwable ignore) { }
        }
        wv.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                // 页面回调里出任何错都只记录、不往上抛，避免主线程异常导致闪退
                try { grabTries = 0; grab(); } catch (Throwable ignore) { }
                try { checkCookie(); } catch (Throwable ignore) { }
            }
        });
        root.addView(wv, new LinearLayout.LayoutParams(1, 1));

        setContentView(root);
        wv.loadUrl(LOGIN_URL);
        ui.postDelayed(new Runnable() { @Override public void run() { checkCookie(); } }, 800);
    }

    /** 取二维码链接；页面异步渲染，前 20 秒每 600ms 试一次 */
    void grab() {
        if (done || wv == null) return;
        try {
            wv.evaluateJavascript(JS_URL, new android.webkit.ValueCallback<String>() {
                @Override public void onReceiveValue(String v) {
                    String url = unwrap(v);
                    if (url != null && url.startsWith("http")) {
                        if (!url.equals(lastUrl)) { lastUrl = url; render(url); }
                        tip.setText("请用 B 站 App 扫码，3 分钟内有效");
                        return;
                    }
                    if (grabTries++ < 34) {
                        ui.postDelayed(new Runnable() { @Override public void run() { grab(); } }, 600);
                    } else {
                        tip.setText("没能取到二维码，点「换一张码」重试，或点「用官网登录」");
                    }
                }
            });
        } catch (Throwable e) {
            tip.setText("页面脚本执行失败：" + e.getMessage());
        }
    }

    /** 后台线程画码，避免主线程卡顿 / 内存峰值 */
    void render(final String url) {
        new Thread(new Runnable() { @Override public void run() {
            Bitmap bmp = null;
            try { bmp = LoginActivity.makeQr(url, 480); } catch (Throwable ignore) { }
            final Bitmap fBmp = bmp;
            ui.post(new Runnable() { @Override public void run() {
                if (isFinishing()) return;
                if (fBmp != null && qrView != null) qrView.setImageBitmap(fBmp);
                else if (tip != null) tip.setText("二维码渲染失败，请点「换一张码」");
            } });
        } }, "bxq-qr-draw").start();
    }

    void reload() {
        done = false;
        grabTries = 0;
        lastUrl = "";
        if (tip != null) tip.setText("正在刷新二维码…");
        if (qrView != null) qrView.setImageBitmap(null);
        try { if (wv != null) wv.loadUrl(LOGIN_URL); } catch (Throwable ignore) { }
        ui.postDelayed(new Runnable() { @Override public void run() { checkCookie(); } }, 800);
    }

    /** 每 900ms 查一次 Cookie，出现 SESSDATA 即完成（整套一起取） */
    void checkCookie() {
        if (done) return;
        if (cookieTries++ > 500) return;
        try {
            String best = "";
            String[] domains = {"https://www.bilibili.com/", "https://passport.bilibili.com/",
                    "https://account.bilibili.com/"};
            for (String d : domains) {
                try {
                    String one = CookieManager.getInstance().getCookie(d);
                    if (one != null && one.length() > best.length()) best = one;
                } catch (Throwable ignore) { }
            }
            if (best.contains("SESSDATA=")) {
                String sess = cookieVal(best, "SESSDATA");
                if (!sess.isEmpty()) { finishLogin(best, sess); return; }
            }
        } catch (Throwable ignore) { }
        ui.postDelayed(new Runnable() { @Override public void run() { checkCookie(); } }, 900);
    }

    void finishLogin(final String cookieHeader, final String sessdata) {
        done = true;
        try {
            final String jct = cookieVal(cookieHeader, "bili_jct");
            final String uid = cookieVal(cookieHeader, "DedeUserID");
            BiliApi.addCookie(cookieHeader);
            BiliApi.setLoginCookie(sessdata, jct, uid);
            String full = BiliApi.exportLoginCookie();
            SharedPreferences sp = getSharedPreferences("bili_login", MODE_PRIVATE);
            sp.edit().putString("SESSDATA", sessdata)
                    .putString("bili_jct", jct)
                    .putString("DedeUserID", uid)
                    .putString("full_cookie", full.isEmpty() ? cookieHeader : full)
                    .putLong("login_time", System.currentTimeMillis())
                    .apply();
            if (tip != null) tip.setText("登录成功，正在同步账号…");
        } catch (Throwable ignore) { }

        new Thread(new Runnable() { @Override public void run() {
            String name = "";
            for (int i = 0; i < 3; i++) {
                try {
                    org.json.JSONObject nav = BiliApi.navInfo();
                    name = nav.optString("uname", "");
                    if (!name.isEmpty()) break;
                } catch (Throwable ignore) { }
                try { Thread.sleep(1000); } catch (InterruptedException ignore) { }
            }
            final String fName = name;
            ui.post(new Runnable() { @Override public void run() {
                if (isFinishing()) return;
                Toast.makeText(WebQrLoginActivity.this,
                        "登录成功 ✓" + (fName.isEmpty() ? "" : " " + fName), Toast.LENGTH_SHORT).show();
                finish();
            } });
        } }, "bxq-qr-verify").start();
    }

    /** 兜底界面：不闪退，把异常原因与日志位置直接写在屏幕上 */
    void fallback(Throwable e) {
        String stack = android.util.Log.getStackTraceString(e);
        try {
            File dir = getExternalFilesDir(null);
            if (dir == null) dir = getFilesDir();
            PrintWriter pw = new PrintWriter(new FileWriter(new File(dir, "crash.txt"), true));
            pw.println("=== " + new Date() + " WebQrLoginActivity.build");
            pw.println(stack);
            pw.println();
            pw.close();
        } catch (Throwable ignore) { }

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setBackgroundColor(0xFF0F0F12);
        box.setPadding(28, 60, 28, 28);

        // 只取堆栈前几行，够看清崩在哪一行
        String brief = stack;
        String[] lines = stack.split("\n");
        if (lines.length > 7) {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < 7; i++) sb.append(lines[i]).append('\n');
            brief = sb.toString();
        }
        TextView t = new TextView(this);
        t.setText("扫码页打开失败（已避免闪退）\n\n" + brief
                + "\n可以把这段截图发给我，能直接定位。");
        t.setTextColor(Color.WHITE);
        t.setTextSize(14);
        box.addView(t);

        Button b = new Button(this);
        b.setText("换用旧扫码通道（直连 / 云端）");
        b.setAllCaps(false);
        b.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                startActivity(new android.content.Intent(
                        WebQrLoginActivity.this, LoginActivity.class));
                finish();
            }
        });
        box.addView(b);

        Button cp = new Button(this);
        cp.setText("复制错误详情");
        cp.setAllCaps(false);
        cp.setTag(stack);
        cp.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                try {
                    android.content.ClipboardManager cm =
                            (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                    cm.setPrimaryClip(android.content.ClipData.newPlainText(
                            "bxq-crash", String.valueOf(v.getTag())));
                    Toast.makeText(WebQrLoginActivity.this, "已复制，可直接粘贴发我",
                            Toast.LENGTH_SHORT).show();
                } catch (Throwable ignore) { }
            }
        });
        box.addView(cp);

        Button b2 = new Button(this);
        b2.setText("用短信验证码登录");
        b2.setAllCaps(false);
        b2.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                startActivity(new android.content.Intent(
                        WebQrLoginActivity.this, WebViewLoginActivity.class));
                finish();
            }
        });
        box.addView(b2);
        setContentView(box);
    }

    static String unwrap(String v) {
        if (v == null || v.equals("null")) return "";
        try { return new org.json.JSONArray("[" + v + "]").getString(0); }
        catch (Throwable ignore) { return v; }
    }

    static String cookieVal(String header, String key) {
        if (header == null) return "";
        for (String pair : header.split(";")) {
            pair = pair.trim();
            int eq = pair.indexOf('=');
            if (eq > 0 && pair.substring(0, eq).equals(key)) return pair.substring(eq + 1);
        }
        return "";
    }

    @Override
    public void onBackPressed() { finish(); }

    @Override
    protected void onDestroy() {
        done = true;
        try { ui.removeCallbacksAndMessages(null); } catch (Throwable ignore) { }
        if (wv != null) {
            try { wv.stopLoading(); wv.destroy(); } catch (Throwable ignore) { }
            wv = null;
        }
        super.onDestroy();
    }
}
