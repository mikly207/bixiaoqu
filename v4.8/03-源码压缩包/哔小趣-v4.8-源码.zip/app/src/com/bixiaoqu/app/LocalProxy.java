package com.bixiaoqu.app;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URL;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * 本地 HTTP 转发代理：VideoView/MediaPlayer 无法设置 Referer 头，
 * 而 B 站 CDN 校验 Referer，故在本机 127.0.0.1 起一个代理，
 * 把请求转发到 B 站 CDN 并补上 UA/Referer/Cookie 头（含 Range 断点续传）。
 *
 * v4.0 播放提速（流畅度优先）：
 *  - 【并行竞速】所有候选线路同时发起连接，谁先拿到响应头谁胜出，其余立即关闭。
 *    旧版串行尝试时，第一条线路不通要干等满 connectTimeout 才换下一条，
 *    4 条最坏 24 秒 —— 这是「打开很慢」的主因。并行后通常几百毫秒内建连。
 *  - 连接超时 6s → 3.5s（IPv4 已全局强制，正常建连仅几十~几百 ms）。
 *  - 全部线路失败时快速返回 502 触发上层重试，不空等。
 */
public class LocalProxy implements Runnable {

    ServerSocket ss;
    volatile boolean running = true;
    final ExecutorService pool;

    public LocalProxy() throws Exception {
        ss = new ServerSocket(0, 32, InetAddress.getByName("127.0.0.1"));
        pool = Executors.newFixedThreadPool(8, new ThreadFactory() {
            @Override public Thread newThread(Runnable r) {
                Thread t = new Thread(r, "proxy-race");
                t.setDaemon(true);
                return t;
            }
        });
    }

    public int port() {
        return ss.getLocalPort();
    }

    /** 生成给 VideoView 的播放地址（单线路，兼容旧调用） */
    public String playUrl(String targetUrl) throws Exception {
        return playUrlMulti(new String[]{ targetUrl });
    }

    /**
     * 【多线路】生成播放地址，u=主线路，u2/u3/u4=备用线路。
     * 代理会并行竞速所有线路，谁快用谁。
     */
    public String playUrlMulti(String[] urls) throws Exception {
        StringBuilder sb = new StringBuilder("http://127.0.0.1:").append(port()).append("/p?u=");
        sb.append(URLEncoder.encode(urls[0], "UTF-8"));
        for (int i = 1; i < urls.length; i++) {
            sb.append("&u").append(i + 1).append("=").append(URLEncoder.encode(urls[i], "UTF-8"));
        }
        return sb.toString();
    }

    public void start() {
        new Thread(this, "bili-proxy").start();
    }

    public void stop() {
        running = false;
        try { ss.close(); } catch (Exception ignore) { }
        try { pool.shutdownNow(); } catch (Exception ignore) { }
    }

    @Override
    public void run() {
        while (running) {
            try {
                final Socket s = ss.accept();
                new Thread(new Runnable() {
                    @Override public void run() {
                        try { handle(s); }
                        catch (Exception ignore) { }
                        finally {
                            try { s.close(); } catch (Exception ignore) { }
                        }
                    }
                }, "proxy-conn").start();
            } catch (Exception e) {
                if (!running) return;
            }
        }
    }

    /** 解析请求行里的所有候选 URL 与 Range 头 */
    static class Req {
        String[] urls;
        String range;
    }

    Req parseRequest(Socket s) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(s.getInputStream(), "UTF-8"));
        String line = br.readLine();
        if (line == null || !line.startsWith("GET ")) return null;
        String range = null;
        String rl;
        while ((rl = br.readLine()) != null && !rl.isEmpty()) {
            if (rl.regionMatches(true, 0, "Range:", 0, 6)) {
                range = rl.substring(6).trim();
            }
        }
        java.util.List<String> list = new java.util.ArrayList<String>();
        String main = paramFrom(line, "u=");
        if (main != null && !main.isEmpty()) list.add(main);
        for (int i = 2; i <= 4; i++) {
            String alt = paramFrom(line, "u" + i + "=");
            if (alt != null && !alt.isEmpty()) list.add(alt);
        }
        if (list.isEmpty()) return null;
        Req r = new Req();
        r.urls = list.toArray(new String[list.size()]);
        r.range = range;
        return r;
    }

    /** 从请求行里取某个查询参数的值（u2= 不会误匹配到 u= ） */
    String paramFrom(String line, String key) {
        int idx = -1;
        int searchFrom = 0;
        while (true) {
            int p = line.indexOf(key, searchFrom);
            if (p < 0) break;
            boolean boundary = (p == 0) || (line.charAt(p - 1) == '?') || (line.charAt(p - 1) == '&');
            if (boundary) { idx = p; break; }
            searchFrom = p + 1;
        }
        if (idx < 0) return null;
        int start = idx + key.length();
        int end = line.indexOf(' ', start);
        String raw = end > 0 ? line.substring(start, end) : line.substring(start);
        try { return URLDecoder.decode(raw, "UTF-8"); }
        catch (Exception e) { return raw; }
    }

    /** 一次线路竞速的结果 */
    static class Trial {
        HttpURLConnection conn;   // 成功拿到响应头的连接；非胜出者会被关闭并置 null
        String url;
        String err;
    }

    void handle(Socket s) throws Exception {
        Req req = parseRequest(s);
        if (req == null || req.urls == null || req.urls.length == 0) return;

        final String range = req.range;
        final BlockingQueue<Trial> results = new LinkedBlockingQueue<Trial>();
        final AtomicBoolean claimed = new AtomicBoolean(false); // 保证只有一个胜出连接

        // 所有线路同时开跑
        for (final String target : req.urls) {
            pool.execute(new Runnable() {
                @Override public void run() {
                    Trial t = new Trial();
                    t.url = target;
                    HttpURLConnection trial = null;
                    try {
                        trial = open(target, range);
                        int code = trial.getResponseCode();   // 连接阶段失败会抛异常
                        if (code >= 500) throw new Exception("HTTP " + code);
                        t.conn = trial;
                    } catch (Exception e) {
                        t.err = e.getMessage();
                        if (trial != null) { try { trial.disconnect(); } catch (Exception ignore) { } }
                        t.conn = null;
                    }
                    // 只有一个连接能成为胜者；迟到的成功者自行关闭，避免泄漏
                    if (t.conn != null && !claimed.compareAndSet(false, true)) {
                        try { t.conn.disconnect(); } catch (Exception ignore) { }
                        t.conn = null;
                    }
                    results.offer(t);
                }
            });
        }

        // 收结果：拿到第一个成功连接即用；全部失败则快速返回 502
        HttpURLConnection c = null;
        String usedUrl = null;
        int remaining = req.urls.length;
        long deadline = System.currentTimeMillis() + 8000L;
        while (remaining > 0) {
            long left = deadline - System.currentTimeMillis();
            if (left <= 0) break;
            Trial t = results.poll(left, TimeUnit.MILLISECONDS);
            if (t == null) break;
            remaining--;
            if (t.conn != null) {
                c = t.conn;
                usedUrl = t.url;
                CrashHandler.note("proxy", "竞速胜出 " + hostOf(usedUrl));
                break;
            } else if (t.err != null) {
                CrashHandler.note("proxy", "线路失败 " + hostOf(t.url) + "：" + t.err);
            }
        }

        if (c == null) {
            OutputStream out = s.getOutputStream();
            String body = "all lines failed";
            out.write(("HTTP/1.1 502 Bad Gateway\r\nContent-Length: " + body.length()
                    + "\r\nConnection: close\r\n\r\n" + body).getBytes("UTF-8"));
            out.flush();
            return;
        }

        try {
            long len = c.getContentLength();
            String cr = c.getHeaderField("Content-Range");
            String ct = c.getContentType();

            OutputStream out = s.getOutputStream();
            StringBuilder h = new StringBuilder();
            h.append("HTTP/1.1 ").append(c.getResponseCode()).append(' ')
             .append(c.getResponseCode() == 206 ? "Partial Content" : "OK").append("\r\n");
            if (len >= 0) h.append("Content-Length: ").append(len).append("\r\n");
            if (cr != null) h.append("Content-Range: ").append(cr).append("\r\n");
            if (ct != null) h.append("Content-Type: ").append(ct).append("\r\n");
            h.append("Accept-Ranges: bytes\r\nConnection: close\r\n\r\n");
            out.write(h.toString().getBytes("UTF-8"));
            out.flush();

            InputStream in = c.getResponseCode() >= 400 ? c.getErrorStream() : c.getInputStream();
            if (in != null) {
                byte[] buf = new byte[64 * 1024];
                int n;
                while ((n = in.read(buf)) > 0 && running) {
                    out.write(buf, 0, n);
                }
            }
            out.flush();
            try { in.close(); } catch (Exception ignore) { }
            try { out.close(); } catch (Exception ignore) { }
        } finally {
            c.disconnect();
        }
    }

    /** 打开一条线路：缩短超时 + 完整请求头 */
    HttpURLConnection open(String target, String range) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(target).openConnection();
        c.setConnectTimeout(5000);     // v4.5：移动网络(5G)握手偶发偏慢，3.5s 收紧到 5s；并行竞速取最快，不影响快线路
        c.setReadTimeout(30000);
        c.setInstanceFollowRedirects(true);
        c.setRequestProperty("User-Agent", BiliApi.UA);
        c.setRequestProperty("Referer", BiliApi.REFERER);
        StringBuilder ck = new StringBuilder();
        for (java.util.Map.Entry<String, String> e : BiliApi.COOKIES.entrySet()) {
            if (ck.length() > 0) ck.append("; ");
            ck.append(e.getKey()).append('=').append(e.getValue());
        }
        if (ck.length() > 0) c.setRequestProperty("Cookie", ck.toString());
        if (range != null) c.setRequestProperty("Range", range);
        return c;
    }

    String hostOf(String url) {
        try { return new URL(url).getHost(); } catch (Exception e) { return "unknown"; }
    }
}
