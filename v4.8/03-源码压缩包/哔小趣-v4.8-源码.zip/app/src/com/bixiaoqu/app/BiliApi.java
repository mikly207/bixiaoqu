package com.bixiaoqu.app;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.GZIPInputStream;
import java.util.zip.Inflater;

/**
 * B 站接口封装：Cookie 管理、短链解析、view API、WBI 签名的 playurl API。
 * 全部走公开网页端接口，不涉及登录态破解；提供 SESSDATA 可解锁高码率音源。
 */
public final class BiliApi {

    static final String UA =
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) " +
            "Chrome/126.0.0.0 Safari/537.36";
    static final String REFERER = "https://www.bilibili.com/";

    /** 进程内 Cookie（自动收集 Set-Cookie；可用 addCookie 注入 SESSDATA） */
    static final Map<String, String> COOKIES = new LinkedHashMap<>();
    static volatile String mixinKey = null;

    static final Pattern P_BV = Pattern.compile("(BV[0-9A-Za-z]{8,12})");
    static final Pattern P_AV = Pattern.compile("(?:^|[^A-Za-z0-9])av(\\d{1,15})(?:[^0-9]|$)");

    static {
        // 不预置伪造 buvid3：伪造格式会被 B 站 WAF 直接 412
        COOKIES.put("b_nut", String.valueOf(System.currentTimeMillis() / 1000));
    }

    /** 获取 B 站真实设备指纹：首页 Set-Cookie → finger/spi → 合规格式兜底 */
    static volatile boolean fingerReady = false;

    static void initFinger() {
        if (fingerReady) return;
        synchronized (BiliApi.class) {
            if (fingerReady) return;
            try {
                // ① 关键：先访问首页，让 B 站下发 WAF 认可的 buvid3/buvid4/b_nut/_uuid
                primeCookies();
                // ② 再用 finger 接口补齐
                if (!COOKIES.containsKey("buvid3") || !COOKIES.containsKey("buvid4")) {
                    try {
                        JSONObject r = getJson("https://api.bilibili.com/x/frontend/finger/spi");
                        if (r.optInt("code", -1) == 0) {
                            JSONObject d = r.getJSONObject("data");
                            String b3 = d.optString("b_3", "");
                            String b4 = d.optString("b_4", "");
                            if (!b3.isEmpty()) COOKIES.put("buvid3", b3);
                            if (!b4.isEmpty()) COOKIES.put("buvid4", b4);
                        }
                    } catch (Throwable ignore) { }
                }
                // ③ 仍缺失才用合规格式伪造（32位hex + 5位数字 + infoc）
                if (!COOKIES.containsKey("buvid3")) COOKIES.put("buvid3", fakeBuvid3());
                if (!COOKIES.containsKey("buvid4")) COOKIES.put("buvid4", fakeBuvid4());
                if (!COOKIES.containsKey("b_nut"))
                    COOKIES.put("b_nut", String.valueOf(System.currentTimeMillis() / 1000));
            } catch (Throwable ignore) { }
            fingerReady = true;
        }
    }

    /** 访问 B 站首页，收集它下发的全部 Cookie（这是通过 WAF 的关键） */
    static void primeCookies() {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL("https://www.bilibili.com/").openConnection();
            c.setConnectTimeout(12000);
            c.setReadTimeout(12000);
            c.setInstanceFollowRedirects(true);
            c.setRequestProperty("User-Agent", UA);
            c.setRequestProperty("Accept",
                    "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8");
            c.setRequestProperty("Accept-Language", "zh-CN,zh;q=0.9,en;q=0.8");
            int code = c.getResponseCode();
            collectCookies(c);
            // 必须把流读完，否则连接不能复用且部分 cookie 可能丢失
            InputStream in = c.getInputStream();
            byte[] buf = new byte[8192];
            while (in.read(buf) > 0) { }
            in.close();
        } catch (Throwable ignore) {
        } finally {
            if (c != null) try { c.disconnect(); } catch (Throwable ignore) { }
        }
    }

    /** 从响应头收集 Set-Cookie */
    static void collectCookies(HttpURLConnection c) {
        try {
            java.util.List<String> list = c.getHeaderFields().get("Set-Cookie");
            if (list == null) {
                list = c.getHeaderFields().get("set-cookie");
            }
            if (list == null) {
                // 某些实现 key 大小写不定，全表扫一遍
                for (Map.Entry<String, java.util.List<String>> e : c.getHeaderFields().entrySet()) {
                    if (e.getKey() != null && e.getKey().equalsIgnoreCase("Set-Cookie")) {
                        list = e.getValue();
                        break;
                    }
                }
            }
            if (list == null) return;
            for (String v : list) {
                if (v == null) continue;
                int semi = v.indexOf(';');
                String pair = semi > 0 ? v.substring(0, semi) : v;
                int eq = pair.indexOf('=');
                if (eq > 0) {
                    String k = pair.substring(0, eq).trim();
                    String val = pair.substring(eq + 1).trim();
                    if (!k.isEmpty() && !val.isEmpty()) COOKIES.put(k, val);
                }
            }
        } catch (Throwable ignore) { }
    }

    /** 合规格式的 buvid3 兜底：32位大写hex + 5位数字 + infoc */
    static String fakeBuvid3() {
        java.util.Random r = new java.util.Random();
        StringBuilder sb = new StringBuilder(42);
        for (int i = 0; i < 32; i++) sb.append("0123456789ABCDEF".charAt(r.nextInt(16)));
        sb.append(10000 + r.nextInt(90000));
        sb.append("infoc");
        return sb.toString();
    }

    static String fakeBuvid4() {
        return UUID.randomUUID().toString().toUpperCase() + "-"
                + (System.currentTimeMillis() / 1000);
    }

    /** 写入登录 Cookie（扫码成功后调用） */
    public static void setLoginCookie(String sessdata, String biliJct, String dedeUserId) {
        COOKIES.put("SESSDATA", sessdata);
        COOKIES.put("bili_jct", biliJct);
        COOKIES.put("DedeUserID", dedeUserId);
    }

    /** 清除登录态 */
    public static void clearLoginCookie() {
        COOKIES.remove("SESSDATA");
        COOKIES.remove("bili_jct");
        COOKIES.remove("DedeUserID");
    }

    /** 已登录用户 ID（未登录返回 null） */
    public static String loggedInUid() {
        return COOKIES.get("DedeUserID");
    }

    /** 供设置页注入登录 Cookie（Netscape txt 或 k=v 字符串） */
    public static void addCookie(String raw) {
        if (raw == null) return;
        for (String line : raw.split("\\r?\\n")) {
            line = line.trim();
            if (line.isEmpty() || line.startsWith("#")) continue;
            String[] parts = line.split("\t");
            if (parts.length >= 7) { // Netscape 格式
                COOKIES.put(parts[5], parts[6]);
            } else {
                int eq = line.indexOf('=');
                if (eq > 0) COOKIES.put(line.substring(0, eq), line.substring(eq + 1));
            }
        }
    }

    // ------------------------------------------------------------ HTTP

    public static String httpGet(String url) throws IOException {
        return httpGet0(url, 0, null);
    }

    /** 指定 Referer 的请求（关注/收藏等接口会校验来源页） */
    public static String httpGet(String url, String referer) throws IOException {
        return httpGet0(url, 0, referer);
    }

    static String httpGet0(String url, int retry) throws IOException {
        return httpGet0(url, retry, null);
    }

    static String httpGet0(String url, int retry, String referer) throws IOException {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setConnectTimeout(15000);
        c.setReadTimeout(30000);
        c.setInstanceFollowRedirects(false);
        c.setRequestProperty("User-Agent", UA);
        c.setRequestProperty("Referer", referer != null ? referer : REFERER);
        c.setRequestProperty("Origin", "https://www.bilibili.com");
        c.setRequestProperty("Accept", "application/json, text/plain, */*");
        c.setRequestProperty("Accept-Language", "zh-CN,zh;q=0.9,en;q=0.8");
        c.setRequestProperty("Sec-Fetch-Dest", "empty");
        c.setRequestProperty("Sec-Fetch-Mode", "cors");
        c.setRequestProperty("Sec-Fetch-Site", "same-site");

        StringBuilder ck = new StringBuilder();
        for (Map.Entry<String, String> e : COOKIES.entrySet()) {
            if (ck.length() > 0) ck.append("; ");
            ck.append(e.getKey()).append('=').append(e.getValue());
        }
        if (ck.length() > 0) c.setRequestProperty("Cookie", ck.toString());

        int code = c.getResponseCode();
        // 关键：Set-Cookie 必须在连接建立（getResponseCode）之后才读得到
        collectCookies(c);
        if (code == 301 || code == 302 || code == 303 || code == 307) {
            String loc = c.getHeaderField("Location");
            c.disconnect();
            if (loc == null) throw new IOException("重定向缺少 Location: HTTP " + code);
            return httpGet0(new URL(new URL(url), loc.replace(" ", "%20")).toString(), retry, referer);
        }
        if (code == 412) {
            c.disconnect();
            // 风控：重新获取设备指纹后重试一次（多数情况可恢复）
            if (retry < 1) {
                fingerReady = false;
                primeCookies();
                return httpGet0(url, retry + 1, referer);
            }
            throw new IOException("B站风控(412)：" + (loggedInUid() != null
                    ? "账号被临时限流，请稍后重试"
                    : "未登录被限流，点右上角「登录」后再试，或稍后重试"));
        }
        if (code != 200) {
            throw new IOException("HTTP " + code + "：" + url);
        }

        InputStream in = c.getInputStream();
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
        in.close();
        String enc = c.getContentEncoding();
        c.disconnect();
        byte[] raw = bos.toByteArray();
        if (enc != null) {
            String e = enc.toLowerCase();
            if (e.contains("gzip")) raw = gunzip(raw);
            else if (e.contains("deflate")) raw = inflate(raw);
        }
        return new String(raw, "UTF-8");
    }

    /** 解 gzip（部分接口无视 Accept-Encoding 也会压缩） */
    static byte[] gunzip(byte[] raw) throws IOException {
        try {
            java.io.ByteArrayInputStream bin = new java.io.ByteArrayInputStream(raw);
            GZIPInputStream gin = new GZIPInputStream(bin);
            ByteArrayOutputStream out = new ByteArrayOutputStream(raw.length * 3);
            byte[] buf = new byte[8192];
            int n;
            while ((n = gin.read(buf)) > 0) out.write(buf, 0, n);
            gin.close();
            return out.toByteArray();
        } catch (IOException e) {
            return raw;
        }
    }

    /** 解 deflate：先按 zlib 头解，失败再按 raw deflate 解 */
    static byte[] inflate(byte[] raw) {
        try {
            return inflate0(raw, false);
        } catch (Throwable e) {
            try {
                return inflate0(raw, true);
            } catch (Throwable e2) {
                return raw;
            }
        }
    }

    static byte[] inflate0(byte[] raw, boolean nowrap) throws IOException {
        Inflater inf = new Inflater(nowrap);
        inf.setInput(raw);
        ByteArrayOutputStream out = new ByteArrayOutputStream(raw.length * 3);
        byte[] buf = new byte[8192];
        try {
            while (!inf.finished()) {
                int n = inf.inflate(buf);
                if (n == 0) {
                    if (inf.needsInput() || inf.needsDictionary()) break;
                }
                out.write(buf, 0, n);
            }
        } catch (java.util.zip.DataFormatException e) {
            throw new IOException(e);
        } finally {
            inf.end();
        }
        return out.toByteArray();
    }

    /** POST 表单（点赞 / 投币 / 收藏 / 关注 / 发弹幕等），返回 JSON。带一次风控 412 自愈重试。 */
    static JSONObject postForm(String url, String body, String referer) throws Exception {
        return postForm(url, body, referer, 0);
    }

    static JSONObject postForm(String url, String body, String referer, int retry) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setConnectTimeout(15000);
        c.setReadTimeout(20000);
        c.setRequestMethod("POST");
        c.setDoOutput(true);
        c.setRequestProperty("User-Agent", UA);
        c.setRequestProperty("Referer", referer != null ? referer : REFERER);
        c.setRequestProperty("Origin", "https://www.bilibili.com");
        c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8");
        c.setRequestProperty("Accept", "application/json, text/plain, */*");
        c.setRequestProperty("Accept-Language", "zh-CN,zh;q=0.9,en;q=0.8");
        c.setRequestProperty("Sec-Fetch-Site", "same-site");
        c.setRequestProperty("Sec-Fetch-Mode", "cors");
        c.setRequestProperty("Sec-Fetch-Dest", "empty");

        StringBuilder ck = new StringBuilder();
        for (Map.Entry<String, String> e : COOKIES.entrySet()) {
            if (ck.length() > 0) ck.append("; ");
            ck.append(e.getKey()).append('=').append(e.getValue());
        }
        if (ck.length() > 0) c.setRequestProperty("Cookie", ck.toString());

        byte[] data = body.getBytes("UTF-8");
        c.setFixedLengthStreamingMode(data.length);
        OutputStream os = c.getOutputStream();
        os.write(data);
        os.close();

        int code = c.getResponseCode();
        collectCookies(c);
        if (code == 412) {
            // 写操作撞风控：与 GET 一样重取设备指纹后再试一次（互动场景最易触发）
            c.disconnect();
            if (retry < 1) {
                fingerReady = false;
                primeCookies();
                return postForm(url, body, referer, retry + 1);
            }
            throw new IOException("B站风控拦截(412)，请稍后再试");
        }
        if (code != 200) {
            c.disconnect();
            throw new IOException("HTTP " + code);
        }
        InputStream in = c.getInputStream();
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        byte[] buf = new byte[4096];
        int n;
        while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
        in.close();
        String enc = c.getContentEncoding();
        c.disconnect();
        byte[] raw = bos.toByteArray();
        if (enc != null) {
            String e = enc.toLowerCase();
            if (e.contains("gzip")) raw = gunzip(raw);
            else if (e.contains("deflate")) raw = inflate(raw);
        }
        return new JSONObject(new String(raw, "UTF-8"));
    }

    static JSONObject getJson(String url) throws Exception {
        return getJson(url, null);
    }

    static JSONObject getJson(String url, String referer) throws Exception {
        String body = httpGet(url, referer);
        try {
            return new JSONObject(body);
        } catch (Exception e) {
            throw new IOException("接口返回非 JSON（可能被风控）：" + body.substring(0, Math.min(120, body.length())));
        }
    }

    // ------------------------------------------------------------ 解析输入

    /** 从任意输入提取 BV 号；b23.tv 短链自动跟随重定向。无法解析返回 null。 */
    public static String extractBvid(String text) throws IOException {
        if (text == null || text.trim().isEmpty()) return null;
        text = text.trim();
        if (text.contains("b23.tv") || text.contains("bili2233.cn")) {
            try {
                HttpURLConnection c = (HttpURLConnection) new URL(text).openConnection();
                c.setInstanceFollowRedirects(true);
                c.setConnectTimeout(15000);
                c.setRequestProperty("User-Agent", UA);
                c.setRequestMethod("HEAD");
                c.getResponseCode(); // 触发重定向
                String finalUrl = c.getURL().toString();
                c.disconnect();
                text = finalUrl;
            } catch (Exception e) {
                return null;
            }
        }
        Matcher m = P_BV.matcher(text);
        if (m.find()) return m.group(1);
        return null;
    }

    /** 提取 av 号（BV 优先）。 */
    public static String extractAvid(String text) {
        if (text == null) return null;
        Matcher m = P_AV.matcher(text.trim());
        return m.find() ? m.group(1) : null;
    }

    // ------------------------------------------------------------ API

    /** 视频信息：标题、aid、分P 列表。 */
    public static JSONObject view(String bvid, String aid) throws Exception {
        String q = bvid != null ? "bvid=" + bvid : "aid=" + aid;
        JSONObject r = getJson("https://api.bilibili.com/x/web-interface/view?" + q);
        if (r.optInt("code", -1) != 0) {
            throw new IOException("获取视频信息失败：" + r.optString("message", "未知错误"));
        }
        return r.getJSONObject("data");
    }

    static String baseName(String url) {
        int slash = url.lastIndexOf('/');
        String s = slash >= 0 ? url.substring(slash + 1) : url;
        int dot = s.lastIndexOf('.');
        return dot > 0 ? s.substring(0, dot) : s;
    }

    /** WBI mixin key（懒加载，进程内缓存） */
    static String navMixinKey() throws Exception {
        if (mixinKey != null) return mixinKey;
        JSONObject nav = getJson("https://api.bilibili.com/x/web-interface/nav");
        JSONObject w = nav.getJSONObject("data").getJSONObject("wbi_img");
        mixinKey = Wbi.mixinKey(baseName(w.getString("img_url")), baseName(w.getString("sub_url")));
        return mixinKey;
    }

    /**
     * 播放地址（DASH/durl）。
     * 端点链：x/player/wbi/playurl（文档化接口，主链）
     *      → x/player/playurl（旧接口，无 WBI）
     *      → platform=html5（合一流 mp4 兜底）。
     * 未登录自动携带 try_look=1（游客试看，可拿 64-132kbps DASH 音轨）。
     */
    public static JSONObject playurl(String bvid, String aid, long cid) throws Exception {
        return playurl(bvid, aid, cid, 0);
    }

    /**
     * 指定清晰度档位（qn）请求播放地址。qn=0 走「最高可用」。
     * fnval=4048 一次性打开 DASH / 4K / 8K / HDR / 杜比 / AV1，
     * 这样 dash.video 里会把 4K、2K、1080P60 一起返回，切换清晰度不必重复请求。
     */
    public static JSONObject playurl(String bvid, String aid, long cid, int qn) throws Exception {
        initFinger();
        boolean logged = loggedInUid() != null;
        String lastErr = "未知错误";
        int wantQn = qn > 0 ? qn : 120;

        // ---- 链1：wbi/playurl（文档化接口） ----
        Map<String, String> p = new LinkedHashMap<>();
        p.put("bvid", bvid);
        p.put("cid", String.valueOf(cid));
        p.put("qn", String.valueOf(wantQn));
        p.put("fnval", "4048"); // DASH|8K|HDR|杜比|4K|AV1
        p.put("fnver", "0");
        p.put("fourk", "1");
        p.put("platform", "pc");
        if (!logged) p.put("try_look", "1");
        if (aid != null && !aid.isEmpty()) p.put("aid", aid);
        try {
            String query = Wbi.sign(p, navMixinKey());
            JSONObject r = getJson("https://api.bilibili.com/x/player/wbi/playurl?" + query);
            if (r.optInt("code", -1) != 0) {
                lastErr = "wbi/playurl: " + r.optString("message", "?") + " (code=" + r.optInt("code") + ")";
            } else {
                JSONObject d = r.getJSONObject("data");
                if (hasMedia(d)) return d;
                lastErr = "wbi/playurl: dash/durl 均为空";
            }
        } catch (Exception e) {
            lastErr = "wbi/playurl: " + e.getMessage();
        }

        // ---- 链2：旧接口 x/player/playurl（无 WBI） ----
        StringBuilder q2 = new StringBuilder();
        q2.append("bvid=").append(bvid).append("&cid=").append(cid)
          .append("&qn=").append(wantQn).append("&fnval=4048&fnver=0&fourk=1&platform=pc");
        if (!logged) q2.append("&try_look=1");
        if (aid != null && !aid.isEmpty()) q2.append("&aid=").append(aid);
        try {
            JSONObject r = getJson("https://api.bilibili.com/x/player/playurl?" + q2);
            if (r.optInt("code", -1) != 0) {
                lastErr = "旧接口: " + r.optString("message", "?") + " (code=" + r.optInt("code") + ")";
            } else {
                JSONObject d = r.getJSONObject("data");
                if (hasMedia(d)) return d;
                lastErr = "旧接口: dash/durl 均为空";
            }
        } catch (Exception e) {
            lastErr = "旧接口: " + e.getMessage();
        }

        // ---- 链3：html5 合一流兜底 ----
        try {
            JSONObject r = getJson("https://api.bilibili.com/x/player/playurl?bvid=" + bvid
                    + "&cid=" + cid + "&qn=16&platform=html5&high_quality=1");
            if (r.optInt("code", -1) == 0) {
                JSONObject d = r.getJSONObject("data");
                if (hasMedia(d)) return d;
            }
        } catch (Exception ignore) { }

        throw new Exception("获取播放信息失败：" + lastErr
                + "。若多次出现，可能是 B 站风控、视频需付费/大会员/地区限制，请稍后重试或确认视频可正常在线播放。");
    }

    static boolean hasMedia(JSONObject d) {
        if (d.has("dash") && !d.isNull("dash")) {
            JSONObject dash = d.optJSONObject("dash");
            if (dash != null && dash.optJSONArray("audio") != null
                    && dash.optJSONArray("audio").length() > 0) return true;
        }
        if (d.has("durl") && !d.isNull("durl")) {
            JSONArray du = d.optJSONArray("durl");
            if (du != null && du.length() > 0 && !du.optJSONObject(0).optString("url", "").isEmpty())
                return true;
        }
        return false;
    }

    // ------------------------------------------------------------ 搜索 / 播放器

    /**
     * 关键字搜索视频（WBI 签名搜索接口）。返回 video 类型条目数组，
     * 每条含 bvid / title / author / duration / play。
     */
    public static JSONArray searchVideos(String keyword, int page) throws Exception {
        initFinger();
        Map<String, String> p = new LinkedHashMap<>();
        p.put("search_type", "video");
        p.put("keyword", keyword);
        p.put("page", String.valueOf(page));
        p.put("order", "totalrank");
        String q = Wbi.sign(p, navMixinKey());
        JSONObject r = getJson("https://api.bilibili.com/x/web-interface/wbi/search/type?" + q);
        if (r.optInt("code", -1) != 0) {
            throw new IOException("搜索失败：" + r.optString("message", "未知错误")
                    + " (code=" + r.optInt("code") + ")");
        }
        return r.getJSONObject("data").optJSONArray("result");
    }

    /** 去掉搜索结果标题里的关键词高亮标签与 HTML 实体 */
    public static String cleanTitle(String t) {
        if (t == null) return "";
        return t.replace("<em class=\"keyword\">", "")
                .replace("</em>", "")
                .replace("&quot;", "\"")
                .replace("&amp;", "&")
                .replace("&lt;", "<")
                .replace("&gt;", ">")
                .replace("&#39;", "'");
    }

    /**
     * 【v4.7】把 playurl 的业务错误码翻译成人话。
     * B站对「cid 不属于该 bvid」「视频失效」等情况只回一句 "啥都木有"，对用户毫无意义。
     */
    static String playErrText(int code, String raw) {
        switch (code) {
            case -404: return "该视频不存在或已失效";
            case -403: return "该视频已下架或无播放权限";
            case -10403: return "该视频需要大会员账号";
            case 87007: return "这是充电专属视频，需先充电";
            case 87008: return "这是付费课程视频";
            case -101: return "请先登录后再播放";
            case -412: return "请求被风控拦截，请稍后重试";
            default:
                return (raw == null || raw.isEmpty()) ? ("错误码 " + code) : raw;
        }
    }

    /**
     * 取 mp4 合一流直链（html5 模式，给 VideoView 播放用）。
     * 登录时自动带高画质；未登录为 360/480p。
     */
    public static String playDurlMp4(String bvid, long cid) throws Exception {
        initFinger();
        StringBuilder q = new StringBuilder();
        q.append("bvid=").append(bvid).append("&cid=").append(cid)
         .append("&qn=64&fnval=0&fnver=0&platform=html5&high_quality=1");
        JSONObject r = getJson("https://api.bilibili.com/x/player/playurl?" + q);
        if (r.optInt("code", -1) != 0) {
            throw new IOException(playErrText(r.optInt("code"), r.optString("message", ""))
                    + " (code=" + r.optInt("code") + ")");
        }
        JSONObject d = r.getJSONObject("data");
        JSONArray du = d.optJSONArray("durl");
        if (du == null || du.length() == 0) {
            throw new IOException("未返回播放地址（durl 为空，可能需要登录或视频受限）");
        }
        return du.getJSONObject(0).getString("url");
    }

    /**
     * 取第一个分P信息（含 cid）。
     * 用 pagelist 而不是 view：pagelist 的风控等级更低，未登录/新 IP 下成功率明显更高。
     */
    public static JSONObject firstPage(String bvid) throws Exception {
        initFinger();
        JSONObject r = getJson("https://api.bilibili.com/x/player/pagelist?bvid=" + bvid);
        if (r.optInt("code", -1) != 0) {
            throw new IOException("获取分P失败：" + r.optString("message", "?")
                    + " (code=" + r.optInt("code") + ")");
        }
        JSONArray arr = r.getJSONArray("data");
        if (arr.length() == 0) throw new IOException("该视频没有可播放的分P");
        return arr.getJSONObject(0);
    }

    /** 全部分P（选集用）。字段：cid / page / part / duration */
    public static JSONArray pages(String bvid) throws Exception {
        initFinger();
        JSONObject r = getJson("https://api.bilibili.com/x/player/pagelist?bvid=" + bvid);
        if (r.optInt("code", -1) != 0) {
            throw new IOException("获取分P失败：" + r.optString("message", "?")
                    + " (code=" + r.optInt("code") + ")");
        }
        JSONArray arr = r.optJSONArray("data");
        if (arr == null || arr.length() == 0) throw new IOException("该视频没有可播放的分P");
        return arr;
    }

    /**
     * 【v4.0 提速】取最多 4 条候选 CDN 直链，供本地代理并行竞速。
     * v3.9 曾为凑线路串行请求 3 次 playurl，实测 backup_url 多为 0，
     * 3 次请求纯属白等（网络差时每次几百 ms~2s）——v4.0 改为只请求 1 次：
     * ① 主地址 ② 同响应 backup_url ③ 域名替换补到 4 条，全程 1 次网络往返。
     */
    public static String[] playDurlMp4Multi(String bvid, long cid, boolean low) throws Exception {
        initFinger();
        java.util.LinkedHashSet<String> urls = new java.util.LinkedHashSet<String>();
        int qn = low ? 16 : 64;
        int hq = low ? 0 : 1;
        String primary = null;
        StringBuilder q = new StringBuilder();
        q.append("bvid=").append(bvid).append("&cid=").append(cid)
         .append("&qn=").append(qn).append("&fnval=0&fnver=0&platform=html5&high_quality=")
         .append(hq);
        JSONObject r = getJson("https://api.bilibili.com/x/player/playurl?" + q);
        if (r.optInt("code", -1) != 0) {
            throw new IOException(playErrText(r.optInt("code"), r.optString("message", "")));
        }
        JSONObject d = r.optJSONObject("data");
        JSONArray du = d == null ? null : d.optJSONArray("durl");
        if (du == null || du.length() == 0) throw new IOException("未返回可播放地址（可能需要登录）");
        JSONObject d0 = du.getJSONObject(0);
        String u = d0.optString("url", "");
        if (u != null && !u.isEmpty()) { primary = u; urls.add(u); }
        JSONArray bu = d0.optJSONArray("backup_url");
        if (bu != null) {
            for (int k = 0; k < bu.length() && urls.size() < 4; k++) {
                String b = bu.optString(k, "");
                if (b != null && !b.isEmpty()) urls.add(b);
            }
        }
        // 域名替换补足：换已知备用 CDN 节点，路径与鉴权参数原样保留（本地操作，零网络开销）
        if (primary != null && urls.size() < 4) {
            String[] altHosts = {
                "upos-sz-mirrorali.bilivideo.com", "upos-sz-mirrorhw.bilivideo.com",
                "upos-sz-mirrorcos.bilivideo.com", "upos-sz-mirrorbd.bilivideo.com"
            };
            try {
                java.net.URL pu = new java.net.URL(primary);
                for (String host : altHosts) {
                    if (urls.size() >= 4) break;
                    String alt = primary.replace(pu.getHost(), host);
                    if (!alt.equals(primary)) urls.add(alt);
                }
            } catch (Throwable ignore) { }
        }
        if (urls.isEmpty()) throw new IOException("未返回任何播放线路（可能需要登录或视频受限）");
        return urls.toArray(new String[urls.size()]);
    }

    /** 兼容模式低负载流（360p mp4，给低端机/省流播放） */
    public static String playDurlMp4Low(String bvid, long cid) throws Exception {
        initFinger();
        JSONObject r = getJson("https://api.bilibili.com/x/player/playurl?bvid=" + bvid
                + "&cid=" + cid + "&qn=16&fnval=0&fnver=0&platform=html5&high_quality=0");
        if (r.optInt("code", -1) != 0) {
            throw new IOException(playErrText(r.optInt("code"), r.optString("message", "")));
        }
        JSONArray du = r.getJSONObject("data").optJSONArray("durl");
        if (du == null || du.length() == 0)
            throw new IOException("未返回播放地址（可能需要登录或视频受限）");
        return du.getJSONObject(0).getString("url");
    }

    // ------------------------------------------------------------ 哔小趣：推荐 / 关注

    /** 热门推荐视频列表（无需登录）。字段：bvid/title/owner.name/duration(秒) */
    public static JSONArray popular(int page) throws Exception {
        initFinger();
        JSONObject r = getJson("https://api.bilibili.com/x/web-interface/popular?ps=20&pn=" + page);
        if (r.optInt("code", -1) != 0) {
            throw new IOException("获取推荐失败：" + r.optString("message", "?")
                    + " (code=" + r.optInt("code") + ")");
        }
        return r.getJSONObject("data").optJSONArray("list");
    }

    /**
     * 首页推荐流（WBI 签名）。fresh_idx 每换一次，返回的一批内容就不同，
     * 这是「下拉刷新永远是同一批」的解药：旧版固定 popular pn=1，榜单在几分钟内是死的。
     */
    public static JSONArray recommendFeed(int freshIdx) throws Exception {
        initFinger();
        Map<String, String> p = new LinkedHashMap<>();
        p.put("ps", "20");
        p.put("fresh_type", "4");
        p.put("fresh_idx", String.valueOf(Math.max(1, freshIdx)));
        p.put("fresh_idx_1h", String.valueOf(Math.max(1, freshIdx / 2 + 1)));
        p.put("feed_version", "V8");
        p.put("homepage_ver", "1");
        p.put("brush", String.valueOf(freshIdx % 4));
        p.put("y_num", "4");
        p.put("fresh_sub", "1");
        p.put("last_yiqi_state", "0");
        p.put("web_location", "1430650");
        String q = Wbi.sign(p, navMixinKey());
        JSONObject r = getJson(
                "https://api.bilibili.com/x/web-interface/wbi/index/top/feed/rcmd?" + q);
        if (r.optInt("code", -1) != 0) {
            throw new IOException("推荐流: " + r.optString("message", "?")
                    + " (code=" + r.optInt("code") + ")");
        }
        return r.getJSONObject("data").optJSONArray("item");
    }

    /** 分区排行榜（0=全站）。字段与 popular 一致，可当推荐备源 */
    public static JSONArray ranking(int rid) throws Exception {
        initFinger();
        JSONObject r = getJson("https://api.bilibili.com/x/web-interface/ranking/v2?rid="
                + rid + "&type=all");
        if (r.optInt("code", -1) != 0) {
            throw new IOException("排行榜: " + r.optString("message", "?")
                    + " (code=" + r.optInt("code") + ")");
        }
        return r.getJSONObject("data").optJSONArray("list");
    }

    /** 推荐可用分区（随机挑一个当备源，保证换一批时品类也变） */
    static final int[] REC_RIDS = {0, 1, 4, 36, 119, 129, 155, 160, 181, 188, 211, 217, 223, 234, 249};

    /**
     * 混合推荐：首页推荐流 + 热门随机页 + 随机分区排行榜，去重后打乱。
     * seed 每刷新一次自增，三个来源同时变化 → 每次下拉都是新内容。
     * 任一来源失败不影响其余，全失败才抛错。
     */
    public static JSONArray recommendMix(int seed) throws Exception {
        initFinger();
        Random rnd = new Random(seed * 7919L + System.currentTimeMillis() / 60000L);
        LinkedHashMap<String, JSONObject> uniq = new LinkedHashMap<>();
        String lastErr = null;
        int ok = 0;

        // 1) 首页推荐流（主源，最「千人千面」）
        try {
            JSONArray a = recommendFeed(seed % 12 + 1 + rnd.nextInt(6));
            if (a != null) { addAll(uniq, a); ok++; }
        } catch (Exception e) { lastErr = e.getMessage(); }

        // 2) 热门随机页（4 页梯度，每页 20 条，内容差异明显）
        if (uniq.size() < 34) {
            try {
                JSONArray a = popular(1 + rnd.nextInt(4));
                if (a != null) { addAll(uniq, a); ok++; }
            } catch (Exception e) { lastErr = e.getMessage(); }
        }

        // 3) 随机分区排行榜（补品类）
        if (uniq.size() < 44) {
            try {
                int rid = REC_RIDS[rnd.nextInt(REC_RIDS.length)];
                JSONArray a = ranking(rid);
                if (a != null) { addAll(uniq, a); ok++; }
            } catch (Exception e) { lastErr = e.getMessage(); }
        }

        if (ok == 0) throw new IOException("获取推荐失败：" + (lastErr == null ? "空" : lastErr));

        ArrayList<JSONObject> all = new ArrayList<>(uniq.values());
        Collections.shuffle(all, rnd);
        JSONArray out = new JSONArray();
        int limit = Math.min(26, all.size());
        for (int i = 0; i < limit; i++) out.put(all.get(i));
        return out;
    }

    /** 合并去重：只收有 bvid 的稿件 */
    static void addAll(LinkedHashMap<String, JSONObject> uniq, JSONArray arr) {
        for (int i = 0; i < arr.length(); i++) {
            JSONObject o = arr.optJSONObject(i);
            if (o == null) continue;
            String bv = o.optString("bvid", "");
            if (bv.isEmpty()) continue;
            if (!uniq.containsKey(bv)) uniq.put(bv, o);
        }
    }

    /** 相关推荐（播放页下方）。字段：bvid/title/pic/owner.name/duration/stat.view */
    public static JSONArray related(String bvid) throws Exception {
        initFinger();
        JSONObject r = getJson(
                "https://api.bilibili.com/x/web-interface/archive/related?bvid=" + bvid);
        if (r.optInt("code", -1) != 0) {
            throw new IOException("获取相关推荐失败：" + r.optString("message", "?")
                    + " (code=" + r.optInt("code") + ")");
        }
        return r.optJSONArray("data");
    }

    /**
     * 我的关注列表（需登录）。字段：mid/uname/face/sign
     * 关键：vmid 必须传，且新版必须 WBI 签名，否则一律 -400/-352（这就是旧版关注空白的根因）。
     * 签名链失败时再尝试无签名旧接口。
     */
    public static JSONArray followings() throws Exception {
        initFinger();
        final String uid = loggedInUid();
        if (uid == null || uid.isEmpty()) throw new IOException("未登录");

        // 主链：WBI 签名
        try {
            Map<String, String> p = new LinkedHashMap<>();
            p.put("vmid", uid);
            p.put("pn", "1");
            p.put("ps", "50");
            p.put("order", "desc");
            p.put("order_type", "attention");
            String q = Wbi.sign(p, navMixinKey());
            JSONObject r = getJson("https://api.bilibili.com/x/relation/followings?" + q,
                    "https://space.bilibili.com/" + uid + "/fans/follow");
            if (r.optInt("code", -1) == 0) {
                JSONArray list = r.getJSONObject("data").optJSONArray("list");
                if (list != null) return list;
            }
        } catch (Throwable ignore) { }

        // 兜底：不带签名（少数风控宽松场景仍可用）
        JSONObject r2 = getJson("https://api.bilibili.com/x/relation/followings?vmid=" + uid
                + "&pn=1&ps=50&order=desc&order_type=attention",
                "https://space.bilibili.com/" + uid + "/fans/follow");
        if (r2.optInt("code", -1) != 0) {
            throw new IOException("获取关注列表失败：" + r2.optString("message", "?")
                    + " (code=" + r2.optInt("code") + ")");
        }
        return r2.getJSONObject("data").optJSONArray("list");
    }

    // ------------------------------------------------------------ 个人主页

    /** 当前登录用户信息（nav）。未登录抛 IOException("未登录") */
    public static JSONObject navInfo() throws Exception {
        initFinger();
        JSONObject r = getJson("https://api.bilibili.com/x/web-interface/nav");
        int code = r.optInt("code", -1);
        JSONObject d = r.optJSONObject("data");
        if (code != 0 || d == null || !d.optBoolean("isLogin", false)) {
            throw new IOException("未登录");
        }
        return d;
    }

    /** 关注数 / 粉丝数（无需登录） */
    public static JSONObject relationStat(String mid) throws Exception {
        initFinger();
        JSONObject r = getJson("https://api.bilibili.com/x/relation/stat?vmid=" + mid);
        if (r.optInt("code", -1) != 0) {
            throw new IOException("获取关注数据失败：" + r.optString("message", "?"));
        }
        return r.getJSONObject("data");
    }

    /** 投稿/动态数量（无需登录）。返回 {video, opus} */
    public static JSONObject spaceNavNum(String mid) throws Exception {
        initFinger();
        JSONObject r = getJson("https://api.bilibili.com/x/space/navnum?mid=" + mid);
        if (r.optInt("code", -1) != 0) {
            throw new IOException("获取投稿数据失败：" + r.optString("message", "?"));
        }
        return r.getJSONObject("data");
    }

    /** 收藏夹列表（需登录，看自己的）。字段：id / title / media_count */
    public static JSONArray favFolders(String mid) throws Exception {
        initFinger();
        JSONObject r = getJson(
                "https://api.bilibili.com/x/v3/fav/folder/created/list-all?up_mid=" + mid);
        if (r.optInt("code", -1) != 0) {
            throw new IOException("获取收藏夹失败：" + r.optString("message", "?")
                    + " (code=" + r.optInt("code") + ")");
        }
        JSONArray arr = r.optJSONObject("data") != null
                ? r.getJSONObject("data").optJSONArray("list") : null;
        return arr == null ? new JSONArray() : arr;
    }

    /** 收藏夹内容（字段：bvid/title/cover/duration/upper.name） */
    public static JSONArray favItems(long mediaId) throws Exception {
        initFinger();
        JSONObject r = getJson("https://api.bilibili.com/x/v3/fav/resource/list?media_id="
                + mediaId + "&pn=1&ps=30&order=mtime&type=0&platform=web");
        if (r.optInt("code", -1) != 0) {
            throw new IOException("获取收藏内容失败：" + r.optString("message", "?"));
        }
        JSONObject d = r.optJSONObject("data");
        JSONArray arr = d != null ? d.optJSONArray("medias") : null;
        return arr == null ? new JSONArray() : arr;
    }

    /** 稍后再看（需登录）。字段：bvid/title/pic/duration/owner */
    public static JSONArray toView() throws Exception {
        initFinger();
        JSONObject r = getJson("https://api.bilibili.com/x/v2/history/toview");
        if (r.optInt("code", -1) != 0) {
            throw new IOException("获取稍后再看失败：" + r.optString("message", "?")
                    + " (code=" + r.optInt("code") + ")");
        }
        JSONObject d = r.optJSONObject("data");
        JSONArray arr = d != null ? d.optJSONArray("list") : null;
        return arr == null ? new JSONArray() : arr;
    }

    /** 二维码登录：生成（返回 data 节点） */
    public static JSONObject qrcodeGenerate() throws Exception {
        JSONObject r = getJson(
                "https://passport.bilibili.com/x/passport-login/web/qrcode/generate");
        if (r.optInt("code", -1) != 0)
            throw new IOException("生成二维码失败：" + r.optString("message"));
        return r.getJSONObject("data");
    }

    /** 二维码登录：轮询。code=0 已确认；86038 过期；86090 已扫码待确认；86101 未扫描 */
    public static JSONObject qrcodePoll(String qrcodeKey) throws Exception {
        return getJson("https://passport.bilibili.com/x/passport-login/web/qrcode/poll?qrcode_key="
                + java.net.URLEncoder.encode(qrcodeKey, "UTF-8"));
    }

    // ------------------------------------------------------------ 扫码登录

    /** 列出 playurl 中全部音轨（按码率降序）。无 DASH 时抛出可读异常 */
    public static JSONArray audioTracks(JSONObject playData) throws Exception {
        if (playData.has("dash") && !playData.isNull("dash")
                && playData.getJSONObject("dash").has("audio")) {
            return playData.getJSONObject("dash").getJSONArray("audio");
        }
        throw new Exception("无 DASH 音轨（可能返回了合一流，请用新版 durl 路径）");
    }

    /**
     * 统一取最佳音频源 URL：
     *  1) DASH 音轨（登录后可得 320k/Hi-Res）：取码率最高的一条
     *  2) 回退 durl 合一流（mp4，未登录常见）：取第一段
     * 返回 [0]=url，[1]="dash" 或 "durl"
     */
    public static String[] bestAudioSource(JSONObject playData) throws Exception {
        // DASH 优先
        if (playData.has("dash") && !playData.isNull("dash")) {
            JSONObject dash = playData.getJSONObject("dash");
            if (dash.has("audio") && !dash.isNull("audio")
                    && dash.getJSONArray("audio").length() > 0) {
                JSONArray audios = dash.getJSONArray("audio");
                int best = 0; long bestBw = -1;
                for (int i = 0; i < audios.length(); i++) {
                    long bw = audios.getJSONObject(i).optLong("bandwidth", 0);
                    if (bw > bestBw) { bestBw = bw; best = i; }
                }
                return new String[]{audios.getJSONObject(best).getString("baseUrl"), "dash"};
            }
        }
        // durl 合一流（mp4/flv，音视频合一条流）
        if (playData.has("durl") && !playData.isNull("durl")) {
            JSONArray durl = playData.getJSONArray("durl");
            if (durl.length() > 0) {
                String u = durl.getJSONObject(0).optString("url");
                if (!u.isEmpty()) return new String[]{u, "durl"};
            }
        }
        throw new Exception("接口未返回任何音频数据（dash 与 durl 均为空）");
    }

    /** 取 DASH 视频源（最高可用，最高 1080p）。无 DASH 视频时抛异常 */
    public static String bestVideoSource(JSONObject playData) throws Exception {
        if (playData.has("dash") && !playData.isNull("dash")) {
            JSONObject dash = playData.getJSONObject("dash");
            if (dash.has("video") && !dash.isNull("video")
                    && dash.getJSONArray("video").length() > 0) {
                JSONArray vs = dash.getJSONArray("video");
                int best = -1;
                long bestBw = -1;
                for (int i = 0; i < vs.length(); i++) {
                    JSONObject v = vs.getJSONObject(i);
                    int id = v.optInt("id", 0);          // 80=1080P 64=720P 32=480P 16=360P
                    if (id > 80) continue;               // 跳过 1080P+/4K，控制体积与性能
                    long bw = v.optLong("bandwidth", 0);
                    if (bw > bestBw) { bestBw = bw; best = i; }
                }
                if (best >= 0) {
                    JSONObject v = vs.getJSONObject(best);
                    String u = v.optString("baseUrl", "");
                    if (u.isEmpty() && v.optJSONArray("backupUrl") != null
                            && v.getJSONArray("backupUrl").length() > 0) {
                        u = v.getJSONArray("backupUrl").getString(0);
                    }
                    if (!u.isEmpty()) return u;
                }
            }
        }
        throw new IOException("无 DASH 视频流（将回退合一流）");
    }

    /** 播放地址的备用地址（CDN 主链失败时用） */
    public static String backupOf(JSONObject playData) {
        try {
            JSONObject dash = playData.optJSONObject("dash");
            JSONArray arr = dash != null ? dash.optJSONArray("video") : null;
            if (arr != null && arr.length() > 0) {
                JSONArray b = arr.getJSONObject(0).optJSONArray("backupUrl");
                if (b != null && b.length() > 0) return b.getString(0);
            }
        } catch (Throwable ignore) { }
        return null;
    }

    // ------------------------------------------------------------ 清晰度选流

    /**
     * 按目标高度挑 DASH 视频流。
     * 返回 {url, height, qn, label}；targetH<=0 表示「最高可用」。
     * 编码优先 AVC（硬解兼容性最好），其次 HEVC，最后 AV1 —— AV1 在多数手机上只能软解。
     */
    /** 编码 mime 支持缓存（按 mime 只查一次系统解码器列表） */
    static final java.util.HashMap<String, Boolean> CODEC_SUPPORT = new java.util.HashMap<String, Boolean>();

    /**
     * 【v4.5 关键修复】本机系统 MediaPlayer 是否能解这种编码。
     * B 站 fnval=4048 会返回 AV1(av01)/HEVC(hvc) 轨道，而不少机型（尤其非旗舰）系统解码器
     * 不支持 AV1 —— 选中后 VideoView/MediaPlayer 一直准备不出来，永远卡在「正在加载喵~」。
     * 这里按 mime 查系统解码器白名单，把本机解不了的轨道直接排除；H.264(avc) 全机型通吃。
     * 查询本身异常时一律放行（宁可让上层看门狗回退，也不误杀能播的轨道）。
     */
    static boolean codecPlayable(String codecs) {
        if (codecs == null || codecs.isEmpty()) return true;
        String mime;
        if (codecs.startsWith("avc")) mime = "video/avc";
        else if (codecs.startsWith("hvc") || codecs.startsWith("hev")) mime = "video/hevc"; // B站 HEVC 常见 hev1.*
        else if (codecs.startsWith("av01")) mime = "video/av01";
        else if (codecs.startsWith("vp09")) mime = "video/x-vnd.on2.vp9";
        else if (codecs.startsWith("mp4v")) mime = "video/mp4v-es";
        else return true; // 未知编码放行，交给播放器/看门狗兜底
        synchronized (CODEC_SUPPORT) {
            Boolean cached = CODEC_SUPPORT.get(mime);
            if (cached != null) return cached;
        }
        boolean ok = true;
        try {
            android.media.MediaCodecList list =
                    new android.media.MediaCodecList(android.media.MediaCodecList.ALL_CODECS);
            ok = false;
            for (android.media.MediaCodecInfo info : list.getCodecInfos()) {
                if (info == null || info.isEncoder()) continue;
                String[] types = info.getSupportedTypes();
                if (types == null) continue;
                for (String t : types) {
                    if (t != null && t.equalsIgnoreCase(mime)) { ok = true; break; }
                }
                if (ok) break;
            }
        } catch (Throwable e) {
            ok = true; // 查询失败 → 放行
        }
        synchronized (CODEC_SUPPORT) { CODEC_SUPPORT.put(mime, ok); }
        return ok;
    }

    public static String[] pickVideo(JSONObject playData, int targetH) throws Exception {
        JSONObject dash = playData.optJSONObject("dash");
        JSONArray vs = dash != null ? dash.optJSONArray("video") : null;
        if (vs == null || vs.length() == 0) throw new IOException("无 DASH 视频流");

        int best = -1;
        int bestScore = Integer.MIN_VALUE;
        for (int i = 0; i < vs.length(); i++) {
            JSONObject v = vs.optJSONObject(i);
            if (v == null) continue;
            int h = v.optInt("height", 0);
            int id = v.optInt("id", 0);
            if (h <= 0) h = id;   // 兜底：没有 height 字段时用 qn 粗判
            String codecs = v.optString("codecs", "");
            // 【v4.5】跳过本机解码器不支持的编码（AV1/HEVC 在部分机型上会导致永久卡加载）
            if (!codecPlayable(codecs)) continue;
            boolean hevc = codecs.startsWith("hvc") || codecs.startsWith("hev");
            int codecRank = codecs.startsWith("avc") ? 3 : hevc ? 2 : 1;

            int score;
            if (targetH <= 0) {
                score = h * 10 + codecRank;                  // 最高画质优先
            } else if (h <= targetH) {
                score = 100000 + h * 10 + codecRank;         // 不超过目标档，取最高
            } else {
                score = h * 10 + codecRank - 1000000;        // 超出目标档，尽量取最接近的
            }
            if (score > bestScore) { bestScore = score; best = i; }
        }
        if (best < 0) throw new IOException("本机不支持该视频的高清编码，已切换兼容播放");

        JSONObject v = vs.getJSONObject(best);
        String u = v.optString("baseUrl", "");
        if (u.isEmpty() && v.optJSONArray("backupUrl") != null
                && v.getJSONArray("backupUrl").length() > 0) {
            u = v.getJSONArray("backupUrl").getString(0);
        }
        if (u.isEmpty()) throw new IOException("视频流地址为空");
        int h = v.optInt("height", v.optInt("id", 0));
        return new String[]{u, String.valueOf(h), String.valueOf(v.optInt("id", 0)),
                qualityLabel(h)};
    }

    /**
     * 【v3.9 四线路】按 pickVideo 选中的地址，找出该视频流的主地址+所有 backupUrl。
     * pickVideo 可能已把 backupUrl[0] 当主地址返回，这里统一收集去重后最多 4 条。
     */
    public static String[] videoLines(JSONObject playData, String chosenUrl, int targetH) {
        java.util.LinkedHashSet<String> out = new java.util.LinkedHashSet<String>();
        if (chosenUrl != null && !chosenUrl.isEmpty()) out.add(chosenUrl);
        try {
            JSONObject dash = playData.optJSONObject("dash");
            JSONArray vs = dash != null ? dash.optJSONArray("video") : null;
            if (vs != null) {
                // 找与 chosenUrl 高度一致的流，收集其 baseUrl + backupUrl
                for (int i = 0; i < vs.length() && out.size() < 4; i++) {
                    JSONObject v = vs.optJSONObject(i);
                    if (v == null) continue;
                    String base = v.optString("baseUrl", "");
                    JSONArray bu = v.optJSONArray("backupUrl");
                    boolean match = (!base.isEmpty() && base.equals(chosenUrl))
                            || (bu != null && matchesAny(bu, chosenUrl));
                    if (!match) continue;
                    if (!base.isEmpty()) out.add(base);
                    if (bu != null) {
                        for (int k = 0; k < bu.length() && out.size() < 4; k++) {
                            String b = bu.optString(k, "");
                            if (!b.isEmpty()) out.add(b);
                        }
                    }
                }
            }
        } catch (Throwable ignore) { }
        if (out.isEmpty() && chosenUrl != null) return new String[]{ chosenUrl };
        return out.toArray(new String[out.size()]);
    }

    /**
     * 【v3.9 四线路】按 pickAudio 选中的地址，收集该音轨的主地址+backupUrl。
     */
    public static String[] audioLines(JSONObject playData, String chosenUrl) {
        java.util.LinkedHashSet<String> out = new java.util.LinkedHashSet<String>();
        if (chosenUrl != null && !chosenUrl.isEmpty()) out.add(chosenUrl);
        try {
            JSONObject dash = playData.optJSONObject("dash");
            JSONArray as = dash != null ? dash.optJSONArray("audio") : null;
            if (as != null) {
                for (int i = 0; i < as.length() && out.size() < 4; i++) {
                    JSONObject a = as.optJSONObject(i);
                    if (a == null) continue;
                    String base = a.optString("baseUrl", "");
                    JSONArray bu = a.optJSONArray("backupUrl");
                    boolean match = (!base.isEmpty() && base.equals(chosenUrl))
                            || (bu != null && matchesAny(bu, chosenUrl));
                    if (!match) continue;
                    if (!base.isEmpty()) out.add(base);
                    if (bu != null) {
                        for (int k = 0; k < bu.length() && out.size() < 4; k++) {
                            String b = bu.optString(k, "");
                            if (!b.isEmpty()) out.add(b);
                        }
                    }
                }
            }
        } catch (Throwable ignore) { }
        if (out.isEmpty() && chosenUrl != null) return new String[]{ chosenUrl };
        return out.toArray(new String[out.size()]);
    }

    static boolean matchesAny(JSONArray arr, String url) {
        for (int i = 0; i < arr.length(); i++) {
            if (url.equals(arr.optString(i, ""))) return true;
        }
        return false;
    }

    /** 高度 → 界面标签 */
    public static String qualityLabel(int h) {
        if (h >= 2000) return "4K";
        if (h >= 1400) return "2K";
        if (h >= 1000) return "1080P";
        if (h >= 700) return "720P";
        if (h >= 400) return "480P";
        if (h > 0) return h + "P";
        return "标清";
    }

    /** 挑音频：优先 AAC（mp4a，封 MP4/硬解都稳），同编码取最高码率 */
    public static String[] pickAudio(JSONObject playData) throws Exception {
        JSONObject dash = playData.optJSONObject("dash");
        JSONArray as = dash != null ? dash.optJSONArray("audio") : null;
        if (as == null || as.length() == 0) throw new IOException("无 DASH 音轨");
        JSONObject best = null;
        int bestScore = -1;
        for (int i = 0; i < as.length(); i++) {
            JSONObject a = as.optJSONObject(i);
            if (a == null) continue;
            String codecs = a.optString("codecs", "");
            boolean aac = codecs.startsWith("mp4a");
            int score = (aac ? 100000000 : 0) + a.optInt("bandwidth", 0);
            if (score > bestScore) { bestScore = score; best = a; }
        }
        if (best == null) throw new IOException("无可用音轨");
        String u = best.optString("baseUrl", "");
        if (u.isEmpty() && best.optJSONArray("backupUrl") != null
                && best.getJSONArray("backupUrl").length() > 0) {
            u = best.getJSONArray("backupUrl").getString(0);
        }
        if (u.isEmpty()) throw new IOException("音轨地址为空");
        return new String[]{u, String.valueOf(best.optInt("bandwidth", 0))};
    }

    /** 该稿件实际可选的最高画质高度（用于「自动」时告诉用户拿到了什么） */
    public static int maxVideoHeight(JSONObject playData) {
        JSONObject dash = playData.optJSONObject("dash");
        JSONArray vs = dash != null ? dash.optJSONArray("video") : null;
        int max = 0;
        if (vs != null) {
            for (int i = 0; i < vs.length(); i++) {
                JSONObject v = vs.optJSONObject(i);
                if (v != null) max = Math.max(max, v.optInt("height", 0));
            }
        }
        return max;
    }

    /**
     * 取适合封进 MP4 的音轨：优先 AAC（codecs 含 mp4a），码率最高者。
     * FLAC / E-AC3（Hi-Res、杜比）无法写入 MP4，会让封装失败，故排除；
     * 无 AAC 时退回普通最佳音轨。
     */
    public static String bestMp4Audio(JSONObject playData) throws Exception {
        if (playData.has("dash") && !playData.isNull("dash")) {
            JSONObject dash = playData.getJSONObject("dash");
            JSONArray audios = dash.optJSONArray("audio");
            if (audios != null && audios.length() > 0) {
                String best = null;
                long bestBw = -1;
                for (int i = 0; i < audios.length(); i++) {
                    JSONObject a = audios.getJSONObject(i);
                    String codecs = a.optString("codecs", "");
                    String mime = a.optString("mimeType", "");
                    boolean aac = codecs.startsWith("mp4a") || mime.contains("mp4a");
                    if (!aac) continue;
                    long bw = a.optLong("bandwidth", 0);
                    if (bw > bestBw) {
                        bestBw = bw;
                        best = a.optString("baseUrl", "");
                        if (best.isEmpty() && a.optJSONArray("backupUrl") != null
                                && a.getJSONArray("backupUrl").length() > 0) {
                            best = a.getJSONArray("backupUrl").getString(0);
                        }
                    }
                }
                if (best != null && !best.isEmpty()) return best;
            }
        }
        String[] fb = bestAudioSource(playData);
        return fb[0];
    }

    // ------------------------------------------------------------ 动态 / 关注粉丝 / 用户空间

    /** 粉丝列表（需登录，看自己）。字段：mid/uname/face/sign */
    public static JSONArray followers(String mid, int pn) throws Exception {
        initFinger();
        if (mid == null || mid.isEmpty()) throw new IOException("未登录");
        String ref = "https://space.bilibili.com/" + mid + "/fans/follow";
        try {
            Map<String, String> p = new LinkedHashMap<>();
            p.put("vmid", mid);
            p.put("pn", String.valueOf(pn));
            p.put("ps", "50");
            p.put("order", "desc");
            p.put("order_type", "attention");
            String q = Wbi.sign(p, navMixinKey());
            JSONObject r = getJson("https://api.bilibili.com/x/relation/followers?" + q, ref);
            if (r.optInt("code", -1) == 0) {
                JSONArray list = r.optJSONObject("data") != null
                        ? r.getJSONObject("data").optJSONArray("list") : null;
                if (list != null) return list;
            }
        } catch (Throwable ignore) { }

        JSONObject r2 = getJson("https://api.bilibili.com/x/relation/followers?vmid=" + mid
                + "&pn=" + pn + "&ps=50&order=desc&order_type=attention", ref);
        if (r2.optInt("code", -1) != 0) {
            throw new IOException("获取粉丝列表失败：" + r2.optString("message", "?")
                    + " (code=" + r2.optInt("code") + ")");
        }
        JSONArray list = r2.optJSONObject("data") != null
                ? r2.getJSONObject("data").optJSONArray("list") : null;
        return list == null ? new JSONArray() : list;
    }

    /** 用户空间投稿视频（需 WBI 签名；字段：bvid/title/pic/play/length/created） */
    public static JSONArray userVideos(String mid, int pn) throws Exception {
        initFinger();
        String ref = "https://space.bilibili.com/" + mid + "/video";
        final String dmList = "[]";
        final String dmStr = "V2ViR0wgMS4wIChPcGVuR0wgRVMgMi4wIENocm9taXVtKQ";
        final String dmCover = "QU5HTEUgKE5WSURJQSwgTlZJRElBIEdlRm9yY2UgR1RYIDEwNjAgNkdCIERpcmVjdDNEMTEgdnNfNV8wIHBzXzVfMCwgRDNEMTEpR29vZ2xlIEluYy4gKE5WSURJQS)";

        try {
            Map<String, String> p = new LinkedHashMap<>();
            p.put("mid", mid);
            p.put("ps", "30");
            p.put("pn", String.valueOf(pn));
            p.put("order", "pubdate");
            p.put("platform", "web");
            p.put("web_location", "1550101");
            p.put("dm_img_list", dmList);
            p.put("dm_img_str", dmStr);
            p.put("dm_cover_img_str", dmCover);
            String q = Wbi.sign(p, navMixinKey());
            JSONObject r = getJson("https://api.bilibili.com/x/space/wbi/arc/search?" + q, ref);
            JSONArray v = vlistOf(r);
            if (v != null) return v;
        } catch (Throwable ignore) { }

        JSONObject r2 = getJson("https://api.bilibili.com/x/space/arc/search?mid=" + mid
                + "&ps=30&pn=" + pn + "&order=pubdate&platform=web&web_location=1550101", ref);
        JSONArray v2 = vlistOf(r2);
        if (v2 == null) {
            throw new IOException("获取投稿失败：" + (r2.optString("message", "").isEmpty()
                    ? "可能被风控，请稍后重试" : r2.optString("message"))
                    + " (code=" + r2.optInt("code") + ")");
        }
        return v2;
    }

    static JSONArray vlistOf(JSONObject r) {
        try {
            if (r == null || r.optInt("code", -1) != 0) return null;
            JSONObject d = r.optJSONObject("data");
            JSONObject list = d != null ? d.optJSONObject("list") : null;
            return list != null ? list.optJSONArray("vlist") : null;
        } catch (Throwable e) {
            return null;
        }
    }

    /**
     * 用户动态（第一页或翻页）。
     * 返回 data 节点：{items:[...], offset, has_more}
     */
    public static JSONObject dynamicFeed(String mid, String offset) throws Exception {
        initFinger();
        String ref = "https://space.bilibili.com/" + mid + "/dynamic";
        Map<String, String> p = new LinkedHashMap<>();
        p.put("host_mid", mid);
        p.put("offset", offset == null ? "" : offset);
        p.put("timezone_offset", "-480");
        p.put("platform", "web");
        p.put("web_location", "333.1387");
        p.put("features", "itemOpusStyle,listOnlyfans,opusBigCover,onlyfansVote,"
                + "decorationCard,onlyfansAssetsV2,forwardListHidden,ugcDelete,onlyfansQaCard");
        String q = Wbi.sign(p, navMixinKey());
        JSONObject r = getJson(
                "https://api.bilibili.com/x/polymer/web-dynamic/v1/feed/space?" + q, ref);
        if (r.optInt("code", -1) != 0) {
            throw new IOException("获取动态失败：" + r.optString("message", "?")
                    + " (code=" + r.optInt("code") + ")");
        }
        JSONObject d = r.optJSONObject("data");
        if (d == null) throw new IOException("动态为空");
        return d;
    }

    /** 用户名片（头像/昵称/签名/粉丝数），无需登录 */
    public static JSONObject userCard(String mid) throws Exception {
        initFinger();
        JSONObject r = getJson("https://api.bilibili.com/x/web-interface/card?mid=" + mid);
        if (r.optInt("code", -1) != 0) {
            throw new IOException("获取用户资料失败：" + r.optString("message", "?"));
        }
        return r.getJSONObject("data");
    }

    // ------------------------------------------------------------ 弹幕

    /** 弹幕 XML（deflate 压缩，httpGet 已自动解压）。失败自动换备用域名 */
    public static String danmakuXml(long cid) throws IOException {
        initFinger();
        try {
            return httpGet("https://api.bilibili.com/x/v1/dm/list.so?oid=" + cid,
                    "https://www.bilibili.com/video/");
        } catch (IOException e) {
            return httpGet("https://comment.bilibili.com/" + cid + ".xml",
                    "https://www.bilibili.com/video/");
        }
    }

    /** 发送弹幕（需登录）。progress 单位毫秒 */
    public static void danmakuSend(String bvid, long cid, String msg, long progressMs)
            throws Exception {
        String csrf = COOKIES.get("bili_jct");
        if (csrf == null || csrf.isEmpty()) throw new IOException("请先登录后再发弹幕");
        if (msg == null || msg.trim().isEmpty()) throw new IOException("弹幕内容不能为空");
        String body = "type=1&oid=" + cid
                + "&msg=" + URLEncoder.encode(msg.trim(), "UTF-8")
                + "&bvid=" + bvid
                + "&progress=" + Math.max(0, progressMs)
                + "&mode=1&fontsize=25&color=16777215&pool=0&csrf=" + csrf;
        JSONObject r = postForm("https://api.bilibili.com/x/v2/dm/post", body,
                "https://www.bilibili.com/video/" + bvid);
        if (r.optInt("code", -1) != 0) {
            throw new IOException(r.optString("message", "发送失败")
                    + " (code=" + r.optInt("code") + ")");
        }
    }

    // ------------------------------------------------------------ 私信

    static final String IM_REF = "https://message.bilibili.com/";
    static String imDevId;

    static String devId() {
        if (imDevId == null) {
            // Web 端要求带上稳定的 dev_id，缺失会被 -400
            String uid = loggedInUid();
            imDevId = java.util.UUID.nameUUIDFromBytes(
                    ("bxq-" + (uid == null ? "guest" : uid)).getBytes()).toString().toUpperCase();
        }
        return imDevId;
    }

    static void requireLogin() throws IOException {
        String uid = loggedInUid();
        if (uid == null || uid.isEmpty()) throw new IOException("请先登录 B 站账号");
    }

    /**
     * 私信会话列表（需登录）。
     * 返回 data.session_list，元素含 talker_id / unread_count / last_msg{...} / top_ts。
     */
    public static JSONArray sessions() throws Exception {
        requireLogin();
        initFinger();
        String url = "https://api.vc.bilibili.com/session_svr/v1/session_svr/get_sessions"
                + "?session_type=1&group_id=0&build=0&mobi_app=web&size=50&end_seqno=";
        JSONObject r = getJson(url, IM_REF);
        int code = r.optInt("code", -1);
        if (code != 0) {
            throw new IOException("获取会话失败：" + r.optString("message", "?")
                    + " (code=" + code + ")");
        }
        JSONArray list = r.optJSONObject("data") != null
                ? r.getJSONObject("data").optJSONArray("session_list") : null;
        return list == null ? new JSONArray() : list;
    }

    /** 批量取用户名片（昵称/头像）。返回 map: uid -> {name, face} */
    public static JSONObject userCards(String uids) throws Exception {
        JSONObject map = new JSONObject();
        if (uids == null || uids.isEmpty()) return map;
        try {
            JSONObject r = getJson("https://api.vc.bilibili.com/account/v1/user/cards?uids="
                    + uids, IM_REF);
            if (r.optInt("code", -1) != 0) return map;
            JSONObject d = r.optJSONObject("data");
            if (d == null) return map;
            java.util.Iterator<String> it = d.keys();
            while (it.hasNext()) {
                String k = it.next();
                JSONObject u = d.optJSONObject(k);
                if (u == null) continue;
                JSONObject o = new JSONObject();
                o.put("name", u.optString("name", "用户" + k));
                o.put("face", u.optString("face", ""));
                map.put(k, o);
            }
        } catch (Throwable ignore) { }
        return map;
    }

    /**
     * 拉取与某人的聊天记录（需登录）。
     * endSeqno>0 时向前翻页（取更早的消息），0 表示取最新一批。
     * 返回 data.messages（已按时间升序排好）。
     */
    public static JSONArray sessionMsgs(long talkerId, long endSeqno, int size) throws Exception {
        requireLogin();
        initFinger();
        String url = "https://api.vc.bilibili.com/svr_sync/v1/svr_sync/fetch_session_msgs"
                + "?talker_id=" + talkerId + "&session_type=1&size=" + size
                + "&begin_seqno=&end_seqno=" + (endSeqno > 0 ? endSeqno : "");
        JSONObject r = getJson(url, IM_REF);
        int code = r.optInt("code", -1);
        if (code != 0) {
            throw new IOException("获取消息失败：" + r.optString("message", "?")
                    + " (code=" + code + ")");
        }
        JSONObject d = r.optJSONObject("data");
        JSONArray msgs = d != null ? d.optJSONArray("messages") : null;
        if (msgs == null) return new JSONArray();
        // 接口返回顺序不固定，统一按 timestamp 升序
        List<JSONObject> tmp = new ArrayList<>();
        for (int i = 0; i < msgs.length(); i++) {
            JSONObject m = msgs.optJSONObject(i);
            if (m != null) tmp.add(m);
        }
        Collections.sort(tmp, new java.util.Comparator<JSONObject>() {
            @Override public int compare(JSONObject a, JSONObject b) {
                long ta = a.optLong("timestamp", 0), tb = b.optLong("timestamp", 0);
                return ta < tb ? -1 : (ta > tb ? 1 : 0);
            }
        });
        JSONArray out = new JSONArray();
        for (JSONObject m : tmp) out.put(m);
        return out;
    }

    /** 发送私信（需登录，msg_type=1 纯文本） */
    public static void sendMsg(long talkerId, String text) throws Exception {
        requireLogin();
        String csrf = COOKIES.get("bili_jct");
        if (csrf == null || csrf.isEmpty()) throw new IOException("登录态缺少 bili_jct，请重新登录");
        final String uid = loggedInUid();
        if (text == null || text.trim().isEmpty()) throw new IOException("消息不能为空");
        String content = new JSONObject().put("content", text.trim()).toString();
        String body = "msg%5Bsender_uid%5D=" + uid
                + "&msg%5Breceiver_id%5D=" + talkerId
                + "&msg%5Breceiver_type%5D=1"
                + "&msg%5Bmsg_type%5D=1"
                + "&msg%5Bdev_id%5D=" + URLEncoder.encode(devId(), "UTF-8")
                + "&msg%5Btimestamp%5D=" + (System.currentTimeMillis() / 1000L)
                + "&msg%5Bcontent%5D=" + URLEncoder.encode(content, "UTF-8")
                + "&csrf=" + csrf + "&csrf_token=" + csrf;
        JSONObject r = postForm("https://api.vc.bilibili.com/web_im/v1/web_im/send_msg",
                body, IM_REF);
        if (r.optInt("code", -1) != 0) {
            throw new IOException("发送失败：" + r.optString("message", "?")
                    + " (code=" + r.optInt("code") + ")");
        }
    }

    /** 标记单个会话已读：x/v2/msg/feed/read（session_type=1 私聊） */
    public static void markSessionRead(long talkerId) throws Exception {
        String csrf = csrfOrThrow("标记已读");
        String body = "talker_id=" + talkerId
                + "&session_type=1"
                + "&csrf=" + csrf + "&csrf_token=" + csrf;
        JSONObject r = postForm("https://api.bilibili.com/x/v2/msg/feed/read", body, IM_REF);
        // code 0 成功；部分账号该接口返回 -404/-403，视为无需处理
        if (r.optInt("code", -1) != 0
                && r.optInt("code") != -404 && r.optInt("code") != -403) {
            throw new IOException("标记已读失败：" + r.optString("message", "?"));
        }
    }

    /** 会话里最后一条消息的文字预览（处理文本/图片/视频分享等类型） */
    public static String previewOf(JSONObject lastMsg) {
        if (lastMsg == null) return "";
        int type = lastMsg.optInt("msg_type", 1);
        String raw = lastMsg.optString("content", "");
        try {
            if (type == 1) return new JSONObject(raw).optString("content", "");
            if (type == 2) return "[图片]";
            if (type == 5) return "[已撤回]";
            if (type == 7) {
                JSONObject c = new JSONObject(raw);
                String t = c.optString("title", "");
                return t.isEmpty() ? "[视频分享]" : "[视频] " + t;
            }
            if (type == 10) {
                JSONObject c = new JSONObject(raw);
                return c.optString("content", "[系统消息]");
            }
            if (type == 6) return "[表情]";
        } catch (Throwable ignore) { }
        return raw.length() > 40 ? raw.substring(0, 40) : raw;
    }

    // ------------------------------------------------------------ 视频互动（点赞 / 投币 / 收藏 / 关注 / 评论）

    /** 登录态失效：-101 未登录 / -400 -403 请求被拒 / -412 风控。UI 层据此引导重新登录。 */
    public static class LoginExpired extends IOException {
        public LoginExpired(String msg) { super(msg); }
    }

    /** 写操作统一取 bili_jct，缺失说明登录态不完整 */
    static String csrfOrThrow(String action) throws IOException {
        String csrf = COOKIES.get("bili_jct");
        if (csrf == null || csrf.isEmpty()) throw new LoginExpired("登录态已失效，请到「我的」页重新登录");
        return csrf;
    }

    /**
     * 统一校验写操作业务码：0 成功；登录失效码抛 LoginExpired；其余抛可读错误。
     * 这样互动失败不会被当成成功，且登录过期能被上层识别并清理本地失效态。
     */
    static void checkWrite(JSONObject r, String action) throws IOException {
        int code = r.optInt("code", -1);
        if (code == 0) return;
        String msg = r.optString("message", "");
        if (code == -101 || code == -400 || code == -403 || code == -411) {
            throw new LoginExpired("登录已过期，请到「我的」页重新登录");
        }
        throw new IOException(action + "失败：" + (msg.isEmpty() ? "未知错误" : msg) + " (code=" + code + ")");
    }

    static String videoRef(String bvid) {
        return "https://www.bilibili.com/video/" + bvid;
    }

    /**
     * 视频详情（用 view 接口）：data 含 aid / cid / title / desc / pubdate / owner{mid,name,face}
     * / stat{view,danmaku,reply,favorite,coin,share,like} / pages[]。
     */
    public static JSONObject archiveMeta(String bvid) throws Exception {
        initFinger();
        JSONObject r = getJson("https://api.bilibili.com/x/web-interface/view?bvid=" + bvid,
                videoRef(bvid));
        if (r.optInt("code", -1) != 0) {
            throw new IOException("获取视频信息失败：" + r.optString("message", "?")
                    + " (code=" + r.optInt("code") + ")");
        }
        return r.getJSONObject("data");
    }

    /** 是否已点赞：-1 未登录 / 0 否 / 1 是（失败按未点赞处理，不打断播放） */
    public static int likeState(String bvid) {
        if (loggedInUid() == null) return -1;
        try {
            JSONObject r = getJson("https://api.bilibili.com/x/web-interface/archive/has/like?bvid="
                    + bvid, videoRef(bvid));
            if (r.optInt("code", -1) == 0) return r.optInt("data", 0);
        } catch (Throwable ignore) { }
        return 0;
    }

    /** 已投币枚数：-1 未登录 / 0 未投 / 1~2 */
    public static int coinState(String bvid) {
        if (loggedInUid() == null) return -1;
        try {
            JSONObject r = getJson("https://api.bilibili.com/x/web-interface/archive/coins?bvid="
                    + bvid, videoRef(bvid));
            if (r.optInt("code", -1) == 0) {
                JSONObject d = r.optJSONObject("data");
                if (d != null) return d.optInt("multiply", 0);
            }
        } catch (Throwable ignore) { }
        return 0;
    }

    /** 是否已关注：-1 未登录 / 0 未关注 / 1 已关注 / 2 互关 */
    public static int followState(long mid) {
        if (loggedInUid() == null || mid <= 0) return -1;
        try {
            JSONObject r = getJson("https://api.bilibili.com/x/relation?fid=" + mid,
                    "https://space.bilibili.com/" + mid);
            if (r.optInt("code", -1) == 0) {
                JSONObject d = r.optJSONObject("data");
                int attr = d == null ? 0 : d.optInt("attribute", 0);
                if (attr == 0) return 0;
                if (attr == 6) return 2;
                return attr == 2 ? 1 : 0;
            }
        } catch (Throwable ignore) { }
        return 0;
    }

    /** 点赞 / 取消点赞 */
    public static void setLike(String bvid, boolean on) throws Exception {
        String csrf = csrfOrThrow(on ? "点赞" : "取消点赞");
        String body = "bvid=" + bvid + "&like=" + (on ? 1 : 2) + "&csrf=" + csrf;
        JSONObject r = postForm("https://api.bilibili.com/x/web-interface/archive/like",
                body, videoRef(bvid));
        checkWrite(r, on ? "点赞" : "取消点赞");
    }

    /** 投币（n = 1 或 2），alsoLike 为 true 时同时点赞 */
    public static void addCoin(String bvid, int n, boolean alsoLike) throws Exception {
        String csrf = csrfOrThrow("投币");
        if (n < 1) n = 1;
        if (n > 2) n = 2;
        String body = "bvid=" + bvid + "&multiply=" + n
                + "&select_like=" + (alsoLike ? 1 : 0) + "&csrf=" + csrf;
        JSONObject r = postForm("https://api.bilibili.com/x/web-interface/coin/add",
                body, videoRef(bvid));
        checkWrite(r, "投币");
    }

    /** 收藏 / 取消收藏：addIds / delIds 为逗号分隔的收藏夹 id */
    public static void dealFav(long aid, String addIds, String delIds) throws Exception {
        String csrf = csrfOrThrow("收藏");
        String body = "rid=" + aid + "&type=2"
                + "&add_media_ids=" + (addIds == null ? "" : addIds)
                + "&del_media_ids=" + (delIds == null ? "" : delIds)
                + "&csrf=" + csrf;
        JSONObject r = postForm("https://api.bilibili.com/x/v3/fav/resource/deal",
                body, "https://www.bilibili.com/");
        checkWrite(r, "收藏");
    }

    /** 关注 / 取关 */
    public static void modifyFollow(long mid, boolean on) throws Exception {
        String csrf = csrfOrThrow(on ? "关注" : "取消关注");
        String body = "fid=" + mid + "&act=" + (on ? 1 : 2) + "&re_src=14&csrf=" + csrf;
        JSONObject r = postForm("https://api.bilibili.com/x/relation/modify",
                body, "https://space.bilibili.com/" + mid);
        checkWrite(r, on ? "关注" : "取消关注");
    }

    /** 视频评论列表（第 1 页 20 条，按热度）。元素含 member{uname,avatar} / content.message / like / ctime */
    public static JSONArray replies(long aid, int pn) throws Exception {
        initFinger();
        JSONObject r = getJson("https://api.bilibili.com/x/v2/reply?type=1&oid=" + aid
                + "&sort=2&ps=20&pn=" + pn, "https://www.bilibili.com/");
        if (r.optInt("code", -1) != 0) {
            throw new IOException("获取评论失败：" + r.optString("message", "?")
                    + " (code=" + r.optInt("code") + ")");
        }
        JSONObject d = r.optJSONObject("data");
        JSONArray arr = d == null ? null : d.optJSONArray("replies");
        return arr == null ? new JSONArray() : arr;
    }

    /** 发表评论 */
    public static void sendReply(long aid, String text) throws Exception {
        String csrf = csrfOrThrow("发表评论");
        if (text == null || text.trim().isEmpty()) throw new IOException("评论内容不能为空");
        String body = "oid=" + aid + "&type=1&plat=1&message="
                + URLEncoder.encode(text.trim(), "UTF-8") + "&csrf=" + csrf;
        JSONObject r = postForm("https://api.bilibili.com/x/v2/reply/add",
                body, "https://www.bilibili.com/");
        int code = r.optInt("code", -1);
        if (code != 0) {
            throw new IOException("发表失败：" + r.optString("message", "?") + " (code=" + code + ")");
        }
    }

    private BiliApi() {}
}
