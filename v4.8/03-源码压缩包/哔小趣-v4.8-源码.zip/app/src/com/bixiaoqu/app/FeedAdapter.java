package com.bixiaoqu.app;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Outline;
import android.graphics.drawable.GradientDrawable;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.widget.AbsListView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * 推荐/关注列表适配器，支持「单列」与「双列」两种排布。
 * 单列直接复用 {@link VideoAdapter} 的横向行；双列把两条数据合成一行，各占一半宽度。
 * 用 ListView 而不是 GridView：占位提示行可以占满整行，列表间距也更好控制。
 */
public class FeedAdapter extends BaseAdapter {

    public interface Listener {
        void onItem(VideoItem item);
    }

    final Context ctx;
    final ArrayList<VideoItem> data;
    final boolean twoCol;
    final VideoAdapter single;
    final Listener listener;
    final int cardW, coverH, gap;

    public FeedAdapter(Context c, ArrayList<VideoItem> d, boolean twoCol, Listener l) {
        ctx = c;
        data = d;
        this.twoCol = twoCol;
        listener = l;
        single = new VideoAdapter(c, d);
        float den = c.getResources().getDisplayMetrics().density;
        gap = (int) (8 * den);
        cardW = (int) ((c.getResources().getDisplayMetrics().widthPixels
                - 20 * den - gap) / 2f);
        coverH = (int) (cardW * 9f / 16f);
    }

    @Override public int getCount() {
        if (!twoCol) return data.size();
        return (data.size() + 1) / 2;
    }

    @Override public Object getItem(int i) {
        return twoCol ? data.get(Math.min(i * 2, Math.max(0, data.size() - 1))) : data.get(i);
    }

    @Override public long getItemId(int i) { return i; }

    @Override public View getView(int i, View cv, ViewGroup p) {
        if (!twoCol) {
            return single.getView(i, cv instanceof VideoAdapter.Row ? cv : null, p);
        }
        Pair row;
        if (cv instanceof Pair) row = (Pair) cv;
        else row = new Pair(ctx, gap, this);
        int a = i * 2;
        int b = a + 1;
        row.bindLeft(a < data.size() ? data.get(a) : null);
        row.bindRight(b < data.size() ? data.get(b) : null, cardW, coverH);
        return row;
    }

    /** 双列的一行：两个卡片 + 间距 */
    static class Pair extends LinearLayout {

        final Card left, right;

        final FeedAdapter owner;

        Pair(Context c, int gap, FeedAdapter owner) {
            super(c);
            this.owner = owner;
            setOrientation(HORIZONTAL);
            setLayoutParams(new AbsListView.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

            left = new Card(c, owner);
            addView(left, new LinearLayout.LayoutParams(0,
                    ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

            right = new Card(c, owner);
            LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(0,
                    ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            rp.leftMargin = gap;
            addView(right, rp);
        }

        void bindLeft(VideoItem it) {
            if (it == null) {
                left.setVisibility(View.INVISIBLE);
            } else {
                left.setVisibility(View.VISIBLE);
                left.bind(it);
            }
        }

        void bindRight(VideoItem it, int w, int h) {
            if (it == null) {
                right.setVisibility(View.INVISIBLE);
            } else {
                right.setVisibility(View.VISIBLE);
                right.bind(it);
            }
            // 占位提示独占整行：右侧隐藏后左侧自动撑满
            if (it == null && left.item != null && left.item.isPlaceholder()) {
                right.setVisibility(View.GONE);
            }
        }
    }

    /** 双列卡片：封面（16:9）+ 标题 + 副标题 */
    static class Card extends LinearLayout {

        RatioImageView img;
        TextView title, sub;
        VideoItem item;
        final FeedAdapter owner;

        Card(Context c, FeedAdapter owner) {
            super(c);
            this.owner = owner;
            float den = c.getResources().getDisplayMetrics().density;
            setOrientation(VERTICAL);
            setClickable(true);

            img = new RatioImageView(c);
            img.setScaleType(ImageView.ScaleType.CENTER_CROP);
            img.setBackgroundColor(Color.parseColor("#2a2e36"));
            final float rad = 9 * den;
            img.setClipToOutline(true);
            img.setOutlineProvider(new ViewOutlineProvider() {
                @Override public void getOutline(View v, Outline o) {
                    o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), rad);
                }
            });
            addView(img, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

            title = new TextView(c);
            title.setTextColor(MainActivity.C_FG);
            title.setTextSize(13);
            title.setMaxLines(2);
            title.setEllipsize(TextUtils.TruncateAt.END);
            title.setLineSpacing(1 * den, 1f);
            LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            tp.topMargin = (int) (7 * den);
            addView(title, tp);

            sub = new TextView(c);
            sub.setTextColor(MainActivity.C_SUB);
            sub.setTextSize(11);
            sub.setMaxLines(1);
            sub.setEllipsize(TextUtils.TruncateAt.END);
            LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            sp.topMargin = (int) (3 * den);
            addView(sub, sp);
        }

        void bind(final VideoItem it) {
            item = it;
            setOnClickListener(new OnClickListener() {
                @Override public void onClick(View v) {
                    if (!it.isPlaceholder() && owner.listener != null) {
                        owner.listener.onItem(it);
                    }
                }
            });
            if (it.isPlaceholder()) {
                img.setVisibility(View.GONE);
                title.setVisibility(View.GONE);
                sub.setVisibility(View.VISIBLE);
                sub.setGravity(Gravity.CENTER);
                sub.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
                sub.setText(it.sub);
                setMinimumHeight((int) (60 * getResources().getDisplayMetrics().density));
                return;
            }
            setMinimumHeight(0);
            img.setVisibility(View.VISIBLE);
            title.setVisibility(View.VISIBLE);
            title.setText(it.title);
            sub.setGravity(Gravity.NO_GRAVITY);
            sub.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
            if (TextUtils.isEmpty(it.sub)) {
                sub.setVisibility(View.GONE);
            } else {
                sub.setVisibility(View.VISIBLE);
                sub.setText(it.sub);
            }
            String t = it.thumb();
            if (it.localUri != null && !it.localUri.isEmpty()) {
                ImgLoader.loadUri(img, android.net.Uri.parse(it.localUri), owner.cardW, owner.coverH);
            } else if (t == null) {
                img.setImageBitmap(null);
            } else {
                ImgLoader.load(img, t, owner.cardW, owner.coverH);
            }
        }
    }

    /** 固定 16:9 的封面（GridView/权重布局里都能算准高度） */
    static class RatioImageView extends ImageView {
        RatioImageView(Context c) { super(c); }

        @Override protected void onMeasure(int wSpec, int hSpec) {
            int w = MeasureSpec.getSize(wSpec);
            if (w <= 0) w = (int) (160 * getResources().getDisplayMetrics().density);
            int h = (int) (w * 9f / 16f);
            super.onMeasure(wSpec, MeasureSpec.makeMeasureSpec(h, MeasureSpec.EXACTLY));
        }
    }

    /** 圆角背景（备用，列表卡片未使用） */
    static GradientDrawable round(int color, float radDp, Context c) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(radDp * c.getResources().getDisplayMetrics().density);
        return g;
    }
}
