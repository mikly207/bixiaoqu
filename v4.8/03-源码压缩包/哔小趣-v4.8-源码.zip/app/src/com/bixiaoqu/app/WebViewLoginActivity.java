package com.bixiaoqu.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/**
 * App 内置浏览器登录：加载 B 站官方登录页。
 * 用户可在官方页面里用任意方式登录：手机号+短信验证码、密码、极验滑块、二维码等，
 * 人机验证由 B 站官方页面自行完成。登录成功后从系统 Cookie 读取 SESSDATA/bili_jct。
 */
public class WebViewLoginActivity extends Activity {

    WebView wv;
    Handler ui = new Handler(Looper.getMainLooper());
    TextView tip;
    boolean done = false;
    int tries = 0;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(MainActivity.C_BG);

        tip = new TextView(this);
        tip.setText("正在打开 B 站官方登录页…\n支持：手机号+验证码 / 密码 / 扫码 / 滑块验证");
        tip.setTextColor(MainActivity.C_ACC);
        tip.setTextSize(12);
        tip.setPadding(24, 16, 24, 16);
        root.addView(tip);

        wv = new WebView(this);
        wv.getSettings().setJavaScriptEnabled(true);
        wv.getSettings().setDomStorageEnabled(true);
        wv.getSettings().setUserAgentString(BiliApi.UA);
        // 接受第三方 Cookie（passport 跳转 bilibili.com 需要）
        CookieManager.getInstance().setAcceptCookie(true);
        if (android.os.Build.VERSION.SDK_INT >= 21) {
            CookieManager.getInstance().setAcceptThirdPartyCookies(wv, true);
        }
        wv.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                // 拦截 bilibili:// 等跳转（防止尝试唤起 B 站 App 导致白屏），http/https 正常加载
                return !(url.startsWith("http://") || url.startsWith("https://"));
            }
            @Override
            public void onPageFinished(WebView view, String url) {
                tip.setText("在官方页面完成登录（验证码/密码/扫码均可）。" +
                        "登录成功会自动确认；若页面已登录但无反应，点「我已登录完成」。");
                scheduleCheck();
            }
        });
        wv.loadUrl("https://passport.bilibili.com/login");
        root.addView(wv, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        Button ok = new Button(this);
        ok.setText("我已登录完成（手动确认）");
        ok.setTextColor(Color.WHITE);
        ok.setBackgroundColor(MainActivity.C_ACC);
        ok.setAllCaps(false);
        LinearLayout.LayoutParams op = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        op.setMargins(24, 12, 24, 24);
        root.addView(ok, op);
        ok.setOnClickListener(new android.view.View.OnClickListener() {
            @Override public void onClick(android.view.View v) {
                tries = 0;
                checkCookie();
            }
        });

        setContentView(root);

        // 立即检查一次（可能已有历史登录 Cookie）
        ui.postDelayed(new Runnable() { @Override public void run() { checkCookie(); } }, 800);
    }

    void scheduleCheck() {
        ui.postDelayed(new Runnable() { @Override public void run() { checkCookie(); } }, 1000);
    }

    void checkCookie() {
        if (done) return;
        tries++;
        if (tries > 600) return; // 最多等 10 分钟
        try {
            String ck = CookieManager.getInstance().getCookie("https://www.bilibili.com/");
            if (ck != null && ck.contains("SESSDATA=")) {
                String sessdata = cookieVal(ck, "SESSDATA");
                String jct = cookieVal(ck, "bili_jct");
                String uid = cookieVal(ck, "DedeUserID");
                if (!sessdata.isEmpty()) {
                    done = true;
                    SharedPreferences sp = getSharedPreferences("bili_login", MODE_PRIVATE);
                    sp.edit().putString("SESSDATA", sessdata)
                            .putString("bili_jct", jct)
                            .putString("DedeUserID", uid)
                            .putLong("login_time", System.currentTimeMillis())
                            .apply();
                    BiliApi.setLoginCookie(sessdata, jct, uid);
                    Toast.makeText(this, "登录成功 ✓（验证码/密码/扫码均可）", Toast.LENGTH_SHORT).show();
                    finish();
                    return;
                }
            }
        } catch (Exception ignore) { }
        scheduleCheck();
    }

    static String cookieVal(String cookieHeader, String key) {
        for (String pair : cookieHeader.split(";")) {
            pair = pair.trim();
            int eq = pair.indexOf('=');
            if (eq > 0 && pair.substring(0, eq).equals(key)) {
                return pair.substring(eq + 1);
            }
        }
        return "";
    }

    @Override
    public void onBackPressed() {
        if (wv != null && wv.canGoBack()) wv.goBack();
        else finish();
    }

    @Override
    protected void onDestroy() {
        done = true;
        ui.removeCallbacksAndMessages(null);
        if (wv != null) {
            wv.destroy();
            wv = null;
        }
        super.onDestroy();
    }
}
