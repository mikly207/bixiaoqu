package com.bixiaoqu.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;

/**
 * 液态玻璃底栏本体（参照酷安 Liquid Glass）。
 *
 * 只负责两件事：
 *  1) 玻璃胶囊外观：圆角 = 高度/2，半透明深色填充 + 顶部亮高光 + 一圈玻璃描边；
 *  2) 按住滑动交互：DOWN/MOVE 实时回报「手指落在第几个 tab」，由外部做预览高亮；
 *     UP 时回报最终 tab，由外部决定是否真正切换页面。
 *
 * 透镜绘制已移到全屏覆盖层 {@link LiquidLensLayer}，因此光晕可扩散到胶囊外面。
 */
public class LiquidNavBar extends FrameLayout {

    /** 滑动交互回调 */
    public interface Callback {
        void onTouchDown(float x, float y);   // 触点坐标（相对本容器）
        void onTouchMove(float x, float y);
        void onTouchUp();
        void onHover(int tabIndex);           // 手指当前悬停的 tab（真实 tab 索引）
        void onCommit(int tabIndex);          // 松手提交的 tab
    }

    private Callback callback;
    /** 槽位 → 真实 tab 索引。去掉中间发布键后是 4 槽：{0,1,3,4} */
    private int[] slots = {0, 1, 2, 3, 4};
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint edge = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint topGloss = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();
    private boolean dragging = false;

    public LiquidNavBar(Context c) {
        super(c);
        setClipChildren(false);
        setClipToPadding(false);
        edge.setStyle(Paint.Style.STROKE);
    }

    public void setCallback(Callback cb) {
        this.callback = cb;
    }

    /** 设置槽位到 tab 索引的映射（例如去掉发布键后传 {0,1,3,4}） */
    public void setSlots(int[] s) {
        if (s != null && s.length > 0) slots = s;
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        rect.set(0, 0, w, h);
        float r = h / 2f;
        fill.setShader(new LinearGradient(0, 0, 0, h,
                Color.parseColor("#D9242830"), Color.parseColor("#C217191F"),
                Shader.TileMode.CLAMP));
        edge.setStrokeWidth(dp(1));
        edge.setShader(new LinearGradient(0, 0, 0, h,
                Color.parseColor("#5AFFFFFF"), Color.parseColor("#14FFFFFF"),
                Shader.TileMode.CLAMP));
        topGloss.setShader(new LinearGradient(0, 0, 0, dp(11),
                Color.parseColor("#33FFFFFF"), Color.parseColor("#00FFFFFF"),
                Shader.TileMode.CLAMP));
    }

    int dp(float v) {
        return (int) (getResources().getDisplayMetrics().density * v + 0.5f);
    }

    @Override
    protected void onDraw(Canvas cv) {
        float r = getHeight() / 2f;
        cv.drawRoundRect(rect, r, r, fill);
    }

    @Override
    protected void dispatchDraw(Canvas cv) {
        super.dispatchDraw(cv);   // 系统绘制 5 个 tab（图标/文字）
        float r = getHeight() / 2f;
        cv.drawRoundRect(rect, r, r, edge);
        RectF gloss = new RectF(rect.left + dp(1), rect.top + dp(1),
                rect.right - dp(1), rect.top + dp(11));
        cv.drawRoundRect(gloss, dp(6), dp(6), topGloss);
    }

    /** 把触点换算成真实 tab 索引；槽位等分胶囊宽度，超出左右边界时钳制 */
    private int tabAt(float x) {
        int n = slots.length;
        int idx = (int) (x / (getWidth() / (float) n));
        idx = idx < 0 ? 0 : (idx >= n ? n - 1 : idx);
        return slots[idx];
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        // 触点转成「相对本容器」的坐标；透镜层在其父容器里用屏幕坐标，由 MainActivity 换算。
        float x = ev.getX(), y = ev.getY();
        switch (ev.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                dragging = true;
                if (callback != null) {
                    callback.onTouchDown(getLeft() + x, getTop() + y);
                    callback.onHover(tabAt(x));
                }
                break;
            case MotionEvent.ACTION_MOVE:
                if (callback != null) {
                    callback.onTouchMove(getLeft() + x, getTop() + y);
                    callback.onHover(tabAt(x));
                }
                break;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                if (dragging && callback != null) {
                    boolean up = ev.getActionMasked() == MotionEvent.ACTION_UP;
                    callback.onTouchUp();
                    if (up) callback.onCommit(tabAt(x));
                }
                dragging = false;
                break;
        }
        // 自己消费事件，避免子 tab 的 click 与「松手提交」重复触发
        return true;
    }
}
