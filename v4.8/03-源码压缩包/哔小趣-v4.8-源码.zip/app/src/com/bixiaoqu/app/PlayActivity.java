package com.bixiaoqu.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.view.GestureDetector;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

/**
 * 播放页（系统解码 + 全屏 + 双指缩放 + 相关推荐）：
 * · DASH 双流：画面轨 VideoView + 音轨 MediaPlayer（1080P/4K）
 * · 合流兼容：单文件 mp4 直连本地代理（DASH 失败或兼容模式时兜底）
 * 注：早期版本的 VLC 软解引擎已移除（libvlc.so 占 19MB，为控制体积删除）
 * 手势：双击暂停/继续 · 长按 2x · 单击控制条 · 双指缩放画面
 * 全屏：横屏 + 隐藏系统栏 + 控制条浮于画面底部 + 推荐区收起
 * 底部：相关推荐（related 接口，失败自动降级热门）
 * 缓存 MP3：下载音轨 → LAME 320k → 音乐/BiliAudio
 */
public class PlayActivity extends Activity {

    VideoView video;
    SurfaceView vlcSurface;
    FrameLike holder;
    FrameLike overlay;
    LinearLayout ctrlBar;
    LinearLayout topBar, upRow, infoWrap, interactBar, actRowRef, titleColRef;
    TextView titleTop, watchText, upNameTop, statText;
    Act actLikeTop, actCmtTop, actCoinTop, actFavTop, actShareTop;
    Act actLikeBot, actCmtBot, actCoinBot, actFavBot, actShareBot;
    Button followBtnTop, followBtnBot;
    ImageView upAvatarTop, upAvatarBot;
    ImageView playIcon, nextBtn, fullIcon;
    DmSwitch dmSwitch;
    android.app.Dialog dmStyleDlg;   // 【v4.8】弹幕样式面板
    TextView timeText, dmHint, pickBtn, speedBtn;
    ImageView moreBtn;
    LinearLayout recWrap;
    ListView recList;
    LinearLayout root;
    TextView tipText, speedTag, zoomTag, bvidText;
    ImageView backArrow;
    TextView hud;
    SeekBar seek;
    Button fullBtn;   // 已废弃，保留字段避免遗漏引用
    TextView qualityBtn;


    // 高清双流：视频轨走 VideoView，音频轨走独立 MediaPlayer（DASH 是音视频分离的）
    MediaPlayer audioPlayer;
    volatile boolean dashMode = false;
    volatile boolean dashFailed = false;
    /** 【v4.6】音频轨已 prepare 完毕、正等画面就绪后再出声（避免声音抢跑） */
    volatile boolean audioPrepared = false;
    /** 【v4.6】音频是否已经真正起播过（未起播时不能被 togglePlay 抢跑） */
    volatile boolean audioStarted = false;
    /** 【v4.6】画面 onPrepared 时应让音频对齐到的起点（续播/seek 异步时 getCurrentPosition 还不可靠） */
    int pendingAudioStartPos = -1;
    JSONObject playDataCache;
    long pageDurMs = 0;
    long curCid = 0;
    String curBv = "";
    long lastAudioSync = 0;
    int resumePos = 0;
    /** 【v4.8】本次 play() 加载层文案（切换视频时显示「正在切换…」，用完自动恢复） */
    String playLoadMsg = "正在加载喵~";

    // ---- 视频信息 / 互动状态 ----
    long aid = 0;
    long ownerMid = 0;
    String videoTitle = "";
    String videoCover = "";
    String upName = "";
    String pubDate = "";
    int statLike = 0, statReply = 0, statCoin = 0, statFav = 0, statShare = 0;
    long statView = 0, statDm = 0;
    boolean liked = false, faved = false;
    int coins = 0, followedState = 0;
    JSONArray pagesArr = null;
    int pageIndex = 0;
    String favFolderId = "";
    boolean metaLoaded = false;

    // 【v4.1 提速】列表页预取的 cid / 宽高，跳过启动时串行的 pages() 请求
    long prefetchedCid = 0;
    float prefetchedAspect = 0f;
    String prefetchedTitle = "";
    long prefetchedDur = 0;

    // 左边上下滑 = 亮度，右边上下滑 = 音量
    android.media.AudioManager audioMgr;
    int maxVolume = 15;
    int startVolume = 0;
    float startBrightness = 0.5f;
    float downX = 0f, downY = 0f;
    boolean vertDrag = false;
    boolean vertVolume = false;

    final ArrayList<VideoItem> recRows = new ArrayList<>();
    VideoAdapter recAdapter;

    MediaPlayer player;                 // 播放引擎（VideoView onPrepared 捕获）

    LocalProxy proxy;
    GestureDetector gesture;
    ScaleGestureDetector scaleDet;

    // 【v3.9】合流播放失败重试计数（换线路重新取地址），切视频时归零
    int muxRetry = 0;
    static final int MAX_MUX_RETRY = 2;

    // 【v4.0】加载界面：圆角方块闭眼小电视 + 「正在加载喵~」+ Dynamo 署名
    android.view.animation.Animation loadDanceAnim;
    android.widget.ImageView loadMascot;
    TextView loadCaption;
    TextView loadSign;
    LinearLayout loadBox;
    boolean loadAnimShowing = false;

    final Handler ui = new Handler(Looper.getMainLooper());
    String bvid;
    volatile boolean boosting = false;
    volatile boolean cached = false;
    boolean ctrlVisible = true;

    boolean fullscreen = false;
    boolean twoFinger = false;
    float zoom = 1f, tx = 0f, ty = 0f;
    int videoHeight;

    // 竖屏视频「铺满整屏」沉浸模式：竖屏持机时让画面按视频比例放大铺满，不留黑边
    boolean portraitFill = false;
    TextView exitFillBtn;

    // 弹幕
    DanmakuView dmView;
    boolean dmOn = true;
    long dmCid = 0;
    String dmBvid = "";
    Button dmToggleBtn;   // 已被自绘 DmSwitch 取代
    LinearLayout dmPanel;
    EditText dmInput;

    // 竖屏视频横屏优化
    ImageView bgCover;
    ImageView flipCover;              // 切视频翻书动画的封面遮罩层
    boolean flipping = false;         // 翻书动画进行中，防止重入
    LinearLayout portraitInfo;
    TextView pTitle, pUp;
    float videoAspect = 16f / 9f;
    boolean portraitVideo = false;
    String coverUrl = "", vTitle = "", vUp = "";

    final Runnable tick = new Runnable() {
        @Override public void run() {
            try {
                if (dashMode) {
                    int len = pageDurMs > 0 ? (int) pageDurMs : video.getDuration();
                    if (len > 0) seek.setMax(len);
                    int pos = video.getCurrentPosition();
                    if (pos >= 0) seek.setProgress(pos);
                    setTimeText(pos, len);
                    if (pos > 0) syncAudio(pos);
                } else if (video != null && video.isPlaying()) {
                    int len = video.getDuration() > 0 ? video.getDuration() : (int) pageDurMs;
                    if (len > 0) seek.setMax(len);
                    int pos = video.getCurrentPosition();
                    seek.setProgress(pos);
                    setTimeText(pos, len);
                }
            } catch (Exception ignore) { }
            // 每 5 秒落一次播放进度，用于下次续播
            long nowSave = System.currentTimeMillis();
            if (nowSave - lastPosSave > 5000) {
                lastPosSave = nowSave;
                savePosNow();
            }
            ui.postDelayed(this, 500);
        }
    };

    /** 高清双流音画漂移校正：超过 0.5 秒就把音频拉回画面位置 */
    void syncAudio(int vPos) {
        if (audioPlayer == null || !audioStarted) return;
        long now = System.currentTimeMillis();
        if (now - lastAudioSync < 2500) return;
        lastAudioSync = now;
        try {
            int aPos = audioPlayer.getCurrentPosition();
            if (Math.abs(aPos - vPos) > 500) audioPlayer.seekTo(vPos);
        } catch (Throwable ignore) { }
    }

    /** 弹幕专用高频进度同步（80ms），只读进度不碰 UI 状态 */
    final Runnable dmTick = new Runnable() {
        @Override public void run() {
            try {
                if (dmView != null && dmOn) {
                    long p = -1;
                    if (video != null) {
                        p = video.getCurrentPosition();
                    }
                    if (p >= 0) dmView.setPosition(p);
                }
            } catch (Throwable ignore) { }
            ui.postDelayed(this, 80);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        bvid = getIntent() != null ? getIntent().getStringExtra("bvid") : null;
        if (getIntent() != null) {
            prefetchedCid = getIntent().getLongExtra("cid", 0);
            prefetchedAspect = getIntent().getFloatExtra("aspect", 0f);
            prefetchedTitle = getIntent().getStringExtra("ptitle");
            prefetchedDur = getIntent().getLongExtra("pdur", 0);
            // 用列表页预取的宽高先行判断竖屏，让铺满更早生效，不等 meta 请求
            if (prefetchedAspect > 0f) {
                videoAspect = prefetchedAspect;
                portraitVideo = prefetchedAspect < 1f / 1.15f;
            }
        }
        try {
            proxy = new LocalProxy();
            proxy.start();
        } catch (Exception e) {
            proxy = null;
        }
        dmOn = Prefs.danmaku(this);
        rate = Prefs.speed(this);          // 记住上次倍速
        buildUi();
        if (speedBtn != null) speedBtn.setText(rateLabel(rate));
        ui.post(tick);
        ui.post(dmTick);
        if (bvid != null && !bvid.isEmpty()) play(Prefs.decoder(this));
        loadRec();
    }

    int dp(float v) {
        return (int) (getResources().getDisplayMetrics().density * v);
    }

    /**
     * 【v4.0】加载界面：圆角方块闭眼小电视（应用图标本体）+「正在加载喵~」+ Dynamo 署名。
     * 参考用户提供的播放页加载样式，但保留本软件精华：闭眼小电视 logo、粉色主题、喵~ 文案与作者署名。
     * 浅蓝渐变圆角方块自带底色，无需额外黑色底板；加载开始时显示，画面就绪后收起。
     */
    void buildLoadAnim(FrameLike overlay) {
        loadBox = new LinearLayout(this);
        loadBox.setOrientation(LinearLayout.VERTICAL);
        loadBox.setGravity(Gravity.CENTER);
        loadBox.setClickable(false);
        loadBox.setFocusable(false);
        // 极淡的暗色底板，保证在亮色视频首帧上也能看清（比原纯黑更轻）
        android.graphics.drawable.GradientDrawable plate = new android.graphics.drawable.GradientDrawable();
        plate.setColor(0x33000000);
        plate.setCornerRadius(dp(24));
        loadBox.setBackground(plate);
        loadBox.setPadding(dp(28), dp(24), dp(28), dp(20));

        // 主体：应用图标本身就是「浅蓝渐变圆角方块 + 闭眼小电视」，正是参考图的样子
        loadMascot = new ImageView(this);
        int mascotSize = dp(88);
        int mascotRes = getResources().getIdentifier("ic_launcher", "mipmap", getPackageName());
        if (mascotRes == 0) mascotRes = getResources().getIdentifier("logo", "drawable", getPackageName());
        if (mascotRes == 0) mascotRes = android.R.drawable.ic_media_play;
        loadMascot.setImageResource(mascotRes);
        LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(mascotSize, mascotSize);
        mp.gravity = Gravity.CENTER;
        mp.bottomMargin = dp(14);
        loadMascot.setLayoutParams(mp);
        loadBox.addView(loadMascot);

        // 文案：正在加载喵~（粉色，保留软件主题色）
        loadCaption = new TextView(this);
        loadCaption.setText("正在加载喵~");
        loadCaption.setTextColor(0xFFFB7299);
        loadCaption.setTextSize(15);
        loadCaption.setTypeface(null, android.graphics.Typeface.BOLD);
        loadCaption.setGravity(Gravity.CENTER);
        loadBox.addView(loadCaption);

        // 署名：Dynamo（保留软件精华）
        loadSign = new TextView(this);
        loadSign.setText("Dynamo");
        loadSign.setTextColor(0x99FFFFFF);
        loadSign.setTextSize(11);
        loadSign.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        sp.topMargin = dp(6);
        loadSign.setLayoutParams(sp);
        loadBox.addView(loadSign);

        FrameLike.LayoutParams lp = new FrameLike.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER);
        overlay.addView(loadBox, lp);

        // ---- 柔和跳舞动画：上下轻跳 + 左右摇摆 + 缩放呼吸，作用在 mascot 上 ----
        android.view.animation.AnimationSet dance =
                new android.view.animation.AnimationSet(true);
        android.view.animation.TranslateAnimation jump =
                new android.view.animation.TranslateAnimation(0, 0, dp(0), dp(-10));
        jump.setDuration(680);
        jump.setRepeatCount(android.view.animation.Animation.INFINITE);
        jump.setRepeatMode(android.view.animation.Animation.REVERSE);
        jump.setInterpolator(new android.view.animation.AccelerateDecelerateInterpolator());

        android.view.animation.RotateAnimation wiggle = new android.view.animation.RotateAnimation(
                -8f, 8f, android.view.animation.Animation.RELATIVE_TO_SELF, 0.5f,
                android.view.animation.Animation.RELATIVE_TO_SELF, 0.5f);
        wiggle.setDuration(820);
        wiggle.setRepeatCount(android.view.animation.Animation.INFINITE);
        wiggle.setRepeatMode(android.view.animation.Animation.REVERSE);
        wiggle.setInterpolator(new android.view.animation.AccelerateDecelerateInterpolator());

        android.view.animation.ScaleAnimation breathe = new android.view.animation.ScaleAnimation(
                1f, 0.94f, 1f, 0.94f,
                android.view.animation.Animation.RELATIVE_TO_SELF, 0.5f,
                android.view.animation.Animation.RELATIVE_TO_SELF, 0.5f);
        breathe.setDuration(680);
        breathe.setRepeatCount(android.view.animation.Animation.INFINITE);
        breathe.setRepeatMode(android.view.animation.Animation.REVERSE);

        dance.addAnimation(jump);
        dance.addAnimation(wiggle);
        dance.addAnimation(breathe);
        loadDanceAnim = dance;
        loadBox.setVisibility(View.GONE);
    }

    /** 显示/隐藏加载动画。show=true 同时把文案设成 msg（默认「正在加载喵~」）。 */
    void showLoadAnim(boolean show, String msg) {
        if (loadBox == null) return;
        loadAnimShowing = show;
        if (show) {
            loadCaption.setText(msg == null ? "正在加载喵~" : msg);
            loadBox.setVisibility(View.VISIBLE);
            loadBox.clearAnimation();
            if (loadDanceAnim != null) loadBox.startAnimation(loadDanceAnim);
        } else {
            loadBox.clearAnimation();
            loadBox.setVisibility(View.GONE);
        }
    }

    /** 圆角纯色背景（半径直接给 px） */
    android.graphics.drawable.GradientDrawable roundRect(int color, int radPx, int unusedH) {
        android.graphics.drawable.GradientDrawable g =
                new android.graphics.drawable.GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(radPx);
        return g;
    }

    /** 细进度条：2dp 半透明轨道 + 粉色进度 + 小圆点，整条压在半透明背景上不抢画面 */
    void styleSeek(SeekBar s) {
        int track = dp(2);
        int vh = dp(20);
        android.graphics.drawable.GradientDrawable bg =
                new android.graphics.drawable.GradientDrawable();
        bg.setColor(0x30FFFFFF);
        bg.setCornerRadius(track / 2f);

        android.graphics.drawable.GradientDrawable pg =
                new android.graphics.drawable.GradientDrawable();
        pg.setColor(0xE6FB7299);
        pg.setCornerRadius(track / 2f);

        android.graphics.drawable.ClipDrawable clip =
                new android.graphics.drawable.ClipDrawable(pg, Gravity.LEFT,
                        android.graphics.drawable.ClipDrawable.HORIZONTAL);
        android.graphics.drawable.LayerDrawable ld =
                new android.graphics.drawable.LayerDrawable(
                        new android.graphics.drawable.Drawable[]{bg, clip});
        ld.setId(0, android.R.id.background);
        ld.setId(1, android.R.id.progress);
        int inset = (vh - track) / 2;
        ld.setLayerInset(0, 0, inset, 0, inset);
        ld.setLayerInset(1, 0, inset, 0, inset);
        s.setProgressDrawable(ld);

        android.graphics.drawable.GradientDrawable th =
                new android.graphics.drawable.GradientDrawable();
        th.setShape(android.graphics.drawable.GradientDrawable.OVAL);
        th.setColor(0xF2FFFFFF);
        th.setSize(dp(9), dp(9));
        s.setThumb(th);
        s.setThumbOffset(0);
        s.setSplitTrack(false);
        s.setPadding(0, 0, 0, 0);
        s.setMinimumHeight(vh);
        s.setBackground(null);
    }

    /** 毫秒 → mm:ss */
    static String mmss(int ms) {
        if (ms < 0) ms = 0;
        int total = ms / 1000;
        int m = total / 60, sec = total % 60;
        if (m >= 60) return (m / 60) + ":" + String.format("%02d:%02d", m % 60, sec);
        return String.format("%02d:%02d", m, sec);
    }

    void buildUi() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(MainActivity.C_BG);

        videoHeight = dp(230);
        holder = new FrameLike(this);
        holder.setBackgroundColor(Color.BLACK);

        // 竖屏视频全屏时的背景（封面铺满 + 压暗，替代大片黑边）
        bgCover = new ImageView(this);
        bgCover.setScaleType(ImageView.ScaleType.CENTER_CROP);
        bgCover.setAlpha(0.32f);
        bgCover.setVisibility(View.GONE);
        holder.addView(bgCover, new FrameLike.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        video = new VideoView(this);
        holder.addView(video, new FrameLike.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, videoHeight));

        // VLC 软解引擎已移除（libvlc.so 占 19MB，为把 APK 压到 10MB 内删除），
        // 这里保留一个隐藏的 SurfaceView 占位，避免布局索引与既有尺寸计算改动。
        vlcSurface = new SurfaceView(this);
        vlcSurface.setVisibility(View.GONE);
        holder.addView(vlcSurface, new FrameLike.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, videoHeight));

        // 弹幕层（在画面之上、控制层之下；不拦截触摸）
        dmView = new DanmakuView(this);
        dmView.setClickable(false);
        dmView.setFocusable(false);
        // 【v4.8】应用用户保存的弹幕样式（颜色/透明度/字号）
        dmView.setStyle(Prefs.dmColor(this), Prefs.dmAlpha(this), Prefs.dmSize(this));
        dmView.setVisibility(dmOn ? View.VISIBLE : View.GONE);
        holder.addView(dmView, new FrameLike.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, videoHeight));

        // 切视频「翻书」动画遮罩：盖在画面之上、控制层之下，做 3D 翻页
        flipCover = new ImageView(this);
        flipCover.setScaleType(ImageView.ScaleType.CENTER_CROP);
        flipCover.setVisibility(View.GONE);
        flipCover.setClickable(false);
        flipCover.setBackgroundColor(Color.BLACK);
        holder.addView(flipCover, new FrameLike.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, videoHeight));

        // 手势/提示浮层（FrameLayout，全屏时控制条也挂到这里）
        overlay = new FrameLike(this);

        // ---------------- 顶部栏：返回 + 标题 + 互动图标（参照 B 站横屏播放器） ----------------
        topBar = new LinearLayout(this);
        topBar.setOrientation(LinearLayout.VERTICAL);
        topBar.setBackground(new android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0xCC000000, 0x66000000, 0x00000000}));

        LinearLayout rowA = new LinearLayout(this);
        rowA.setOrientation(LinearLayout.HORIZONTAL);
        rowA.setGravity(Gravity.CENTER_VERTICAL);
        rowA.setPadding(dp(6), dp(6), dp(6), dp(6));

        backArrow = Ic.view(this, "back", Color.WHITE, 22);
        backArrow.setPadding(dp(8), dp(8), dp(8), dp(8));
        rowA.addView(backArrow, new LinearLayout.LayoutParams(dp(38), dp(38)));
        backArrow.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { goBack(); }
        });

        LinearLayout titleCol = new LinearLayout(this);
        titleCol.setOrientation(LinearLayout.VERTICAL);

        titleTop = new TextView(this);
        titleTop.setText("加载中…");
        titleTop.setTextColor(Color.WHITE);
        titleTop.setTextSize(13);
        titleTop.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        titleTop.setSingleLine(true);
        titleTop.setEllipsize(android.text.TextUtils.TruncateAt.END);
        titleTop.setShadowLayer(dp(4), 0, dp(1), 0x99000000);
        titleCol.addView(titleTop, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        watchText = new TextView(this);
        watchText.setText("");
        watchText.setTextColor(0xB3FFFFFF);
        watchText.setTextSize(10);
        watchText.setSingleLine(true);
        watchText.setEllipsize(android.text.TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams wtp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        wtp.topMargin = dp(2);
        titleCol.addView(watchText, wtp);

        LinearLayout.LayoutParams tcp = new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        tcp.leftMargin = dp(2);
        tcp.rightMargin = dp(2);
        rowA.addView(titleCol, tcp);
        titleColRef = titleCol;

        LinearLayout actRow = new LinearLayout(this);
        actRow.setOrientation(LinearLayout.HORIZONTAL);
        actRow.setGravity(Gravity.CENTER_VERTICAL);
        actLikeTop = makeAct("like", "like_on", 22, true);
        actCmtTop = makeAct("comment", "comment", 22, true);
        actCoinTop = makeAct("coin", "coin", 22, true);
        actFavTop = makeAct("star", "star_on", 22, true);
        actShareTop = makeAct("share", "share", 22, true);
        addAct(actRow, actLikeTop);
        addAct(actRow, actCmtTop);
        addAct(actRow, actCoinTop);
        addAct(actRow, actFavTop);
        addAct(actRow, actShareTop);
        actLikeTop.box.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { tapLike(); }
        });
        actLikeTop.box.setOnLongClickListener(new View.OnLongClickListener() {
            @Override public boolean onLongClick(View v) { tripleLike(); return true; }
        });
        actCmtTop.box.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { openComments(); }
        });
        actCoinTop.box.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { tapCoin(); }
        });
        actFavTop.box.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { tapFav(); }
        });
        actShareTop.box.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { tapShare(); }
        });
        rowA.addView(actRow, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        actRowRef = actRow;
        topBar.addView(rowA, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // UP 主 + 关注（全屏时展示，竖屏用下方信息卡）
        upRow = new LinearLayout(this);
        upRow.setOrientation(LinearLayout.HORIZONTAL);
        upRow.setGravity(Gravity.CENTER_VERTICAL);
        upRow.setPadding(dp(14), 0, dp(14), dp(4));
        upRow.setVisibility(View.GONE);

        upAvatarTop = new ImageView(this);
        upAvatarTop.setScaleType(ImageView.ScaleType.CENTER_CROP);
        android.graphics.drawable.GradientDrawable avBg =
                new android.graphics.drawable.GradientDrawable();
        avBg.setShape(android.graphics.drawable.GradientDrawable.OVAL);
        avBg.setColor(0xFF2A2E36);
        upAvatarTop.setBackground(avBg);
        upAvatarTop.setClipToOutline(true);
        upRow.addView(upAvatarTop, new LinearLayout.LayoutParams(dp(26), dp(26)));

        followBtnTop = new Button(this);
        followBtnTop.setText("+ 关注");
        followBtnTop.setTextColor(Color.WHITE);
        followBtnTop.setTextSize(11);
        followBtnTop.setAllCaps(false);
        followBtnTop.setPadding(dp(14), 0, dp(14), 0);
        followBtnTop.setBackground(roundRect(0x33FFFFFF, dp(14), dp(28)));
        LinearLayout.LayoutParams fbt = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, dp(28));
        fbt.leftMargin = dp(8);
        upRow.addView(followBtnTop, fbt);
        followBtnTop.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { tapFollow(); }
        });
        topBar.addView(upRow, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        FrameLike.LayoutParams topLp = new FrameLike.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP);
        overlay.addView(topBar, topLp);

        // 倍速提示：小胶囊 + 半透明，不挡画面
        speedTag = new TextView(this);
        speedTag.setText("2× 快进中");
        speedTag.setTextColor(Color.WHITE);
        speedTag.setTextSize(12);
        speedTag.setGravity(Gravity.CENTER);
        android.graphics.drawable.GradientDrawable sbg =
                new android.graphics.drawable.GradientDrawable();
        sbg.setColor(Color.argb(85, 0, 0, 0));
        sbg.setCornerRadius(20 * getResources().getDisplayMetrics().density);
        speedTag.setBackground(sbg);
        speedTag.setPadding(dp(12), dp(5), dp(12), dp(5));
        speedTag.setVisibility(View.INVISIBLE);
        overlay.addView(speedTag, new FrameLike.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER));

        // 音量/亮度 HUD
        hud = new TextView(this);
        hud.setTextColor(Color.WHITE);
        hud.setTextSize(11);
        hud.setGravity(Gravity.CENTER);
        android.graphics.drawable.GradientDrawable hbg =
                new android.graphics.drawable.GradientDrawable();
        hbg.setColor(Color.argb(110, 0, 0, 0));
        hbg.setCornerRadius(12 * getResources().getDisplayMetrics().density);
        hud.setBackground(hbg);
        hud.setPadding(dp(12), dp(6), dp(12), dp(6));
        hud.setVisibility(View.GONE);
        overlay.addView(hud, new FrameLike.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER));

        zoomTag = new TextView(this);
        zoomTag.setTextColor(Color.WHITE);
        zoomTag.setTextSize(14);
        zoomTag.setBackgroundColor(Color.argb(110, 0, 0, 0));
        zoomTag.setPadding(dp(10), dp(4), dp(10), dp(4));
        zoomTag.setVisibility(View.GONE);
        FrameLike.LayoutParams zp = new FrameLike.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        zp.topMargin = dp(16);
        overlay.addView(zoomTag, zp);

        // 竖屏视频铺满模式：右上角「退出铺满」按钮
        exitFillBtn = new TextView(this);
        exitFillBtn.setText("退出铺满");
        exitFillBtn.setTextColor(Color.WHITE);
        exitFillBtn.setTextSize(11);
        exitFillBtn.setGravity(Gravity.CENTER);
        android.graphics.drawable.GradientDrawable ebg =
                new android.graphics.drawable.GradientDrawable();
        ebg.setColor(Color.argb(150, 0, 0, 0));
        ebg.setCornerRadius(dp(13));
        exitFillBtn.setBackground(ebg);
        exitFillBtn.setPadding(dp(9), dp(5), dp(9), dp(5));
        exitFillBtn.setVisibility(View.GONE);
        FrameLike.LayoutParams efp = new FrameLike.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP | Gravity.RIGHT);
        efp.topMargin = dp(56);
        efp.rightMargin = dp(10);
        overlay.addView(exitFillBtn, efp);
        exitFillBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { exitPortraitFill(); }
        });

        // 竖屏视频全屏：左侧信息面板（填补左右留白）
        portraitInfo = new LinearLayout(this);
        portraitInfo.setOrientation(LinearLayout.VERTICAL);
        portraitInfo.setVisibility(View.GONE);
        portraitInfo.setPadding(dp(4), 0, dp(4), 0);

        pTitle = new TextView(this);
        pTitle.setTextColor(Color.WHITE);
        pTitle.setTextSize(15);
        pTitle.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        pTitle.setMaxLines(5);
        pTitle.setEllipsize(android.text.TextUtils.TruncateAt.END);
        pTitle.setLineSpacing(dp(3), 1f);
        pTitle.setShadowLayer(dp(4), 0, dp(1), Color.BLACK);
        portraitInfo.addView(pTitle, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        pUp = new TextView(this);
        pUp.setTextColor(Color.parseColor("#cfd3da"));
        pUp.setTextSize(12);
        pUp.setMaxLines(1);
        pUp.setEllipsize(android.text.TextUtils.TruncateAt.END);
        pUp.setShadowLayer(dp(3), 0, dp(1), Color.BLACK);
        LinearLayout.LayoutParams pup = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        pup.topMargin = dp(10);
        portraitInfo.addView(pUp, pup);

        FrameLike.LayoutParams pip = new FrameLike.LayoutParams(
                dp(190), ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.LEFT | Gravity.CENTER_VERTICAL);
        pip.leftMargin = dp(16);
        overlay.addView(portraitInfo, pip);

        // 发弹幕窗口（顶部滑出，避免和底部控制条、键盘打架）
        dmPanel = new LinearLayout(this);
        dmPanel.setOrientation(LinearLayout.HORIZONTAL);
        dmPanel.setGravity(Gravity.CENTER_VERTICAL);
        android.graphics.drawable.GradientDrawable dpbg =
                new android.graphics.drawable.GradientDrawable();
        dpbg.setColor(Color.argb(238, 31, 34, 41));
        dpbg.setCornerRadius(dp(12));
        dmPanel.setBackground(dpbg);
        dmPanel.setPadding(dp(8), dp(7), dp(8), dp(7));
        dmPanel.setVisibility(View.GONE);

        dmInput = new EditText(this);
        dmInput.setHint("发个友善的弹幕吧…");
        dmInput.setHintTextColor(Color.parseColor("#6f7581"));
        dmInput.setTextColor(Color.WHITE);
        dmInput.setTextSize(13);
        dmInput.setSingleLine(true);
        dmInput.setPadding(dp(10), dp(6), dp(10), dp(6));
        android.graphics.drawable.GradientDrawable ibg =
                new android.graphics.drawable.GradientDrawable();
        ibg.setColor(Color.parseColor("#2a2e36"));
        ibg.setCornerRadius(dp(9));
        dmInput.setBackground(ibg);
        dmPanel.addView(dmInput, new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        Button dmSend = new Button(this);
        dmSend.setText("发送");
        dmSend.setTextColor(Color.WHITE);
        dmSend.setTextSize(12);
        dmSend.setAllCaps(false);
        dmSend.setBackgroundColor(MainActivity.C_ACC);
        LinearLayout.LayoutParams dsp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        dsp.leftMargin = dp(7);
        dmPanel.addView(dmSend, dsp);
        dmSend.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { sendDanmaku(); }
        });

        Button dmClose = new Button(this);
        dmClose.setText("×");
        dmClose.setTextColor(MainActivity.C_SUB);
        dmClose.setTextSize(14);
        dmClose.setAllCaps(false);
        dmClose.setBackgroundColor(Color.TRANSPARENT);
        dmClose.setPadding(dp(8), 0, dp(8), 0);
        dmPanel.addView(dmClose);
        dmClose.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { hideDmPanel(); }
        });

        FrameLike.LayoutParams dmp = new FrameLike.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP);
        dmp.leftMargin = dp(12);
        dmp.rightMargin = dp(12);
        dmp.topMargin = dp(92);
        overlay.addView(dmPanel, dmp);

        tipText = new TextView(this);
        tipText.setTextColor(Color.WHITE);
        tipText.setTextSize(12);
        tipText.setGravity(Gravity.CENTER);
        tipText.setPadding(20, 10, 20, 10);
        FrameLike.LayoutParams ttp = new FrameLike.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER);
        ttp.topMargin = dp(56);
        overlay.addView(tipText, ttp);

        // ---------------- 【v3.9】加载动画：跳舞的小电视 + 正在加载喵~ ----------------
        buildLoadAnim(overlay);

        holder.addView(overlay, new FrameLike.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, videoHeight));
        root.addView(holder, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // ---------------- 控制条（参照 B 站：时间行 / 细进度条 / 工具行） ----------------
        ctrlBar = new LinearLayout(this);
        ctrlBar.setOrientation(LinearLayout.VERTICAL);
        ctrlBar.setBackgroundColor(0xE60B0D10);
        ctrlBar.setPadding(dp(12), dp(7), dp(12), dp(5));

        // 第一行：时间 + 更多
        LinearLayout timeRow = new LinearLayout(this);
        timeRow.setOrientation(LinearLayout.HORIZONTAL);
        timeRow.setGravity(Gravity.CENTER_VERTICAL);

        timeText = new TextView(this);
        timeText.setText("00:00/00:00");
        timeText.setTextColor(Color.WHITE);
        timeText.setTextSize(10);
        timeText.setTypeface(android.graphics.Typeface.MONOSPACE);
        timeRow.addView(timeText, new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        qualityBtn = textTool(qualityShort(Prefs.quality(this)), new View.OnClickListener() {
            @Override public void onClick(View v) { showQualityDialog(); }
        });
        qualityBtn.setTextColor(0xD9FFFFFF);
        timeRow.addView(qualityBtn);

        moreBtn = Ic.view(this, "more", Color.WHITE, 18);
        moreBtn.setPadding(dp(6), dp(2), dp(2), dp(2));
        timeRow.addView(moreBtn, new LinearLayout.LayoutParams(dp(30), dp(24)));
        moreBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showMoreMenu(); }
        });
        ctrlBar.addView(timeRow, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // 第二行：细进度条
        seek = new SeekBar(this);
        styleSeek(seek);
        LinearLayout.LayoutParams sk = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(18));
        sk.topMargin = dp(1);
        ctrlBar.addView(seek, sk);
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                if (!fromUser) return;
                doSeek(p);
            }
            @Override public void onStartTrackingTouch(SeekBar s) { }
            @Override public void onStopTrackingTouch(SeekBar s) { }
        });

        // 第三行：播放 / 下一集 / 弹幕 / 输入框 / 选集 / 倍速 / 清晰度 / 全屏
        LinearLayout tools = new LinearLayout(this);
        tools.setOrientation(LinearLayout.HORIZONTAL);
        tools.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams toolsLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        toolsLp.topMargin = dp(4);

        playIcon = Ic.view(this, "pause", Color.WHITE, 24);
        playIcon.setPadding(dp(4), dp(4), dp(4), dp(4));
        tools.addView(playIcon, new LinearLayout.LayoutParams(dp(32), dp(32)));
        playIcon.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { togglePlay(); }
        });

        nextBtn = Ic.view(this, "next", Color.WHITE, 20);
        nextBtn.setPadding(dp(4), dp(4), dp(4), dp(4));
        LinearLayout.LayoutParams nlp = new LinearLayout.LayoutParams(dp(30), dp(30));
        nlp.leftMargin = dp(2);
        tools.addView(nextBtn, nlp);
        nextBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { nextPage(); }
        });

        dmSwitch = new DmSwitch(this);
        LinearLayout.LayoutParams dmlp = new LinearLayout.LayoutParams(dp(34), dp(30));
        dmlp.leftMargin = dp(6);
        tools.addView(dmSwitch, dmlp);
        dmSwitch.setClickable(true);
        dmSwitch.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { toggleDanmaku(); }
        });
        // 【v4.8】长按「弹」打开弹幕样式设置（颜色/透明度/字号）
        dmSwitch.setOnLongClickListener(new View.OnLongClickListener() {
            @Override public boolean onLongClick(View v) {
                showDmStylePanel();
                return true;
            }
        });

        dmHint = new TextView(this);
        dmHint.setText("发个友善的弹幕见证当下");
        dmHint.setTextColor(0x99FFFFFF);
        dmHint.setTextSize(11);
        dmHint.setSingleLine(true);
        dmHint.setEllipsize(android.text.TextUtils.TruncateAt.END);
        dmHint.setGravity(Gravity.CENTER_VERTICAL);
        dmHint.setPadding(dp(12), 0, dp(12), 0);
        dmHint.setBackground(roundRect(0x26FFFFFF, dp(15), dp(30)));
        LinearLayout.LayoutParams dhp = new LinearLayout.LayoutParams(0, dp(30), 1f);
        dhp.leftMargin = dp(7);
        dhp.rightMargin = dp(7);
        tools.addView(dmHint, dhp);
        dmHint.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showDmPanel(); }
        });

        pickBtn = textTool("选集", new View.OnClickListener() {
            @Override public void onClick(View v) { showPages(); }
        });
        tools.addView(pickBtn);

        speedBtn = textTool("倍速", new View.OnClickListener() {
            @Override public void onClick(View v) { showSpeed(); }
        });
        tools.addView(speedBtn);

        fullIcon = Ic.view(this, "full", Color.WHITE, 22);
        fullIcon.setPadding(dp(4), dp(4), dp(4), dp(4));
        LinearLayout.LayoutParams flp = new LinearLayout.LayoutParams(dp(34), dp(34));
        flp.leftMargin = dp(4);
        tools.addView(fullIcon, flp);
        fullIcon.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { toggleFullscreen(); }
        });

        ctrlBar.addView(tools, toolsLp);

        root.addView(ctrlBar, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // ---------------- 视频信息 + 互动栏（竖屏，参照 B 站详情页） ----------------
        infoWrap = new LinearLayout(this);
        infoWrap.setOrientation(LinearLayout.VERTICAL);
        infoWrap.setBackgroundColor(MainActivity.C_BG);
        infoWrap.setPadding(dp(14), dp(10), dp(14), dp(4));

        // UP 主 + 关注
        LinearLayout upLine = new LinearLayout(this);
        upLine.setOrientation(LinearLayout.HORIZONTAL);
        upLine.setGravity(Gravity.CENTER_VERTICAL);

        upAvatarBot = new ImageView(this);
        upAvatarBot.setScaleType(ImageView.ScaleType.CENTER_CROP);
        android.graphics.drawable.GradientDrawable ab2 =
                new android.graphics.drawable.GradientDrawable();
        ab2.setShape(android.graphics.drawable.GradientDrawable.OVAL);
        ab2.setColor(0xFF2A2E36);
        upAvatarBot.setBackground(ab2);
        upAvatarBot.setClipToOutline(true);
        upLine.addView(upAvatarBot, new LinearLayout.LayoutParams(dp(34), dp(34)));

        TextView upCol = new TextView(this);
        upCol.setText("UP 主");
        upCol.setTextColor(Color.parseColor("#FB7299"));
        upCol.setTextSize(12);
        upCol.setSingleLine(true);
        upCol.setEllipsize(android.text.TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams ucp = new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        ucp.leftMargin = dp(9);
        upLine.addView(upCol, ucp);
        upNameTop = upCol;

        followBtnBot = new Button(this);
        followBtnBot.setText("+ 关注");
        followBtnBot.setTextColor(Color.WHITE);
        followBtnBot.setTextSize(11);
        followBtnBot.setAllCaps(false);
        followBtnBot.setPadding(dp(16), 0, dp(16), 0);
        followBtnBot.setBackground(roundRect(0xFFFB7299, dp(15), dp(30)));
        upLine.addView(followBtnBot, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, dp(30)));
        followBtnBot.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { tapFollow(); }
        });
        infoWrap.addView(upLine, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // 标题
        bvidText = new TextView(this);
        bvidText.setText("");
        bvidText.setTextColor(MainActivity.C_FG);
        bvidText.setTextSize(14);
        bvidText.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        bvidText.setMaxLines(2);
        bvidText.setEllipsize(android.text.TextUtils.TruncateAt.END);
        bvidText.setLineSpacing(dp(2), 1f);
        LinearLayout.LayoutParams btp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        btp.topMargin = dp(10);
        infoWrap.addView(bvidText, btp);

        // 统计：播放 / 评论 / 日期
        statText = new TextView(this);
        statText.setText("");
        statText.setTextColor(Color.parseColor("#8A909C"));
        statText.setTextSize(10);
        statText.setSingleLine(true);
        LinearLayout.LayoutParams stp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        stp.topMargin = dp(6);
        infoWrap.addView(statText, stp);

        // 互动栏：赞 / 评论 / 投币 / 收藏 / 转发（图标 24dp 统一尺寸）
        interactBar = new LinearLayout(this);
        interactBar.setOrientation(LinearLayout.HORIZONTAL);
        interactBar.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams ibp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        ibp.topMargin = dp(10);

        actLikeBot = makeAct("like", "like_on", 24, false);
        actCmtBot = makeAct("comment", "comment", 24, false);
        actCoinBot = makeAct("coin", "coin", 24, false);
        actFavBot = makeAct("star", "star_on", 24, false);
        actShareBot = makeAct("share", "share", 24, false);
        addActWide(interactBar, actLikeBot);
        addActWide(interactBar, actCmtBot);
        addActWide(interactBar, actCoinBot);
        addActWide(interactBar, actFavBot);
        addActWide(interactBar, actShareBot);
        actLikeBot.box.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { tapLike(); }
        });
        actLikeBot.box.setOnLongClickListener(new View.OnLongClickListener() {
            @Override public boolean onLongClick(View v) { tripleLike(); return true; }
        });
        actCmtBot.box.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { openComments(); }
        });
        actCoinBot.box.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { tapCoin(); }
        });
        actFavBot.box.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { tapFav(); }
        });
        actShareBot.box.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { tapShare(); }
        });
        infoWrap.addView(interactBar, ibp);

        root.addView(infoWrap, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // 相关推荐（占满剩余空间）
        recWrap = new LinearLayout(this);
        recWrap.setOrientation(LinearLayout.VERTICAL);

        LinearLayout recHead = new LinearLayout(this);
        recHead.setOrientation(LinearLayout.HORIZONTAL);
        recHead.setGravity(Gravity.CENTER_VERTICAL);
        recHead.setPadding(dp(14), dp(9), dp(14), dp(4));

        TextView recTitle = new TextView(this);
        recTitle.setText("相关推荐");
        recTitle.setTextColor(MainActivity.C_FG);
        recTitle.setTextSize(13);
        recTitle.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        recHead.addView(recTitle, new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView recTip = new TextView(this);
        recTip.setText("点即切换");
        recTip.setTextColor(MainActivity.C_SUB);
        recTip.setTextSize(11);
        recHead.addView(recTip);

        recWrap.addView(recHead, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        recList = new ListView(this);
        recList.setDivider(new ColorDrawable(Color.TRANSPARENT));
        recList.setDividerHeight(dp(8));
        recList.setPadding(dp(10), 0, dp(10), dp(10));
        recList.setClipToPadding(false);
        recList.setCacheColorHint(Color.TRANSPARENT);
        recList.setSelector(new ColorDrawable(Color.TRANSPARENT));
        recList.setOverScrollMode(View.OVER_SCROLL_NEVER);
        recAdapter = new VideoAdapter(this, recRows);
        recList.setAdapter(recAdapter);
        recList.setOnItemClickListener(new android.widget.AdapterView.OnItemClickListener() {
            @Override public void onItemClick(android.widget.AdapterView<?> p,
                                              View v, int i, long id) {
                if (i < 0 || i >= recRows.size()) return;
                VideoItem it = recRows.get(i);
                if (it.isPlaceholder()) return;
                switchVideo(it);
            }
        });
        recWrap.addView(recList, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        root.addView(recWrap, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        setContentView(root);
        if (actRowRef != null) actRowRef.setVisibility(View.GONE);
        if (titleColRef != null) titleColRef.setVisibility(View.GONE);
        if (topBar != null) topBar.setBackground(null);
        setBackChip(true);
        if (upRow != null) upRow.setVisibility(View.GONE);

        // ---------------- 手势 ----------------
        gesture = new GestureDetector(this, new GestureDetector.SimpleOnGestureListener() {
            @Override public boolean onDoubleTap(MotionEvent e) {
                togglePlay();
                return true;
            }
            @Override public void onLongPress(MotionEvent e) {
                if (twoFinger) return;
                boosting = true;
                speedTag.setVisibility(View.VISIBLE);
                setRate(2.0f);
            }
            @Override public boolean onSingleTapConfirmed(MotionEvent e) {
                ctrlVisible = !ctrlVisible;
                ctrlBar.setVisibility(ctrlVisible ? View.VISIBLE : View.GONE);
                if (topBar != null) {
                    topBar.setVisibility(ctrlVisible ? View.VISIBLE : View.GONE);
                }
                return true;
            }
        });

        scaleDet = new ScaleGestureDetector(this,
                new ScaleGestureDetector.SimpleOnScaleGestureListener() {
                    @Override public boolean onScale(ScaleGestureDetector d) {
                        float f = d.getScaleFactor();
                        float ns = zoom * f;
                        if (ns < 1f) ns = 1f;
                        if (ns > 4f) ns = 4f;
                        float k = ns / zoom;
                        float fx = d.getFocusX();
                        float fy = d.getFocusY();
                        // 以双指焦点为中心缩放（pivot 固定在左上角，用平移补偿）
                        tx = fx - k * (fx - tx);
                        ty = fy - k * (fy - ty);
                        zoom = ns;
                        applyZoom();
                        return true;
                    }
                });

        overlay.setOnTouchListener(new View.OnTouchListener() {
            @Override public boolean onTouch(View v, MotionEvent ev) {
                int act = ev.getActionMasked();
                // 多指：只走缩放手势，绝不触发单击/双击/长按
                if (ev.getPointerCount() > 1
                        || (twoFinger && act != MotionEvent.ACTION_UP
                            && act != MotionEvent.ACTION_CANCEL)) {
                    twoFinger = true;
                    if (boosting) {
                        boosting = false;
                        speedTag.setVisibility(View.INVISIBLE);
                        setRate(1.0f);
                    }
                    if (vertDrag) { vertDrag = false; hideHudSoon(); }
                    scaleDet.onTouchEvent(ev);
                    return true;
                }
                if (twoFinger) {
                    twoFinger = false;
                    scaleDet.onTouchEvent(ev);
                    if (zoom <= 1.02f) {
                        zoom = 1f;
                        tx = 0f;
                        ty = 0f;
                        applyZoom();
                    }
                    return true;
                }

                // 单指上下滑：左半屏调亮度，右半屏调音量
                if (act == MotionEvent.ACTION_DOWN) {
                    downX = ev.getX();
                    downY = ev.getY();
                    vertDrag = false;
                    captureStartLevels();
                } else if (act == MotionEvent.ACTION_MOVE) {
                    if (!vertDrag && !boosting) {
                        float dx = Math.abs(ev.getX() - downX);
                        float up = downY - ev.getY();
                        if (Math.abs(up) > dp(14) && Math.abs(up) > dx) {
                            vertDrag = true;
                            // 落在右半屏 → 音量；左半屏 → 亮度
                            vertVolume = ev.getX() >= v.getWidth() / 2f;
                        }
                    }
                    if (vertDrag) {
                        applyLevel(downY - ev.getY());
                        return true;         // 拖动期间不喂给手势，避免误触暂停
                    }
                } else if (act == MotionEvent.ACTION_UP || act == MotionEvent.ACTION_CANCEL) {
                    if (vertDrag) {
                        vertDrag = false;
                        hideHudSoon();
                        return true;
                    }
                }

                if (act == MotionEvent.ACTION_UP && boosting) {
                    boosting = false;
                    speedTag.setVisibility(View.INVISIBLE);
                    setRate(1.0f);
                }
                gesture.onTouchEvent(ev);
                return true;
            }
        });
    }

    // ------------------------------------------------------------ 音量 / 亮度

    void captureStartLevels() {
        try {
            if (audioMgr == null) {
                audioMgr = (android.media.AudioManager)
                        getSystemService(android.content.Context.AUDIO_SERVICE);
            }
            maxVolume = Math.max(1, audioMgr.getStreamMaxVolume(
                    android.media.AudioManager.STREAM_MUSIC));
            startVolume = audioMgr.getStreamVolume(android.media.AudioManager.STREAM_MUSIC);
        } catch (Throwable ignore) { }
        try {
            float b = getWindow().getAttributes().screenBrightness;
            if (b < 0f) {
                b = android.provider.Settings.System.getInt(getContentResolver(),
                        android.provider.Settings.System.SCREEN_BRIGHTNESS, 128) / 255f;
            }
            startBrightness = Math.max(0.05f, Math.min(1f, b));
        } catch (Throwable ignore) {
            startBrightness = 0.5f;
        }
    }

    /** dy>0 表示手指上滑（增大） */
    void applyLevel(float dy) {
        float range = Math.max(1f, holder.getHeight() * 0.85f);
        float f = dy / range;
        try {
            if (vertVolume) {
                int v = Math.round(startVolume + f * maxVolume);
                if (v < 0) v = 0;
                if (v > maxVolume) v = maxVolume;
                if (audioMgr != null) {
                    audioMgr.setStreamVolume(android.media.AudioManager.STREAM_MUSIC, v, 0);
                }
                showHud("右侧 · 音量  " + Math.round(v * 100f / maxVolume) + "%");
            } else {
                float b = startBrightness + f;
                if (b < 0.05f) b = 0.05f;
                if (b > 1f) b = 1f;
                WindowManager.LayoutParams lp = getWindow().getAttributes();
                lp.screenBrightness = b;
                getWindow().setAttributes(lp);
                showHud("左侧 · 亮度  " + Math.round(b * 100f) + "%");
            }
        } catch (Throwable ignore) { }
    }

    final Runnable hideHudTask = new Runnable() {
        @Override public void run() {
            if (hud != null) hud.setVisibility(View.GONE);
        }
    };

    void showHud(String text) {
        if (hud == null) return;
        hud.setText(text);
        hud.setVisibility(View.VISIBLE);
        ui.removeCallbacks(hideHudTask);
    }

    void hideHudSoon() {
        if (hud == null) return;
        ui.removeCallbacks(hideHudTask);
        ui.postDelayed(hideHudTask, 800);
    }

    // ------------------------------------------------------------ 弹幕 / 竖屏优化

    long currentPos() {
        try {
            return video != null ? video.getCurrentPosition() : 0;
        } catch (Throwable e) {
            return 0;
        }
    }

    void toggleDanmaku() {
        dmOn = !dmOn;
        if (dmView != null) dmView.setVisibility(dmOn ? View.VISIBLE : View.GONE);
        if (dmSwitch != null) {
            dmSwitch.setClickable(true);
            dmSwitch.invalidate();
        }
        if (dmHint != null) {
            dmHint.setText(dmOn ? "发个友善的弹幕见证当下" : "弹幕已关闭，点这里重新开启");
        }
        showToastSafe(dmOn ? "弹幕已开启（长按「弹」调颜色/字号）" : "弹幕已关闭");
    }

    void showDmPanel() {
        if (dmPanel == null) return;
        dmPanel.setVisibility(View.VISIBLE);
        dmPanel.bringToFront();
        dmInput.requestFocus();
        try {
            android.view.inputmethod.InputMethodManager imm =
                    (android.view.inputmethod.InputMethodManager)
                            getSystemService(INPUT_METHOD_SERVICE);
            imm.showSoftInput(dmInput, android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT);
        } catch (Throwable ignore) { }
    }

    void hideDmPanel() {
        if (dmPanel == null) return;
        dmPanel.setVisibility(View.GONE);
        try {
            android.view.inputmethod.InputMethodManager imm =
                    (android.view.inputmethod.InputMethodManager)
                            getSystemService(INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(dmInput.getWindowToken(), 0);
        } catch (Throwable ignore) { }
    }

    void sendDanmaku() {
        final String txt = dmInput != null ? dmInput.getText().toString().trim() : "";
        if (txt.isEmpty()) {
            showToastSafe("先写点内容吧");
            return;
        }
        if (BiliApi.loggedInUid() == null) {
            showToastSafe("请先在「我的」页登录 B 站账号");
            return;
        }
        if (dmCid <= 0 || dmBvid.isEmpty()) {
            showToastSafe("视频信息还没准备好，稍等几秒");
            return;
        }
        final long pos = currentPos();
        hideDmPanel();
        dmInput.setText("");
        new Thread(new Runnable() { @Override public void run() {
            try {
                BiliApi.danmakuSend(dmBvid, dmCid, txt, pos);
                ui.post(new Runnable() { @Override public void run() {
                    if (dmView != null) dmView.addLocal(txt);
                    showToastSafe("弹幕已发送");
                } });
            } catch (final Throwable e) {
                ui.post(new Runnable() { @Override public void run() {
                    showToastSafe("发送失败：" + e.getMessage());
                } });
            }
        } }).start();
    }

    void loadDanmaku(final long cid) {
        dmCid = cid;
        if (dmView == null) return;
        dmView.clear();
        new Thread(new Runnable() { @Override public void run() {
            try {
                final ArrayList<DanmakuView.Item> list =
                        DanmakuView.parse(BiliApi.danmakuXml(cid));
                ui.post(new Runnable() { @Override public void run() {
                    if (dmCid == cid && dmView != null) dmView.setData(list);
                } });
            } catch (Throwable ignore) { }
        } }).start();
    }

    /** 取标题/UP/封面/尺寸：竖屏视频场景与背景填充都靠它 */
    /** 拉取视频详情（view 接口）：标题 / UP / 统计 / 分P / 竖屏尺寸，并同步互动状态 */
    void loadVideoMeta(final String bv) {
        if (bv == null || bv.isEmpty() || bv.startsWith("av")) return;
        new Thread(new Runnable() { @Override public void run() {
            // 【v4.8】原来 4 个请求（meta / like / coin / follow）全串行，
            // 最坏要等 4 个网络往返才把标题和互动数显示出来。
            // 现在 like/coin 与 meta 同时开跑，follow 依赖 meta 里的 mid 再跟上，
            // 整体耗时约等于 max(meta+follow, like, coin)，通常能快 30%~50%。
            final int[] st = new int[3];   // 0=liked 1=coins(已投) 2=followed
            final Thread tl = new Thread(new Runnable() { @Override public void run() {
                try { st[0] = BiliApi.likeState(bv); } catch (Throwable ignore) { }
            } }, "meta-like");
            final Thread tc = new Thread(new Runnable() { @Override public void run() {
                try { st[1] = BiliApi.coinState(bv); } catch (Throwable ignore) { }
            } }, "meta-coin");
            tl.start();
            tc.start();

            JSONObject v = null;
            try {
                v = BiliApi.archiveMeta(bv);
            } catch (Throwable e) {
                v = null;
            }
            if (v == null) {
                // meta 都没拿到就没必要等状态了（线程都是短请求，会自行结束）
                return;
            }
            final JSONObject fv = v;
            JSONObject owner = fv.optJSONObject("owner");
            final long mid = owner == null ? 0 : owner.optLong("mid", 0);
            try { if (mid > 0) st[2] = BiliApi.followState(mid); } catch (Throwable ignore) { }
            try { tl.join(2500); } catch (Throwable ignore) { }
            try { tc.join(2500); } catch (Throwable ignore) { }
            final int lk = st[0], cn = st[1], fl = st[2];
            ui.post(new Runnable() { @Override public void run() {
                // 【v4.7】已切到别的视频时，旧视频的元数据晚返回会把标题/UP主/互动状态改回去
                if (!bv.equals(bvid)) return;
                applyMeta(fv, lk, cn, fl);
            } });
        } }).start();
    }

    void applyMeta(JSONObject v, int lk, int cn, int fl) {
        if (v == null || isFinishing()) return;
        try {
            metaLoaded = true;
            aid = v.optLong("aid", 0);
            videoTitle = BiliApi.cleanTitle(v.optString("title", ""));
            videoCover = v.optString("pic", "");
            coverUrl = videoCover;
            vTitle = videoTitle;

            JSONObject owner = v.optJSONObject("owner");
            if (owner != null) {
                ownerMid = owner.optLong("mid", 0);
                upName = owner.optString("name", "");
                String face = owner.optString("face", "");
                if (face.startsWith("//")) face = "https:" + face;
                if (!face.isEmpty()) {
                    if (upAvatarBot != null) ImgLoader.load(upAvatarBot, face, dp(34), dp(34));
                    if (upAvatarTop != null) ImgLoader.load(upAvatarTop, face, dp(26), dp(26));
                }
                if (bgCover != null && !videoCover.isEmpty()) {
                    ImgLoader.load(bgCover, videoCover,
                            getResources().getDisplayMetrics().widthPixels, dp(400));
                }
            }
            if (upNameTop != null) upNameTop.setText(upName.isEmpty() ? "UP 主" : upName);
            if (pUp != null) pUp.setText(upName.isEmpty() ? "" : "UP主 · " + upName);

            JSONObject stat = v.optJSONObject("stat");
            if (stat != null) {
                statView = stat.optLong("view", 0);
                statDm = stat.optLong("danmaku", 0);
                statReply = stat.optInt("reply", 0);
                statLike = stat.optInt("like", 0);
                statCoin = stat.optInt("coin", 0);
                statFav = stat.optInt("favorite", 0);
                statShare = stat.optInt("share", 0);
            }
            long pub = v.optLong("pubdate", 0);
            if (pub > 0) {
                pubDate = new java.text.SimpleDateFormat("yyyy-MM-dd")
                        .format(new java.util.Date(pub * 1000L));
            }
            JSONArray pages = v.optJSONArray("pages");
            if (pages != null && pages.length() > 0) {
                pagesArr = pages;
                if (nextBtn != null) nextBtn.setAlpha(pages.length() > 1 ? 1f : 0.35f);
            }
            JSONObject dim = v.optJSONObject("dimension");
            if (dim != null) {
                int dw = dim.optInt("width", 0);
                int dh = dim.optInt("height", 0);
                if (dw > 0 && dh > 0) {
                    int rot = dim.optInt("rotate", 0);
                    if (rot == 90 || rot == 270) { int t = dw; dw = dh; dh = t; }
                    videoAspect = dw / (float) dh;
                    portraitVideo = dh > dw * 1.15f;
                }
            }
            // 竖屏视频在竖屏持机时自动铺满整屏；横屏视频恢复普通布局
            if (Prefs.portraitOptimize(this)) {
                if (portraitVideo && !fullscreen) enterPortraitFill();
                else if (!portraitVideo && portraitFill) exitPortraitFill();
            }

            String t = videoTitle.isEmpty() ? curBv : videoTitle;
            if (titleTop != null) titleTop.setText(t);
            if (bvidText != null) bvidText.setText(t);
            if (pTitle != null) pTitle.setText(t);

            String watch = numText(statView) + "播放";
            if (!pubDate.isEmpty()) watch += " · " + pubDate;
            if (watchText != null) watchText.setText(watch);
            if (statText != null) {
                statText.setText(numText(statView) + "播放 · " + numText(statReply) + "评论 · "
                        + numText(statDm) + "弹幕"
                        + (pubDate.isEmpty() ? "" : " · " + pubDate));
            }

            liked = lk == 1;
            coins = Math.max(0, cn);
            followedState = Math.max(0, fl);
            refreshActs();
            if (fullscreen) applyFullscreenLayout();
        } catch (Throwable e) {
            CrashHandler.note("meta", "填充视频信息失败：" + e);
        }
    }

    /** 全屏画面排布：竖屏视频按高度居中 + 封面虚化背景 + 左侧信息；横屏视频照常铺满 */
    void applyFullscreenLayout() {
        if (!fullscreen) return;
        boolean opt = portraitVideo && Prefs.portraitOptimize(this);
        try {
            if (opt) {
                int h = getResources().getDisplayMetrics().heightPixels;
                int w = (int) (h * Math.max(0.3f, Math.min(1.2f, videoAspect)));
                int maxW = getResources().getDisplayMetrics().widthPixels - dp(28);
                if (w > maxW) w = maxW;
                if (w < dp(110)) w = dp(110);
                FrameLike.LayoutParams lp =
                        new FrameLike.LayoutParams(w, ViewGroup.LayoutParams.MATCH_PARENT,
                                Gravity.CENTER);
                video.setLayoutParams(lp);
                vlcSurface.setLayoutParams(new FrameLike.LayoutParams(
                        w, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.CENTER));
                if (dmView != null) dmView.setLayoutParams(new FrameLike.LayoutParams(
                        w, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.CENTER));
                bgCover.setVisibility(View.VISIBLE);
                if (!coverUrl.isEmpty()) {
                    String u = coverUrl.startsWith("//") ? "https:" + coverUrl : coverUrl;
                    if (!u.contains("@")) u = u + "@640w_640h_1c.jpg";
                    ImgLoader.load(bgCover, u, dp(360), dp(640));
                }
                pTitle.setText(vTitle);
                pUp.setText(vUp.isEmpty() ? "" : "UP主 · " + vUp);
                portraitInfo.setVisibility(View.VISIBLE);
            } else {
                video.setLayoutParams(new FrameLike.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
                vlcSurface.setLayoutParams(new FrameLike.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
                if (dmView != null) dmView.setLayoutParams(new FrameLike.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
                bgCover.setVisibility(View.GONE);
                portraitInfo.setVisibility(View.GONE);
            }
            overlay.setLayoutParams(new FrameLike.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        } catch (Throwable ignore) { }
    }

    // ------------------------------------------------------------ 竖屏视频铺满（竖屏持机）

    /**
     * 竖屏视频 + 竖屏持机 → 铺满整屏。
     * 视频画面按自身宽高比放大到「覆盖」整个画面区（超出部分由父容器裁剪），
     * 因此不会变形、也不会留下左右黑边；顶部栏与底部控制条悬浮在画面之上。
     */
    void enterPortraitFill() {
        if (!portraitVideo || fullscreen || portraitFill) return;
        portraitFill = true;
        try {
            // 画面容器占满整屏
            root.updateViewLayout(holder, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
            // 收起普通模式下的页面内容
            if (infoWrap != null) infoWrap.setVisibility(View.GONE);
            if (recWrap != null) recWrap.setVisibility(View.GONE);
            // 顶部栏：返回 + 标题 + 互动图标（复用全屏样式）
            if (upRow != null) upRow.setVisibility(View.VISIBLE);
            if (actRowRef != null) actRowRef.setVisibility(View.VISIBLE);
            if (titleColRef != null) titleColRef.setVisibility(View.VISIBLE);
            if (topBar != null) topBar.setBackground(new android.graphics.drawable.GradientDrawable(
                    android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM,
                    new int[]{0xCC000000, 0x66000000, 0x00000000}));
            setBackChip(false);
            // 控制条从页面流里移到画面底部悬浮
            root.removeView(ctrlBar);
            overlay.addView(ctrlBar, new FrameLike.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                    Gravity.BOTTOM));
            ctrlBar.setBackgroundColor(0xB3000000);
            overlay.setLayoutParams(new FrameLike.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            if (bgCover != null) bgCover.setVisibility(View.GONE);
            if (portraitInfo != null) portraitInfo.setVisibility(View.GONE);
            if (exitFillBtn != null) exitFillBtn.setVisibility(View.VISIBLE);
            ctrlVisible = true;
            ctrlBar.setVisibility(View.VISIBLE);
            if (topBar != null) topBar.setVisibility(View.VISIBLE);
            resetZoom();
            applyPortraitFillSize();
        } catch (Throwable e) {
            CrashHandler.note("portraitFill", "进入竖屏铺满失败：" + e);
        }
    }

    /** 按视频宽高比计算 cover 尺寸，让画面铺满且不留黑边 */
    void applyPortraitFillSize() {
        if (!portraitFill || fullscreen) return;
        ui.post(new Runnable() { @Override public void run() {
            if (!portraitFill || fullscreen || isFinishing()) return;
            int W = holder.getWidth() > 0 ? holder.getWidth()
                    : getResources().getDisplayMetrics().widthPixels;
            int H = holder.getHeight() > 0 ? holder.getHeight()
                    : getResources().getDisplayMetrics().heightPixels;
            if (W <= 0 || H <= 0 || videoAspect <= 0) return;
            float screenAr = W / (float) H;
            int vw, vh;
            if (screenAr < videoAspect) {
                // 屏幕相对更瘦高：按高度撑满，宽度略微超出左右裁切
                vh = H;
                vw = Math.round(H * videoAspect);
            } else {
                // 屏幕相对更宽扁：按宽度撑满，高度略微超出上下裁切
                vw = W;
                vh = Math.round(W / videoAspect);
            }
            final FrameLike.LayoutParams vp =
                    new FrameLike.LayoutParams(vw, vh, Gravity.CENTER);
            video.setLayoutParams(vp);
            vlcSurface.setLayoutParams(new FrameLike.LayoutParams(vw, vh, Gravity.CENTER));
            // 弹幕层跟随可见画面铺满屏幕（弹幕坐标以屏幕为准）
            if (dmView != null) dmView.setLayoutParams(new FrameLike.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT, Gravity.CENTER));
            if (flipCover != null) flipCover.setLayoutParams(new FrameLike.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            try { video.setScaleX(1f); video.setScaleY(1f); } catch (Throwable ignore) { }
        } });
    }

    /** 退出竖屏铺满，还原到普通竖屏详情页布局 */
    void exitPortraitFill() {
        if (!portraitFill) return;
        portraitFill = false;
        try {
            if (exitFillBtn != null) exitFillBtn.setVisibility(View.GONE);
            // 控制条回到页面流
            overlay.removeView(ctrlBar);
            root.addView(ctrlBar, 1, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            ctrlBar.setBackgroundColor(0xE60B0D10);
            // 恢复页面内容
            if (infoWrap != null) infoWrap.setVisibility(View.VISIBLE);
            if (recWrap != null) recWrap.setVisibility(View.VISIBLE);
            if (upRow != null) upRow.setVisibility(View.GONE);
            if (actRowRef != null) actRowRef.setVisibility(View.GONE);
            if (titleColRef != null) titleColRef.setVisibility(View.GONE);
            if (topBar != null) {
                topBar.setBackground(null);
                topBar.setVisibility(View.VISIBLE);
            }
            setBackChip(true);
            root.updateViewLayout(holder, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            video.setLayoutParams(new FrameLike.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, videoHeight));
            vlcSurface.setLayoutParams(new FrameLike.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, videoHeight));
            if (dmView != null) dmView.setLayoutParams(new FrameLike.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, videoHeight));
            if (flipCover != null) flipCover.setLayoutParams(new FrameLike.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, videoHeight));
            overlay.setLayoutParams(new FrameLike.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, videoHeight));
            if (bgCover != null) bgCover.setVisibility(View.GONE);
            if (portraitInfo != null) portraitInfo.setVisibility(View.GONE);
            ctrlVisible = true;
            ctrlBar.setVisibility(View.VISIBLE);
            resetZoom();
        } catch (Throwable e) {
            CrashHandler.note("portraitFill", "退出竖屏铺满失败：" + e);
        }
    }

    // ------------------------------------------------------------ 全屏

    void toggleFullscreen() {
        if (fullscreen) exitFullscreen();
        else enterFullscreen();
    }

    void enterFullscreen() {
        if (fullscreen) return;
        if (portraitFill) exitPortraitFill();   // 与竖屏铺满互斥，先还原
        fullscreen = true;
        if (fullIcon != null) Ic.set(fullIcon, "exitfull", Color.WHITE);
        ctrlVisible = true;
        ctrlBar.setVisibility(View.VISIBLE);

        // 控制条从 root 移到 overlay 底部，浮在画面上
        root.removeView(ctrlBar);
        overlay.addView(ctrlBar, new FrameLike.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM));

        recWrap.setVisibility(View.GONE);
        if (infoWrap != null) infoWrap.setVisibility(View.GONE);
        if (upRow != null) upRow.setVisibility(View.VISIBLE);
        if (actRowRef != null) actRowRef.setVisibility(View.VISIBLE);
        if (titleColRef != null) titleColRef.setVisibility(View.VISIBLE);
        if (topBar != null) topBar.setBackground(new android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0xCC000000, 0x66000000, 0x00000000}));
        setBackChip(false);

        root.updateViewLayout(holder, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        applyFullscreenLayout();

        resetZoom();
        applyFullscreenWindow(true);
        try {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
        } catch (Throwable ignore) { }
    }

    void exitFullscreen() {
        if (!fullscreen) return;
        fullscreen = false;
        if (fullIcon != null) Ic.set(fullIcon, "full", Color.WHITE);

        overlay.removeView(ctrlBar);
        root.addView(ctrlBar, 1, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        recWrap.setVisibility(View.VISIBLE);
        if (infoWrap != null) infoWrap.setVisibility(View.VISIBLE);
        if (upRow != null) upRow.setVisibility(View.GONE);
        if (actRowRef != null) actRowRef.setVisibility(View.GONE);
        if (titleColRef != null) titleColRef.setVisibility(View.GONE);
        if (topBar != null) topBar.setBackground(null);
        setBackChip(true);

        root.updateViewLayout(holder, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        video.setLayoutParams(new FrameLike.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, videoHeight));
        vlcSurface.setLayoutParams(new FrameLike.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, videoHeight));
        if (dmView != null) dmView.setLayoutParams(new FrameLike.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, videoHeight));
        overlay.setLayoutParams(new FrameLike.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, videoHeight));
        bgCover.setVisibility(View.GONE);
        portraitInfo.setVisibility(View.GONE);

        ctrlVisible = true;
        ctrlBar.setVisibility(View.VISIBLE);
        resetZoom();
        applyFullscreenWindow(false);
        try {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
        } catch (Throwable ignore) { }
        // 退出横屏全屏、回到竖屏后：竖屏视频重新铺满整屏
        ui.postDelayed(new Runnable() { @Override public void run() {
            if (!isFinishing() && !fullscreen && portraitVideo
                    && Prefs.portraitOptimize(PlayActivity.this)) enterPortraitFill();
        } }, 450);
    }

    void applyFullscreenWindow(boolean on) {
        try {
            if (on) {
                getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
                getWindow().getDecorView().setSystemUiVisibility(
                        View.SYSTEM_UI_FLAG_FULLSCREEN
                                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
            } else {
                getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
                getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
            }
        } catch (Throwable ignore) { }
    }

    /** 返回：全屏时先退出全屏，竖屏铺满时先还原，普通模式直接返回上一页 */
    void goBack() {
        if (fullscreen) {
            exitFullscreen();
            return;
        }
        if (portraitFill) {
            exitPortraitFill();
            return;
        }
        finish();
    }

    @Override
    public void onBackPressed() {
        if (fullscreen) {
            exitFullscreen();
            return;
        }
        if (portraitFill) {
            exitPortraitFill();
            return;
        }
        super.onBackPressed();
    }

    // ------------------------------------------------------------ 双指缩放

    void resetZoom() {
        zoom = 1f;
        tx = 0f;
        ty = 0f;
        applyZoom();
    }

    void applyZoom() {
        View t = video;
        try {
            int w = t.getWidth();
            int h = t.getHeight();
            if (zoom > 1f && w > 0 && h > 0) {
                float minX = -w * (zoom - 1f);
                float minY = -h * (zoom - 1f);
                if (tx > 0f) tx = 0f;
                if (tx < minX) tx = minX;
                if (ty > 0f) ty = 0f;
                if (ty < minY) ty = minY;
            } else if (zoom <= 1.02f) {
                tx = 0f;
                ty = 0f;
            }
            t.setPivotX(0);
            t.setPivotY(0);
            t.setScaleX(zoom);
            t.setScaleY(zoom);
            t.setTranslationX(tx);
            t.setTranslationY(ty);
        } catch (Throwable ignore) { }
        if (zoomTag != null) {
            if (zoom > 1.02f) {
                zoomTag.setText(String.format("%.1f×", zoom));
                zoomTag.setVisibility(View.VISIBLE);
            } else {
                zoomTag.setVisibility(View.GONE);
            }
        }
    }

    // ------------------------------------------------------------ 播放控制

    float rate = 1f;
    long lastPosSave = 0;      // 上次保存播放进度的时间
    int pendingResumeMs = 0;   // 待提示的续播位置（seek 成功后弹一次提示）

    /** 当前播放位置（ms），兼容 DASH / VLC / 普通三种引擎 */
    int curPosMs() {
        try {
            if (dashMode) return video.getCurrentPosition();
            if (video != null) return video.getCurrentPosition();
        } catch (Throwable ignore) { }
        return 0;
    }

    /** 当前总时长（ms） */
    int curDurMs() {
        try {
            if (dashMode) return pageDurMs > 0 ? (int) pageDurMs : video.getDuration();
            if (video != null) return video.getDuration();
        } catch (Throwable ignore) { }
        return 0;
    }

    /** 保存当前进度（供 tick 周期保存与退出时保存） */
    void savePosNow() {
        try {
            if (curBv == null || curBv.isEmpty()) return;
            int p = curPosMs(), d = curDurMs();
            if (p > 5000) PlayPos.save(this, curBv, p, d);
        } catch (Throwable ignore) { }
    }

    /** 续播成功后弹一次轻提示 */
    void announceResume() {
        if (pendingResumeMs <= 0) return;
        showToastSafe("已从上次 " + PlayPos.fmt(pendingResumeMs) + " 继续播放");
        pendingResumeMs = 0;
    }

    String rateLabel(float r) {
        if (Math.abs(r - 1f) < 0.01f) return "倍速";
        if (Math.abs(r - 0.75f) < 0.01f) return "0.75×";
        if (Math.abs(r - 1.25f) < 0.01f) return "1.25×";
        if (Math.abs(r - 1.5f) < 0.01f) return "1.5×";
        if (Math.abs(r - 2f) < 0.01f) return "2.0×";
        return "0.5×";
    }

    void setRate(float r) {
        rate = r;
        try {
            if (player != null) {
                android.media.PlaybackParams pp = player.getPlaybackParams();
                pp.setSpeed(r);
                player.setPlaybackParams(pp);
            }
            if (dashMode && audioPlayer != null && audioStarted) {
                android.media.PlaybackParams ap = audioPlayer.getPlaybackParams();
                ap.setSpeed(r);
                audioPlayer.setPlaybackParams(ap);
            }
        } catch (Throwable ignore) { }
    }

    void togglePlay() {
        try {
            boolean playing = video != null && video.isPlaying();
            updatePlayIcon(!playing);
            if (video.isPlaying()) {
                video.pause();
                if (dashMode && audioPlayer != null && audioStarted) audioPlayer.pause();
            } else {
                video.start();
                // 【v4.6】仅当音频已起播过才跟随播放；尚未起播的（正在等画面首帧）由起播回调统一放行，
                // 否则声音又会先于画面出来。
                if (dashMode && audioPlayer != null && audioStarted) audioPlayer.start();
            }
        } catch (Throwable ignore) { }
    }

    void onDecodeSwitch(int mode) {
        play(mode);
    }

    /** 拖动进度条：三套引擎分别处理，高清双流要同步拖音频 */
    void doSeek(int p) {
        try {
            if (dashMode) {
                video.seekTo(p);
                if (audioPlayer != null && audioStarted) audioPlayer.seekTo(p);
                lastAudioSync = System.currentTimeMillis();
            } else {
                video.seekTo(p);
            }
        } catch (Throwable ignore) { }
    }

    // ------------------------------------------------------------ 清晰度

    static String qualityShort(int q) {
        switch (q) {
            case Prefs.Q_4K: return "4K";
            case Prefs.Q_2K: return "2K";
            case Prefs.Q_1080P60: return "1080P60";
            case Prefs.Q_1080P: return "1080P";
            case Prefs.Q_720P: return "720P";
            case Prefs.Q_480P: return "480P";
            case Prefs.Q_360P: return "360P";
            default: return "自动";
        }
    }

    void showQualityDialog() {
        final int cur = Prefs.quality(this);
        AlertDialog.Builder b = new AlertDialog.Builder(this);
        b.setTitle("清晰度");
        b.setSingleChoiceItems(Prefs.Q_NAMES, cur, new DialogInterface.OnClickListener() {
            @Override public void onClick(DialogInterface d, int which) {
                d.dismiss();
                Prefs.setQuality(PlayActivity.this, which);
                if (qualityBtn != null) qualityBtn.setText(qualityShort(which));
                applyQuality();
            }
        });
        b.setNegativeButton("取消", null);
        b.show();
    }

    /** 切清晰度：360p / 兼容模式走合流，其余走 DASH 高清双流 */
    void applyQuality() {
        int q = Prefs.quality(this);
        int dec = Prefs.decoder(this);
        try { resumePos = dashMode ? video.getCurrentPosition() : 0; } catch (Throwable ignore) { }
        dashFailed = false;
        if (q == Prefs.Q_360P) {
            play(3);
        } else {
            play(dec == Prefs.DEC_LOW ? 3 : 1);
        }
    }

    // ------------------------------------------------------------ 播放

    void play(final int mode) {
        if (proxy == null) {
            showToastSafe("本地代理启动失败");
            return;
        }
        muxRetry = 0;   // 每次新播放重置重试计数
        showLoadAnim(true, playLoadMsg);
        playLoadMsg = "正在加载喵~";   // 一次性：用完即恢复默认文案
        tipText.setText("获取播放地址…");
        final String currentBv = bvid;
        // 【v4.7】在 UI 线程快照，避免工作线程读到半更新的状态
        final long snapCid = curCid;
        final String snapBv = curBv;
        final String snapTitle = videoTitle;
        final long snapDurSec = pageDurMs / 1000;
        new Thread(new Runnable() { @Override public void run() {
            try {
                String bv = currentBv;
                String aid = null;
                if (bv.startsWith("av")) {
                    aid = bv.substring(2);
                    bv = null;
                }
                String realBvid;
                long cid;
                String pageTitle;
                long durSec = 0;
                long knownCid = prefetchedCid;
                String knownTitle = prefetchedTitle;
                long knownDur = prefetchedDur;
                // 【v4.7】切过视频后 prefetchedCid 已清零；若仍是同一个 bvid 且已有 curCid，
                // 直接复用（切清晰度不必再走一次 pages 往返，也少一次风控风险）
                if (knownCid <= 0 && snapCid > 0 && pageIndex == 0
                        && bv != null && bv.equals(snapBv)) {
                    knownCid = snapCid;
                    knownTitle = snapTitle;
                    knownDur = snapDurSec;
                }
                if (bv != null && knownCid > 0 && pageIndex == 0) {
                    // 【v4.1 提速】列表页已带 cid，直接用，跳过 pages() 网络往返
                    // 分P信息由 loadVideoMeta 后台补齐，不阻塞起播
                    cid = knownCid;
                    realBvid = bv;
                    pageTitle = (knownTitle != null && !knownTitle.isEmpty())
                            ? knownTitle : bv;
                    durSec = knownDur;
                } else if (bv != null) {
                    // 无预取 cid（如深链/搜索）：走 pagelist（抗风控更好，还能拿到分P时长）
                    final JSONArray pgs = BiliApi.pages(bv);
                    if (pageIndex >= pgs.length()) pageIndex = 0;
                    ui.post(new Runnable() { @Override public void run() {
                        pagesArr = pgs;
                        if (nextBtn != null) nextBtn.setAlpha(pgs.length() > 1 ? 1f : 0.35f);
                    } });
                    JSONObject pg = pgs.getJSONObject(pageIndex);
                    cid = pg.getLong("cid");
                    realBvid = bv;
                    pageTitle = pg.optString("part", bv);
                    durSec = pg.optLong("duration", 0);
                } else {
                    // av 号需要 view 反查 bvid
                    JSONObject v = BiliApi.view(null, aid);
                    realBvid = v.optString("bvid", "");
                    JSONObject p0 = v.getJSONArray("pages").getJSONObject(0);
                    cid = p0.getLong("cid");
                    pageTitle = v.optString("title", realBvid);
                    durSec = p0.optLong("duration", 0);
                }
                History.add(PlayActivity.this, realBvid, pageTitle);
                // 续播：本地有进度且当前没有「切清晰度时保留的位置」，就从上次位置继续
                if (resumePos <= 0) {
                    int saved = PlayPos.pos(PlayActivity.this, realBvid);
                    if (saved > 5000) {
                        resumePos = saved;
                        pendingResumeMs = saved;
                    }
                }
                final String bvF = realBvid;
                final long cidF = cid;
                final long durMs = durSec * 1000;

                // ① 高清：DASH 音视频分离流（4K / 2K / 1080P60 / 1080P）
                int q = Prefs.quality(PlayActivity.this);
                boolean wantDash = (mode == 0 || mode == 1) && !dashFailed && q != Prefs.Q_360P;
                if (wantDash) {
                    try {
                        JSONObject pd = BiliApi.playurl(bvF, null, cidF, Prefs.qualityQn(q));
                        final String[] vs = BiliApi.pickVideo(pd, Prefs.qualityHeight(q));
                        final String[] as = BiliApi.pickAudio(pd);
                        final JSONObject pdF = pd;
                        final int maxH = BiliApi.maxVideoHeight(pd);
                        ui.post(new Runnable() { @Override public void run() {
                            // 【v4.7】连点推荐会并发多个 play()，旧视频晚返回的结果必须丢弃，
                            // 否则会把刚切过去的新视频又覆盖回旧视频
                            if (!bvF.equals(bvid)) return;
                            playDataCache = pdF;
                            pageDurMs = durMs;
                            curCid = cidF;
                            curBv = bvF;
                            bvidText.setText(bvF + " · " + vs[3]);
                            tipText.setText("");
                            dmBvid = bvF;
                            loadDanmaku(cidF);
                            loadVideoMeta(bvF);
                            // 【v3.9 四线路】带上 playData，DASH 音/画面也能逐条切换
                            startDash(vs[0], as[0], pdF, Integer.parseInt(vs[1]));
                            if (q == Prefs.Q_4K && maxH < 2000) {
                                showToastSafe("该视频/账号暂无 4K，已用 " + vs[3]);
                            } else if (q == Prefs.Q_2K && maxH < 1400) {
                                showToastSafe("该视频/账号暂无 2K，已用 " + vs[3]);
                            }
                        } });
                        return;
                    } catch (Throwable de) {
                        dashFailed = true;
                        CrashHandler.note("dash", "高清流不可用：" + de);
                    }
                }

                // ② 合流：兼容模式 / 兼容 360p / DASH 失败兜底（统一走系统解码器）
                // 【v3.9 四线路】一次取回最多 4 条 CDN，代理逐条尝试，某条不通自动切换
                String[] lines = (mode == 3) ? BiliApi.playDurlMp4Multi(bvF, cidF, true)
                                             : BiliApi.playDurlMp4Multi(bvF, cidF, false);
                final String local = proxy.playUrlMulti(lines);
                final String title = bvF + " · 合流";
                ui.post(new Runnable() { @Override public void run() {
                    if (!bvF.equals(bvid)) return;   // 【v4.7】丢弃已被切换掉的旧视频结果
                    bvidText.setText(title);
                    tipText.setText("");
                    dmBvid = bvF;
                    curCid = cidF;
                    curBv = bvF;
                    pageDurMs = durMs;
                    loadDanmaku(cidF);
                    loadVideoMeta(bvF);
                    startHard(local);
                } });
            } catch (final Throwable e) {
                ui.post(new Runnable() { @Override public void run() {
                    if (!currentBv.equals(bvid)) return;   // 【v4.7】旧视频的失败提示不要打扰新视频
                    showLoadAnim(false, null);
                    tipText.setText("播放失败：" + e.getMessage());
                } });
            }
        } }).start();
    }

    // ------------------------------------------------------------ 高清双流

    /** 视频轨给 VideoView（静音），音频轨单独一个 MediaPlayer，两路按进度校正 */
    void startDash(final String vUrl, final String aUrl) {
        startDash(vUrl, aUrl, null, 0);
    }

    /** 【v3.9 四线路】带 playData 的版本：从 DASH backupUrl 补充候选线路 */
    void startDash(final String vUrl, final String aUrl, final JSONObject pd, final int height) {
        dashMode = true;
        player = null;   // v4.5：本轮 DASH 是否已 prepared 以 player 是否为空为准，看门狗据此判超时
        video.setVisibility(View.VISIBLE);
        vlcSurface.setVisibility(View.GONE);
        // 先挂回调再 setVideoPath：VideoView 的 prepare 是异步的，顺序反了有概率收不到 onPrepared
        video.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override public void onPrepared(MediaPlayer mp) {
                player = mp;
                showLoadAnim(false, null);   // 画面就绪，收起跳舞动画
                try { mp.setVolume(0f, 0f); } catch (Throwable ignore) { }  // 画面轨本身无音轨
                mp.start();
                applyZoom();
                if (resumePos > 800) {
                    try { mp.seekTo(resumePos); } catch (Throwable ignore) { }
                    pendingAudioStartPos = resumePos;   // 【v4.6】音频也直接从断点起，别从头播
                    resumePos = 0;
                    announceResume();
                }
                if (rate != 1f) {
                    try {
                        android.media.PlaybackParams pp2 = mp.getPlaybackParams();
                        pp2.setSpeed(rate);
                        mp.setPlaybackParams(pp2);
                    } catch (Throwable ignore) { }
                }
                // 【v4.6】不在这里直接放音频：onPrepared 只代表流已就绪，首帧还要等解码器出图。
                // 改为等「画面进度真正推进（首帧已出图）」后再放音频，音画同帧；300ms 后兜底。
                awaitFirstFrameThenStartAudio(0);
            }
        });
        video.setOnErrorListener(new MediaPlayer.OnErrorListener() {
            @Override public boolean onError(MediaPlayer mp, int what, int extra) {
                fallbackMux("高清流解码失败");
                return true;
            }
        });
        try {
            String[] vLines = BiliApi.videoLines(pd, vUrl, height);
            video.setVideoPath(proxy.playUrlMulti(vLines));
        } catch (Throwable e) {
            fallbackMux("高清流打开失败");
            return;
        }
        // 【v4.5 关键修复】看门狗必须在「准备阶段」就启动。旧版放在 onPrepared 里，
        // 一旦编码不被支持导致 onPrepared 永不触发，看门狗就永远不启动 → 无限卡在加载页。
        armDashWatchdog();
        // 【v4.1 提速】音轨与画面轨并行准备（旧版在画面 onPrepared 后才 startAudio，
        // 两路串行使出声要等两倍时间）。音频内部会以画面进度对齐，安全。
        startAudio(aUrl, pd);
        video.start();
        applyZoom();
    }

    void startAudio(final String aUrl) {
        startAudio(aUrl, null);
    }

    /** 【v3.9 四线路】音轨也按 backupUrl 提供多线路 */
    void startAudio(final String aUrl, final JSONObject pd) {
        try {
            releaseAudio();
            audioPlayer = new MediaPlayer();
            audioPlayer.setAudioStreamType(android.media.AudioManager.STREAM_MUSIC);
            String[] aLines = BiliApi.audioLines(pd == null ? playDataCache : pd, aUrl);
            audioPlayer.setDataSource(this, Uri.parse(proxy.playUrlMulti(aLines)));
            audioPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                @Override public void onPrepared(MediaPlayer mp) {
                    // 【v4.6】音轨与画面轨是并行 prepare 的，但视频分片（fMP4 首片+关键帧）通常比音频慢。
                    // 旧版在这里直接 mp.start()，于是"声音先出来、画面晚一秒"。现在只标记就绪，
                    // 由画面 onPrepared 触发 startAudioIfVideoReady() 对齐起播。
                    audioPrepared = true;
                    startAudioIfVideoReady();
                }
            });
            audioPlayer.setOnErrorListener(new MediaPlayer.OnErrorListener() {
                @Override public boolean onError(MediaPlayer mp, int what, int extra) {
                    return true;   // 音频轨出问题不崩，画面继续
                }
            });
            audioPlayer.prepareAsync();
        } catch (Throwable e) {
            fallbackMux("音轨加载失败");
        }
    }

    /**
     * 【v4.6】等画面真正出首帧后再放音频。
     * 不覆盖 VideoView 内部的 OnInfoListener（它会破坏缓冲状态机），改用进度轮询：
     * 进度 > 0 说明解码器已出图；或累计 300ms 兜底（个别机型首帧慢/进度不更新）。
     */
    void awaitFirstFrameThenStartAudio(final int attempt) {
        if (!audioPrepared || audioPlayer == null) return;   // 音频还没备好，由音频自己 onPrepared 时放行
        if (dashMode && player == null) return;              // 画面被回退/重建，放弃等待
        int pos = -1;
        try { pos = video.getCurrentPosition(); } catch (Throwable ignore) { }
        if (pos > 0 || attempt >= 12) {
            startAudioIfVideoReady();
            return;
        }
        ui.postDelayed(new Runnable() { @Override public void run() {
            awaitFirstFrameThenStartAudio(attempt + 1);
        } }, 25);
    }

    /**
     * 【v4.6】音画同步起播：音频可以提前 prepare 完，但必须等画面 onPrepared 后才出声。
     * - 音频先备好 → 静音待命，画面就绪时由 onPrepared 再调本方法；
     * - 画面先就绪 → 音频后到时按画面当前位置对齐后再起播。
     */
    void startAudioIfVideoReady() {
        if (!audioPrepared || audioPlayer == null) return;
        if (dashMode && player == null) return;   // 画面还没 prepared，继续静音等待
        audioPrepared = false;
        try {
            int target = pendingAudioStartPos;
            pendingAudioStartPos = -1;
            if (target < 0) {
                try { target = video.getCurrentPosition(); } catch (Throwable ignore) { target = 0; }
            }
            if (target > 400) audioPlayer.seekTo(target);   // 起播初期无需 seek，避免多一次跳转
            if (rate != 1f) {
                android.media.PlaybackParams ap = audioPlayer.getPlaybackParams();
                ap.setSpeed(rate);
                audioPlayer.setPlaybackParams(ap);
            }
            audioPlayer.start();
            audioStarted = true;
            lastAudioSync = System.currentTimeMillis();
            CrashHandler.note("play", "audio start @v=" + target + "ms");
        } catch (Throwable e) {
            CrashHandler.note("play", "audio start failed: " + e);
        }
    }

    void releaseAudio() {
        try {
            if (audioPlayer != null) {
                audioPlayer.reset();
                audioPlayer.release();
            }
        } catch (Throwable ignore) { }
        audioPlayer = null;
        audioPrepared = false;
        audioStarted = false;
        pendingAudioStartPos = -1;
    }

    /** 看门狗：5 秒内要么一直没 prepared、要么进度不动，都判定高清流不可用 → 回退合流 */
    void armDashWatchdog() {
        ui.postDelayed(new Runnable() { @Override public void run() {
            if (!dashMode) return;
            // v4.5：5 秒过去 player 仍为空 = onPrepared 从未触发（典型：编码不被支持/流拉不下来）
            if (player == null) {
                fallbackMux("高清流准备超时，已切回兼容播放");
                return;
            }
            try {
                if (video.getCurrentPosition() < 400) fallbackMux("该机型不支持高清分离流");
            } catch (Throwable ignore) { }
        } }, 5000);
    }

    /** 高清失败 → 自动回退合流，不让用户看黑屏 */
    void fallbackMux(final String why) {
        if (!dashMode && dashFailed) return;
        dashMode = false;
        dashFailed = true;
        releaseAudio();
        ui.post(new Runnable() { @Override public void run() {
            if (isFinishing()) return;
            tipText.setText(why + "，已切回兼容播放");
            resumePos = 0;
            play(1);
        } });
    }

    /** 系统硬解路径（本地代理补 Referer） */
    void startHard(String localUrl) {
        startHard(localUrl, true);
    }

    /**
     * 【v3.9】合流播放 + 失败自动重试。
     * retryAllowed=false 时由重试调用，避免重复注册回调导致递归。
     */
    void startHard(String localUrl, final boolean retryAllowed) {
        dashMode = false;
        releaseAudio();
        video.setVisibility(View.VISIBLE);
        vlcSurface.setVisibility(View.GONE);
        video.setOnErrorListener(new MediaPlayer.OnErrorListener() {
            @Override public boolean onError(MediaPlayer mp, int what, int extra) {
                if (retryAllowed && muxRetry < MAX_MUX_RETRY) {
                    muxRetry++;
                    final int attempt = muxRetry;
                    ui.post(new Runnable() { @Override public void run() {
                        if (isFinishing()) return;
                        tipText.setText("切换线路 " + attempt + "/" + MAX_MUX_RETRY + " 重试中喵~");
                        // 重新请求播放地址（拿到不同调度节点）+ 重新播放
                        retryMux();
                    } });
                } else {
                    ui.post(new Runnable() { @Override public void run() {
                        if (!isFinishing()) {
                            showLoadAnim(false, null);
                            tipText.setText("播放失败，请检查网络后重试");
                        }
                    } });
                }
                return true;   // 自己处理，不让系统弹出错误框
            }
        });
        video.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override public void onPrepared(MediaPlayer mp) {
                player = mp;
                showLoadAnim(false, null);   // 画面就绪，收起跳舞动画
                muxRetry = 0;   // 成功打开，清零重试计数
                // 【v4.1】续播 seek 放到 prepared 之后：此前在 start() 后立即 seek，
                // 视频尚未就绪，seek 会失败/重复缓冲，导致「看过的视频打开很慢」。
                int seekTo = resumePos;
                resumePos = 0;
                if (seekTo > 800) {
                    try {
                        mp.seekTo(seekTo);
                        if (pendingResumeMs <= 0) pendingResumeMs = seekTo;
                        announceResume();
                    } catch (Throwable ignore) { }
                }
                try { mp.start(); } catch (Throwable ignore) { }
                applyZoom();
                if (rate != 1f) {
                    try {
                        android.media.PlaybackParams pp2 = mp.getPlaybackParams();
                        pp2.setSpeed(rate);
                        mp.setPlaybackParams(pp2);
                    } catch (Throwable ignore) { }
                }
            }
        });
        try {
            video.setVideoPath(localUrl);
        } catch (Throwable e) {
            video.setOnErrorListener(null);
            if (retryAllowed && muxRetry < MAX_MUX_RETRY) {
                muxRetry++;
                retryMux();
            } else {
                ui.post(new Runnable() { @Override public void run() {
                    if (!isFinishing()) {
                        showLoadAnim(false, null);
                        tipText.setText("播放失败，请检查网络后重试");
                    }
                } });
            }
            return;
        }
        // 【v4.1】seek 已移到 onPrepared 内，此处不再过早 seek（否则触发重复缓冲拖慢起播）
    }

    /** 合流失败重试：后台重新取四线路地址，再走 startHard（禁止再次自动重试由计数控制） */
    void retryMux() {
        final String bv = bvid;
        new Thread(new Runnable() { @Override public void run() {
            try {
                long cid = curCid;
                int low = (Prefs.decoder(PlayActivity.this) == Prefs.DEC_LOW) ? 1 : 0;
                String[] lines = BiliApi.playDurlMp4Multi(bv, cid, low == 1);
                final String local = proxy.playUrlMulti(lines);
                ui.post(new Runnable() { @Override public void run() {
                    if (isFinishing()) return;
                    tipText.setText("");
                    video.stopPlayback();
                    startHard(local, true);
                } });
            } catch (final Throwable e) {
                ui.post(new Runnable() { @Override public void run() {
                    if (!isFinishing()) tipText.setText("重试失败：" + e.getMessage());
                } });
            }
        } }).start();
    }

    // ------------------------------------------------------------ 相关推荐

    void switchVideo(VideoItem it) {
        if (it == null || it.isPlaceholder()) return;
        switchVideo(it.bvid, it.cid, it.durSec, it.title);
    }

    /**
     * 【v4.8】cid/title/durSec 来自推荐列表接口，直接复用可跳过 pages() 网络往返。
     * cid<=0 时自动回落到 pages() 现查。
     */
    void switchVideo(String bv, long cid, long durSec, String title) {
        if (bv == null || bv.isEmpty() || bv.equals(bvid)) return;
        bvid = bv;
        cached = false;
        // 【v4.7 关键修复】切视频必须整体替换上一个视频的预取状态。
        // 旧版这里没清 prefetchedCid，导致 play() 拿「新 bvid + 旧 cid」请求 playurl，
        // B站判定 cid 不属于该视频，直接返回 -404「啥都木有」。
        prefetchedCid = cid;                       // 新视频的 cid（0 = 未知，走 pages）
        prefetchedTitle = title != null ? title : "";
        prefetchedDur = durSec;
        prefetchedAspect = 0f;
        pageIndex = 0;          // 新视频从第 1P 开始
        pagesArr = null;        // 丢弃上个视频的分P列表
        resumePos = 0;          // 否则会沿用上个视频的续播进度
        pendingResumeMs = 0;
        dashFailed = false;     // 上个视频 DASH 失败不能连累新视频
        playDataCache = null;
        pageDurMs = 0;          // 进度条总时长先清空，避免显示成上个视频的时长
        if (fullscreen) exitFullscreen();
        if (portraitFill) exitPortraitFill();
        resetZoom();
        // 【v4.8】立即停掉旧视频（含独立音轨），否则网络等待的几百毫秒里旧视频还在出声，
        // 观感上就是「新视频加载中、旧视频还在播」的错乱。
        releaseAudio();
        try { if (video != null) video.pause(); } catch (Throwable ignore) { }
        playLoadMsg = "正在切换…";
        tipText.setText("切换到 " + bv + " …");
        play(Prefs.decoder(this));
        loadRec();
    }

    void loadRec() {
        final String currentBv = bvid;
        new Thread(new Runnable() { @Override public void run() {
            final ArrayList<VideoItem> got = new ArrayList<>();
            try {
                JSONArray arr = null;
                if (currentBv != null && currentBv.startsWith("BV")) {
                    try { arr = BiliApi.related(currentBv); } catch (Throwable ignore) { }
                }
                if (arr == null || arr.length() == 0) arr = BiliApi.popular(1);   // 降级热门
                if (arr != null) {
                    for (int i = 0; i < arr.length() && got.size() < 20; i++) {
                        JSONObject o = arr.getJSONObject(i);
                        String bv = o.optString("bvid", "");
                        if (bv.isEmpty() || bv.equals(currentBv)) continue;
                        String up = o.optJSONObject("owner") != null
                                ? o.getJSONObject("owner").optString("name", "") : "";
                        int dur = o.optInt("duration", 0);
                        long play = o.optJSONObject("stat") != null
                                ? o.getJSONObject("stat").optLong("view", 0) : 0;
                        StringBuilder sub = new StringBuilder();
                        if (!up.isEmpty()) sub.append(up);
                        if (play > 0) {
                            if (sub.length() > 0) sub.append("  ·  ");
                            sub.append(VideoItem.views(play)).append("播放");
                        }
                        if (dur > 0) {
                            if (sub.length() > 0) sub.append("  ·  ");
                            sub.append(VideoItem.dur(dur));
                        }
                        // 【v4.8 提速】related/popular 返回项自带 cid，存下来给播放页直接用，
                        // 切视频时省掉一次 pages() 网络往返（约 150~600ms）
                        long rc = o.optLong("cid", 0);
                        float ra = 0f;
                        JSONObject rdim = o.optJSONObject("dimension");
                        if (rdim != null) {
                            int dw = rdim.optInt("width", 0), dh = rdim.optInt("height", 0);
                            int rot = rdim.optInt("rotate", 0);
                            if (rot == 90 || rot == 270) { int t = dw; dw = dh; dh = t; }
                            if (dw > 0 && dh > 0) ra = dw / (float) dh;
                        }
                        got.add(new VideoItem(bv,
                                BiliApi.cleanTitle(o.optString("title", "")),
                                sub.toString(), o.optString("pic", ""),
                                rc, ra, dur));
                    }
                }
            } catch (Throwable ignore) { }
            ui.post(new Runnable() { @Override public void run() {
                // 【v4.8】连点切换时，旧视频的推荐列表晚返回会把新列表冲掉
                if (!currentBv.equals(bvid)) return;
                recRows.clear();
                recRows.addAll(got);
                if (got.isEmpty()) {
                    recRows.add(new VideoItem("", "暂无推荐（网络或风控原因）", "", null));
                }
                if (recAdapter != null) recAdapter.notifyDataSetChanged();
            } });
        } }).start();
    }

    // ------------------------------------------------------------ 缓存 MP4

    void cacheVideo() {
        if (cached) {
            showToastSafe("本视频已缓存过");
            return;
        }
        cached = true;
        showToastSafe("开始缓存 MP4…");
        new Thread(new Runnable() { @Override public void run() {
            File work = new File(getCacheDir(), "dl");
            File out = new File(work, "cache.mp4");
            File vf = new File(work, "v.m4s");
            File af = new File(work, "a.m4s");
            try {
                work.mkdirs();
                deleteQuiet(out); deleteQuiet(vf); deleteQuiet(af);

                String bv = bvid;
                String aid = null;
                if (bvid.startsWith("av")) {
                    aid = bvid.substring(2);
                    bv = null;
                }
                String realBvid;
                long cid;
                String title;
                if (bv != null) {
                    JSONObject pg = BiliApi.firstPage(bv);
                    cid = pg.getLong("cid");
                    realBvid = bv;
                    title = pg.optString("part", bv);
                } else {
                    JSONObject v = BiliApi.view(null, aid);
                    realBvid = v.optString("bvid", "");
                    cid = v.getJSONArray("pages").getJSONObject(0).getLong("cid");
                    title = v.optString("title", realBvid);
                }

                boolean ok = false;
                try {
                    JSONObject data = BiliApi.playurl(realBvid, aid, cid);
                    String vurl = BiliApi.bestVideoSource(data);
                    String aurl = BiliApi.bestMp4Audio(data);   // 只取能进 MP4 的 AAC
                    setTipText("缓存中：视频流…");
                    download(vurl, vf, true);
                    setTipText("缓存中：音频流…");
                    download(aurl, af, true);
                    setTipText("封装 MP4…");
                    ok = Mp4Muxer.mux(vf, af, out);
                } catch (Throwable e) {
                    CrashHandler.note("cache", "DASH 方案失败：" + e);
                } finally {
                    deleteQuiet(vf); deleteQuiet(af);
                }

                if (!ok) {
                    // 回退：直接下载 html5 合一流 mp4
                    setTipText("缓存中：合一流…");
                    String u = BiliApi.playDurlMp4(realBvid, cid);
                    deleteQuiet(out);
                    download(u, out, true);
                }
                if (!out.exists() || out.length() < 1024) {
                    throw new Exception("下载内容为空（可能被风控）");
                }

                String name = sanitize(title) + ".mp4";
                setTipText("保存到相册…");
                saveToMovies(out, name);
                deleteQuiet(out);

                SharedPreferences sp = getSharedPreferences("video_cache", MODE_PRIVATE);
                java.util.Set<String> set = new java.util.HashSet<>(
                        sp.getStringSet("files", new java.util.HashSet<String>()));
                set.add(name);
                sp.edit().putStringSet("files", set).apply();

                setTipText("");
                ui.post(new Runnable() { @Override public void run() {
                    Toast.makeText(PlayActivity.this,
                            "✓ MP4 已保存到 电影/BiliAudio", Toast.LENGTH_LONG).show();
                } });
            } catch (final Throwable e) {
                cached = false;
                deleteQuiet(out);
                setTipText("");
                ui.post(new Runnable() { @Override public void run() {
                    Toast.makeText(PlayActivity.this,
                            "缓存失败：" + e.getMessage(), Toast.LENGTH_LONG).show();
                } });
            }
        } }).start();
    }

    void setTipText(final String s) {
        ui.post(new Runnable() { @Override public void run() {
            if (tipText != null) tipText.setText(s);
        } });
    }

    static void deleteQuiet(File f) {
        try { if (f != null && f.exists()) f.delete(); } catch (Throwable ignore) { }
    }

    void download(String url, File dst) throws Exception {
        download(url, dst, false);
    }

    void download(String url, File dst, boolean report) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setConnectTimeout(15000);
        c.setReadTimeout(60000);
        c.setRequestProperty("User-Agent", BiliApi.UA);
        c.setRequestProperty("Referer", BiliApi.REFERER);
        StringBuilder ck = new StringBuilder();
        for (java.util.Map.Entry<String, String> e : BiliApi.COOKIES.entrySet()) {
            if (ck.length() > 0) ck.append("; ");
            ck.append(e.getKey()).append('=').append(e.getValue());
        }
        if (ck.length() > 0) c.setRequestProperty("Cookie", ck.toString());
        int code = c.getResponseCode();
        if (code != 200 && code != 206) {
            c.disconnect();
            throw new Exception("下载失败 HTTP " + code);
        }
        InputStream in = c.getInputStream();
        FileOutputStream fos = new FileOutputStream(dst);
        byte[] buf = new byte[64 * 1024];
        int n;
        long total = 0, last = 0;
        while ((n = in.read(buf)) > 0) {
            fos.write(buf, 0, n);
            total += n;
            if (report && total - last > 4 * 1024 * 1024) {
                last = total;
                final String mb = String.format("%.1f MB", total / 1048576.0);
                ui.post(new Runnable() { @Override public void run() {
                    if (tipText != null) tipText.setText("缓存中 " + mb);
                } });
            }
        }
        fos.close();
        in.close();
        c.disconnect();
    }

    void saveToMovies(File src, String displayName) throws Exception {
        ContentValues cv = new ContentValues();
        cv.put(MediaStore.Video.Media.DISPLAY_NAME, displayName);
        cv.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4");
        cv.put(MediaStore.Video.Media.RELATIVE_PATH,
                Environment.DIRECTORY_MOVIES + "/BiliAudio");
        cv.put(MediaStore.Video.Media.IS_PENDING, 1);
        Uri uri = getContentResolver().insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, cv);
        if (uri == null) {
            File f = new File(getExternalFilesDir(Environment.DIRECTORY_MOVIES), displayName);
            copyFile(src, f);
            return;
        }
        OutputStream os = getContentResolver().openOutputStream(uri);
        byte[] buf = new byte[64 * 1024];
        InputStream is = new java.io.FileInputStream(src);
        int n;
        while ((n = is.read(buf)) > 0) os.write(buf, 0, n);
        is.close();
        os.close();
        cv.clear();
        cv.put(MediaStore.Video.Media.IS_PENDING, 0);
        getContentResolver().update(uri, cv, null, null);
    }

    static void copyFile(File src, File dst) throws Exception {
        java.io.FileInputStream is = new java.io.FileInputStream(src);
        FileOutputStream os = new FileOutputStream(dst);
        byte[] buf = new byte[32 * 1024];
        int n;
        while ((n = is.read(buf)) > 0) os.write(buf, 0, n);
        is.close();
        os.close();
    }

    static String sanitize(String name) {
        String s = name.replaceAll("[\\\\/:*?\"<>|\\r\\n\\t]", "_")
                      .replaceAll("^[ ._-]+|[ ._-]+$", "");
        if (s.isEmpty()) s = "untitled";
        return s.substring(0, Math.min(80, s.length()));
    }

    void showToastSafe(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    /**
     * 互动写操作的统一失败处理：登录过期时清掉本地失效 Cookie（含 SharedPreferences），
     * 让下一次点击走正常的「请先登录」流程，避免用户反复点却一直失败。
     */
    void handleActError(String err) {
        if (err == null) return;
        showToastSafe(err);
        if (err.contains("重新登录") || err.contains("登录已过期") || err.contains("登录态已失效")) {
            BiliApi.clearLoginCookie();
            try {
                getSharedPreferences("bili_login", MODE_PRIVATE).edit()
                        .remove("SESSDATA").remove("bili_jct").remove("DedeUserID").remove("login_time")
                        .apply();
            } catch (Throwable ignore) { }
        }
    }

    /** 把互动异常转成可读文案，登录态失效走专属提示 */
    String actErr(Throwable e) {
        if (e == null) return "操作失败，请重试";
        if (e instanceof BiliApi.LoginExpired || e.getMessage() == null) return "登录已过期，请到「我的」页重新登录";
        String m = e.getMessage();
        return m.isEmpty() ? "操作失败，请重试" : m;
    }

    @Override
    protected void onDestroy() {
        savePosNow();   // 退出前落一次进度
        ui.removeCallbacksAndMessages(null);
        if (dmStyleDlg != null) {   // 【v4.8】避免退出时窗口泄漏
            try { dmStyleDlg.dismiss(); } catch (Throwable ignore) { }
            dmStyleDlg = null;
        }
        if (video != null) video.stopPlayback();
        releaseAudio();
        if (proxy != null) proxy.stop();
        super.onDestroy();
    }

    // ------------------------------------------------------------ 互动 UI（图标统一 24dp 视觉框）

    static class Act {
        LinearLayout box;
        ImageView icon;
        TextView label;
        String off, on;
    }

    /**
     * 图标项：顶部栏用「数字在上、图标在下」（贴合横屏播放器），
     * 竖屏互动栏用「图标在上、文字在下」（贴合详情页）。图标本体尺寸统一由 sizeDp 决定。
     */
    Act makeAct(String off, String on, int sizeDp, boolean labelTop) {
        Act a = new Act();
        a.off = off;
        a.on = on;
        a.box = new LinearLayout(this);
        a.box.setOrientation(LinearLayout.VERTICAL);
        a.box.setGravity(Gravity.CENTER);
        a.box.setClickable(true);
        a.box.setPadding(dp(3), dp(1), dp(3), dp(1));

        a.label = new TextView(this);
        a.label.setTextColor(Color.WHITE);
        a.label.setTextSize(labelTop ? 9 : 10);
        a.label.setGravity(Gravity.CENTER);
        a.label.setSingleLine(true);
        if (labelTop) a.label.setShadowLayer(dp(3), 0, dp(1), 0x99000000);

        a.icon = Ic.view(this, off, Color.WHITE, sizeDp);
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);

        if (labelTop) {
            a.box.addView(a.label, lp);
            ip.topMargin = dp(2);
            a.box.addView(a.icon, ip);
        } else {
            a.box.addView(a.icon, ip);
            lp.topMargin = dp(4);
            a.box.addView(a.label, lp);
        }
        return a;
    }

    void addAct(LinearLayout row, Act a) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.leftMargin = dp(6);
        row.addView(a.box, lp);
    }

    /** 竖屏互动栏：五等分，保证图标间距一致 */
    void addActWide(LinearLayout row, Act a) {
        row.addView(a.box, new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
    }

    /** 控制条上的文字按钮（无背景，靠间距区分） */
    TextView textTool(String txt, View.OnClickListener l) {
        TextView t = new TextView(this);
        t.setText(txt);
        t.setTextColor(Color.WHITE);
        t.setTextSize(10.5f);
        t.setSingleLine(true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(5), dp(6), dp(5), dp(6));
        t.setOnClickListener(l);
        return t;
    }

    /** 竖屏给返回键一个半透明圆底（亮画面也能看清）；全屏用纯箭头 */
    void setBackChip(boolean chip) {
        if (backArrow == null) return;
        if (chip) {
            android.graphics.drawable.GradientDrawable g =
                    new android.graphics.drawable.GradientDrawable();
            g.setShape(android.graphics.drawable.GradientDrawable.OVAL);
            g.setColor(0x66000000);
            backArrow.setBackground(g);
        } else {
            backArrow.setBackground(null);
        }
    }

    void setTimeText(int pos, int len) {
        if (timeText != null) timeText.setText(mmss(pos) + "/" + mmss(len));
    }

    static String numText(long n) {
        if (n >= 100000000L) return String.format("%.1f亿", n / 100000000f);
        if (n >= 10000L) return String.format("%.1f万", n / 10000f);
        return String.valueOf(n);
    }

    void styleAct(Act a, boolean on, int onColor, String text) {
        if (a == null) return;
        a.icon.setImageResource(Ic.id(this, on ? a.on : a.off));
        a.icon.setColorFilter(on ? onColor : Color.WHITE);
        if (text != null) a.label.setText(text);
    }

    /** 同步顶部与底部两套图标的选中态和计数 */
    void refreshActs() {
        String lk = statLike > 0 ? numText(statLike) : "赞";
        String cm = statReply > 0 ? numText(statReply) : "评论";
        String cn = coins > 0 ? (coins + "/2") : (statCoin > 0 ? numText(statCoin) : "投币");
        String fv = statFav > 0 ? numText(statFav) : "收藏";

        styleAct(actLikeTop, liked, 0xFFFB7299, lk);
        styleAct(actLikeBot, liked, 0xFFFB7299, lk);
        styleAct(actCmtTop, false, Color.WHITE, cm);
        styleAct(actCmtBot, false, Color.WHITE, cm);
        styleAct(actCoinTop, coins > 0, 0xFFFFC53D, cn);
        styleAct(actCoinBot, coins > 0, 0xFFFFC53D, cn);
        styleAct(actFavTop, faved, 0xFFFFC53D, fv);
        styleAct(actFavBot, faved, 0xFFFFC53D, fv);
        styleAct(actShareTop, false, Color.WHITE, statShare > 0 ? numText(statShare) : "转发");
        styleAct(actShareBot, false, Color.WHITE, statShare > 0 ? numText(statShare) : "转发");
        updateFollowBtn();
    }

    void updateFollowBtn() {
        boolean on = followedState > 0;
        String txt = on ? (followedState == 2 ? "互相关注" : "已关注") : "+ 关注";
        try {
            if (followBtnTop != null) {
                followBtnTop.setText(txt);
                followBtnTop.setBackground(roundRect(on ? 0x33FFFFFF : 0x4DFB7299, dp(14), dp(28)));
                followBtnTop.setVisibility(metaLoaded ? View.VISIBLE : View.GONE);
            }
            if (followBtnBot != null) {
                followBtnBot.setText(txt);
                followBtnBot.setBackground(roundRect(on ? 0x33FFFFFF : 0xFFFB7299, dp(15), dp(30)));
                followBtnBot.setTextColor(on ? 0xCCFFFFFF : Color.WHITE);
            }
        } catch (Throwable ignore) { }
    }

    void updatePlayIcon(boolean playing) {
        if (playIcon == null) return;
        Ic.set(playIcon, playing ? "pause" : "play", Color.WHITE);
    }

    // ------------------------------------------------------------ 互动动作

    boolean needLoginFor(String act) {
        if (BiliApi.loggedInUid() != null) return false;
        showToastSafe("请先登录后再" + act);
        return true;
    }

    /** 点赞图标轻轻摇一摇：左右小幅摆动后回正 */
    void wiggle(Act a) {
        if (a == null || a.icon == null) return;
        View v = a.icon;
        v.animate().cancel();
        v.setRotation(0f);
        try {
            android.animation.ObjectAnimator oa = android.animation.ObjectAnimator.ofFloat(
                    v, "rotation", 0f, -16f, 13f, -10f, 7f, -4f, 0f);
            oa.setDuration(560);
            oa.setInterpolator(new android.view.animation.DecelerateInterpolator());
            oa.start();
        } catch (Throwable ignore) {
            // 极老机型动画框架不可用时，静默降级为无动画
        }
    }

    /** 一键三连：点赞 + 投币(2枚) + 收藏(默认收藏夹)，逐个执行并带摇一摇反馈 */
    void tripleLike() {
        if (needLoginFor("一键三连")) return;
        showToastSafe("一键三连 ٩(๑>◡<๑)و");
        // 视觉反馈：赞、币、收藏三个图标依次摇一摇
        wiggle(actLikeTop); wiggle(actLikeBot);
        wiggle(actCoinTop); wiggle(actCoinBot);
        wiggle(actFavTop); wiggle(actFavBot);
        // 执行前快照：已经赞/藏过的就不再重复提交
        final boolean wasLiked = liked;
        final boolean wasFaved = faved;
        final int coinN = 2 - coins;   // 补足到 2 枚
        // 不预先改 UI —— 每个动作只有服务端确认成功才更新状态，避免「假成功」
        new Thread(new Runnable() { @Override public void run() {
            final boolean[] ok = { true, true, true }; // 赞 / 币 / 藏
            final String[] errs = { null, null, null };
            if (!wasLiked) {
                try { BiliApi.setLike(curBv, true); }
                catch (Throwable e) { ok[0] = false; errs[0] = actErr(e); }
            }
            if (coinN > 0) {
                try { BiliApi.addCoin(curBv, coinN, false); }
                catch (Throwable e) { ok[1] = false; errs[1] = actErr(e); }
            }
            if (!wasFaved) {
                try {
                    String uid = BiliApi.loggedInUid();
                    JSONArray fs = uid == null ? null : BiliApi.favFolders(uid);
                    if (fs == null || fs.length() == 0) {
                        ok[2] = false; errs[2] = "没有可用的收藏夹";
                    } else {
                        long fid = fs.getJSONObject(0).optLong("id", 0);
                        if (fid == 0) { ok[2] = false; errs[2] = "收藏夹 id 异常"; }
                        else BiliApi.dealFav(aid, String.valueOf(fid), "");
                    }
                } catch (Throwable e) { ok[2] = false; errs[2] = actErr(e); }
            }
            ui.post(new Runnable() { @Override public void run() {
                if (ok[0] && !wasLiked) { liked = true; statLike += 1; }
                if (ok[1] && coinN > 0) { coins = Math.min(2, coins + coinN); statCoin += coinN; }
                if (ok[2] && !wasFaved) { faved = true; statFav += 1; }
                refreshActs();
                // 汇总失败原因；登录过期统一清理失效态
                String firstErr = null;
                for (String e : errs) if (e != null) { firstErr = e; break; }
                if (firstErr != null) {
                    handleActError(firstErr);
                } else {
                    showToastSafe("三连成功 ٩(๑>◡<๑)و");
                }
            } });
        } }).start();
    }

    void tapLike() {
        if (needLoginFor("点赞")) return;
        // 短按点赞：图标摇一摇
        wiggle(actLikeTop); wiggle(actLikeBot);
        final boolean target = !liked;
        liked = target;
        statLike += target ? 1 : -1;
        if (statLike < 0) statLike = 0;
        refreshActs();
        new Thread(new Runnable() { @Override public void run() {
            String err = null;
            try {
                BiliApi.setLike(curBv, target);
            } catch (Throwable e) {
                err = actErr(e);
            }
            final String fErr = err;
            if (fErr != null) ui.post(new Runnable() { @Override public void run() {
                liked = !target;
                statLike += target ? -1 : 1;
                if (statLike < 0) statLike = 0;
                refreshActs();
                handleActError(fErr);
            } });
        } }).start();
    }

    void tapCoin() {
        if (needLoginFor("投币")) return;
        if (coins >= 2) {
            showToastSafe("这个视频已经投过 2 枚硬币了");
            return;
        }
        final String[] items = {"投 1 枚硬币", "投 2 枚硬币"};
        AlertDialog.Builder b = new AlertDialog.Builder(this);
        b.setTitle("投币支持 UP 主");
        b.setItems(items, new DialogInterface.OnClickListener() {
            @Override public void onClick(DialogInterface d, int which) { doCoin(which + 1); }
        });
        b.setNegativeButton("取消", null);
        b.show();
    }

    void doCoin(final int n) {
        showToastSafe("投币中…");
        new Thread(new Runnable() { @Override public void run() {
            String err = null;
            try {
                BiliApi.addCoin(curBv, n, false);
            } catch (Throwable e) {
                err = actErr(e);
            }
            final String fErr = err;
            ui.post(new Runnable() { @Override public void run() {
                if (fErr != null) {
                    handleActError(fErr);
                    return;
                }
                coins = Math.min(2, coins + n);
                statCoin += n;
                refreshActs();
                showToastSafe("已投 " + n + " 枚硬币，感谢支持");
            } });
        } }).start();
    }

    void tapFav() {
        if (needLoginFor("收藏")) return;
        if (faved && !favFolderId.isEmpty()) {
            AlertDialog.Builder b = new AlertDialog.Builder(this);
            b.setTitle("已收藏");
            b.setMessage("要把这个视频从收藏夹移除吗？");
            b.setPositiveButton("取消收藏", new DialogInterface.OnClickListener() {
                @Override public void onClick(DialogInterface d, int w) { doFav("", favFolderId); }
            });
            b.setNegativeButton("再选收藏夹", new DialogInterface.OnClickListener() {
                @Override public void onClick(DialogInterface d, int w) { pickFavFolders(); }
            });
            b.show();
            return;
        }
        pickFavFolders();
    }

    void pickFavFolders() {
        final String uid = BiliApi.loggedInUid();
        if (uid == null) return;
        new Thread(new Runnable() { @Override public void run() {
            JSONArray fs = null;
            String err = null;
            try {
                fs = BiliApi.favFolders(uid);
            } catch (Throwable e) {
                err = actErr(e);
            }
            final JSONArray fFs = fs;
            final String fErr = err;
            ui.post(new Runnable() { @Override public void run() {
                if (fFs == null || fFs.length() == 0) {
                    handleActError(fErr != null ? fErr : "没有可用的收藏夹");
                    return;
                }
                final ArrayList<String> ids = new ArrayList<>();
                ArrayList<String> names = new ArrayList<>();
                for (int i = 0; i < fFs.length(); i++) {
                    JSONObject f = fFs.optJSONObject(i);
                    if (f == null) continue;
                    ids.add(String.valueOf(f.optLong("id", 0)));
                    names.add(f.optString("title", "收藏夹"));
                }
                if (ids.isEmpty()) {
                    showToastSafe("没有可用的收藏夹");
                    return;
                }
                final boolean[] checked = new boolean[ids.size()];
                AlertDialog.Builder b = new AlertDialog.Builder(PlayActivity.this);
                b.setTitle("收藏到");
                b.setMultiChoiceItems(names.toArray(new String[0]), checked,
                        new DialogInterface.OnMultiChoiceClickListener() {
                            @Override public void onClick(DialogInterface d, int which, boolean isChecked) {
                                checked[which] = isChecked;
                            }
                        });
                b.setPositiveButton("确定", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        StringBuilder add = new StringBuilder();
                        for (int i = 0; i < checked.length; i++) {
                            if (!checked[i]) continue;
                            if (add.length() > 0) add.append(',');
                            add.append(ids.get(i));
                        }
                        if (add.length() == 0) {
                            showToastSafe("请至少选择一个收藏夹");
                            return;
                        }
                        doFav(add.toString(), "");
                    }
                });
                b.setNegativeButton("取消", null);
                b.show();
            } });
        } }).start();
    }

    void doFav(final String addIds, final String delIds) {
        new Thread(new Runnable() { @Override public void run() {
            String err = null;
            try {
                BiliApi.dealFav(aid, addIds, delIds);
            } catch (Throwable e) {
                err = actErr(e);
            }
            final String fErr = err;
            ui.post(new Runnable() { @Override public void run() {
                if (fErr != null) {
                    handleActError(fErr);
                    return;
                }
                if (!delIds.isEmpty()) {
                    faved = false;
                    statFav = Math.max(0, statFav - 1);
                    showToastSafe("已取消收藏");
                } else {
                    faved = true;
                    favFolderId = addIds.split(",")[0];
                    statFav += 1;
                    showToastSafe("已收藏");
                }
                refreshActs();
            } });
        } }).start();
    }

    void tapShare() {
        final String url = "https://www.bilibili.com/video/" + curBv;
        final String[] items = {"复制链接", "分享到其他应用"};
        AlertDialog.Builder b = new AlertDialog.Builder(this);
        b.setTitle(videoTitle.isEmpty() ? "转发" : videoTitle);
        b.setItems(items, new DialogInterface.OnClickListener() {
            @Override public void onClick(DialogInterface d, int which) {
                if (which == 0) {
                    try {
                        android.content.ClipboardManager cm = (android.content.ClipboardManager)
                                getSystemService(android.content.Context.CLIPBOARD_SERVICE);
                        cm.setPrimaryClip(android.content.ClipData.newPlainText("bili", url));
                        showToastSafe("链接已复制");
                    } catch (Throwable e) {
                        showToastSafe("复制失败：" + e.getMessage());
                    }
                    return;
                }
                try {
                    android.content.Intent i = new android.content.Intent(
                            android.content.Intent.ACTION_SEND);
                    i.setType("text/plain");
                    i.putExtra(android.content.Intent.EXTRA_SUBJECT, videoTitle);
                    i.putExtra(android.content.Intent.EXTRA_TEXT,
                            (videoTitle.isEmpty() ? "哔哩哔哩视频" : videoTitle) + "\n" + url);
                    startActivity(android.content.Intent.createChooser(i, "分享到"));
                } catch (Throwable e) {
                    showToastSafe("分享失败：" + e.getMessage());
                }
            }
        });
        b.setNegativeButton("取消", null);
        b.show();
    }

    void tapFollow() {
        if (needLoginFor("关注")) return;
        if (ownerMid <= 0) {
            showToastSafe("还没拿到 UP 主信息，稍后再试");
            return;
        }
        final boolean target = followedState == 0;
        final int old = followedState;
        followedState = target ? 1 : 0;
        updateFollowBtn();
        new Thread(new Runnable() { @Override public void run() {
            String err = null;
            try {
                BiliApi.modifyFollow(ownerMid, target);
            } catch (Throwable e) {
                err = actErr(e);
            }
            final String fErr = err;
            ui.post(new Runnable() { @Override public void run() {
                if (fErr != null) {
                    followedState = old;
                    updateFollowBtn();
                    handleActError(fErr);
                } else {
                    showToastSafe(target ? "已关注" : "已取消关注");
                }
            } });
        } }).start();
    }

    void openComments() {
        if (aid <= 0) {
            showToastSafe("评论还没加载好，稍后再试");
            return;
        }
        try {
            android.content.Intent i = new android.content.Intent(this, CommentActivity.class);
            i.putExtra("aid", aid);
            i.putExtra("bvid", curBv);
            i.putExtra("title", videoTitle);
            i.putExtra("total", statReply);
            startActivity(i);
        } catch (Throwable e) {
            showToastSafe("打开评论失败：" + e.getMessage());
        }
    }

    // ------------------------------------------------------------ 控制条菜单

    void showMoreMenu() {
        final String[] items = {"解码方式：" + decName(Prefs.decoder(this)), "缓存到本地", "复制视频链接"};
        AlertDialog.Builder b = new AlertDialog.Builder(this);
        b.setTitle("更多");
        b.setItems(items, new DialogInterface.OnClickListener() {
            @Override public void onClick(DialogInterface d, int which) {
                if (which == 0) showDecoderDialog();
                else if (which == 1) cacheVideo();
                else tapShare();
            }
        });
        b.setNegativeButton("取消", null);
        b.show();
    }

    static String decName(int v) {
        switch (v) {
            case Prefs.DEC_HW: return "硬解";
            case Prefs.DEC_COMPAT: return "兼容（合流）";
            case Prefs.DEC_LOW: return "兼容 360p";
            default: return "自动";
        }
    }

    void showDecoderDialog() {
        int cur = Prefs.decoder(this);
        AlertDialog.Builder b = new AlertDialog.Builder(this);
        b.setTitle("解码方式");
        b.setSingleChoiceItems(Prefs.DEC_NAMES, cur, new DialogInterface.OnClickListener() {
            @Override public void onClick(DialogInterface d, int which) {
                d.dismiss();
                Prefs.setDecoder(PlayActivity.this, which);
                play(which);
            }
        });
        b.setNegativeButton("取消", null);
        b.show();
    }

    void showPages() {
        if (pagesArr == null || pagesArr.length() <= 1) {
            showToastSafe("该视频只有一个分P");
            return;
        }
        final String[] names = new String[pagesArr.length()];
        for (int i = 0; i < pagesArr.length(); i++) {
            JSONObject o = pagesArr.optJSONObject(i);
            String part = o == null ? "" : o.optString("part", "");
            names[i] = "P" + (i + 1) + "  " + (part.isEmpty() ? "第" + (i + 1) + "话" : part);
        }
        AlertDialog.Builder b = new AlertDialog.Builder(this);
        b.setTitle("选集");
        b.setSingleChoiceItems(names, pageIndex, new DialogInterface.OnClickListener() {
            @Override public void onClick(DialogInterface d, final int which) {
                d.dismiss();
                if (which == pageIndex) return;
                flipToPage(new Runnable() {
                    @Override public void run() {
                        pageIndex = which;
                        resumePos = 0;
                        play(Prefs.decoder(PlayActivity.this));
                    }
                });
            }
        });
        b.setNegativeButton("取消", null);
        b.show();
    }

    /**
     * 切视频「翻书」过渡：用封面遮罩绕 Y 轴翻页，翻到 90°（画面侧向不可见）时执行切换，
     * 再从 -90° 翻回 0°。总时长约 400ms，不快不慢。遮罩用当前封面，避免露出黑屏。
     */
    void flipToPage(final Runnable switchAction) {
        if (flipCover == null || isFinishing()) {
            if (switchAction != null) switchAction.run();
            return;
        }
        if (flipping) return;   // 动画中忽略重复点击
        flipping = true;
        // 尝试加载当前封面作为翻页画面
        flipCover.setImageDrawable(null);
        flipCover.setBackgroundColor(0xFF0E1014);
        if (!coverUrl.isEmpty()) {
            try { ImgLoader.load(flipCover, coverUrl,
                    getResources().getDisplayMetrics().widthPixels, dp(400)); } catch (Throwable ignore) { }
        }
        flipCover.setVisibility(View.VISIBLE);
        flipCover.setAlpha(1f);
        flipCover.setRotationY(0f);
        flipCover.setPivotX(flipCover.getWidth() / 2f);
        flipCover.setCameraDistance(12000f);

        // 第一段：0 → -90（封面翻走），中点 0.5 之后执行切换
        final android.animation.ValueAnimator out =
                android.animation.ValueAnimator.ofFloat(0f, -90f);
        out.setDuration(200);
        out.setInterpolator(new android.view.animation.AccelerateInterpolator());
        final boolean[] switched = {false};
        out.addUpdateListener(new android.animation.ValueAnimator.AnimatorUpdateListener() {
            @Override public void onAnimationUpdate(android.animation.ValueAnimator a) {
                float ang = (Float) a.getAnimatedValue();
                flipCover.setRotationY(ang);
                if (!switched[0] && ang <= -84f) {
                    switched[0] = true;
                    if (switchAction != null) switchAction.run();
                }
            }
        });
        out.addListener(new android.animation.AnimatorListenerAdapter() {
            @Override public void onAnimationEnd(android.animation.Animator a) {
                if (!switched[0] && switchAction != null) switchAction.run();
                // 第二段：-90 → 0 翻入新画面（从另一侧进入，形成连续翻页感）
                flipCover.setRotationY(90f);
                android.animation.ValueAnimator in =
                        android.animation.ValueAnimator.ofFloat(90f, 0f);
                in.setDuration(200);
                in.setInterpolator(new android.view.animation.DecelerateInterpolator());
                in.addUpdateListener(new android.animation.ValueAnimator.AnimatorUpdateListener() {
                    @Override public void onAnimationUpdate(android.animation.ValueAnimator a2) {
                        flipCover.setRotationY((Float) a2.getAnimatedValue());
                    }
                });
                in.addListener(new android.animation.AnimatorListenerAdapter() {
                    @Override public void onAnimationEnd(android.animation.Animator a2) {
                        flipCover.setVisibility(View.GONE);
                        flipCover.setRotationY(0f);
                        flipping = false;
                    }
                });
                in.start();
            }
        });
        out.start();
    }

    void nextPage() {
        if (pagesArr == null || pageIndex + 1 >= pagesArr.length()) {
            showToastSafe("已经是最后一集了");
            return;
        }
        flipToPage(new Runnable() {
            @Override public void run() {
                pageIndex++;
                resumePos = 0;
                play(Prefs.decoder(PlayActivity.this));
            }
        });
    }

    void showSpeed() {
        final float[] rates = {0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f};
        final String[] names = {"0.5×", "0.75×", "1.0×", "1.25×", "1.5×", "2.0×"};
        int cur = 2;
        for (int i = 0; i < rates.length; i++) if (Math.abs(rates[i] - rate) < 0.01f) cur = i;
        AlertDialog.Builder b = new AlertDialog.Builder(this);
        b.setTitle("播放倍速");
        b.setSingleChoiceItems(names, cur, new DialogInterface.OnClickListener() {
            @Override public void onClick(DialogInterface d, int which) {
                d.dismiss();
                setRate(rates[which]);
                Prefs.setSpeed(PlayActivity.this, rates[which]);   // 记住倍速
                if (speedBtn != null) speedBtn.setText(which == 2 ? "倍速" : names[which]);
            }
        });
        b.setNegativeButton("取消", null);
        b.show();
    }

    // ------------------------------------------------------------ 【v4.8】弹幕样式设置

    /** 第 0 项 = 0 表示跟随弹幕自带颜色（B站彩色弹幕） */
    static final int[] DM_COLORS = {
            0x000000, 0xFFFFFF, 0xFFEB3B, 0xFB7299, 0x4FC3F7, 0x81C784, 0xBA68C8, 0xFF9800
    };

    void applyDmStyle() {
        if (dmView != null) {
            dmView.setStyle(Prefs.dmColor(this), Prefs.dmAlpha(this), Prefs.dmSize(this));
        }
    }

    void showDmStylePanel() {
        if (isFinishing()) return;
        final android.app.Dialog dlg = new android.app.Dialog(this);
        dlg.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);
        final android.widget.LinearLayout box = new android.widget.LinearLayout(this);
        box.setOrientation(android.widget.LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(15), dp(16), dp(12));
        android.graphics.drawable.GradientDrawable bg = new android.graphics.drawable.GradientDrawable();
        bg.setColor(0xF21C1C22);
        bg.setCornerRadius(dp(14));
        box.setBackground(bg);
        dlg.setContentView(box);
        dmStyleDlg = dlg;
        fillDmPanel(box);
        dlg.setOnDismissListener(new android.content.DialogInterface.OnDismissListener() {
            @Override public void onDismiss(android.content.DialogInterface d) { dmStyleDlg = null; }
        });
        dlg.show();
        if (dlg.getWindow() != null) {
            dlg.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(0x00000000));
            dlg.getWindow().setLayout(dp(318), android.view.ViewGroup.LayoutParams.WRAP_CONTENT);
        }
    }

    android.widget.TextView dmRowLabel(String s) {
        android.widget.TextView t = new android.widget.TextView(this);
        t.setText(s);
        t.setTextSize(12f);
        t.setTextColor(0x99FFFFFF);
        t.setPadding(0, dp(10), 0, dp(6));
        return t;
    }

    android.widget.TextView dmChip(String s, boolean sel) {
        android.widget.TextView t = new android.widget.TextView(this);
        t.setText(s);
        t.setTextSize(12.5f);
        t.setGravity(android.view.Gravity.CENTER);
        t.setTextColor(sel ? 0xFFFFFFFF : 0xC0FFFFFF);
        android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable();
        g.setColor(sel ? 0xFFFB7299 : 0x22FFFFFF);
        g.setCornerRadius(dp(15));
        t.setBackground(g);
        return t;
    }

    void fillDmPanel(final android.widget.LinearLayout box) {
        box.removeAllViews();

        android.widget.TextView title = new android.widget.TextView(this);
        title.setText("弹幕样式");
        title.setTextSize(16f);
        title.setTextColor(0xFFFFFFFF);
        title.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        box.addView(title);

        final int curColor = Prefs.dmColor(this);
        final int curAlpha = Prefs.dmAlpha(this);
        final int curSize = Prefs.dmSize(this);

        // ---- 颜色 ----
        box.addView(dmRowLabel("颜色（第 1 个为原色：保留 B 站彩色弹幕）"));
        android.widget.LinearLayout crow = new android.widget.LinearLayout(this);
        crow.setOrientation(android.widget.LinearLayout.HORIZONTAL);
        for (int i = 0; i < DM_COLORS.length; i++) {
            final int c = DM_COLORS[i];
            boolean sel = (c == curColor);
            android.view.View dot = new android.view.View(this);
            android.graphics.drawable.GradientDrawable g;
            if (c == 0) {
                g = new android.graphics.drawable.GradientDrawable(
                        android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT,
                        new int[]{0xFFFF6B6B, 0xFFFFD166, 0xFF5FD3A6, 0xFF4FC3F7});
                g.setShape(android.graphics.drawable.GradientDrawable.OVAL);
            } else {
                g = new android.graphics.drawable.GradientDrawable();
                g.setShape(android.graphics.drawable.GradientDrawable.OVAL);
                g.setColor(c);
            }
            g.setStroke(sel ? dp(2.5f) : dp(1), sel ? 0xFFFFFFFF : 0x33FFFFFF);
            dot.setBackground(g);
            android.widget.LinearLayout.LayoutParams lp =
                    new android.widget.LinearLayout.LayoutParams(dp(30), dp(30));
            lp.rightMargin = dp(4);
            crow.addView(dot, lp);
            dot.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    Prefs.setDmColor(PlayActivity.this, c);
                    applyDmStyle();
                    fillDmPanel(box);
                }
            });
        }
        box.addView(crow);

        // ---- 不透明度 ----
        box.addView(dmRowLabel("不透明度"));
        android.widget.LinearLayout arow = new android.widget.LinearLayout(this);
        arow.setOrientation(android.widget.LinearLayout.HORIZONTAL);
        final int[] alphas = {30, 55, 80, 100};
        final String[] anames = {"淡", "中", "较浓", "不透明"};
        for (int i = 0; i < alphas.length; i++) {
            final int av = alphas[i];
            android.widget.TextView chip = dmChip(anames[i], av == curAlpha);
            android.widget.LinearLayout.LayoutParams lp =
                    new android.widget.LinearLayout.LayoutParams(0, dp(30), 1f);
            if (i > 0) lp.leftMargin = dp(6);
            arow.addView(chip, lp);
            chip.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    Prefs.setDmAlpha(PlayActivity.this, av);
                    applyDmStyle();
                    fillDmPanel(box);
                }
            });
        }
        box.addView(arow);

        // ---- 字号 ----
        box.addView(dmRowLabel("字号"));
        android.widget.LinearLayout srow = new android.widget.LinearLayout(this);
        srow.setOrientation(android.widget.LinearLayout.HORIZONTAL);
        final int[] sizes = {80, 100, 130};
        final String[] snames = {"小", "标准", "大"};
        for (int i = 0; i < sizes.length; i++) {
            final int sv = sizes[i];
            android.widget.TextView chip = dmChip(snames[i], sv == curSize);
            android.widget.LinearLayout.LayoutParams lp =
                    new android.widget.LinearLayout.LayoutParams(0, dp(30), 1f);
            if (i > 0) lp.leftMargin = dp(6);
            srow.addView(chip, lp);
            chip.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    Prefs.setDmSize(PlayActivity.this, sv);
                    applyDmStyle();
                    fillDmPanel(box);
                }
            });
        }
        box.addView(srow);

        // ---- 底部：恢复默认 / 完成 ----
        android.widget.LinearLayout brow = new android.widget.LinearLayout(this);
        brow.setOrientation(android.widget.LinearLayout.HORIZONTAL);
        brow.setPadding(0, dp(14), 0, 0);

        android.widget.TextView reset = new android.widget.TextView(this);
        reset.setText("恢复默认");
        reset.setTextSize(12f);
        reset.setTextColor(0x80FFFFFF);
        reset.setGravity(android.view.Gravity.CENTER_VERTICAL);
        reset.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                Prefs.setDmColor(PlayActivity.this, 0);
                Prefs.setDmAlpha(PlayActivity.this, 100);
                Prefs.setDmSize(PlayActivity.this, 100);
                applyDmStyle();
                fillDmPanel(box);
            }
        });
        brow.addView(reset, new android.widget.LinearLayout.LayoutParams(0, dp(34), 1f));

        android.widget.TextView done = new android.widget.TextView(this);
        done.setText("完成");
        done.setTextSize(13f);
        done.setTextColor(0xFFFFFFFF);
        done.setGravity(android.view.Gravity.CENTER);
        android.graphics.drawable.GradientDrawable dg = new android.graphics.drawable.GradientDrawable();
        dg.setColor(0xFFFB7299);
        dg.setCornerRadius(dp(17));
        done.setBackground(dg);
        done.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (dmStyleDlg != null) dmStyleDlg.dismiss();
            }
        });
        brow.addView(done, new android.widget.LinearLayout.LayoutParams(dp(88), dp(34)));
        box.addView(brow);
    }

    // ------------------------------------------------------------ 弹幕开关（「弹」字方框 + 勾）

    class DmSwitch extends View {
        final android.graphics.Paint p = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);

        DmSwitch(android.content.Context c) { super(c); }

        @Override protected void onDraw(android.graphics.Canvas cv) {
            boolean on = dmOn;
            float w = getWidth(), h = getHeight();
            float boxH = h - dp(8);
            android.graphics.RectF rf = new android.graphics.RectF(
                    dp(1.5f), dp(1.5f), w - dp(1.5f), boxH);
            float r = dp(6);
            p.setStyle(android.graphics.Paint.Style.STROKE);
            p.setStrokeWidth(Math.max(2f, dp(1.4f)));
            p.setColor(on ? Color.WHITE : 0x8AFFFFFF);
            cv.drawRoundRect(rf, r, r, p);

            p.setStyle(android.graphics.Paint.Style.FILL);
            p.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
            p.setTextSize(dp(12));
            p.setTextAlign(android.graphics.Paint.Align.CENTER);
            p.setColor(on ? Color.WHITE : 0x8AFFFFFF);
            android.graphics.Paint.FontMetrics fm = p.getFontMetrics();
            cv.drawText("弹", w / 2f, rf.centerY() - (fm.ascent + fm.descent) / 2f, p);

            // 右下角小勾：开=粉，关=灰
            android.graphics.Path path = new android.graphics.Path();
            path.moveTo(w - dp(11), boxH - dp(1));
            path.lineTo(w - dp(7.5f), boxH + dp(3));
            path.lineTo(w - dp(2), boxH - dp(4.5f));
            p.setStyle(android.graphics.Paint.Style.STROKE);
            p.setStrokeWidth(Math.max(2f, dp(1.5f)));
            p.setStrokeCap(android.graphics.Paint.Cap.ROUND);
            p.setStrokeJoin(android.graphics.Paint.Join.ROUND);
            p.setColor(on ? 0xFFFB7299 : 0x666F7581);
            cv.drawPath(path, p);
        }
    }

    /** 轻量 FrameLayout 容器 */
    static class FrameLike extends android.widget.FrameLayout {
        FrameLike(Activity a) { super(a); }
        static class LayoutParams extends android.widget.FrameLayout.LayoutParams {
            LayoutParams(int w, int h) { super(w, h); }
            LayoutParams(int w, int h, int gravity) { super(w, h, gravity); }
        }
    }
}
