package com.bixiaoqu.app;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

/** 本地观看历史（仅记录 bvid + 标题 + 时间，不上传任何数据） */
public final class History {

    static final String PREF = "history";
    static final String KEY = "list";
    static final int MAX = 60;

    public static void add(Context c, String bvid, String title) {
        if (c == null || bvid == null || bvid.isEmpty()) return;
        try {
            SharedPreferences sp = c.getSharedPreferences(PREF, Context.MODE_PRIVATE);
            JSONArray old = new JSONArray(sp.getString(KEY, "[]"));
            JSONArray out = new JSONArray();
            out.put(item(bvid, title));
            for (int i = 0; i < old.length() && out.length() < MAX; i++) {
                JSONObject o = old.optJSONObject(i);
                if (o == null) continue;
                if (bvid.equals(o.optString("bvid", ""))) continue;  // 去重，最新置顶
                out.put(o);
            }
            sp.edit().putString(KEY, out.toString()).apply();
        } catch (Throwable ignore) { }
    }

    public static ArrayList<VideoItem> list(Context c) {
        ArrayList<VideoItem> out = new ArrayList<>();
        try {
            SharedPreferences sp = c.getSharedPreferences(PREF, Context.MODE_PRIVATE);
            JSONArray arr = new JSONArray(sp.getString(KEY, "[]"));
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.optJSONObject(i);
                if (o == null) continue;
                String bv = o.optString("bvid", "");
                if (bv.isEmpty()) continue;
                out.add(new VideoItem(bv, o.optString("title", bv),
                        "观看于 " + time(o.optLong("t", 0)), null));
            }
        } catch (Throwable ignore) { }
        return out;
    }

    public static void clear(Context c) {
        try {
            c.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().clear().apply();
        } catch (Throwable ignore) { }
    }

    static JSONObject item(String bvid, String title) {
        JSONObject o = new JSONObject();
        try {
            o.put("bvid", bvid);
            o.put("title", title == null ? bvid : title);
            o.put("t", System.currentTimeMillis());
        } catch (Throwable ignore) { }
        return o;
    }

    static String time(long t) {
        if (t <= 0) return "—";
        java.text.SimpleDateFormat f = new java.text.SimpleDateFormat("MM-dd HH:mm",
                java.util.Locale.CHINA);
        return f.format(new java.util.Date(t));
    }

    private History() {}
}
