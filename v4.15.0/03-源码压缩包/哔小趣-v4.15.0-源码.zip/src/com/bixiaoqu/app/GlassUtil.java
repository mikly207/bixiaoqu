package com.bixiaoqu.app;

import android.content.Context;
import android.graphics.drawable.GradientDrawable;

/**
 * 【v4.14.5】通用液态玻璃卡片材质。
 *
 * 设置页、搜索页这类纯色背景页面没有可模糊的背后内容，
 * 因此用「半透明渐变 + 一圈细高光描边 + 内外受光」来表达玻璃质感：
 *   - 半透明：能透出底层背景色，不再是死实色块；
 *   - 上亮下暗渐变：模拟玻璃受光的体积感；
 *   - 细描边：顶缘亮、底缘暗，勾出玻璃边缘。
 *
 * 全部为 API1 可用的 GradientDrawable，API22~17 通用。
 */
public final class GlassUtil {

    /** 液态玻璃卡片背景（带圆角、半透明渐变、细高光描边） */
    public static GradientDrawable card(boolean dark, float radDp, Context c) {
        float d = c.getResources().getDisplayMetrics().density;
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.RECTANGLE);
        g.setCornerRadius(radDp * d);
        g.setOrientation(GradientDrawable.Orientation.TOP_BOTTOM);
        if (dark) {
            // 深灰蓝半透明渐变：比底色略亮，透出背景又有玻璃厚度
            g.setColors(new int[]{0xB2363C47, 0x9C282C35});
            g.setStroke(Math.max(1, (int) d), 0x2EFFFFFF);
        } else {
            // 半透明白玻璃：淡描边用主题粉，干净通透
            g.setColors(new int[]{0xDEFFFFFF, 0xB5EEF0F5});
            g.setStroke(Math.max(1, (int) d), 0x2AFB7299);
        }
        return g;
    }

    /** 玻璃小胶囊（搜索历史词、标签用），比卡片更亮一点 */
    public static GradientDrawable chip(boolean dark, float radDp, Context c) {
        float d = c.getResources().getDisplayMetrics().density;
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.RECTANGLE);
        g.setCornerRadius(radDp * d);
        g.setOrientation(GradientDrawable.Orientation.TOP_BOTTOM);
        if (dark) {
            g.setColors(new int[]{0x9C3A404C, 0x8C2E333D});
            g.setStroke(Math.max(1, (int) d), 0x24FFFFFF);
        } else {
            g.setColors(new int[]{0xCCFFFFFF, 0x99EAECF2});
            g.setStroke(Math.max(1, (int) d), 0x22FB7299);
        }
        return g;
    }

    private GlassUtil() { }
}
