package com.bixiaoqu.app;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.animation.ValueAnimator;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.widget.FrameLayout;

/**
 * 液态玻璃悬浮底栏（v4.14.4 · 三格）。
 *
 * 苹果 Liquid Glass 观感的四个要素：
 *   1) 通透：抓取底栏背后的真实内容，本地高斯模糊后作为半透明背景；
 *   2) 材质：在模糊层上叠一层带渐变的半透明染色，既透出背后又保证文字可读；
 *   3) 边缘：整圈「受光高光」描边（上亮下暗）+ 顶部棱高光 + 极淡彩色色散；
 *   4) 悬浮：三层柔和外投影 + 更大的离底间距。
 *
 * 【v4.65.0 流畅度重构】
 *   · 滑动跟手：手指按下期间水珠直接跟随手指的浮点位置（不走动画、不打断重建），
 *     松手时用一次 ValueAnimator 平滑吸附到整数格 —— 消除旧的「MOVE 每次 cancel+new
 *     动画导致水珠永远到不了目标、卡顿」问题。
 *   · 渐变缓存：onDraw 用到的 9 个 LinearGradient 只在尺寸/主题变化时重建，
 *     不再每帧 new，消除 GC 抖动。
 *   · setActiveSlot 增加「已到位 / 同目标动画中」短路，避免重复动画与重绘。
 *
 * 兼容：全部为 API1 / API22 可用的 Canvas/Paint/Bitmap 基础绘制，模糊用纯 Java
 *       分离式 box blur（不依赖 RenderScript / RenderEffect），无额外权限。
 */
public class LiquidNavBar extends FrameLayout {

    public interface Callback {
        void onTouchDown(float x, float y);
        void onTouchMove(float x, float y);
        void onTouchUp();
        void onHover(int tabIndex);
        void onCommit(int tabIndex);
    }

    private Callback callback;
    /** 槽位 → 真实 tab 索引。底栏三格：{0,1,4} */
    private int[] slots = {0, 1, 4};

    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint edge = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint gloss = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint rim = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint shadow = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint bmpPaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final RectF rect = new RectF();
    private final RectF tmp = new RectF();
    private final RectF t2 = new RectF();
    private final Path clip = new Path();

    // Apple Music 液态玻璃水珠：独立滑动的选中胶囊
    private final Paint dropFill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dropEdge = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dropGloss = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF dropRect = new RectF();
    /** 当前高亮格子的浮点下标（支持滑动中间态）；<0 表示未初始化 */
    private float dropPos = -1f;
    /** 正在进行的吸附动画目标槽位（用于避免重复动画） */
    private float dropTarget = -1f;
    private ValueAnimator dropAnim;

    // 【v4.65.0】渐变缓存：onDraw 每帧不再 new LinearGradient
    private LinearGradient gTint, gTop, gBottom, gSideL, gSideR, gEdge;
    private LinearGradient gDropFill, gDropGloss, gDropEdge;
    private int shaderKey = -1;
    private boolean shaderDark = false;

    /** 背后内容视图（MainActivity 的 content），用于抓取模糊背景 */
    private View backdropSource;
    /** 模糊后的背景位图 */
    private Bitmap backdrop;

    private boolean dragging;
    /** 跟手中：水珠直接随手指移动，不走动画 */
    private boolean following;

    public LiquidNavBar(Context c) {
        super(c);
        setClipChildren(false);
        setClipToPadding(false);
        setWillNotDraw(false);   // ViewGroup 默认可能跳过 onDraw，这里必须强制绘制材质
        edge.setStyle(Paint.Style.STROKE);
        rim.setStyle(Paint.Style.STROKE);
    }

    public void setCallback(Callback cb) {
        this.callback = cb;
    }

    public void setSlots(int[] s) {
        if (s != null && s.length > 0) slots = s;
    }

    /**
     * Apple Music 水珠：把选中胶囊移动到第 slot 格（浮点，支持中间态）。
     * animate=false 时立即定位（用于初始化 / 跟手后的最终落位）。
     * 【v4.65.0】已到位或正在朝同一目标动画时直接短路，避免重复 cancel/new 动画。
     */
    public void setActiveSlot(float slot, boolean animate) {
        if (slot < 0) slot = 0;
        if (slot > slots.length - 1) slot = slots.length - 1;
        // 已到位：直接返回，不再触发动画或重绘
        if (Math.abs(dropPos - slot) < 0.005f) { dropPos = slot; return; }
        // 正在朝同一目标吸附：不打断（松手动画不被 commit 重复启动）
        if (animate && dropAnim != null && dropAnim.isRunning()
                && Math.abs(dropTarget - slot) < 0.01f) return;
        if (dropAnim != null) { dropAnim.cancel(); dropAnim = null; }
        dropTarget = slot;
        if (!animate || dropPos < 0) {
            dropPos = slot;
            invalidate();
            return;
        }
        dropAnim = ValueAnimator.ofFloat(dropPos, slot);
        dropAnim.setDuration(230);
        dropAnim.setInterpolator(new DecelerateInterpolator(1.5f));
        dropAnim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override public void onAnimationUpdate(ValueAnimator a) {
                dropPos = (Float) a.getAnimatedValue();
                invalidate();
            }
        });
        dropAnim.start();
    }

    /** 设置需要被模糊的背后内容视图 */
    public void setBackdropSource(View v) {
        this.backdropSource = v;
    }

    int dp(float v) {
        return (int) (getResources().getDisplayMetrics().density * v + 0.5f);
    }

    /** 手指 x → 槽位下标（0..n-1，整数，用于 tabAt / 松手吸附） */
    private int slotAt(float x) {
        int n = slots.length;
        int w = getWidth();
        if (w <= 0) return 0;
        int idx = (int) (x / (w / (float) n));
        if (idx < 0) idx = 0;
        if (idx >= n) idx = n - 1;
        return idx;
    }

    /**
     * 【v4.65.0】跟手：手指在底栏上滑动时，水珠直接跟随手指的浮点槽位，
     * 不走 ValueAnimator（动画在 MOVE 高频回调下会被反复 cancel，是卡顿根因）。
     */
    private void followFinger(float x) {
        int w = getWidth();
        if (w <= 0) return;
        if (dropAnim != null) { dropAnim.cancel(); dropAnim = null; }
        dropTarget = -1;
        float cw = w / (float) slots.length;
        float slot = x / cw - 0.5f;   // 让水珠中心对准手指所在格中心
        if (slot < 0) slot = 0;
        if (slot > slots.length - 1) slot = slots.length - 1;
        if (Math.abs(dropPos - slot) > 0.002f) {   // 亚像素级才重绘，减少无效帧
            dropPos = slot;
            invalidate();
        }
    }

    /**
     * 【v4.65.0】缓存 onDraw 用到的全部渐变。key=(w<<16|h)+dark，
     * 只有尺寸或主题变化才重建；滑动时 dropPos 变化不影响这些渐变（均为纵向）。
     */
    private void ensureShaders(int w, int h, boolean dark) {
        int key = (w << 16) | (h & 0xffff);
        if (key == shaderKey && dark == shaderDark) return;
        shaderKey = key;
        shaderDark = dark;

        gTint = new LinearGradient(0, 0, 0, h,
                dark ? 0x3D12141A : 0x7AFFFFFF,
                dark ? 0x660B0C10 : 0xA6ECEDF3, Shader.TileMode.CLAMP);
        gTop = new LinearGradient(0, 0, 0, dp(10),
                dark ? 0x24FFFFFF : 0x9FFFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP);
        gBottom = new LinearGradient(0, h * 0.66f, 0, h,
                0x00000000, dark ? 0x2E000000 : 0x14000000, Shader.TileMode.CLAMP);
        int sideA = dark ? 0x2FFFFFFF : 0x66FFFFFF;
        gSideL = new LinearGradient(0, 0, w * 0.18f, 0,
                sideA, 0x00FFFFFF, Shader.TileMode.CLAMP);
        gSideR = new LinearGradient(w, 0, w - w * 0.18f, 0,
                sideA, 0x00FFFFFF, Shader.TileMode.CLAMP);
        gEdge = new LinearGradient(0, 0, 0, h,
                dark ? 0x66FFFFFF : 0x7AFFFFFF,
                dark ? 0x14FFFFFF : 0x26FFFFFF, Shader.TileMode.CLAMP);

        float dh = h - dp(9);
        float dt = (h - dh) / 2f;
        gDropFill = new LinearGradient(0, dt, 0, dt + dh,
                dark ? 0x5AFFFFFF : 0xB3FFFFFF,
                dark ? 0x24FFFFFF : 0x7AF2F4F8, Shader.TileMode.CLAMP);
        gDropGloss = new LinearGradient(0, dt, 0, dt + dh * 0.62f,
                dark ? 0x2FFFFFFF : 0x8CFFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP);
        gDropEdge = new LinearGradient(0, dt, 0, dt + dh,
                dark ? 0x7AFFFFFF : 0x9FFFFFFF,
                dark ? 0x20FFFFFF : 0x40C8D0DC, Shader.TileMode.CLAMP);
    }

    /**
     * 抓取背后 content 在底栏所在区域的内容，缩小、模糊后缓存。
     * 低频调用（布局完成 / 切 tab / 回到前台），不做每帧刷新，避免抢播放带宽与算力。
     */
    public void captureBackdrop() {
        final int w = getWidth(), h = getHeight();
        if (w <= 0 || h <= 0 || backdropSource == null) return;
        try {
            // 缩小后再模糊：像素更少、模糊更柔和，开销极低
            int bw = Math.min(w, 480);
            int bh = Math.max(1, Math.round(h * (bw / (float) w)));
            Bitmap small = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888);
            Canvas c = new Canvas(small);

            // 以页面背景色铺底（content 本身无背景，避免透明处抓成黑块）
            c.drawColor(MainActivity.C_BG);

            int[] navLoc = new int[2], srcLoc = new int[2];
            getLocationOnScreen(navLoc);
            backdropSource.getLocationOnScreen(srcLoc);
            float dx = navLoc[0] - srcLoc[0];
            float dy = navLoc[1] - srcLoc[1];
            float sx = bw / (float) w, sy = bh / (float) h;
            c.scale(sx, sy);
            c.translate(-dx, -dy);
            backdropSource.draw(c);

            int[] px = new int[bw * bh];
            small.getPixels(px, 0, bw, 0, 0, bw, bh);
            GlassBlur.blurInPlace(px, bw, bh, 6);   // 共用模糊内核
            small.setPixels(px, 0, bw, 0, 0, bw, bh);

            if (backdrop != null && !backdrop.isRecycled()) backdrop.recycle();
            backdrop = small;
        } catch (Throwable ignore) {
            // 抓取失败时保留上一次的模糊背景，或退回实色，绝不影响交互
        }
        invalidate();
    }

    @Override
    protected void onDraw(Canvas cv) {
        final int w = getWidth(), h = getHeight();
        if (w <= 0 || h <= 0) return;
        final float r = h / 2f;
        final boolean dark = MainActivity.DARK;
        ensureShaders(w, h, dark);
        rect.set(0, 0, w, h);

        // ---------- 1) 外投影：三层递减，制造明显悬浮感 ----------
        int shadowLayers = 3;
        for (int i = shadowLayers; i >= 1; i--) {
            float off = dp(i * 2.2f);
            shadow.setColor(dark
                    ? (i == 1 ? 0x4D000000 : (i == 2 ? 0x2A000000 : 0x16000000))
                    : (i == 1 ? 0x38000000 : (i == 2 ? 0x1F000000 : 0x12000000)));
            tmp.set(-off * 0.42f, -off * 0.22f, w + off * 0.42f, h + off * 1.05f);
            cv.drawRoundRect(tmp, r + off * 0.45f, r + off * 0.45f, shadow);
        }

        // ---------- 2) 通透主体：模糊背景 + 半透明染色 ----------
        clip.reset();
        clip.addRoundRect(rect, r, r, Path.Direction.CW);
        final int sc = cv.save();
        cv.clipPath(clip);

        if (backdrop != null && !backdrop.isRecycled()) {
            bmpPaint.setAlpha(255);
            cv.drawBitmap(backdrop, null, rect, bmpPaint);
        } else {
            fill.setShader(null);
            fill.setColor(dark ? 0xF216181D : 0xF4FFFFFF);
            cv.drawRoundRect(rect, r, r, fill);
        }

        // 染色层：整体再降一档不透明度，让背后内容透得更多、更"通透"
        gloss.setShader(gTint);
        cv.drawRect(rect, gloss);
        gloss.setShader(null);

        // 顶部受光
        gloss.setShader(gTop);
        cv.drawRect(rect, gloss);
        gloss.setShader(null);

        // 底部内暗边（玻璃厚度感）
        gloss.setShader(gBottom);
        cv.drawRect(rect, gloss);
        gloss.setShader(null);

        // 左右端侧光，让弧面立起来
        gloss.setShader(gSideL);
        cv.drawRect(0, 0, w * 0.18f, h, gloss);
        gloss.setShader(gSideR);
        cv.drawRect(w - w * 0.18f, 0, w, h, gloss);
        gloss.setShader(null);

        cv.restoreToCount(sc);

        // ---------- 2.5) Apple Music 液态玻璃水珠（独立滑动选中胶囊） ----------
        if (dropPos >= 0) {
            final int n = slots.length;
            final float cw = w / (float) n;                  // 单格宽
            final float cx = (dropPos + 0.5f) * cw;          // 水珠中心 x
            final float pad = dp(4);                         // 左右留缝
            float dw = cw - pad * 2f;                        // 水珠宽
            float dh = h - dp(9);                            // 水珠高（略小于胶囊，露出外圈玻璃）
            float dl = cx - dw / 2f, dt = (h - dh) / 2f;
            float dr = dh / 2f;                              // 全圆角 = 胶囊
            dropRect.set(dl, dt, dl + dw, dt + dh);

            // 材质：半透明玻璃染色（深色偏亮灰、浅色偏乳白），背后模糊透上来
            dropFill.setShader(gDropFill);
            cv.drawRoundRect(dropRect, dr, dr, dropFill);
            dropFill.setShader(null);

            // 顶部受光：一道从上往下的白色高光，制造球面/玻璃凸起感
            dropGloss.setShader(gDropGloss);
            cv.drawRoundRect(dropRect, dr, dr, dropGloss);
            dropGloss.setShader(null);

            // 一圈极细半透明描边，强化水珠轮廓
            dropEdge.setStrokeWidth(dp(1f));
            dropEdge.setShader(gDropEdge);
            cv.drawRoundRect(dropRect, dr, dr, dropEdge);
            dropEdge.setShader(null);
        }

        // ---------- 3) 边缘高光：单圈细的半透明描边 ----------
        edge.setStrokeWidth(dp(1f));
        edge.setShader(gEdge);
        cv.drawRoundRect(rect, r, r, edge);
        edge.setShader(null);

        // ---------- 4) 按下提亮 ----------
        if (dragging) {
            gloss.setShader(null);
            gloss.setColor(dark ? 0x1AFFFFFF : 0x26FFFFFF);
            cv.drawRoundRect(rect, r, r, gloss);
        }
    }

    private int tabAt(float x) {
        return slots[slotAt(x)];
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        float x = ev.getX(), y = ev.getY();
        int action = ev.getActionMasked();
        switch (action) {
            case MotionEvent.ACTION_DOWN:
                dragging = true;
                following = true;
                // 按下即启动到该格的短动画，给出即时反馈；一旦滑动会被 followFinger 接管
                setActiveSlot(slotAt(x), true);
                if (callback != null) {
                    callback.onTouchDown(getLeft() + x, getTop() + y);
                    callback.onHover(tabAt(x));
                }
                return true;
            case MotionEvent.ACTION_MOVE:
                // 【v4.65.0】水珠直接跟手（连续浮点），不 new 动画 —— 流畅的关键
                followFinger(x);
                if (callback != null) {
                    callback.onTouchMove(getLeft() + x, getTop() + y);
                    callback.onHover(tabAt(x));
                }
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL: {
                boolean up = action == MotionEvent.ACTION_UP;
                following = false;
                dragging = false;
                int target = slotAt(x);
                // 松手：一次吸附动画到目标格（setActiveSlot 内部会避免重复动画）
                setActiveSlot(target, true);
                if (callback != null) {
                    callback.onTouchUp();
                    if (up) callback.onCommit(tabAt(x));
                }
                invalidate();
                return true;
            }
        }
        return true;
    }
}
