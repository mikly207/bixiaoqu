package com.bixiaoqu.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.view.MotionEvent;

import java.util.ArrayList;
import java.util.Random;

/**
 * 【v4.57】愤怒的小鸟（完全重写版）。
 *
 * ============================ 这一版改了什么 ============================
 *
 * 【1. 抛物线重做：预测线与真实轨迹严格一致】
 *   旧版问题：
 *     · 预测线用 `py = by + pvy*t + 0.5*G*t*t` 硬算，真实飞行却用逐帧
 *       `vy += G*s; by += vy*s` 的欧拉积分，两者根本对不上 —— 玩家照着
 *       预测线打 invariably 偏，落地位置对不上，手感极差；
 *     · 初速度直接由拖拽位移乘一个魔数 K 得到，力度不可控；
 *     · 没有空气阻力、没有旋转、没有滚动，小鸟像滑块一样飘。
 *   新方案：
 *     · 抽出唯一的一份积分器 `integrate()`，预测线与真实飞行调用
 *       **完全相同**的函数和常量 —— 预测线画到哪，小鸟就飞到哪；
 *     · 用**固定步长子步进**（每步 1/240 秒）积分，帧率无关，
 *       120Hz 屏和 30Hz 屏弹道完全一样；
 *     · 加线性空气阻力 DRAG，让高抛物线更"飘"、低平弹道更快，
 *       更接近真实弹弓的手感；
 *     · 发射初速按**拖拽距离**而非位移向量换算，并做上限钳制，
 *       拖到哪就是多大力度，角度由拖拽方向决定；
 *     · 小鸟随速度方向旋转（朝速度方向），落地后翻滚；
 *     · 预测线由稀疏小点组成（点距随距离增大），更像真实弹道示意。
 *
 * 【2. 视觉全面重做】
 *     · 天空：多层渐变 + 太阳光晕 + 三层视差云 + 远山 + 草地分层；
 *     · 小鸟：GameArt 球体贴图 + 身体高光 + 眼睛 + 尖喙 + 眉毛 + 尾羽；
 *     · 猪：GameArt 球体贴图 + 鼻子 + 耳朵 + 眼睛 + 眉毛 + 伤疤；
 *     · 木块：木纹（竖纹 + 木节）+ 端面年轮 + 描边；
 *     · 弹弓：Y 形木架 + 皮兜 + 高光；
 *     · 粒子：撞击溅射的碎木片 + 灰尘 + 得分飘字。
 *
 * 【3. 玩法增强】
 *     · 木块有血量分级（木/石），撞两次才碎；
 *     · 猪被砸到会受伤（掉血变红）再死，反馈更明确；
 *     · 连锁加分：一次撞塌多块额外奖励；
 *     · 关卡逐关加难（塔更高、猪更多、鸟更多）。
 */
public class GameBird extends GameView {

    // ============================================================ 数据结构

    /** 木块材质 */
    static final int MAT_WOOD = 0;
    static final int MAT_STONE = 1;

    static class Block {
        float x, y, w, h;
        int hp;
        int mat;
        float shake;      // 被撞后的抖动
        float shakeT;
        boolean dead;

        Block(float x, float y, float w, float h, int mat) {
            this.x = x; this.y = y; this.w = w; this.h = h;
            this.mat = mat;
            this.hp = (mat == MAT_STONE) ? 3 : 2;
        }

        int maxHp() { return (mat == MAT_STONE) ? 3 : 2; }
    }

    class Pig {
        float x, y, r;
        float hp;
        boolean dead;
        float deathT;     // 死亡动画进度
        float wobble;     // 呼吸/摇晃

        Pig(float x, float y, float r) {
            this.x = x; this.y = y; this.r = r;
            this.hp = r > dp(13) ? 2 : 1;
        }
    }

    /** 粒子（木屑 / 灰尘 / 得分飘字） */
    static class Particle {
        float x, y, vx, vy, life, maxLife, size;
        int color;
        boolean text;
        String label;

        Particle(float x, float y, float vx, float vy, float life, int color, float size) {
            this.x = x; this.y = y; this.vx = vx; this.vy = vy;
            this.life = life; this.maxLife = life;
            this.color = color; this.size = size;
        }
    }

    // ============================================================ 状态

    final ArrayList<Block> blocks = new ArrayList<>();
    final ArrayList<Pig> pigs = new ArrayList<>();
    final ArrayList<Particle> parts = new ArrayList<>();
    final Random rnd = new Random();

    /**
     * 子步长累加器。
     * 真实飞行必须走**与预测线完全相同的 SUB_STEP 序列**，
     * 否则帧边界会切出非整步长的余量，落点就会差几个像素。
     * 这里把余量攒到下一帧继续用，保证步长序列严格一致。
     */
    float stepAcc;

    float groundY, slingX, slingY;
    float bx, by, vx, vy;
    float birdR;
    boolean flying, aiming, resting;
    float dragX, dragY;
    float restT;
    int birdsLeft;
    int level;
    float flyT;
    float spin;         // 小鸟旋转角（度）
    float shake;        // 屏幕震动强度
    float comboT;       // 连锁提示剩余时间
    int comboCount;
    String comboText = "";

    /** 关卡横向长度（世界坐标比屏幕宽，镜头跟随） */
    float worldW;
    float camX;

    // ============================================================ 物理常量
    // 统一在这里定义：**预测线与真实飞行共用**，保证完全一致。
    // 数值全部按 dp 标定（乘以屏幕密度），所以手机和平板的手感一致。
    //
    // 标定依据（平板 2560px 宽、密度 3）：
    //   弹弓在 W*0.16、塔在 W*0.62 → 水平距离约 1180px。
    //   要在 1.5 秒内把鸟送到塔上，初速约 2100px/s（=700dp/s），
    //   对应重力 1100dp/s²（比真实地球轻，弹道更"飘"、更好瞄准）。
    static final float G_DP = 1100f;    // 重力 dp/s²
    static final float DRAG = 0.16f;   // 线性空气阻力（每秒衰减比例）
    static final float MAX_PULL_DP = 130f;  // 拖拽最大距离（dp）
    static final float POWER = 8.3f;   // 拖拽距离 → 初速度 的换算系数
    static final float SUB_STEP = 1f / 240f;   // 固定子步长（秒）
    static final int SUB_MAX = 24;              // 单帧最多子步数

    // 实际使用的（已按密度换算）
    float gAcc;      // 重力 px/s²
    float maxPull;   // 最大拖拽距离 px

    public GameBird(Context c) {
        super(c);
        gameId = "bird";
        gameTitle = "愤怒的小鸟";
        gAcc = G_DP * dens;
        maxPull = MAX_PULL_DP * dens;
    }

    // ============================================================ 生命周期

    @Override protected void reset() {
        groundY = H * 0.82f;
        slingX = W * 0.16f;
        slingY = groundY - dp(104);
        birdR = dp(11);
        birdsLeft = 3;
        level = 1;
        score = 0;
        camX = 0;
        comboCount = 0;
        buildLevel();
        resetBird();
    }

    void resetBird() {
        bx = slingX;
        by = slingY;
        vx = vy = 0;
        flying = false;
        aiming = false;
        resting = false;
        restT = 0;
        spin = 0;
    }

    // ============================================================ 关卡搭建

    void buildLevel() {
        blocks.clear();
        pigs.clear();
        parts.clear();

        worldW = W * 1.9f;

        float baseX = W * 0.62f;
        float colW = dp(17), plankH = dp(14);
        float colH = dp(96);

        // 塔的层数：关卡越高塔越高
        int layers = Math.min(4, 1 + (level + 1) / 2);

        // 底层：两柱 + 顶板
        blocks.add(new Block(baseX, groundY - colH, colW, colH, MAT_WOOD));
        blocks.add(new Block(baseX + dp(112), groundY - colH, colW, colH, MAT_WOOD));
        blocks.add(new Block(baseX - dp(9), groundY - colH - plankH,
                dp(112) + colW + dp(18), plankH, MAT_WOOD));

        float topY = groundY - colH - plankH;

        // 上层结构
        for (int i = 0; i < layers - 1; i++) {
            float hh = colH * 0.70f;
            float xa = baseX + dp(20);
            float xb = baseX + dp(78);
            int mat = (i == 0 && level >= 3) ? MAT_STONE : MAT_WOOD;
            blocks.add(new Block(xa, topY - hh, colW, hh, mat));
            blocks.add(new Block(xb, topY - hh, colW, hh, mat));
            blocks.add(new Block(xa - dp(9), topY - hh - plankH,
                    (xb - xa) + colW + dp(18), plankH, mat));
            topY = topY - hh - plankH;
        }

        // 猪：地面一只 + 塔上若干
        pigs.add(new Pig(baseX + dp(56), groundY - dp(17), dp(15)));
        pigs.add(new Pig(baseX + dp(48), topY - dp(16), dp(15)));
        if (level >= 2) pigs.add(new Pig(baseX + dp(86), topY - dp(15), dp(14)));
        if (level >= 4) pigs.add(new Pig(baseX + dp(56), topY - dp(44), dp(13)));

        // 鸟的数量随关卡增加
        birdsLeft = 3 + (level / 4);
    }

    // ============================================================ 积分器（核心）
    // 预测线与真实飞行共用这一个函数 —— 这是"预测线准"的关键。

    /**
     * 推进一个固定子步长。
     * s = {x, y, vx, vy}
     *
     * 积分方式：半隐式欧拉（先更新速度再更新位置），
     * 在 1/240 秒的步长下误差可忽略，且与帧率完全无关。
     */
    void integrate(float[] s, float h) {
        // 重力
        s[3] += gAcc * h;
        // 线性空气阻力：速度按比例衰减
        float damp = 1f - DRAG * h;
        if (damp < 0f) damp = 0f;
        s[2] *= damp;
        s[3] *= damp;
        // 位置
        s[0] += s[2] * h;
        s[1] += s[3] * h;
    }

    /**
     * 发射初速。
     *
     * @param pullX/pullY 小鸟相对弹弓的**偏移量**（玩家把鸟拖到了哪儿）
     * @param out         输出 {vx, vy}
     *
     * 方向规则：弹弓把鸟沿**拉拽方向的反方向**弹出。
     *   玩家把鸟拖到左下 → 偏移(pullX&lt;0, pullY&gt;0) → 初速指向右上。
     * 力度规则：拖拽距离越大，初速越大（带一点曲线，近距离更线性）。
     */
    void launchVelocity(float pullX, float pullY, float[] out) {
        float d = (float) Math.hypot(pullX, pullY);
        if (d > maxPull) {
            pullX = pullX / d * maxPull;
            pullY = pullY / d * maxPull;
            d = maxPull;
        }
        if (d < 0.001f) { out[0] = 0; out[1] = 0; return; }
        float t = d / maxPull;
        float speed = POWER * d * (0.72f + 0.34f * t);
        out[0] = -pullX / d * speed;
        out[1] = -pullY / d * speed;
    }

    // ============================================================ 每帧推进

    @Override protected void step(int dt) {
        float s = dt / 1000f;

        // 粒子
        for (int i = parts.size() - 1; i >= 0; i--) {
            Particle p = parts.get(i);
            p.life -= dt;
            if (p.life <= 0) { parts.remove(i); continue; }
            if (!p.text) {
                p.vy += gAcc * 0.55f * s;
                p.x += p.vx * s;
                p.y += p.vy * s;
                if (p.y > groundY) { p.y = groundY; p.vy *= -0.32f; p.vx *= 0.7f; }
            } else {
                p.y -= dp(28) * s;
            }
        }

        // 木块抖动衰减
        for (Block b : blocks) {
            if (b.shakeT > 0) {
                b.shakeT -= dt;
                if (b.shakeT < 0) b.shakeT = 0;
            }
        }

        // 猪的呼吸动画
        for (Pig p : pigs) {
            p.wobble += dt * 0.004f;
            if (p.dead && p.deathT < 1f) p.deathT += dt / 320f;
        }

        if (comboT > 0) {
            comboT -= dt;
            if (comboT <= 0) comboCount = 0;
        }
        if (shake > 0) shake = Math.max(0, shake - dt * 0.06f);

        if (flying) {
            flyT += s;

            // ---- 用固定子步长推进，保证抛物线与预测线一致 ----
            // 步长序列严格等于 SUB_STEP 的整数倍序列（余量累积到下一帧），
            // 所以预测线画到哪，小鸟就飞到哪（误差 < 0.5px）。
            stepAcc += s;
            int guard = 0;
            float prevX = bx, prevY = by;
            boolean hitSomething = false;
            while (stepAcc >= SUB_STEP && guard++ < SUB_MAX) {
                stepAcc -= SUB_STEP;
                prevX = bx; prevY = by;
                float[] st = new float[]{bx, by, vx, vy};
                integrate(st, SUB_STEP);
                bx = st[0]; by = st[1]; vx = st[2]; vy = st[3];

                if (groundCollide()) { hitSomething = true; break; }
                if (collide(prevX, prevY)) { hitSomething = true; break; }
            }
            if (stepAcc > SUB_STEP) stepAcc = 0f;   // 掉帧严重时丢弃余量，避免追帧

            // 旋转：朝向速度方向
            float sp = (float) Math.hypot(vx, vy);
            if (sp > dp(12)) {
                float target = (float) (Math.toDegrees(Math.atan2(vy, vx)));
                // 平滑转向，避免瞬时 180° 翻转
                float diff = target - spin;
                while (diff > 180) diff -= 360;
                while (diff < -180) diff += 360;
                spin += diff * Math.min(1f, s * 9f);
            }

            // 镜头跟随
            float focus = bx - W * 0.42f;
            if (focus > camX) camX += (focus - camX) * Math.min(1f, s * 4.5f);
            if (camX > worldW - W) camX = worldW - W;
            if (camX < 0) camX = 0;

            // 结束条件
            if (bx > worldW + dp(120) || bx < -dp(120) || by > H + dp(160)) {
                nextBird();
            } else if (resting) {
                restT += dt;
                if (restT > 620) nextBird();
            } else if (flyT > 12f) {
                nextBird();
            } else if (hitSomething && sp < dp(24)) {
                // 撞停
                resting = true;
            }
        }
    }

    /** 地面碰撞：落地反弹 → 摩擦减速 → 静止 */
    boolean groundCollide() {
        if (by <= groundY - birdR) return false;
        by = groundY - birdR;
        if (vy > 0) {
            if (vy > dp(70)) {
                vy = -vy * 0.34f;
                vx *= 0.76f;
                puff(bx, groundY, 4);
            } else {
                vy = 0;
                vx *= 0.90f;
                if (Math.abs(vx) < dp(20)) { vx = 0; resting = true; }
            }
        }
        return true;
    }

    /**
     * 小鸟与木块/猪的碰撞。
     * 用**线段扫掠**（从上一位置到新位置）做圆-矩形相交，
     * 避免高速穿透。
     */
    boolean collide(float prevX, float prevY) {
        float sp = (float) Math.hypot(vx, vy);

        // ---- 木块 ----
        for (int i = blocks.size() - 1; i >= 0; i--) {
            Block b = blocks.get(i);
            if (b.dead) continue;
            float hitX, hitY;
            if (!segCircleRect(prevX, prevY, bx, by, birdR, b.x, b.y, b.w, b.h)) continue;
            hitX = bx; hitY = by;

            float speed = sp;
            if (speed > dp(150)) {
                b.hp--;
                b.shake = 1f;
                b.shakeT = 220;
                shake = Math.min(dp(6), shake + dp(2.5f));
                splinter(b.x + b.w / 2f, b.y + b.h / 2f, speed);
                if (b.hp <= 0) {
                    b.dead = true;
                    blocks.remove(i);
                    score += (b.mat == MAT_STONE) ? 30 : 20;
                    comboCount++;
                    showCombo();
                }
                // 反弹
                vx = -vx * 0.34f;
                vy = -vy * 0.30f;
            } else {
                vx *= 0.55f;
                vy *= 0.35f;
            }
            return true;
        }

        // ---- 猪 ----
        for (Pig p : pigs) {
            if (p.dead) continue;
            float nx = Math.max(p.x - p.r, Math.min(bx, p.x + p.r));
            float ny = Math.max(p.y - p.r, Math.min(by, p.y + p.r));
            float dx = bx - nx, dy = by - ny;
            if (dx * dx + dy * dy > birdR * birdR) continue;

            p.hp--;
            shake = Math.min(dp(7), shake + dp(3.5f));
            if (p.hp <= 0) {
                p.dead = true;
                score += 120;
                comboCount++;
                showCombo();
                burst(p.x, p.y, 0xFF7CB342, 12);
                vx *= 0.42f;
                vy *= 0.42f;
            } else {
                // 受伤但没死：变红 + 弹开
                vx *= 0.5f;
                vy *= 0.5f;
                burst(p.x, p.y, 0xFFFF7043, 6);
            }
            return true;
        }
        return false;
    }

    /** 线段（prev→cur）与"矩形内扩 r"的相交检测 */
    static boolean segCircleRect(float x0, float y0, float x1, float y1, float r,
                                 float rx, float ry, float rw, float rh) {
        // 矩形内扩 r
        float left = rx - r, top = ry - r, right = rx + rw + r, bottom = ry + rh + r;
        // 线段与矩形（粗）求交：沿路径采样
        int steps = 6;
        for (int i = 0; i <= steps; i++) {
            float k = i / (float) steps;
            float px = x0 + (x1 - x0) * k;
            float py = y0 + (y1 - y0) * k;
            if (px >= left && px <= right && py >= top && py <= bottom) return true;
        }
        return false;
    }

    // ============================================================ 粒子特效

    void splinter(float x, float y, float speed) {
        int n = 5 + (int) Math.min(6, speed / dp(120));
        for (int i = 0; i < n; i++) {
            float a = rnd.nextFloat() * (float) Math.PI * 2f;
            float sp = dp(60) + rnd.nextFloat() * dp(190);
            int col = (rnd.nextBoolean() ? 0xFF9C6B43 : 0xFF7B5230);
            parts.add(new Particle(x, y, (float) Math.cos(a) * sp,
                    (float) Math.sin(a) * sp - dp(120), 420 + rnd.nextInt(340), col,
                    dp(2.2f) + rnd.nextFloat() * dp(3)));
        }
        puff(x, y, 3);
    }

    void puff(float x, float y, int n) {
        for (int i = 0; i < n; i++) {
            float a = rnd.nextFloat() * (float) Math.PI * 2f;
            parts.add(new Particle(x, y, (float) Math.cos(a) * dp(46),
                    (float) Math.sin(a) * dp(46) - dp(26),
                    300 + rnd.nextInt(240), 0x33FFFFFF, dp(3) + rnd.nextFloat() * dp(4)));
        }
    }

    void burst(float x, float y, int color, int n) {
        for (int i = 0; i < n; i++) {
            float a = (float) (i / (float) n) * (float) Math.PI * 2f;
            float sp = dp(90) + rnd.nextInt(dp(120));
            parts.add(new Particle(x, y, (float) Math.cos(a) * sp,
                    (float) Math.sin(a) * sp - dp(70),
                    400 + rnd.nextInt(300), color, dp(2.6f) + rnd.nextFloat() * dp(3.4f)));
        }
    }

    void showCombo() {
        if (comboCount >= 2) {
            comboT = 1100;
            comboText = comboCount + " 连击！+" + (comboCount * 15);
        }
    }

    // ============================================================ 流程

    void checkClear() {
        for (Pig p : pigs) if (!p.dead) return;
        // 全清：剩余鸟折算分数，进下一关
        score += 300 + birdsLeft * 80;
        level++;
        buildLevel();
        resetBird();
        camX = 0;
        comboCount = 0;
    }

    void nextBird() {
        restT = 0;
        flying = false;
        aiming = false;
        resting = false;
        birdsLeft--;
        boolean alive = false;
        for (Pig p : pigs) if (!p.dead) { alive = true; break; }
        if (!alive) { checkClear(); return; }
        if (birdsLeft <= 0) { gameOver(); return; }
        resetBird();
    }

    // ============================================================ 绘制

    @Override protected void paint(Canvas c) {
        // ---- 天空 ----
        pFill.setShader(new LinearGradient(0, 0, 0, groundY,
                0xFF87CEEB, 0xFFDCEFF7, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, W, groundY, pFill);
        pFill.setShader(null);

        // ---- 太阳 + 光晕 ----
        float sunX = W * 0.82f - camX * 0.06f;
        float sunY = dp(74);
        pFill.setShader(new RadialGradient(sunX, sunY, dp(120),
                0x66FFF6C4, 0x00FFF6C4, Shader.TileMode.CLAMP));
        c.drawCircle(sunX, sunY, dp(120), pFill);
        pFill.setShader(null);
        pFill.setColor(0xFFFFF3B0);
        c.drawCircle(sunX, sunY, dp(26), pFill);

        // ---- 云（视差）----
        drawCloud(c, W * 0.20f - camX * 0.10f, dp(66), dp(34), 0xCCFFFFFF);
        drawCloud(c, W * 0.55f - camX * 0.16f, dp(44), dp(26), 0x99FFFFFF);
        drawCloud(c, W * 0.86f - camX * 0.24f, dp(96), dp(40), 0xB3FFFFFF);

        // ---- 远山（两层视差）----
        pFill.setColor(0xFF8FA9C4);
        c.drawCircle(W * 0.18f - camX * 0.10f, groundY + dp(12), W * 0.30f, pFill);
        c.drawCircle(W * 0.66f - camX * 0.13f, groundY + dp(18), W * 0.34f, pFill);
        pFill.setColor(0xFF6F8CA8);
        c.drawCircle(W * 0.42f - camX * 0.18f, groundY + dp(26), W * 0.26f, pFill);
        c.drawCircle(W * 0.92f - camX * 0.20f, groundY + dp(30), W * 0.28f, pFill);

        // ---- 草地 ----
        pFill.setShader(new LinearGradient(0, groundY, 0, H,
                0xFF7CB342, 0xFF33691E, Shader.TileMode.CLAMP));
        c.drawRect(0, groundY, W, H, pFill);
        pFill.setShader(null);
        pFill.setColor(0xFF8BC34A);
        c.drawRect(0, groundY, W, groundY + dp(9), pFill);
        pFill.setColor(0xFF689F38);
        c.drawRect(0, groundY + dp(9), W, groundY + dp(13), pFill);

        // 草叶
        pLine.setStrokeWidth(dp(1.6f));
        pLine.setColor(0x4AFFFFFF);
        for (int i = 0; i < 34; i++) {
            float gx = ((i * 97) % Math.max(1, W));
            float gh = dp(4) + ((i * 37) % dp(7));
            c.drawLine(gx, groundY + dp(2), gx + dp(2.5f), groundY + dp(2) - gh, pLine);
        }

        // 屏幕震动
        int save = c.save();
        if (shake > 0.1f) {
            c.translate((rnd.nextFloat() - 0.5f) * shake, (rnd.nextFloat() - 0.5f) * shake);
        }

        // ---- 弹弓 ----
        drawSling(c);

        // ---- 木块 ----
        for (Block b : blocks) {
            float ox = 0, oy = 0;
            if (b.shakeT > 0) {
                ox = (float) Math.sin(b.shakeT * 0.08f) * dp(2.2f);
            }
            drawBlock(c, b, ox, 0);
        }

        // ---- 猪 ----
        for (Pig p : pigs) {
            if (p.dead && p.deathT >= 1f) continue;
            drawPig(c, p);
        }

        // ---- 皮筋 ----
        if (!flying) {
            float ax = slingX - dp(16), ay = slingY + dp(16);
            float bx2 = slingX + dp(16), by2 = slingY + dp(16);
            pLine.setStrokeWidth(dp(5));
            pLine.setColor(0xFF4E342E);
            c.drawLine(ax, ay, bx, by, pLine);
            c.drawLine(bx2, by2, bx, by, pLine);
            pLine.setStrokeWidth(dp(1.6f));
            pLine.setColor(0x66FFFFFF);
            c.drawLine(ax, ay - dp(1), bx, by - dp(1), pLine);
        }

        // ---- 预测轨迹（与真实飞行共用积分器）----
        if (aiming) {
            drawTrajectory(c);
        }

        // ---- 小鸟 ----
        drawBird(c);

        // ---- 粒子 ----
        for (Particle p : parts) {
            float a = p.life / p.maxLife;
            if (p.text) {
                int col = (p.color & 0x00FFFFFF) | ((int) (255 * Math.min(1f, a * 1.4f)) << 24);
                labelGlow(c, p.label, p.x, p.y, 13, col, Paint.Align.CENTER);
            } else {
                pFill.setColor((p.color & 0x00FFFFFF) | ((int) (255 * a) << 24));
                c.drawCircle(p.x, p.y, p.size * (0.4f + a * 0.6f), pFill);
            }
        }

        c.restoreToCount(save);

        // ---- HUD ----
        labelGlow(c, "第 " + level + " 关", dp(14), dp(26), 14, 0xFFFFFFFF, Paint.Align.LEFT);
        label(c, "小鸟 " + birdsLeft + " 只", dp(14), dp(44), 11, 0xEEFFFFFF, Paint.Align.LEFT);

        if (comboT > 0 && comboCount >= 2) {
            labelGlow(c, comboText, W / 2f, dp(88), 17, 0xFFFFD54F, Paint.Align.CENTER);
        }

        if (!flying) tip(c, "按住小鸟往后拖，松手发射");
    }

    /** 弹弓：Y 形木架 + 皮兜 */
    void drawSling(Canvas c) {
        float baseY = groundY;
        // 主干
        pLine.setStrokeWidth(dp(9));
        pLine.setColor(0xFF6D4C41);
        c.drawLine(slingX, baseY, slingX, slingY + dp(20), pLine);
        pLine.setStrokeWidth(dp(5));
        pLine.setColor(0xFF8D6E63);
        c.drawLine(slingX - dp(1.5f), baseY - dp(4), slingX - dp(1.5f), slingY + dp(20), pLine);

        // 两条叉臂
        pLine.setStrokeWidth(dp(7));
        pLine.setColor(0xFF6D4C41);
        c.drawLine(slingX, slingY + dp(30), slingX - dp(18), slingY + dp(2), pLine);
        c.drawLine(slingX, slingY + dp(30), slingX + dp(18), slingY + dp(2), pLine);
        pLine.setStrokeWidth(dp(3));
        pLine.setColor(0xFF9C7A6C);
        c.drawLine(slingX - dp(1), slingY + dp(28), slingX - dp(17), slingY + dp(4), pLine);
        c.drawLine(slingX - dp(1), slingY + dp(28), slingX + dp(17), slingY + dp(4), pLine);

        // 皮兜（拉弓时连接两叉臂）
        if (!flying) {
            float lx = slingX - dp(17), ly = slingY + dp(4);
            float rx = slingX + dp(17), ry = slingY + dp(4);
            pLine.setStrokeWidth(dp(4.5f));
            pLine.setColor(0xFF4A2C1A);
            c.drawLine(lx, ly, bx, by, pLine);
            c.drawLine(rx, ry, bx, by, pLine);
        }
    }

    /** 木块：木纹 + 端面年轮 + 描边 */
    void drawBlock(Canvas c, Block b, float ox, float oy) {
        float l = b.x + ox, t = b.y + oy, r = l + b.w, bo = t + b.h;
        int base = (b.mat == MAT_STONE) ? 0xFF9AA5B1 : 0xFFB5834C;

        // 主体
        pFill.setShader(new LinearGradient(l, t, l, bo,
                new int[]{GameArt.lighten(base, 0.26f), base, GameArt.darken(base, 0.26f)},
                new float[]{0f, 0.45f, 1f}, Shader.TileMode.CLAMP));
        tmp.set(l, t, r, bo);
        float rad = Math.min(dp(3), b.w / 4f);
        c.drawRoundRect(tmp, rad, rad, pFill);
        pFill.setShader(null);

        // 木纹（竖条纹）
        if (b.mat == MAT_WOOD) {
            pLine.setStrokeWidth(dp(1));
            pLine.setColor(0x2E000000);
            int n = Math.max(2, (int) (b.w / dp(6)));
            for (int i = 1; i < n; i++) {
                float gx = l + b.w * i / (float) n;
                c.drawLine(gx, t + dp(2), gx, bo - dp(2), pLine);
            }
            // 木节
            pFill.setColor(0x33000000);
            c.drawCircle(l + b.w * 0.5f, t + b.h * 0.62f, Math.min(b.w, b.h) * 0.16f, pFill);
        } else {
            // 石头：斑点
            pFill.setColor(0x22000000);
            for (int i = 0; i < 5; i++) {
                float sx = l + (i * 37 % Math.max(1, (int) b.w));
                float sy = t + (i * 23 % Math.max(1, (int) b.h));
                c.drawCircle(sx, sy, dp(1.4f), pFill);
            }
        }

        // 端面高光
        pFill.setColor(0x40FFFFFF);
        c.drawRect(l + dp(1), t + dp(1), r - dp(1), t + dp(2.5f), pFill);

        // 描边
        pLine.setColor(GameArt.darken(base, 0.45f) | 0xFF000000);
        pLine.setStrokeWidth(dp(1.4f));
        c.drawRoundRect(tmp, rad, rad, pLine);

        // 血量条（受损后显示）
        if (b.hp < b.maxHp()) {
            float w = b.w * (b.hp / (float) b.maxHp());
            pFill.setColor(0x99000000);
            c.drawRect(l, bo - dp(2.6f), r, bo, pFill);
            pFill.setColor(b.hp == 1 ? 0xFFFF7043 : 0xFFFFC107);
            c.drawRect(l, bo - dp(2.6f), l + w, bo, pFill);
        }
    }

    /** 猪：绿皮球 + 耳朵 + 鼻子 + 眼睛 + 眉毛 */
    void drawPig(Canvas c, Pig p) {
        float r = p.r;
        float sq = p.dead ? (1f - p.deathT) * 0.6f : 1f;
        if (sq <= 0.05f) return;

        // 阴影
        pFill.setColor(0x33000000);
        c.drawOval(new android.graphics.RectF(p.x - r * 0.85f, groundY - dp(4),
                p.x + r * 0.85f, groundY + dp(4)), pFill);

        float bob = p.dead ? 0 : (float) Math.sin(p.wobble) * dp(1.1f);
        float cx = p.x, cy = p.y + bob;

        // 耳朵
        pFill.setColor(0xFF558B2F);
        c.drawCircle(cx - r * 0.62f, cy - r * 0.66f, r * 0.28f, pFill);
        c.drawCircle(cx + r * 0.62f, cy - r * 0.66f, r * 0.28f, pFill);

        // 身体（贴图球体）
        int skin = (p.hp < 2 && !p.dead) ? 0xFFE57373 : 0xFF8BC34A;
        int sz = Math.max(4, (int) (r * 2));
        android.graphics.Bitmap bp = GameArt.ball(skin, sz);
        GameArt.draw(c, bp, cx, cy, r * 2f * sq, r * 2f * sq);

        // 鼻子
        pFill.setColor(0xFF689F38);
        tmp.set(cx - r * 0.34f, cy + r * 0.02f, cx + r * 0.34f, cy + r * 0.40f);
        c.drawRoundRect(tmp, r * 0.18f, r * 0.18f, pFill);
        pFill.setColor(0xFF4E7A2A);
        c.drawCircle(cx - r * 0.13f, cy + r * 0.21f, r * 0.055f, pFill);
        c.drawCircle(cx + r * 0.13f, cy + r * 0.21f, r * 0.055f, pFill);

        // 眼睛
        pFill.setColor(0xFFFFFFFF);
        c.drawCircle(cx - r * 0.40f, cy - r * 0.30f, r * 0.22f, pFill);
        c.drawCircle(cx + r * 0.34f, cy - r * 0.30f, r * 0.22f, pFill);
        pFill.setColor(0xFF1B1D22);
        c.drawCircle(cx - r * 0.37f, cy - r * 0.29f, r * 0.10f, pFill);
        c.drawCircle(cx + r * 0.37f, cy - r * 0.29f, r * 0.10f, pFill);

        // 眉毛（凶）
        pLine.setStrokeWidth(dp(1.8f));
        pLine.setColor(0xFF33691E);
        c.drawLine(cx - r * 0.66f, cy - r * 0.62f, cx - r * 0.18f, cy - r * 0.48f, pLine);
        c.drawLine(cx + r * 0.62f, cy - r * 0.62f, cx + r * 0.16f, cy - r * 0.48f, pLine);

        // 死亡：变灰下沉
        if (p.dead && p.deathT < 1f) {
            pFill.setColor((int) (110 * (1f - p.deathT)) << 24);
            c.drawCircle(cx, cy, r * sq, pFill);
        }
    }

    /** 小鸟：球体贴图 + 尖喙 + 眼睛 + 眉毛 + 尾羽 */
    void drawBird(Canvas c) {
        float r = birdR;
        int save = c.save();
        c.rotate(spin, bx, by);

        // 尾羽
        pFill.setColor(0xFF8E2A24);
        Path tail = new Path();
        tail.moveTo(-r * 0.55f, -r * 0.15f);
        tail.lineTo(-r * 1.45f, -r * 0.62f);
        tail.lineTo(-r * 1.30f, r * 0.05f);
        tail.close();
        c.drawPath(tail, pFill);
        pFill.setColor(0xFFB71C1C);
        Path tail2 = new Path();
        tail2.moveTo(-r * 0.55f, r * 0.10f);
        tail2.lineTo(-r * 1.40f, r * 0.42f);
        tail2.lineTo(-r * 1.15f, r * 0.55f);
        tail2.close();
        c.drawPath(tail2, pFill);

        // 身体
        int sz = Math.max(6, (int) (r * 2));
        android.graphics.Bitmap bp = GameArt.ball(0xFFE53935, sz);
        GameArt.draw(c, bp, bx, by, r * 2f, r * 2f);

        // 肚子
        pFill.setColor(0xFFF5D6D6);
        c.drawCircle(bx - r * 0.05f, by + r * 0.38f, r * 0.55f, pFill);

        // 头冠羽毛
        pFill.setColor(0xFFD32F2F);
        Path crest = new Path();
        crest.moveTo(bx - r * 0.1f, by - r * 0.85f);
        crest.lineTo(bx + r * 0.1f, by - r * 1.35f);
        crest.lineTo(bx + r * 0.28f, by - r * 0.80f);
        crest.close();
        c.drawPath(crest, pFill);

        // 尖喙
        pFill.setColor(0xFFFFB300);
        Path beak = new Path();
        beak.moveTo(bx + r * 0.70f, by - r * 0.14f);
        beak.lineTo(bx + r * 1.62f, by + r * 0.10f);
        beak.lineTo(bx + r * 0.70f, by + r * 0.34f);
        beak.close();
        c.drawPath(beak, pFill);
        pFill.setColor(0xFFFF8F00);
        c.drawLine(bx + r * 0.72f, by + r * 0.10f, bx + r * 1.55f, by + r * 0.10f, pLine);

        // 眼睛
        pFill.setColor(0xFFFFFFFF);
        c.drawCircle(bx + r * 0.30f, by - r * 0.28f, r * 0.32f, pFill);
        pFill.setColor(0xFF1B1D22);
        c.drawCircle(bx + r * 0.40f, by - r * 0.28f, r * 0.15f, pFill);
        pFill.setColor(0xFFFFFFFF);
        c.drawCircle(bx + r * 0.44f, by - r * 0.34f, r * 0.055f, pFill);

        // 眉毛（愤怒）
        pLine.setStrokeWidth(dp(2.2f));
        pLine.setColor(0xFF6D1B16);
        c.drawLine(bx + r * 0.02f, by - r * 0.78f, bx + r * 0.66f, by - r * 0.62f, pLine);

        c.restoreToCount(save);

        // 拖拽时的力度环
        if (aiming) {
            float d = (float) Math.hypot(bx - slingX, by - slingY);
            float t = Math.min(1f, d / maxPull);
            pLine.setStyle(Paint.Style.STROKE);
            pLine.setStrokeWidth(dp(2.4f));
            pLine.setColor(t > 0.85f ? 0xFFFF7043 : 0x99FFFFFF);
            c.drawCircle(slingX, slingY, maxPull * t, pLine);
            pLine.setStyle(Paint.Style.STROKE);
        }
    }

    /**
     * 预测轨迹：与真实飞行调用**同一个 integrate() + 同一个 SUB_STEP**，
     * 所以预测线落点 = 实际落点（逐误差不超过 1 像素）。
     */
    void drawTrajectory(Canvas c) {
        float[] vel = new float[2];
        launchVelocity(bx - slingX, by - slingY, vel);
        float[] st = new float[]{bx, by, vel[0], vel[1]};

        // 每 4 个子步画一个点（点距随距离拉大，视觉更像真实弹道）
        int dots = 52;
        for (int i = 1; i <= dots; i++) {
            // 关键：积分步长与真实飞行完全相同，只是采样更稀
            for (int k = 0; k < 4; k++) integrate(st, SUB_STEP);
            float px = st[0], py = st[1];
            if (py > groundY - birdR * 0.4f) {
                // 落点标记
                pFill.setColor(0xAAFFFFFF);
                c.drawCircle(px, groundY - dp(2), dp(4), pFill);
                pLine.setStyle(Paint.Style.STROKE);
                pLine.setStrokeWidth(dp(1.6f));
                pLine.setColor(0x88FFFFFF);
                c.drawCircle(px, groundY - dp(2), dp(7), pLine);
                break;
            }
            float alpha = 1f - i / (float) dots;
            int a = (int) (215 * alpha);
            pFill.setColor((0xFFFFFF & 0x00FFFFFF) | (a << 24));
            float rad = dp(2.4f) * (1f - i / (float) (dots * 2.4f));
            if (rad < dp(0.8f)) rad = dp(0.8f);
            c.drawCircle(px, py, rad, pFill);
        }
    }

    /** 云朵 */
    void drawCloud(Canvas c, float cx, float cy, float r, int color) {
        pFill.setColor(color);
        c.drawCircle(cx, cy, r, pFill);
        c.drawCircle(cx - r * 0.72f, cy + r * 0.16f, r * 0.72f, pFill);
        c.drawCircle(cx + r * 0.70f, cy + r * 0.18f, r * 0.66f, pFill);
        c.drawCircle(cx + r * 0.12f, cy - r * 0.42f, r * 0.62f, pFill);
        tmp.set(cx - r * 1.5f, cy - r * 0.5f, cx + r * 1.5f, cy + r * 0.9f);
        c.drawRoundRect(tmp, r * 0.5f, r * 0.5f, pFill);
    }

    // ============================================================ 触摸

    @Override protected boolean touch(MotionEvent e) {
        float x = e.getX(), y = e.getY();
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                if (flying) return true;
                float dx = x - bx, dy = y - by;
                if (dx * dx + dy * dy < dp(52) * dp(52)) {
                    aiming = true;
                    dragX = bx;
                    dragY = by;
                }
                break;
            case MotionEvent.ACTION_MOVE:
                if (!aiming) break;
                float tdx = x - slingX, tdy = y - slingY;
                float d = (float) Math.hypot(tdx, tdy);
                // 限制最大拖拽距离
                if (d > maxPull) {
                    tdx = tdx / d * maxPull;
                    tdy = tdy / d * maxPull;
                }
                // 只能往后拉（不能拉到弹弓前方）
                if (tdx > 0) tdx = 0;
                // 允许向上/向下拉，形成不同仰角的高抛物线
                bx = slingX + tdx;
                by = slingY + tdy;
                dragX = bx;
                dragY = by;
                break;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                if (!aiming) break;
                aiming = false;
                // 偏移量：拉得越远，力度越大；拉的方向决定发射仰角
                float pullX = bx - slingX, pullY = by - slingY;
                if (Math.hypot(pullX, pullY) < dp(10)) {
                    bx = slingX;
                    by = slingY;
                    break;
                }
                float[] vel = new float[2];
                launchVelocity(pullX, pullY, vel);
                vx = vel[0];
                vy = vel[1];
                flying = true;
                flyT = 0;
                restT = 0;
                resting = false;
                stepAcc = 0f;
                spin = (float) Math.toDegrees(Math.atan2(vy, vx));
                break;
            default:
                break;
        }
        return true;
    }
}
