package com.bixiaoqu.app;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.widget.AbsListView;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

/**
 * 【v4.10.3】「关注」动态流（底栏第二格）。
 *
 * 按参考图重做：
 *   顶部「关注」标题 + 刷新
 *   全部 / 视频 分段
 *   最常访问（横滑头像）
 *   动态卡：作者行 → 视频封面（16:9，底部时长/播放/弹幕）→ 标题 → 转发/评论/点赞
 *
 * 数据走 BiliApi.followDynamic（polymer feed/all），需要登录 Cookie。
 */
public class DynFeedView extends FrameLayout {

    public interface Listener {
        void onOpenVideo(String bvid, String title);
        void onOpenUp(String mid, String name);
    }

    /** 一条动态 */
    static class Dyn {
        String name = "", face = "", time = "", action = "", text = "", mid = "";
        String bvid = "", cover = "", title = "", dur = "", image = "";
        long play = 0, danmaku = 0, like = 0, comment = 0, forward = 0;
    }

    final ArrayList<Dyn> items = new ArrayList<>();
    final Handler ui = new Handler(Looper.getMainLooper());
    final Listener listener;

    ListView lv;
    LinearLayout visitBox;
    TextView emptyView, moreBtn;
    TextView segAll, segVideo;

    int type = 0;
    String offset = "";
    boolean hasMore = true, loading = false, everLoaded = false;
    int cardW;

    public DynFeedView(Context c, Listener l) {
        super(c);
        listener = l;
        cardW = c.getResources().getDisplayMetrics().widthPixels - dp(24);
        build();
        load(true);
        loadVisits();
    }

    int dp(float v) {
        return (int) (getResources().getDisplayMetrics().density * v + 0.5f);
    }

    GradientDrawable roundBg(int color, float radDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(radDp * getResources().getDisplayMetrics().density);
        return g;
    }

    // ------------------------------------------------------------ 结构

    void build() {
        lv = new ListView(getContext());
        lv.setDivider(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
        lv.setDividerHeight(dp(8));
        lv.setSelector(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
        lv.setCacheColorHint(Color.TRANSPARENT);
        lv.setOverScrollMode(View.OVER_SCROLL_NEVER);
        lv.setPadding(0, 0, 0, dp(10));
        lv.setClipToPadding(false);

        lv.addHeaderView(buildHeader(), null, false);
        emptyView = new TextView(getContext());
        emptyView.setTextColor(MainActivity.C_SUB);
        emptyView.setTextSize(13);
        emptyView.setGravity(Gravity.CENTER);
        emptyView.setPadding(dp(20), dp(60), dp(20), dp(40));
        emptyView.setLineSpacing(dp(4), 1f);
        emptyView.setVisibility(View.GONE);
        lv.addHeaderView(emptyView, null, false);

        moreBtn = new TextView(getContext());
        moreBtn.setTextSize(12.5f);
        moreBtn.setTextColor(MainActivity.C_SUB);
        moreBtn.setGravity(Gravity.CENTER);
        moreBtn.setPadding(0, dp(14), 0, dp(18));
        moreBtn.setVisibility(View.GONE);
        moreBtn.setOnClickListener(new OnClickListener() {
            @Override public void onClick(View v) { load(false); }
        });
        lv.addFooterView(moreBtn, null, false);

        adapter = new DynAdapter();
        lv.setAdapter(adapter);

        addView(lv, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    DynAdapter adapter;

    View buildHeader() {
        LinearLayout head = new LinearLayout(getContext());
        head.setOrientation(LinearLayout.VERTICAL);

        // ---- 标题栏：关注 + 刷新 ----
        FrameLayout titleBar = new FrameLayout(getContext());
        TextView title = new TextView(getContext());
        title.setText("关注");
        title.setTextColor(MainActivity.C_FG);
        title.setTextSize(17);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setGravity(Gravity.CENTER);
        titleBar.addView(title, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(46)));
        TextView refresh = new TextView(getContext());
        refresh.setText("刷新");
        refresh.setTextColor(MainActivity.C_SUB);
        refresh.setTextSize(12);
        refresh.setPadding(dp(14), dp(8), dp(16), dp(8));
        refresh.setOnClickListener(new OnClickListener() {
            @Override public void onClick(View v) {
                load(true);
                loadVisits();
            }
        });
        FrameLayout.LayoutParams rlp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.END | Gravity.CENTER_VERTICAL);
        titleBar.addView(refresh, rlp);
        head.addView(titleBar);

        // ---- 全部 / 视频 ----
        LinearLayout segRow = new LinearLayout(getContext());
        segRow.setOrientation(LinearLayout.HORIZONTAL);
        segRow.setPadding(dp(14), 0, dp(14), dp(10));
        segAll = segCell("全部", true);
        segVideo = segCell("视频", false);
        LinearLayout.LayoutParams s1 = new LinearLayout.LayoutParams(0, dp(34), 1f);
        s1.rightMargin = dp(4);
        segRow.addView(segAll, s1);
        LinearLayout.LayoutParams s2 = new LinearLayout.LayoutParams(0, dp(34), 1f);
        s2.leftMargin = dp(4);
        segRow.addView(segVideo, s2);
        segAll.setOnClickListener(new OnClickListener() {
            @Override public void onClick(View v) { switchType(0); }
        });
        segVideo.setOnClickListener(new OnClickListener() {
            @Override public void onClick(View v) { switchType(1); }
        });
        head.addView(segRow);

        // ---- 最常访问 ----
        visitBox = new LinearLayout(getContext());
        visitBox.setOrientation(LinearLayout.VERTICAL);
        visitBox.setVisibility(View.GONE);
        head.addView(visitBox);

        View gap = new View(getContext());
        gap.setBackgroundColor(MainActivity.DARK ? 0xFF0D0E11 : 0xFFEDEFF3);
        head.addView(gap, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(8)));
        return head;
    }

    TextView segCell(String text, boolean on) {
        TextView t = new TextView(getContext());
        t.setText(text);
        t.setTextSize(13);
        t.setGravity(Gravity.CENTER);
        t.setBackground(roundBg(MainActivity.C_CARD, 8));
        t.setTextColor(on ? MainActivity.C_ACC : MainActivity.C_SUB);
        if (on) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    void switchType(int t) {
        if (t == type && everLoaded) return;
        type = t;
        applySegStyle();
        offset = "";
        hasMore = true;
        items.clear();
        adapter.notifyDataSetChanged();
        load(true);
    }

    void applySegStyle() {
        boolean dark = MainActivity.DARK;
        segAll.setTextColor(type == 0 ? MainActivity.C_ACC : MainActivity.C_SUB);
        segVideo.setTextColor(type == 1 ? MainActivity.C_ACC : MainActivity.C_SUB);
        segAll.setTypeface(type == 0 ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
        segVideo.setTypeface(type == 1 ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
        segAll.setBackground(roundBg(
                type == 0 ? (dark ? 0xFF24272E : 0xFFEFF1F5) : MainActivity.C_CARD, 8));
        segVideo.setBackground(roundBg(
                type == 1 ? (dark ? 0xFF24272E : 0xFFEFF1F5) : MainActivity.C_CARD, 8));
    }

    // ------------------------------------------------------------ 最常访问

    void loadVisits() {
        if (BiliApi.loggedInUid() == null) return;
        new Thread(new Runnable() { @Override public void run() {
            final JSONArray list;
            try { list = BiliApi.followings(); } catch (Throwable e) { return; }
            if (list == null || list.length() == 0) return;
            final JSONObject[] arr = new JSONObject[Math.min(10, list.length())];
            for (int i = 0; i < arr.length; i++) arr[i] = list.optJSONObject(i);
            ui.post(new Runnable() { @Override public void run() {
                if (isAttachedToWindow()) renderVisits(arr);
            } });
        } }).start();
    }

    void renderVisits(JSONObject[] arr) {
        if (visitBox == null) return;
        visitBox.removeAllViews();
        visitBox.setVisibility(View.VISIBLE);

        TextView h = new TextView(getContext());
        h.setText("最常访问");
        h.setTextColor(MainActivity.C_FG);
        h.setTextSize(14.5f);
        h.setTypeface(Typeface.DEFAULT_BOLD);
        h.setPadding(dp(16), dp(14), dp(16), dp(10));
        visitBox.addView(h);

        android.widget.HorizontalScrollView hs = new android.widget.HorizontalScrollView(getContext());
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout row = new LinearLayout(getContext());
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(dp(10), 0, dp(10), dp(2));

        for (JSONObject o : arr) {
            if (o == null) continue;
            final String mid = o.optString("mid", "");
            final String uname = o.optString("uname", "");
            String face = o.optString("face", "");
            if (face.startsWith("//")) face = "https:" + face;
            if (!face.isEmpty() && !face.contains("@")) face += "@120w_120h_1c.jpg";

            LinearLayout one = new LinearLayout(getContext());
            one.setOrientation(LinearLayout.VERTICAL);
            one.setGravity(Gravity.CENTER_HORIZONTAL);
            one.setPadding(dp(6), 0, dp(6), 0);

            FrameLayout avBox = new FrameLayout(getContext());
            ImageView av = new ImageView(getContext());
            av.setScaleType(ImageView.ScaleType.CENTER_CROP);
            av.setBackgroundColor(MainActivity.DARK ? 0xFF2A2E37 : 0xFFDDE1E8);
            av.setClipToOutline(true);
            av.setOutlineProvider(new ViewOutlineProvider() {
                @Override public void getOutline(View v, android.graphics.Outline o) {
                    o.setOval(0, 0, v.getWidth(), v.getHeight());
                }
            });
            avBox.addView(av, new FrameLayout.LayoutParams(dp(48), dp(48)));
            ImgLoader.load(av, face, dp(48), dp(48));

            // 右下角小圆点（表示最近有更新）
            View dot = new View(getContext());
            GradientDrawable dg = new GradientDrawable();
            dg.setShape(GradientDrawable.OVAL);
            dg.setColor(MainActivity.C_ACC);
            dg.setStroke(dp(1.5f), MainActivity.C_BG);
            dot.setBackground(dg);
            FrameLayout.LayoutParams dlp = new FrameLayout.LayoutParams(
                    dp(9), dp(9), Gravity.BOTTOM | Gravity.RIGHT);
            dlp.rightMargin = dp(2);
            dlp.bottomMargin = dp(2);
            avBox.addView(dot, dlp);

            one.addView(avBox, new LinearLayout.LayoutParams(dp(48), dp(48)));

            TextView nm = new TextView(getContext());
            nm.setText(uname);
            nm.setTextColor(MainActivity.C_SUB);
            nm.setTextSize(11);
            nm.setSingleLine(true);
            nm.setEllipsize(TextUtils.TruncateAt.END);
            nm.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams nlp = new LinearLayout.LayoutParams(dp(64),
                    ViewGroup.LayoutParams.WRAP_CONTENT);
            nlp.topMargin = dp(6);
            one.addView(nm, nlp);

            one.setOnClickListener(new OnClickListener() {
                @Override public void onClick(View v) {
                    if (listener != null) listener.onOpenUp(mid, uname);
                }
            });
            row.addView(one, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        }

        hs.addView(row, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        visitBox.addView(hs);

        View line = new View(getContext());
        line.setBackgroundColor(MainActivity.DARK ? 0xFF0D0E11 : 0xFFEDEFF3);
        LinearLayout.LayoutParams llp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(8));
        visitBox.addView(line, llp);
    }

    // ------------------------------------------------------------ 数据

    public void refreshIfEmpty() {
        if (BiliApi.loggedInUid() == null) {
            showTip("登录后可以看到关注的人的最新动态");
            return;
        }
        if (items.isEmpty() && !loading) load(true);
    }

    void load(final boolean first) {
        if (loading) return;
        if (BiliApi.loggedInUid() == null) {
            showTip("登录后可以看到关注的人的最新动态");
            return;
        }
        if (!first && !hasMore) return;
        loading = true;
        if (first) {
            emptyView.setVisibility(VISIBLE);
            emptyView.setText("加载中…");
            if (moreBtn != null) moreBtn.setVisibility(View.GONE);
        } else if (moreBtn != null) {
            moreBtn.setText("加载中…");
        }

        new Thread(new Runnable() { @Override public void run() {
            final ArrayList<Dyn> got = new ArrayList<>();
            final String[] err = {null};
            final String[] next = {""};
            final boolean[] more = {false};
            try {
                JSONObject d = BiliApi.followDynamic(type, first ? "" : offset);
                next[0] = d.optString("offset", "");
                more[0] = d.optBoolean("has_more", false);
                JSONArray its = d.optJSONArray("items");
                if (its != null) {
                    for (int i = 0; i < its.length(); i++) {
                        Dyn dy = parse(its.optJSONObject(i));
                        if (dy != null) got.add(dy);
                    }
                }
            } catch (final Throwable e) {
                err[0] = e.getMessage();
            }
            ui.post(new Runnable() { @Override public void run() {
                loading = false;
                everLoaded = true;
                if (!isAttachedToWindow()) return;
                if (err[0] != null) {
                    showTip("加载失败：" + err[0]);
                    return;
                }
                offset = next[0];
                hasMore = more[0];
                if (first) items.clear();
                items.addAll(got);
                adapter.notifyDataSetChanged();
                if (items.isEmpty()) {
                    showTip(type == 1 ? "关注的人最近没有投稿" : "还没有动态，去关注几个 UP 主吧");
                } else {
                    emptyView.setVisibility(View.GONE);
                }
                updateFooter();
            } });
        } }).start();
    }

    void showTip(String msg) {
        emptyView.setText(msg);
        emptyView.setVisibility(VISIBLE);
        if (moreBtn != null) moreBtn.setVisibility(View.GONE);
    }

    void updateFooter() {
        if (moreBtn == null) return;
        moreBtn.setText(hasMore ? "加载更多" : "没有更多了");
        moreBtn.setVisibility(items.isEmpty() ? View.GONE : View.VISIBLE);
        moreBtn.setEnabled(hasMore);
    }

    static Dyn parse(JSONObject o) {
        try {
            if (o == null) return null;
            Dyn d = new Dyn();
            JSONObject modules = o.optJSONObject("modules");
            if (modules == null) return null;
            JSONObject author = modules.optJSONObject("module_author");
            if (author != null) {
                d.name = author.optString("name", "");
                d.face = author.optString("face", "");
                d.time = author.optString("pub_time", "");
                d.action = author.optString("pub_action", "");
                d.mid = author.optString("mid", "");
            }
            JSONObject md = modules.optJSONObject("module_dynamic");
            if (md != null) {
                JSONObject desc = md.optJSONObject("desc");
                if (desc != null) d.text = desc.optString("text", "");
                JSONObject major = md.optJSONObject("major");
                if (major != null) {
                    JSONObject arc = major.optJSONObject("archive");
                    if (arc != null) {
                        d.bvid = arc.optString("bvid", "");
                        d.title = arc.optString("title", "");
                        d.cover = arc.optString("cover", "");
                        d.dur = arc.optString("duration_text", "");
                        JSONObject st = arc.optJSONObject("stat");
                        if (st != null) {
                            d.play = st.optLong("play", 0);
                            d.danmaku = st.optLong("danmaku", 0);
                        }
                    }
                    JSONObject draw = major.optJSONObject("draw");
                    if (draw != null) {
                        JSONArray its = draw.optJSONArray("items");
                        if (its != null && its.length() > 0 && its.optJSONObject(0) != null) {
                            d.image = its.optJSONObject(0).optString("src", "");
                        }
                    }
                }
            }
            JSONObject stat = modules.optJSONObject("module_stat");
            if (stat != null) {
                JSONObject c = stat.optJSONObject("comment");
                JSONObject f = stat.optJSONObject("forward");
                JSONObject l = stat.optJSONObject("like");
                d.comment = c != null ? c.optLong("count", 0) : 0;
                d.forward = f != null ? f.optLong("count", 0) : 0;
                d.like = l != null ? l.optLong("count", 0) : 0;
            }
            if (d.text.isEmpty() && d.bvid.isEmpty() && d.image.isEmpty()) return null;
            return d;
        } catch (Throwable e) {
            return null;
        }
    }

    // ------------------------------------------------------------ 列表

    class DynAdapter extends BaseAdapter {
        @Override public int getCount() { return items.size(); }
        @Override public Object getItem(int i) { return items.get(i); }
        @Override public long getItemId(int i) { return i; }

        @Override public View getView(int i, View cv, ViewGroup p) {
            DynCard c = (cv instanceof DynCard) ? (DynCard) cv : new DynCard(getContext());
            c.bind(items.get(i));
            return c;
        }
    }

    /** 一条动态卡片 */
    class DynCard extends LinearLayout {
        ImageView avatar;
        TextView name, sub, text, title, actFwd, actCm, actLike;
        ImageView iconFwd, iconCm, iconLike;
        ImageView cover;
        FrameLayout videoBox;
        TextView vDur, vMeta;
        LinearLayout actions;
        ImageView image;
        Dyn item;

        DynCard(Context c) {
            super(c);
            setOrientation(VERTICAL);
            setBackgroundColor(MainActivity.C_CARD);
            setPadding(dp(12), dp(12), dp(12), dp(6));

            // ---- 作者行 ----
            LinearLayout head = new LinearLayout(c);
            head.setOrientation(HORIZONTAL);
            head.setGravity(Gravity.CENTER_VERTICAL);

            avatar = new ImageView(c);
            avatar.setScaleType(ImageView.ScaleType.CENTER_CROP);
            avatar.setBackgroundColor(MainActivity.DARK ? 0xFF2A2E37 : 0xFFDDE1E8);
            avatar.setClipToOutline(true);
            avatar.setOutlineProvider(new ViewOutlineProvider() {
                @Override public void getOutline(View v, android.graphics.Outline o) {
                    o.setOval(0, 0, v.getWidth(), v.getHeight());
                }
            });
            head.addView(avatar, new LinearLayout.LayoutParams(dp(38), dp(38)));

            LinearLayout names = new LinearLayout(c);
            names.setOrientation(VERTICAL);
            LinearLayout.LayoutParams nlp = new LinearLayout.LayoutParams(
                    0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            nlp.leftMargin = dp(10);
            head.addView(names, nlp);

            LinearLayout nameRow = new LinearLayout(c);
            nameRow.setOrientation(HORIZONTAL);
            nameRow.setGravity(Gravity.CENTER_VERTICAL);

            name = new TextView(c);
            name.setTextSize(14);
            name.setTypeface(Typeface.DEFAULT_BOLD);
            name.setTextColor(MainActivity.C_ACC);
            name.setSingleLine(true);
            name.setEllipsize(TextUtils.TruncateAt.END);
            nameRow.addView(name, new LinearLayout.LayoutParams(
                    0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

            // 认证小黄标
            TextView vBadge = new TextView(c);
            vBadge.setText("V");
            vBadge.setTextColor(Color.WHITE);
            vBadge.setTextSize(7);
            vBadge.setTypeface(Typeface.DEFAULT_BOLD);
            vBadge.setGravity(Gravity.CENTER);
            GradientDrawable bg = new GradientDrawable();
            bg.setShape(GradientDrawable.OVAL);
            bg.setColor(0xFFF5B942);
            vBadge.setBackground(bg);
            LinearLayout.LayoutParams vlp = new LinearLayout.LayoutParams(dp(13), dp(13));
            vlp.leftMargin = dp(4);
            nameRow.addView(vBadge, vlp);
            names.addView(nameRow);

            sub = new TextView(c);
            sub.setTextSize(11.5f);
            sub.setTextColor(MainActivity.C_SUB);
            sub.setSingleLine(true);
            sub.setEllipsize(TextUtils.TruncateAt.END);
            LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            slp.topMargin = dp(3);
            names.addView(sub, slp);

            head.addView(names);

            ImageView more = Ic.view(c, "more", MainActivity.C_SUB, 16);
            more.setPadding(dp(8), dp(8), dp(2), dp(8));
            head.addView(more, new LinearLayout.LayoutParams(dp(30), dp(30)));
            more.setOnClickListener(new OnClickListener() {
                @Override public void onClick(View v) { showMore(); }
            });

            addView(head, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

            // ---- 正文 ----
            text = new TextView(c);
            text.setTextSize(13.5f);
            text.setTextColor(MainActivity.C_FG);
            text.setLineSpacing(dp(3), 1f);
            text.setMaxLines(5);
            text.setEllipsize(TextUtils.TruncateAt.END);
            LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            tlp.topMargin = dp(8);
            addView(text, tlp);

            // ---- 视频卡 ----
            videoBox = new FrameLayout(c);
            videoBox.setClipToOutline(true);
            videoBox.setOutlineProvider(new ViewOutlineProvider() {
                @Override public void getOutline(View v, android.graphics.Outline o) {
                    o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), dp(8));
                }
            });
            cover = new ImageView(c);
            cover.setScaleType(ImageView.ScaleType.CENTER_CROP);
            cover.setBackgroundColor(MainActivity.DARK ? 0xFF14161A : 0xFFDFE3EA);
            videoBox.addView(cover, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

            // 底部信息条：时长 / 播放 / 弹幕
            LinearLayout bar = new LinearLayout(c);
            bar.setOrientation(HORIZONTAL);
            bar.setGravity(Gravity.BOTTOM | Gravity.CENTER_VERTICAL);
            bar.setBackground(new GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP,
                    new int[]{0xCC000000, 0x00000000}));
            bar.setPadding(dp(8), dp(4), dp(8), dp(5));

            vDur = new TextView(c);
            vDur.setTextColor(Color.WHITE);
            vDur.setTextSize(10.5f);
            bar.addView(vDur);
            vMeta = new TextView(c);
            vMeta.setTextColor(0xCCFFFFFF);
            vMeta.setTextSize(10.5f);
            LinearLayout.LayoutParams mlp = new LinearLayout.LayoutParams(
                    0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            mlp.leftMargin = dp(8);
            bar.addView(vMeta, mlp);
            videoBox.addView(bar, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                    Gravity.BOTTOM));

            LinearLayout.LayoutParams vbp = new LinearLayout.LayoutParams(cardW,
                    cardW * 9 / 16);
            vbp.topMargin = dp(9);
            addView(videoBox, vbp);

            // ---- 图片动态 ----
            image = new ImageView(c);
            image.setScaleType(ImageView.ScaleType.CENTER_CROP);
            image.setBackgroundColor(MainActivity.DARK ? 0xFF14161A : 0xFFDFE3EA);
            image.setClipToOutline(true);
            image.setOutlineProvider(new ViewOutlineProvider() {
                @Override public void getOutline(View v, android.graphics.Outline o) {
                    o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), dp(8));
                }
            });
            LinearLayout.LayoutParams ilp = new LinearLayout.LayoutParams(cardW,
                    cardW * 9 / 16);
            ilp.topMargin = dp(9);
            addView(image, ilp);

            // ---- 标题 ----
            title = new TextView(c);
            title.setTextSize(15.5f);
            title.setTypeface(Typeface.DEFAULT_BOLD);
            title.setTextColor(MainActivity.C_FG);
            title.setMaxLines(2);
            title.setEllipsize(TextUtils.TruncateAt.END);
            title.setLineSpacing(dp(2), 1f);
            LinearLayout.LayoutParams tl2 = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            tl2.topMargin = dp(9);
            addView(title, tl2);

            // ---- 操作行 ----
            actions = new LinearLayout(c);
            actions.setOrientation(HORIZONTAL);
            actions.setGravity(Gravity.CENTER_VERTICAL);
            LinearLayout.LayoutParams alp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, dp(42));
            alp.topMargin = dp(4);
            addView(actions, alp);

            iconFwd = Ic.view(c, "share", MainActivity.C_SUB, 17);
            actFwd = actionText();
            actions.addView(actionCell(iconFwd, actFwd), new LinearLayout.LayoutParams(
                    0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));

            iconCm = Ic.view(c, "comment", MainActivity.C_SUB, 17);
            actCm = actionText();
            actions.addView(actionCell(iconCm, actCm), new LinearLayout.LayoutParams(
                    0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));

            iconLike = Ic.view(c, "like", MainActivity.C_SUB, 17);
            actLike = actionText();
            LinearLayout likeCell = actionCell(iconLike, actLike);
            actions.addView(likeCell, new LinearLayout.LayoutParams(
                    0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));
            likeCell.setOnClickListener(new OnClickListener() {
                @Override public void onClick(View v) { doLike(); }
            });
        }

        TextView actionText() {
            TextView t = new TextView(getContext());
            t.setTextColor(MainActivity.C_SUB);
            t.setTextSize(12);
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            p.leftMargin = dp(5);
            t.setLayoutParams(p);
            return t;
        }

        LinearLayout actionCell(View icon, TextView label) {
            LinearLayout c = new LinearLayout(getContext());
            c.setOrientation(HORIZONTAL);
            c.setGravity(Gravity.CENTER);
            c.setClickable(true);
            c.addView(icon, new LinearLayout.LayoutParams(dp(17), dp(17)));
            c.addView(label);
            return c;
        }

        void bind(Dyn d) {
            item = d;
            name.setText(d.name);
            StringBuilder sb = new StringBuilder();
            if (!d.time.isEmpty()) sb.append(d.time);
            if (!d.action.isEmpty()) {
                if (sb.length() > 0) sb.append(" · ");
                sb.append(d.action);
            }
            sub.setText(sb.toString());

            String face = d.face.startsWith("//") ? "https:" + d.face : d.face;
            if (!face.isEmpty() && !face.contains("@")) face += "@96w_96h_1c.jpg";
            ImgLoader.load(avatar, face, dp(38), dp(38));

            text.setVisibility(d.text.isEmpty() ? GONE : VISIBLE);
            text.setText(d.text);

            boolean hasVideo = !d.bvid.isEmpty();
            videoBox.setVisibility(hasVideo ? VISIBLE : GONE);
            if (hasVideo) {
                String cv = d.cover.startsWith("//") ? "https:" + d.cover : d.cover;
                ImgLoader.load(cover, cv, cardW, cardW * 9 / 16);
                vDur.setText(d.dur);
                vMeta.setText(VideoItem.views(d.play) + "播放  "
                        + VideoItem.views(d.danmaku) + "弹幕");
            }

            boolean hasImg = !hasVideo && !d.image.isEmpty();
            image.setVisibility(hasImg ? VISIBLE : GONE);
            if (hasImg) {
                String im = d.image.startsWith("//") ? "https:" + d.image : d.image;
                ImgLoader.load(image, im, cardW, cardW * 9 / 16);
            }

            boolean hasTitle = hasVideo && !d.title.isEmpty();
            title.setVisibility(hasTitle ? VISIBLE : GONE);
            title.setText(d.title);

            actFwd.setText(d.forward > 0 ? VideoItem.views(d.forward) : "转发");
            actCm.setText(d.comment > 0 ? VideoItem.views(d.comment) : "评论");
            actLike.setText(d.like > 0 ? VideoItem.views(d.like) : "点赞");
            actLike.setTextColor(MainActivity.C_SUB);
            Ic.set(iconLike, "like", MainActivity.C_SUB);
            liked = false;

            setOnClickListener(new OnClickListener() {
                @Override public void onClick(View v) {
                    if (item != null && !item.bvid.isEmpty() && listener != null) {
                        listener.onOpenVideo(item.bvid, item.title);
                    }
                }
            });
        }

        boolean liked;

        void doLike() {
            if (item == null || item.bvid.isEmpty()) return;
            if (BiliApi.loggedInUid() == null) {
                Toast.makeText(getContext(), "请先登录", Toast.LENGTH_SHORT).show();
                return;
            }
            final boolean on = !liked;
            liked = on;
            item.like += on ? 1 : -1;
            if (item.like < 0) item.like = 0;
            actLike.setText(item.like > 0 ? VideoItem.views(item.like) : "点赞");
            actLike.setTextColor(on ? MainActivity.C_ACC : MainActivity.C_SUB);
            Ic.set(iconLike, on ? "like_on" : "like", on ? MainActivity.C_ACC : MainActivity.C_SUB);
            final String bvid = item.bvid;
            new Thread(new Runnable() { @Override public void run() {
                try { BiliApi.setLike(bvid, on); } catch (Throwable ignore) { }
            } }).start();
        }

        void showMore() {
            if (item == null) return;
            final String[] its = {"打开 UP 主空间", "复制链接"};
            new android.app.AlertDialog.Builder(getContext())
                    .setItems(its, new android.content.DialogInterface.OnClickListener() {
                        @Override public void onClick(android.content.DialogInterface dlg, int w) {
                            if (w == 0) {
                                if (listener != null) listener.onOpenUp(item.mid, item.name);
                            } else {
                                String link = "https://www.bilibili.com/video/" + item.bvid;
                                android.content.ClipboardManager cm =
                                        (android.content.ClipboardManager) getContext()
                                                .getSystemService(Context.CLIPBOARD_SERVICE);
                                cm.setPrimaryClip(android.content.ClipData.newPlainText("bili", link));
                                Toast.makeText(getContext(), "已复制", Toast.LENGTH_SHORT).show();
                            }
                        }
                    }).show();
        }
    }
}
