package com.bixiaoqu.app;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

/**
 * 【v4.56】在线视频转 MP3：从**软件内的在线视频**（B站）里挑一个，
 * 解析出它的音频流 → 下载音轨 → 转码为 MP3 → 存入留声机曲库并可直接播放。
 *
 * 与 v4.55 的「本地视频转 MP3」的区别：
 *   v4.55 选的是手机里的本地视频文件；
 *   v4.56 选的是本 App 内正在推荐的在线视频，直接从网络取音轨，无需本地文件。
 *
 * 流程：
 *   1) 拉取在线视频推荐列表（BiliApi.recommendFeed / popular）
 *   2) 用户点选某个视频 → BiliApi.playurl 拿 DASH → pickAudio 取音轨直链
 *   3) 带 Referer 下载音轨（m4s/AAC）
 *   4) AudioConverter.decodeToMp3 转成 MP3
 *   5) 结果经静态字段桥接回 MusicActivity，入库并播放
 */
public class OnlineVideoToMp3Activity extends Activity {

    /** 转换结果桥接（MusicActivity.onActivityResult 读取后清空） */
    static String lastOutputPath;
    static String lastTitle;
    static String lastArtist;

    private LinearLayout content;
    private ProgressDialog pd;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        MainActivity.applyTheme(this);
        buildUi();
        loadList();
    }

    // ------------------------------------------------------------ UI
    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(MainActivity.C_BG);

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(14), dp(12), dp(14), dp(10));

        TextView tv = new TextView(this);
        tv.setText("选择在线视频转 MP3");
        tv.setTextColor(MainActivity.C_FG);
        tv.setTextSize(17);
        top.addView(tv, new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView back = new TextView(this);
        back.setText("返回");
        back.setTextColor(Theme.c(0xFFFB7299));
        back.setTextSize(14);
        back.setPadding(dp(12), dp(6), dp(12), dp(6));
        back.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { finish(); }
        });
        top.addView(back);
        root.addView(top);

        TextView hint = new TextView(this);
        hint.setText("以下为本软件内的在线视频。选中后会自动提取其音轨并转为 MP3，"
                + "转换完成的歌曲会存入留声机曲库，可直接播放。");
        hint.setTextColor(MainActivity.C_SUB);
        hint.setTextSize(12);
        hint.setPadding(dp(16), dp(2), dp(16), dp(8));
        root.addView(hint);

        ScrollView sc = new ScrollView(this);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(12), 0, dp(12), dp(20));
        sc.addView(content, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(sc, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        setContentView(root);
    }

    private void loading(String s) {
        content.removeAllViews();
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextColor(MainActivity.C_SUB);
        t.setTextSize(13);
        t.setPadding(dp(14), dp(20), dp(14), dp(20));
        content.addView(t);
    }

    // ------------------------------------------------------------ 列表
    /** 一条在线视频（只保留转码必需的字段）。 */
    static final class Ov {
        String bvid, title, sub, pic;
        long cid, durSec;
    }

    /** 从 B 站推荐流/热门 item 中解析出视频信息。 */
    static Ov parseItem(JSONObject o) {
        if (o == null) return null;
        String bv = o.optString("bvid", "");
        if (bv.isEmpty()) {
            // 推荐流也可能把稿件信息包在 data 里
            JSONObject d = o.optJSONObject("data");
            if (d != null) bv = d.optString("bvid", "");
        }
        if (bv.isEmpty()) return null;
        Ov v = new Ov();
        v.bvid = bv;
        v.title = o.optString("title", "");
        if (v.title.isEmpty()) {
            JSONObject d = o.optJSONObject("data");
            if (d != null) v.title = d.optString("title", "");
        }
        v.sub = o.optString("owner", "");
        if (v.sub.isEmpty()) {
            JSONObject ow = o.optJSONObject("owner");
            if (ow != null) v.sub = ow.optString("name", "");
        }
        if (v.sub.isEmpty()) {
            JSONObject d = o.optJSONObject("data");
            JSONObject ow = d != null ? d.optJSONObject("owner") : null;
            if (ow != null) v.sub = ow.optString("name", "");
        }
        v.durSec = o.optLong("duration", 0L);
        if (v.durSec <= 0) {
            JSONObject d = o.optJSONObject("data");
            if (d != null) v.durSec = d.optLong("duration", 0L);
        }
        v.pic = o.optString("pic", "");
        if (v.pic.isEmpty()) {
            JSONObject d = o.optJSONObject("data");
            if (d != null) v.pic = d.optString("pic", "");
        }
        return v;
    }

    private void loadList() {
        loading("正在获取在线视频…");
        new Thread(new Runnable() {
            @Override public void run() {
                final List<Ov> items = new ArrayList<Ov>();
                try {
                    JSONArray arr = BiliApi.recommendMix(1, 40);
                    if (arr != null) {
                        for (int i = 0; i < arr.length() && items.size() < 40; i++) {
                            Ov v = parseItem(arr.optJSONObject(i));
                            if (v != null && !TextUtils.isEmpty(v.bvid)) items.add(v);
                        }
                    }
                } catch (Throwable ignore) { }
                if (items.isEmpty()) {
                    try {
                        JSONArray arr = BiliApi.popular(1);
                        if (arr != null) {
                            for (int i = 0; i < arr.length() && items.size() < 40; i++) {
                                Ov v = parseItem(arr.optJSONObject(i));
                                if (v != null && !TextUtils.isEmpty(v.bvid)) items.add(v);
                            }
                        }
                    } catch (Throwable ignore) { }
                }
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        if (items.isEmpty()) {
                            loading("没有取到在线视频，请检查网络后重试");
                            return;
                        }
                        render(items);
                    }
                });
            }
        }).start();
    }

    private void render(List<Ov> items) {
        content.removeAllViews();
        for (final Ov v : items) {
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.HORIZONTAL);
            card.setGravity(Gravity.CENTER_VERTICAL);
            card.setPadding(dp(8), dp(8), dp(10), dp(8));
            card.setBackgroundColor(MainActivity.C_CARD);

            ImageView iv = new ImageView(this);
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            ImgLoader.load(iv, v.pic, dp(96), dp(64));
            LinearLayout.LayoutParams ivp = new LinearLayout.LayoutParams(dp(96), dp(64));
            ivp.rightMargin = dp(10);
            card.addView(iv, ivp);

            LinearLayout col = new LinearLayout(this);
            col.setOrientation(LinearLayout.VERTICAL);
            TextView t1 = new TextView(this);
            t1.setText(v.title == null ? "（无标题）" : v.title);
            t1.setTextColor(MainActivity.C_FG);
            t1.setTextSize(14);
            t1.setMaxLines(2);
            col.addView(t1);
            TextView t2 = new TextView(this);
            t2.setText((v.sub == null ? "" : v.sub)
                    + (v.durSec > 0 ? ("　" + VideoItem.dur((int) v.durSec)) : ""));
            t2.setTextColor(MainActivity.C_SUB);
            t2.setTextSize(11.5f);
            t2.setMaxLines(1);
            col.addView(t2);
            card.addView(col, new LinearLayout.LayoutParams(0,
                    ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

            TextView go = new TextView(this);
            go.setText("转 MP3");
            go.setTextColor(Color.WHITE);
            go.setTextSize(12.5f);
            go.setGravity(Gravity.CENTER);
            go.setPadding(dp(10), dp(6), dp(10), dp(6));
            go.setBackgroundColor(Theme.c(0xFFFB7299));
            go.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View view) { convert(v); }
            });
            card.addView(go);

            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            cp.bottomMargin = dp(8);
            card.setLayoutParams(cp);
            content.addView(card);
        }
    }

    // ------------------------------------------------------------ 转换
    private void convert(final Ov v) {
        pd = new ProgressDialog(this);
        pd.setMessage("正在解析音轨…");
        pd.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
        pd.setMax(100);
        pd.setCancelable(false);
        pd.show();

        new Thread(new Runnable() {
            @Override public void run() {
                try {
                    // 1) 拿 cid
                    long cid = v.cid;
                    if (cid <= 0) {
                        JSONObject view = BiliApi.view(v.bvid, null);
                        cid = view.optLong("cid", 0);
                        if (cid <= 0) {
                            JSONArray pages = view.optJSONArray("pages");
                            if (pages != null && pages.length() > 0) {
                                cid = pages.getJSONObject(0).optLong("cid", 0);
                            }
                        }
                    }
                    if (cid <= 0) throw new Exception("无法取得视频分P信息");

                    // 2) 拿播放信息 → 选音轨
                    JSONObject play = BiliApi.playurl(v.bvid, null, cid);
                    String[] au = BiliApi.pickAudio(play);
                    final String audioUrl = au[0];

                    // 3) 下载音轨
                    File dir = new File(getExternalFilesDir("music"), "video2mp3");
                    if (!dir.exists()) dir.mkdirs();
                    File src = new File(dir, "aud_" + System.currentTimeMillis() + ".m4s");
                    setProgress(5, "正在下载音轨…");
                    download(audioUrl, src, new Runnable() {
                        @Override public void run() { setProgress(30, "正在下载音轨…"); }
                    });

                    // 4) 转 MP3
                    setProgress(35, "正在转换 MP3…");
                    String title = (v.title == null || v.title.isEmpty()) ? ("在线视频音乐") : v.title;
                    String safe = title.replaceAll("[\\\\/:*?\"<>|]", "_");
                    if (safe.length() > 48) safe = safe.substring(0, 48);
                    File out = new File(dir, safe + ".mp3");
                    AudioConverter.decodeToMp3(src.getAbsolutePath(), out.getAbsolutePath(), 192,
                            new AudioConverter.Progress() {
                                @Override public void onProgress(final double r) {
                                    setProgress((int) (35 + r * 60), "正在转换 MP3…");
                                }
                            });
                    src.delete();

                    lastOutputPath = out.getAbsolutePath();
                    lastTitle = safe;
                    lastArtist = (v.sub == null || v.sub.isEmpty()) ? "在线视频" : v.sub;
                    runOnUiThread(new Runnable() {
                        @Override public void run() {
                            dismissPd();
                            Toast.makeText(OnlineVideoToMp3Activity.this,
                                    "转换完成，已加入留声机", Toast.LENGTH_SHORT).show();
                            setResult(RESULT_OK);
                            finish();
                        }
                    });
                } catch (final Throwable e) {
                    runOnUiThread(new Runnable() {
                        @Override public void run() {
                            dismissPd();
                            Toast.makeText(OnlineVideoToMp3Activity.this,
                                    "转换失败：" + e.getMessage(), Toast.LENGTH_LONG).show();
                        }
                    });
                }
            }
        }).start();
    }

    private void setProgress(final int p, final String msg) {
        runOnUiThread(new Runnable() {
            @Override public void run() {
                if (pd != null && pd.isShowing()) {
                    pd.setProgress(p);
                    if (msg != null) pd.setMessage(msg);
                }
            }
        });
    }

    private void dismissPd() {
        try { if (pd != null) pd.dismiss(); } catch (Throwable ignore) { }
    }

    /** 下载 B 站音轨（必须带 Referer，否则 403）。 */
    private void download(String url, File dst, final Runnable onTick) throws Exception {
        HttpURLConnection c = null;
        InputStream is = null;
        OutputStream os = null;
        try {
            c = (HttpURLConnection) new URL(url).openConnection();
            c.setConnectTimeout(15000);
            c.setReadTimeout(30000);
            c.setRequestProperty("User-Agent",
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                            + "(KHTML, like Gecko) Chrome/120.0 Safari/537.36");
            c.setRequestProperty("Referer", "https://www.bilibili.com/");
            c.setRequestProperty("Origin", "https://www.bilibili.com");
            int code = c.getResponseCode();
            if (code != 200) throw new Exception("下载音轨失败 HTTP " + code);
            is = c.getInputStream();
            os = new FileOutputStream(dst);
            byte[] buf = new byte[64 * 1024];
            int n;
            long got = 0;
            while ((n = is.read(buf)) > 0) {
                os.write(buf, 0, n);
                got += n;
                if (onTick != null && (got % (512 * 1024)) < 64 * 1024) onTick.run();
            }
            os.flush();
        } finally {
            try { if (os != null) os.close(); } catch (Throwable ignore) { }
            try { if (is != null) is.close(); } catch (Throwable ignore) { }
            try { if (c != null) c.disconnect(); } catch (Throwable ignore) { }
        }
    }

    private int dp(float v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }
}
