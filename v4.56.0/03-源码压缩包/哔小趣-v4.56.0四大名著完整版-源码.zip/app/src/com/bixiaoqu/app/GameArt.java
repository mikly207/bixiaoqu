package com.bixiaoqu.app;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;

import java.util.HashMap;
import java.util.Map;

/**
 * 【v4.56】小游戏贴图引擎。
 *
 * 目标：把此前「纯色方块 + 圆角矩形」的朴素画风，换成有**体积感**的贴图。
 * 做法：运行时用 Canvas 程序化生成精灵 Bitmap（一次性生成、之后复用），
 * 每个精灵都包含：
 *   · 主体纵向渐变（上亮下暗 → 圆柱/金属感）
 *   · 顶部高光条（模拟受光面）
 *   · 底部内阴影（模拟接地阴影）
 *   · 描边（深色勾边，提升辨识度）
 *   · 可选投影（立体悬浮感）
 *
 * 不引入任何外部图片资源：所有贴图都是代码生成，APK 体积零增长，
 * 且能按屏幕密度生成任意尺寸，永远清晰不糊。
 */
public final class GameArt {

    // key = "类型:色值:半径" → 贴图
    private static final Map<String, Bitmap> CACHE = new HashMap<String, Bitmap>();

    private GameArt() { }

    /**
     * 圆角方块贴图（带渐变 + 高光 + 描边）。
     *
     * @param color  主色
     * @param size   贴图边长（px）
     * @param radius 圆角半径（px）
     * @param gloss  是否画顶部高光
     */
    public static Bitmap tile(int color, int size, float radius, boolean gloss) {
        int r = Math.max(1, Math.round(radius));
        String key = "T:" + color + ":" + size + ":" + r + ":" + (gloss ? 1 : 0);
        Bitmap b = CACHE.get(key);
        if (b != null) return b;

        b = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        // 主体：上亮下暗的纵向渐变
        int top = lighten(color, 0.34f);
        int mid = color;
        int bot = darken(color, 0.30f);
        p.setShader(new LinearGradient(0, 0, 0, size,
                new int[]{top, mid, bot},
                new float[]{0f, 0.42f, 1f}, Shader.TileMode.CLAMP));
        c.drawRoundRect(new RectF(0, 0, size, size), r, r, p);
        p.setShader(null);

        // 顶部高光条（内嵌，模拟受光面）
        if (gloss && size > 6) {
            float gh = size * 0.34f;
            p.setShader(new LinearGradient(0, 0, 0, gh,
                    new int[]{0x70FFFFFF, 0x00FFFFFF}, null, Shader.TileMode.CLAMP));
            c.drawRoundRect(new RectF(r * 0.35f, r * 0.30f, size - r * 0.35f, gh),
                    r * 0.6f, r * 0.6f, p);
            p.setShader(null);
        }

        // 底部内阴影
        float sh = size * 0.22f;
        p.setShader(new LinearGradient(0, size - sh, 0, size,
                new int[]{0x00000000, 0x40000000}, null, Shader.TileMode.CLAMP));
        c.drawRoundRect(new RectF(0, 0, size, size), r, r, p);
        p.setShader(null);

        // 勾边
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(Math.max(1f, size * 0.045f));
        p.setColor(darken(color, 0.42f) | 0xFF000000);
        c.drawRoundRect(new RectF(p.getStrokeWidth() / 2f, p.getStrokeWidth() / 2f,
                size - p.getStrokeWidth() / 2f, size - p.getStrokeWidth() / 2f), r, r, p);

        CACHE.put(key, b);
        return b;
    }

    /** 圆形贴图（球体：径向渐变 + 高光点 + 描边）。 */
    public static Bitmap ball(int color, int size) {
        String key = "B:" + color + ":" + size;
        Bitmap b = CACHE.get(key);
        if (b != null) return b;

        b = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        float rad = size / 2f;

        // 球体主体：径向渐变（光从左上 35% 处来）
        p.setShader(new RadialGradient(size * 0.35f, size * 0.32f, size * 0.78f,
                new int[]{lighten(color, 0.52f), color, darken(color, 0.38f)},
                new float[]{0f, 0.55f, 1f}, Shader.TileMode.CLAMP));
        c.drawCircle(rad, rad, rad - 0.5f, p);
        p.setShader(null);

        // 高光点
        p.setColor(0x99FFFFFF);
        c.drawCircle(size * 0.32f, size * 0.28f, size * 0.13f, p);

        // 底部反光
        p.setColor(0x22FFFFFF);
        c.drawCircle(size * 0.60f, size * 0.72f, size * 0.16f, p);

        // 勾边
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(Math.max(1f, size * 0.055f));
        p.setColor(darken(color, 0.45f) | 0xFF000000);
        c.drawCircle(rad, rad, rad - p.getStrokeWidth() / 2f, p);

        CACHE.put(key, b);
        return b;
    }

    /** 胶囊贴图（角色身体：圆头胶囊 + 竖向渐变 + 高光）。 */
    public static Bitmap capsule(int color, int w, int h) {
        String key = "C:" + color + ":" + w + ":" + h;
        Bitmap b = CACHE.get(key);
        if (b != null) return b;

        b = Bitmap.createBitmap(Math.max(2, w), Math.max(2, h), Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        float rad = Math.min(w, h) / 2f;

        p.setShader(new LinearGradient(0, 0, 0, h,
                new int[]{lighten(color, 0.30f), color, darken(color, 0.28f)},
                new float[]{0f, 0.45f, 1f}, Shader.TileMode.CLAMP));
        c.drawRoundRect(new RectF(0, 0, w, h), rad, rad, p);
        p.setShader(null);

        // 左侧高光条
        p.setShader(new LinearGradient(0, 0, w * 0.55f, 0,
                new int[]{0x66FFFFFF, 0x00FFFFFF}, null, Shader.TileMode.CLAMP));
        c.drawRoundRect(new RectF(rad * 0.35f, rad * 0.30f, w * 0.55f, h - rad * 0.30f),
                rad * 0.6f, rad * 0.6f, p);
        p.setShader(null);

        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(Math.max(1f, Math.min(w, h) * 0.07f));
        p.setColor(darken(color, 0.40f) | 0xFF000000);
        c.drawRoundRect(new RectF(p.getStrokeWidth() / 2f, p.getStrokeWidth() / 2f,
                w - p.getStrokeWidth() / 2f, h - p.getStrokeWidth() / 2f), rad, rad, p);

        CACHE.put(key, b);
        return b;
    }

    /** 把贴图画到指定矩形（居中缩放）。 */
    public static void draw(Canvas c, Bitmap b, float cx, float cy, float w, float h) {
        if (b == null || b.isRecycled()) return;
        c.drawBitmap(b, null, new RectF(cx - w / 2f, cy - h / 2f, cx + w / 2f, cy + h / 2f),
                null);
    }

    /** 把贴图画到指定矩形（左上角定位）。 */
    public static void drawAt(Canvas c, Bitmap b, float l, float t, float w, float h) {
        if (b == null || b.isRecycled()) return;
        c.drawBitmap(b, null, new RectF(l, t, l + w, t + h), null);
    }

    // ---------------------------------------------------------------- 颜色工具

    public static int lighten(int c, float amt) {
        int a = Color.alpha(c);
        int r = (int) (Color.red(c) + (255 - Color.red(c)) * amt);
        int g = (int) (Color.green(c) + (255 - Color.green(c)) * amt);
        int b = (int) (Color.blue(c) + (255 - Color.blue(c)) * amt);
        return Color.argb(a, clamp(r), clamp(g), clamp(b));
    }

    public static int darken(int c, float amt) {
        int a = Color.alpha(c);
        int r = (int) (Color.red(c) * (1f - amt));
        int g = (int) (Color.green(c) * (1f - amt));
        int b = (int) (Color.blue(c) * (1f - amt));
        return Color.argb(a, clamp(r), clamp(g), clamp(b));
    }

    private static int clamp(int v) { return v < 0 ? 0 : (v > 255 ? 255 : v); }

    /** 清理缓存（低内存时调用）。 */
    public static void trim() {
        if (CACHE.size() > 120) CACHE.clear();
    }
}
