package com.bixiaoqu.app;

import android.app.Activity;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/**
 * 【v4.56】四大名著内置阅读器（完整全文版）。
 *
 * 与 v4.55 的节选版不同：这里加载的是 assets 中的**无删节全书**，
 * 目录列出全部回目（西游 100 回 / 三国 120 回 / 红楼 120 回 / 水浒 120 回），
 * 每章正文逐字完整呈现，可跳章、上下章、记忆阅读进度。
 *
 * 交互：
 *   - 顶部：书名 + 目录 / 字号 / 护眼
 *   - 正文区：滚动阅读，点正文左侧 1/4 上一章、右侧 1/4 下一章
 *   - 底部：上一章 / 章节目录 / 下一章
 */
public class BookReaderActivity extends Activity {

    private String bookKey;
    private String bookName;
    private BookStore.Book book;

    private LinearLayout root;
    private TextView tvTitle;
    private TextView tvChapter;
    private ScrollView scroll;
    private TextView tvBody;

    private int curChapter = 1;
    private int fontSp = 17;
    private int eyeMode = 0;   // 0=白 1=米黄 2=绿

    private static final String PREF = "bxq_book_read";
    private static final int[] EYE_BG = {0xFFF6F7F9, 0xFFF5EEDC, 0xFFDDE8D6};
    private static final int[] EYE_FG = {0xFF1F2328, 0xFF3A3222, 0xFF243019};

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        bookKey = getIntent().getStringExtra("key");
        if (bookKey == null || bookKey.isEmpty()) bookKey = "xiyouji";
        book = BookStore.load(this, bookKey);
        if (book == null) { finish(); return; }
        bookName = nameOf(bookKey);

        buildUi();
        int last = getSharedPreferences(PREF, MODE_PRIVATE).getInt(bookKey + "_ch", 1);
        curChapter = (last >= 1 && last <= book.chapterCount) ? last : 1;
        loadChapter(curChapter, false);
    }

    private String nameOf(String key) {
        if ("xiyouji".equals(key)) return "西游记";
        if ("sanguoyanyi".equals(key)) return "三国演义";
        if ("hongloumeng".equals(key)) return "红楼梦";
        if ("shuihuzhuan".equals(key)) return "水浒传";
        return "名著";
    }

    // ---------------------------------------------------------------- UI
    private void buildUi() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(EYE_BG[eyeMode]);
        root.setLayoutParams(new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // ---- 顶栏 ----
        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(12), dp(10), dp(12), dp(8));
        top.setBackgroundColor(0x22000000);

        tvTitle = new TextView(this);
        tvTitle.setText(bookName);
        tvTitle.setTextColor(EYE_FG[eyeMode]);
        tvTitle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17);
        tvTitle.setTypeface(null, android.graphics.Typeface.BOLD);
        top.addView(tvTitle, new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        top.addView(btn("目录", new View.OnClickListener() {
            @Override public void onClick(View v) { showCatalog(); }
        }));
        top.addView(btn("A", new View.OnClickListener() {
            @Override public void onClick(View v) {
                fontSp = fontSp >= 24 ? 15 : fontSp + 2;
                tvBody.setTextSize(TypedValue.COMPLEX_UNIT_SP, fontSp);
            }
        }));
        top.addView(btn("护眼", new View.OnClickListener() {
            @Override public void onClick(View v) {
                eyeMode = (eyeMode + 1) % 3;
                applyEye();
            }
        }));
        root.addView(top);

        // ---- 章节标题 ----
        tvChapter = new TextView(this);
        tvChapter.setTextColor(EYE_FG[eyeMode]);
        tvChapter.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        tvChapter.setPadding(dp(16), dp(4), dp(16), dp(6));
        root.addView(tvChapter);

        // ---- 正文 ----
        scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        tvBody = new TextView(this);
        tvBody.setTextColor(EYE_FG[eyeMode]);
        tvBody.setTextSize(TypedValue.COMPLEX_UNIT_SP, fontSp);
        tvBody.setLineSpacing(dp(6), 1.28f);
        tvBody.setPadding(dp(16), dp(8), dp(16), dp(30));
        scroll.addView(tvBody, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(scroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        // 点正文左右侧翻章
        scroll.setOnTouchListener(new View.OnTouchListener() {
            @Override public boolean onTouch(View v, MotionEvent e) {
                if (e.getActionMasked() == MotionEvent.ACTION_UP) {
                    float x = e.getX();
                    if (x < scroll.getWidth() * 0.28f) prevChapter();
                    else if (x > scroll.getWidth() * 0.72f) nextChapter();
                }
                return false;
            }
        });

        // ---- 底栏 ----
        LinearLayout bottomBar = new LinearLayout(this);
        bottomBar.setOrientation(LinearLayout.HORIZONTAL);
        bottomBar.setGravity(Gravity.CENTER);
        bottomBar.setPadding(dp(10), dp(6), dp(10), dp(10));
        bottomBar.setBackgroundColor(0x22000000);
        bottomBar.addView(btn("上一章", new View.OnClickListener() {
            @Override public void onClick(View v) { prevChapter(); }
        }));
        bottomBar.addView(btn("章节目录", new View.OnClickListener() {
            @Override public void onClick(View v) { showCatalog(); }
        }));
        bottomBar.addView(btn("下一章", new View.OnClickListener() {
            @Override public void onClick(View v) { nextChapter(); }
        }));
        root.addView(bottomBar);

        setContentView(root);
    }

    private TextView btn(String text, View.OnClickListener l) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(EYE_FG[eyeMode]);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(14), dp(7), dp(14), dp(7));
        t.setBackgroundColor(0x33FFFFFF);
        t.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(dp(3), 0, dp(3), 0);
        t.setLayoutParams(lp);
        return t;
    }

    private void applyEye() {
        root.setBackgroundColor(EYE_BG[eyeMode]);
        tvTitle.setTextColor(EYE_FG[eyeMode]);
        tvChapter.setTextColor(EYE_FG[eyeMode]);
        tvBody.setTextColor(EYE_FG[eyeMode]);
    }

    // ---------------------------------------------------------------- 章节
    private void loadChapter(final int no, final boolean smooth) {
        final int target = no;
        new Thread(new Runnable() {
            @Override public void run() {
                final BookStore.Chapter ch = BookStore.chapter(BookReaderActivity.this, bookKey, target);
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        if (ch == null) {
                            tvBody.setText("本章加载失败");
                            return;
                        }
                        curChapter = target;
                        tvChapter.setText(ch.title + "　（" + curChapter + "/" + book.chapterCount + "）");
                        tvBody.setText(ch.body);
                        if (smooth) scroll.smoothScrollTo(0, 0);
                        else scroll.scrollTo(0, 0);
                        getSharedPreferences(PREF, MODE_PRIVATE).edit()
                                .putInt(bookKey + "_ch", curChapter).apply();
                    }
                });
            }
        }).start();
    }

    private void nextChapter() {
        if (curChapter >= book.chapterCount) {
            android.widget.Toast.makeText(this, "已是最后一回", android.widget.Toast.LENGTH_SHORT).show();
            return;
        }
        loadChapter(curChapter + 1, true);
    }

    private void prevChapter() {
        if (curChapter <= 1) {
            android.widget.Toast.makeText(this, "已是第一回", android.widget.Toast.LENGTH_SHORT).show();
            return;
        }
        loadChapter(curChapter - 1, true);
    }

    // ---------------------------------------------------------------- 目录
    private void showCatalog() {
        final FrameLayout wrap = new FrameLayout(this);
        wrap.setBackgroundColor(0xEE111318);

        final LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);

        TextView head = new TextView(this);
        head.setText(bookName + "　全 " + book.chapterCount + " 回");
        head.setTextColor(0xFFFFFFFF);
        head.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        head.setPadding(dp(16), dp(14), dp(16), dp(10));
        box.addView(head);

        ScrollView sc = new ScrollView(this);
        LinearLayout items = new LinearLayout(this);
        items.setOrientation(LinearLayout.VERTICAL);
        items.setPadding(dp(10), 0, dp(10), dp(20));
        sc.addView(items, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        box.addView(sc, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        TextView close = new TextView(this);
        close.setText("关闭");
        close.setTextColor(0xFFFB7299);
        close.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15);
        close.setGravity(Gravity.CENTER);
        close.setPadding(dp(16), dp(12), dp(16), dp(16));
        close.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { wrap.removeAllViews(); }
        });
        box.addView(close);

        wrap.addView(box, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        final android.app.Dialog dlg = new android.app.Dialog(this);
        dlg.setContentView(wrap);
        dlg.setCanceledOnTouchOutside(true);
        dlg.show();

        // 目录条目：直接用索引里的标题，无需加载正文
        for (int i = 1; i <= book.chapterCount; i++) {
            final int no = i;
            TextView t = new TextView(this);
            t.setText(no + ". " + book.chapterTitle(no));
            t.setTextColor(no == curChapter ? 0xFFFB7299 : 0xFFD8DEE6);
            t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13.5f);
            t.setPadding(dp(12), dp(10), dp(12), dp(10));
            t.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    try { dlg.dismiss(); } catch (Throwable ignore) { }
                    loadChapter(no, true);
                }
            });
            items.addView(t);
        }
    }

    private int dp(float v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }
}
