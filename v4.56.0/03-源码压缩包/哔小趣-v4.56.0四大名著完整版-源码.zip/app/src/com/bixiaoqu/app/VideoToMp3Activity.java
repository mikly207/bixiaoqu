package com.bixiaoqu.app;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.text.TextUtils;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * 【v4.55】视频转 MP3：选任意本地视频 → 提取音轨 → LAME 编码为 MP3 → 存入留声机曲库。
 * 复用已有的 AudioConverter.decodeToMp3（MediaExtractor + MediaCodec + jump3r/LAME）。
 * 输出放在应用外部私有目录，转换完成后由 MusicActivity 直接加入播放列表并播放。
 */
public class VideoToMp3Activity extends Activity {
    static final int PICK_VIDEO = 71;
    /** 转换结果桥接：MusicActivity.onActivityResult 读取后清空 */
    static String lastOutputPath;
    static String lastTitle;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        MainActivity.applyTheme(this);
        TextView tv = new TextView(this);
        tv.setText("请选择要转换的视频…");
        tv.setTextColor(MainActivity.C_FG);
        tv.setTextSize(15);
        tv.setPadding(24, 40, 24, 24);
        setContentView(tv);
        Intent it = new Intent(Intent.ACTION_GET_CONTENT);
        it.setType("video/*");
        it.addCategory(Intent.CATEGORY_OPENABLE);
        try { startActivityForResult(Intent.createChooser(it, "选择视频"), PICK_VIDEO); }
        catch (Throwable e) { Toast.makeText(this, "没有可用的文件选择器", Toast.LENGTH_SHORT).show(); finish(); }
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != PICK_VIDEO || res != RESULT_OK || data == null || data.getData() == null) {
            finish(); return;
        }
        Uri uri = data.getData();
        final String name = displayName(uri);
        final ProgressDialog pd = new ProgressDialog(this);
        pd.setMessage("正在提取音频并转为 MP3…");
        pd.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
        pd.setMax(100);
        pd.setCancelable(false);
        pd.show();

        new Thread(new Runnable() { @Override public void run() {
            try {
                File dir = new File(getExternalFilesDir("music"), "video2mp3");
                if (!dir.exists()) dir.mkdirs();
                String base = name.replaceAll("[\\/:*?\"<>|]", "_");
                if (base.length() > 40) base = base.substring(0, 40);
                File tmpVideo = new File(dir, "src_" + System.currentTimeMillis() + ".bin");
                copy(uri, tmpVideo);
                File out = new File(dir, base + ".mp3");
                AudioConverter.decodeToMp3(tmpVideo.getAbsolutePath(), out.getAbsolutePath(),
                        192, new AudioConverter.Progress() {
                            @Override public void onProgress(final double r) {
                                runOnUiThread(new Runnable() { @Override public void run() {
                                    pd.setProgress((int) (r * 100));
                                }});
                            }
                        });
                tmpVideo.delete();
                lastOutputPath = out.getAbsolutePath();
                lastTitle = base;
                runOnUiThread(new Runnable() { @Override public void run() {
                    try { pd.dismiss(); } catch (Throwable ignore) {}
                    Toast.makeText(VideoToMp3Activity.this, "转换完成，已加入留声机", Toast.LENGTH_SHORT).show();
                    setResult(RESULT_OK);
                    finish();
                }});
            } catch (final Throwable e) {
                runOnUiThread(new Runnable() { @Override public void run() {
                    try { pd.dismiss(); } catch (Throwable ignore) {}
                    Toast.makeText(VideoToMp3Activity.this,
                            "转换失败：" + e.getMessage(), Toast.LENGTH_LONG).show();
                    finish();
                }});
            }
        }}).start();
    }

    void copy(Uri uri, File dst) throws Exception {
        InputStream is = getContentResolver().openInputStream(uri);
        if (is == null) throw new Exception("无法读取该视频");
        OutputStream os = new FileOutputStream(dst);
        byte[] buf = new byte[64 * 1024];
        int n;
        while ((n = is.read(buf)) > 0) os.write(buf, 0, n);
        os.flush(); os.close(); is.close();
    }

    String displayName(Uri uri) {
        String n = null;
        try {
            Cursor c = getContentResolver().query(uri, null, null, null, null);
            if (c != null && c.moveToFirst()) {
                int i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (i >= 0) n = c.getString(i);
                c.close();
            }
        } catch (Throwable ignore) {}
        if (TextUtils.isEmpty(n)) {
            String s = uri.toString();
            n = s.substring(s.lastIndexOf('/') + 1);
        }
        int dot = n.lastIndexOf('.');
        if (dot > 0) n = n.substring(0, dot);
        return n.isEmpty() ? "视频音乐" : n;
    }
}
