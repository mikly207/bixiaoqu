package com.bixiaoqu.app;

import android.content.Context;
import android.graphics.SurfaceTexture;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.view.Surface;
import android.view.TextureView;
import android.view.View;
import android.widget.FrameLayout;

/**
 * 轻量视频显示控件（TextureView + MediaPlayer）。
 *
 * 【为什么不用系统 VideoView】
 *  1) VideoView 内部是 SurfaceView —— 它位于独立图层，父容器做 translationY/scale 时
 *     画面**不会跟随**动画，无法实现抖音式的「跟手上下滑翻页」。
 *  2) TextureView 把画面画在普通 View 层级里，可以自由做位移 / 缩放 / 淡入淡出，
 *     切视频时还能用封面做无缝过渡，不闪黑屏。
 *  3) 附带收益：setDataSource 的网络建连放到子线程，主线程不再被 CDN 握手阻塞，
 *     这是「滑动切换卡顿」的一个隐形大头。
 *
 * 【接口约定】
 *  对外方法刻意与 VideoView 保持一致（setVideoPath / start / pause / seekTo /
 *  getCurrentPosition / getDuration / isPlaying / stopPlayback），PlayActivity
 *  里的既有播放逻辑可以平滑迁移，无需成片改写。
 */
public class TxVideoView extends FrameLayout implements TextureView.SurfaceTextureListener {

    final TextureView tx;
    MediaPlayer mp;
    Surface surface;
    String pendingPath;
    boolean prepared = false;
    /** 【v4.9】是否已渲染过至少一帧（TextureView 回调置位） */
    boolean firstFrame = false;
    /** 用户主动调用过 start()（或在未就绪时请求播放）→ 就绪后自动开播 */
    boolean startWhenReady = false;
    int videoW = 0, videoH = 0;
    MediaPlayer.OnPreparedListener onPrepared;
    MediaPlayer.OnErrorListener onError;
    final Handler ui = new Handler(Looper.getMainLooper());

    public TxVideoView(Context c) {
        super(c);
        setBackgroundColor(0xFF000000);
        tx = new TextureView(c);
        tx.setLayoutParams(new FrameLayout.LayoutParams(
                LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT));
        addView(tx);
        tx.setSurfaceTextureListener(this);
    }

    // ------------------------------------------------------------ 对外接口（与 VideoView 对齐）

    public void setVideoPath(String path) {
        if (path == null || path.isEmpty()) return;
        releasePlayer();
        pendingPath = path;
        prepared = false;
        firstFrame = false;   // 【v4.9】换了视频 → 首帧标志重置
        startWhenReady = true;     // 与 VideoView 一致：设路径后自动播放
        // 【v4.9.1 修复黑屏】必须等 Surface 真正就绪再 prepare。
        // MediaPlayer 在没有 Surface 的情况下会「正常播放音频、不渲染画面」，
        // 表现就是用户看到的「只有声音、一片黑」。这是本次黑屏的根因。
        ensureSurfaceAndOpen(0);
    }

    /**
     * 确保 Surface 就绪后再建流。
     * TextureView 的 SurfaceTexture 可能还没 available（甚至 occasionally 不回调），
     * 这里主动从 tx.getSurfaceTexture() 取一次，并做有限次延迟重试。
     */
    void ensureSurfaceAndOpen(final int attempt) {
        if (pendingPath == null) return;
        if (surface == null && tx.isAvailable()) {
            SurfaceTexture st = tx.getSurfaceTexture();
            if (st != null) {
                applyBufferSize(st, getWidth(), getHeight());
                try { surface = new Surface(st); } catch (Throwable ignore) { }
            }
        }
        if (surface != null) {
            openPlayer();
            return;
        }
        // 有限次重试（400ms × 5 ≈ 2s），最后一次仍无 Surface 也强行建流，
        // 至少保证音频可用，并把异常暴露成「无画面」而不是卡死等待。
        if (attempt >= 5) { openPlayer(); return; }
        ui.postDelayed(new Runnable() { @Override public void run() {
            if (mp == null || !prepared) ensureSurfaceAndOpen(attempt + 1);
        } }, 400);
    }

    /** TextureView 的缓冲区尺寸必须与 Surface 尺寸一致，否则部分机型渲染为全黑 */
    void applyBufferSize(SurfaceTexture st, int w, int h) {
        if (st == null) return;
        int bw = w > 0 ? w : getWidth();
        int bh = h > 0 ? h : getHeight();
        if (bw <= 0 || bh <= 0) return;
        try { st.setDefaultBufferSize(bw, bh); } catch (Throwable ignore) { }
    }

    public void start() {
        startWhenReady = true;
        MediaPlayer p = mp;
        if (p != null && prepared) {
            try { p.start(); } catch (Throwable ignore) { }
        }
    }

    public void pause() {
        MediaPlayer p = mp;
        if (p != null) {
            try { if (p.isPlaying()) p.pause(); } catch (Throwable ignore) { }
        }
    }

    public void seekTo(int ms) {
        MediaPlayer p = mp;
        if (p != null) {
            try { p.seekTo(ms); } catch (Throwable ignore) { }
        }
    }

    public int getCurrentPosition() {
        MediaPlayer p = mp;
        if (p == null) return 0;
        try { return p.getCurrentPosition(); } catch (Throwable e) { return 0; }
    }

    public int getDuration() {
        MediaPlayer p = mp;
        if (p == null || !prepared) return 0;
        try { return p.getDuration(); } catch (Throwable e) { return 0; }
    }

    public boolean isPlaying() {
        MediaPlayer p = mp;
        if (p == null) return false;
        try { return p.isPlaying(); } catch (Throwable e) { return false; }
    }

    /** 彻底释放（切视频 / 退出页面时用） */
    public void stopPlayback() {
        pendingPath = null;
        releasePlayer();
    }

    public void setOnPreparedListener(MediaPlayer.OnPreparedListener l) {
        onPrepared = l;
    }

    public void setOnErrorListener(MediaPlayer.OnErrorListener l) {
        onError = l;
    }

    // ------------------------------------------------------------ 内部

    void releasePlayer() {
        MediaPlayer p = mp;
        mp = null;
        prepared = false;
        if (p != null) {
            try { p.reset(); } catch (Throwable ignore) { }
            try { p.release(); } catch (Throwable ignore) { }
        }
    }

    /**
     * 建流。MediaPlayer 必须在主线程创建（回调绑定主线程 Looper），
     * 但 setDataSource 对 http 会同步做 DNS/TCP 握手 —— 放子线程，避免卡住 UI 帧。
     */
    void openPlayer() {
        final String path = pendingPath;
        if (path == null) return;
        final MediaPlayer p = new MediaPlayer();
        mp = p;
        try {
            p.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MOVIE).build());
        } catch (Throwable ignore) { }
        p.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override public void onPrepared(MediaPlayer m) {
                prepared = true;
                if (startWhenReady) {
                    try { m.start(); } catch (Throwable ignore) { }
                }
                MediaPlayer.OnPreparedListener l = onPrepared;
                if (l != null) l.onPrepared(m);
            }
        });
        p.setOnErrorListener(new MediaPlayer.OnErrorListener() {
            @Override public boolean onError(MediaPlayer m, int what, int extra) {
                prepared = false;
                MediaPlayer.OnErrorListener l = onError;
                if (l != null) return l.onError(m, what, extra);
                return true;   // 自己处理，不弹系统错误框
            }
        });
        p.setOnVideoSizeChangedListener(new MediaPlayer.OnVideoSizeChangedListener() {
            @Override public void onVideoSizeChanged(MediaPlayer m, int w, int h) {
                videoW = w;
                videoH = h;
                requestLayout();
            }
        });
        Surface s = surface;
        if (s != null) {
            // 缓冲区尺寸必须匹配，否则部分机型（尤其高分辨率屏）渲染成纯黑
            SurfaceTexture st = tx.getSurfaceTexture();
            if (st != null) applyBufferSize(st, getWidth(), getHeight());
            try { p.setSurface(s); } catch (Throwable ignore) { }
        }
        new Thread(new Runnable() { @Override public void run() {
            try {
                p.setDataSource(getContext(), Uri.parse(path));
                p.prepareAsync();
            } catch (final Throwable e) {
                ui.post(new Runnable() { @Override public void run() {
                    MediaPlayer.OnErrorListener l = onError;
                    if (l != null) l.onError(p, MediaPlayer.MEDIA_ERROR_UNKNOWN, 0);
                } });
            }
        } }, "tx-open").start();
    }

    // ------------------------------------------------------------ SurfaceTexture 回调

    @Override public void onSurfaceTextureAvailable(SurfaceTexture st, int w, int h) {
        applyBufferSize(st, w, h);
        if (surface != null) {
            try { surface.release(); } catch (Throwable ignore) { }
            surface = null;
        }
        try { surface = new Surface(st); } catch (Throwable ignore) { }
        MediaPlayer p = mp;
        if (p != null && surface != null) {
            try { p.setSurface(surface); } catch (Throwable ignore) { }
        } else if (p == null && pendingPath != null) {
            // Surface 迟到了：之前因无 Surface 没建流，这里补上
            ensureSurfaceAndOpen(0);
        }
    }

    @Override public void onSurfaceTextureSizeChanged(SurfaceTexture st, int w, int h) {
        applyBufferSize(st, w, h);
        // 尺寸变化后部分机型会丢渲染目标，重新绑一次最保险
        MediaPlayer p = mp;
        if (p != null && surface != null) {
            try { p.setSurface(surface); } catch (Throwable ignore) { }
        }
    }

    @Override public boolean onSurfaceTextureDestroyed(SurfaceTexture st) {
        MediaPlayer p = mp;
        if (p != null) {
            try { p.setSurface(null); } catch (Throwable ignore) { }
        }
        if (surface != null) {
            try { surface.release(); } catch (Throwable ignore) { }
            surface = null;
        }
        return true;
    }

    @Override public void onSurfaceTextureUpdated(SurfaceTexture st) {
        // 【v4.9】TextureView 每渲染一帧都会回调这里 —— 这是「画面真的出来了」的最可靠信号。
        // 比轮询 getCurrentPosition()>0 准得多：续播时 getCurrentPosition 会直接返回
        // seek 目标值（还没出帧就已经 >0），用进度判断会误判。
        firstFrame = true;
    }

    /** 【v4.9】是否已经渲染过至少一帧 */
    public boolean hasRenderedFrame() {
        return firstFrame;
    }

    /**
     * 【v4.9.1】重新绑定 Surface。
     * 有些机型在 prepare 完成后会丢掉渲染目标（表现为有声音、画面全黑），
     * 重新 setSurface 一次通常就能恢复。
     */
    public void rebindSurface() {
        try {
            SurfaceTexture st = tx.getSurfaceTexture();
            if (st == null) return;
            applyBufferSize(st, getWidth(), getHeight());
            if (surface != null) {
                try { surface.release(); } catch (Throwable ignore) { }
                surface = null;
            }
            surface = new Surface(st);
            MediaPlayer p = mp;
            if (p != null) {
                try { p.setSurface(surface); } catch (Throwable ignore) { }
            }
        } catch (Throwable ignore) { }
    }

    // ------------------------------------------------------------ 尺寸：与 VideoView 一致地保持宽高比

    /**
     * 【v4.9.1】布局兜底：个别机型 TextureView 的 onSurfaceTextureAvailable 会漏回调，
     * 导致 surface 永远为 null → 只有声音没有画面。这里在每次布局后补建一次。
     */
    @Override protected void onLayout(boolean changed, int l, int t, int r, int b) {
        super.onLayout(changed, l, t, r, b);
        if (surface == null && tx.isAvailable()) {
            SurfaceTexture st = tx.getSurfaceTexture();
            if (st != null) {
                applyBufferSize(st, r - l, b - t);
                try { surface = new Surface(st); } catch (Throwable ignore) { }
                MediaPlayer p = mp;
                if (p != null && surface != null) {
                    try { p.setSurface(surface); } catch (Throwable ignore) { }
                }
            }
        }
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int width = getDefaultSize(videoW, widthMeasureSpec);
        int height = getDefaultSize(videoH, heightMeasureSpec);
        if (videoW > 0 && videoH > 0) {
            if (width > 0 && height > 0) {
                int wSpecSize = MeasureSpec.getSize(widthMeasureSpec);
                int hSpecSize = MeasureSpec.getSize(heightMeasureSpec);
                width = height * videoW / videoH;
                if (width > wSpecSize) {
                    width = wSpecSize;
                    height = width * videoH / videoW;
                } else if (height > hSpecSize) {
                    height = hSpecSize;
                    width = height * videoW / videoH;
                }
            }
        }
        setMeasuredDimension(width, height);
    }
}
