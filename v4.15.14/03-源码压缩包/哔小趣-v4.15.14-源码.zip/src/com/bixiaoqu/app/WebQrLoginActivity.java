package com.bixiaoqu.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/**
 * 【v4.15.14】官方网页套用 + 本地重绘二维码。
 *
 * 为什么这么做：同一台手机上，浏览器打开 B 站官网能正常弹出二维码，而 App 用自己的
 * HTTP 栈请求接口始终拿不到 —— 问题在 App 的网络层，不在网络本身。
 *
 * 所以：用桌面 UA 加载 passport 官方登录页（页面自带二维码、自己轮询），
 * 从 DOM 里取出二维码承载的链接，再用 App 内置的 ZXing 重新画一张高清二维码显示。
 * 这样既有官方页面的会话与轮询（扫码确认由它完成），屏幕上的码又足够清晰好扫。
 * 登录成功后 Cookie 落在 WebView，直接整套读出。
 */
public class WebQrLoginActivity extends Activity {

    static final String DESKTOP_UA =
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                    + "(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36";

    static final String LOGIN_URL = "https://passport.bilibili.com/login";

    /** 取二维码承载的登录链接（页面把 URL 放在 img.title 上） */
    static final String JS_URL =
            "(function(){var i=document.querySelector('.login-scan__qrcode img');"
            + "if(!i){return '';}"
            + "var t=i.getAttribute('title')||'';"
            + "if(!t&&i.parentNode&&i.parentNode.getAttribute){t=i.parentNode.getAttribute('title')||'';}"
            + "if(!t){var p=i.closest?i.closest('[title]'):null;if(p){t=p.getAttribute('title')||'';}}"
            + "return (t&&t.indexOf('http')===0)?t:'';})()";

    WebView wv;
    ImageView qrView;
    LinearLayout overlay;
    TextView tip;
    Button againBtn;
    Handler ui = new Handler(Looper.getMainLooper());

    boolean done = false;
    int injectTries = 0;
    int cookieTries = 0;
    String lastUrl = "";

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        wv = new WebView(this);
        WebSettings s = wv.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setUserAgentString(DESKTOP_UA);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setUseWideViewPort(false);
        s.setLoadWithOverviewMode(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        CookieManager.getInstance().setAcceptCookie(true);
        if (android.os.Build.VERSION.SDK_INT >= 21) {
            CookieManager.getInstance().setAcceptThirdPartyCookies(wv, true);
        }
        wv.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return !(url.startsWith("http://") || url.startsWith("https://"));
            }
            @Override
            public void onPageFinished(WebView view, String url) {
                injectTries = 0;
                grab();
                checkCookie();
            }
        });
        wv.loadUrl(LOGIN_URL);
        root.addView(wv, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // ---- 原生遮罩：大二维码 + 提示 + 按钮 ----
        overlay = new LinearLayout(this);
        overlay.setOrientation(LinearLayout.VERTICAL);
        overlay.setGravity(Gravity.CENTER_HORIZONTAL);
        overlay.setBackgroundColor(0xFF0F0F12);

        TextView head = new TextView(this);
        head.setText("扫码登录 B 站");
        head.setTextColor(Color.WHITE);
        head.setTextSize(17);
        head.setGravity(Gravity.CENTER);
        head.setPadding(0, 46, 0, 6);
        overlay.addView(head);

        tip = new TextView(this);
        tip.setText("正在打开 B 站官方扫码页…");
        tip.setTextColor(MainActivity.C_ACC);
        tip.setTextSize(12);
        tip.setGravity(Gravity.CENTER);
        tip.setPadding(24, 0, 24, 16);
        overlay.addView(tip);

        qrView = new ImageView(this);
        qrView.setAdjustViewBounds(true);
        qrView.setScaleType(ImageView.ScaleType.FIT_CENTER);
        overlay.addView(qrView, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        TextView hint = new TextView(this);
        hint.setText("请用 B 站 App 扫码\n扫码后在手机上点「确认登录」，App 会自动完成");
        hint.setTextColor(0xFFE8E8EA);
        hint.setTextSize(14);
        hint.setGravity(Gravity.CENTER);
        hint.setLineSpacing(6, 1f);
        hint.setPadding(24, 12, 24, 6);
        overlay.addView(hint);

        againBtn = new Button(this);
        againBtn.setText("换一张码");
        againBtn.setTextColor(Color.WHITE);
        againBtn.setBackgroundColor(0xFF2B2B2B);
        againBtn.setAllCaps(false);
        againBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { reload(); }
        });
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        bp.setMargins(0, 10, 0, 4);
        overlay.addView(againBtn, bp);

        Button plain = new Button(this);
        plain.setText("显示官方页面（可改用短信登录）");
        plain.setTextColor(MainActivity.C_ACC);
        plain.setBackgroundColor(Color.TRANSPARENT);
        plain.setAllCaps(false);
        plain.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                overlay.setVisibility(View.GONE);
                wv.setVisibility(View.VISIBLE);
            }
        });
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        pp.setMargins(0, 0, 0, 34);
        overlay.addView(plain, pp);

        root.addView(overlay, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        setContentView(root);
        ui.postDelayed(new Runnable() { @Override public void run() { checkCookie(); } }, 800);
    }

    /** 页面异步渲染二维码，前 20 秒每 600ms 取一次 */
    void grab() {
        if (done) return;
        wv.evaluateJavascript(JS_URL, new android.webkit.ValueCallback<String>() {
            @Override public void onReceiveValue(String v) {
                String url = unwrap(v);
                if (url != null && url.startsWith("http")) {
                    if (!url.equals(lastUrl)) {
                        lastUrl = url;
                        render(url);
                    }
                    tip.setText("请用 B 站 App 扫码，3 分钟内有效");
                    return;
                }
                if (injectTries++ < 34) {
                    ui.postDelayed(new Runnable() { @Override public void run() { grab(); } }, 600);
                } else {
                    tip.setText("未能取到二维码，已切回官方页面，可改用短信登录");
                    overlay.setVisibility(View.GONE);
                }
            }
        });
    }

    void render(String url) {
        Bitmap bmp = LoginActivity.makeQr(url, 900);
        if (bmp == null) { tip.setText("二维码渲染失败，请点「换一张码」"); return; }
        qrView.setImageBitmap(bmp);
        againBtn.setEnabled(true);
    }

    void reload() {
        done = false;
        injectTries = 0;
        lastUrl = "";
        tip.setText("正在刷新二维码…");
        qrView.setImageBitmap(null);
        wv.loadUrl(LOGIN_URL);
    }

    /** 每 800ms 查一次 Cookie；出现 SESSDATA 即完成（整套 Cookie 一起取） */
    void checkCookie() {
        if (done) return;
        if (cookieTries++ > 600) return;
        try {
            String best = "";
            String[] domains = {"https://www.bilibili.com/", "https://passport.bilibili.com/",
                    "https://account.bilibili.com/", "https://.bilibili.com/"};
            for (String d : domains) {
                try {
                    String one = CookieManager.getInstance().getCookie(d);
                    if (one != null && one.length() > best.length()) best = one;
                } catch (Throwable ignore) { }
            }
            if (best.contains("SESSDATA=")) {
                String sess = cookieVal(best, "SESSDATA");
                if (!sess.isEmpty()) { finishLogin(best, sess); return; }
            }
        } catch (Throwable ignore) { }
        ui.postDelayed(new Runnable() { @Override public void run() { checkCookie(); } }, 800);
    }

    void finishLogin(final String cookieHeader, final String sessdata) {
        done = true;
        final String jct = cookieVal(cookieHeader, "bili_jct");
        final String uid = cookieVal(cookieHeader, "DedeUserID");
        BiliApi.addCookie(cookieHeader);
        BiliApi.setLoginCookie(sessdata, jct, uid);
        String full = BiliApi.exportLoginCookie();
        SharedPreferences sp = getSharedPreferences("bili_login", MODE_PRIVATE);
        sp.edit().putString("SESSDATA", sessdata)
                .putString("bili_jct", jct)
                .putString("DedeUserID", uid)
                .putString("full_cookie", full.isEmpty() ? cookieHeader : full)
                .putLong("login_time", System.currentTimeMillis())
                .apply();
        tip.setText("登录成功，正在同步账号信息…");
        new Thread(new Runnable() { @Override public void run() {
            String name = "";
            for (int i = 0; i < 3; i++) {
                try {
                    org.json.JSONObject nav = BiliApi.navInfo();
                    name = nav.optString("uname", "");
                    if (!name.isEmpty()) break;
                } catch (Throwable ignore) { }
                try { Thread.sleep(1000); } catch (InterruptedException ignore) { }
            }
            final String fName = name;
            runOnUiThread(new Runnable() { @Override public void run() {
                Toast.makeText(WebQrLoginActivity.this,
                        "登录成功 ✓" + (fName.isEmpty() ? "" : " " + fName), Toast.LENGTH_SHORT).show();
                finish();
            } });
        } }, "bxq-webqr-verify").start();
    }

    /** evaluateJavascript 回传的是 JSON 编码字符串，先还原成原文 */
    static String unwrap(String v) {
        if (v == null || v.equals("null")) return "";
        try {
            return new org.json.JSONArray("[" + v + "]").getString(0);
        } catch (Throwable ignore) {
            return v;
        }
    }

    static String cookieVal(String header, String key) {
        if (header == null) return "";
        for (String pair : header.split(";")) {
            pair = pair.trim();
            int eq = pair.indexOf('=');
            if (eq > 0 && pair.substring(0, eq).equals(key)) return pair.substring(eq + 1);
        }
        return "";
    }

    @Override
    public void onBackPressed() { finish(); }

    @Override
    protected void onDestroy() {
        done = true;
        ui.removeCallbacksAndMessages(null);
        if (wv != null) {
            try { wv.stopLoading(); wv.destroy(); } catch (Throwable ignore) { }
            wv = null;
        }
        super.onDestroy();
    }
}
