#!/usr/bin/env node
/**
 * 哔小趣 · 作者控制台（本地图形化工具）
 * ============================================================================
 *
 * 零第三方依赖，只用 Node 内置模块。双击启动器即可运行。
 *
 * 界面包含：
 *   · 服务状态：地址、管理员令牌、运行状态、在线设备数
 *   · 一键出包：点一下自动生成密钥 → 写入 App 内置配置 → 编译平板/手机双 APK
 *   · 核销开通：粘贴用户设备 ID → 点「立即开通」→ 用户约 3 秒后可登录
 *   · 设备列表：查看所有用户设备及其开通状态
 *   · 实时日志：出包与服务的输出实时显示
 *
 * 端口：控制台 8789，服务端 8788（可用 --port 调整）
 */

'use strict';

const http = require('http');
const fs = require('fs');
const path = require('path');
const os = require('os');
const { spawn } = require('child_process');

const DIR = __dirname;
const SRC_CANDIDATES = [
  path.join(DIR, '..'),                 // 源码包：捐赠校验服务/ 的上一级
  path.join(DIR, '..', '..'),
  path.join(DIR, '..', '..', '..'),
];
let SRC = '';
for (const c of SRC_CANDIDATES) {
  if (fs.existsSync(path.join(c, 'app', 'build.sh'))) { SRC = path.resolve(c); break; }
}

const CONSOLE_PORT = parseInt(process.env.CONSOLE_PORT || '8789', 10);
const SERVER_PORT = parseInt(process.env.SERVER_PORT || '8788', 10);
const ADMIN_TOKEN = process.env.ADMIN_TOKEN || '';

/* ------------------------------------------------------------------ 状态 */

const state = {
  serverProc: null,
  serverUrl: '',
  adminToken: ADMIN_TOKEN,
  building: false,
  logs: [],
  startedAt: Date.now(),
};

function log(kind, text) {
  const line = { t: Date.now(), kind, text: String(text) };
  state.logs.push(line);
  if (state.logs.length > 800) state.logs.splice(0, state.logs.length - 800);
  const stamp = new Date().toLocaleTimeString('zh-CN', { hour12: false });
  const tag = kind === 'err' ? '\x1b[31m[错误]\x1b[0m'
    : kind === 'ok' ? '\x1b[32m[完成]\x1b[0m'
    : kind === 'cmd' ? '\x1b[36m[执行]\x1b[0m' : '\x1b[90m' + stamp + '\x1b[0m';
  console.log(tag + ' ' + line.text);
}

function lanIp() {
  const ifs = os.networkInterfaces();
  for (const name of Object.keys(ifs)) {
    for (const i of ifs[name] || []) {
      if (i.family === 'IPv4' && !i.internal) return i.address;
    }
  }
  return '127.0.0.1';
}

/* ------------------------------------------------------------------ 服务端 */

function startServer() {
  if (state.serverProc) return;
  const js = path.join(DIR, 'server.js');
  if (!fs.existsSync(js)) { log('err', '找不到 server.js'); return; }
  state.serverUrl = 'http://127.0.0.1:' + SERVER_PORT;
  state.serverProc = spawn(process.execPath, [js], {
    cwd: DIR,
    env: Object.assign({}, process.env, {
      PORT: String(SERVER_PORT),
      ADMIN_TOKEN: state.adminToken || undefined,
      PAY_SECRET: process.env.PAY_SECRET || state.adminToken || undefined,
    }),
  });
  state.serverProc.stdout.on('data', (d) => {
    String(d).split('\n').forEach((l) => { if (l.trim()) log('srv', l); });
  });
  state.serverProc.stderr.on('data', (d) => {
    String(d).split('\n').forEach((l) => { if (l.trim()) log('err', l); });
  });
  state.serverProc.on('exit', (code) => {
    log('err', '服务端已退出（code=' + code + '）');
    state.serverProc = null;
  });
  log('ok', '服务端已启动：' + state.serverUrl);
  // 从服务端日志里抓管理员令牌
  setTimeout(readTokenFromDb, 600);
}

function readTokenFromDb() {
  try {
    const db = JSON.parse(fs.readFileSync(path.join(DIR, 'data.json'), 'utf8'));
    if (db.admin_token && !state.adminToken) {
      state.adminToken = db.admin_token;
      log('ok', '已读取管理员令牌：' + state.adminToken);
    }
  } catch (e) { /* 尚未生成，忽略 */ }
}

function stopServer() {
  if (!state.serverProc) return;
  try { state.serverProc.kill(); } catch (e) { }
  state.serverProc = null;
  log('ok', '服务端已停止');
}

/* ------------------------------------------------------------------ 出包 */

function runBuild(serverUrl) {
  if (state.building) { log('err', '已有出包任务在进行'); return; }
  if (!SRC) { log('err', '找不到 App 源码目录（需要 app/ 与 app_phone/）'); return; }
  state.building = true;
  const url = (serverUrl || 'http://' + lanIp() + ':' + SERVER_PORT).replace(/\/+$/, '');
  log('cmd', '开始出包，服务地址：' + url);

  const script = path.join(DIR, '出包.sh');
  const args = ['-e', `
set -e
D="${DIR.replace(/\\/g, '\\\\')}"
SRC="${SRC.replace(/\\/g, '\\\\')}"
URL="${url.replace(/\\/g, '\\\\')}"
cd "$D"
# 1) 密钥
KEYDIR="$D/keys"; mkdir -p "$KEYDIR"
if [ ! -f "$KEYDIR/donate_priv.pem" ]; then
  node -e "
const {generateKeyPairSync}=require('crypto'),fs=require('fs');
const {publicKey,privateKey}=generateKeyPairSync('rsa',{modulusLength:2048,
  publicKeyEncoding:{type:'spki',format:'der'},privateKeyEncoding:{type:'pkcs8',format:'pem'}});
fs.writeFileSync('$KEYDIR/donate_priv.pem',privateKey);
fs.writeFileSync('$KEYDIR/donate_pub.der',publicKey);"
  echo "已生成密钥 keys/donate_priv.pem"
else
  echo "复用已有密钥"
fi
# 2) 写入内置配置
PUB=$(node -e "console.log(require('fs').readFileSync('$KEYDIR/donate_pub.der').toString('base64'))")
for T in app app_phone; do
  F="$SRC/$T/src/com/bixiaoqu/app/DonateConfig.java"
  [ -f "$F" ] || continue
  node -e "
const fs=require('fs');const f='$F';let s=fs.readFileSync(f,'utf8');
s=s.replace(/(public static final String SERVER_URL = \\")[^\\"]*(\\")/, '\\$1$URL\\$2');
s=s.replace(/(public static final String PUB_KEY_B64 = \\")[^\\"]*(\\")/, '\\$1$PUB\\$2');
fs.writeFileSync(f,s);"
  echo "$T 已写入服务地址与公钥"
done
# 3) 编译
for T in app app_phone; do
  [ -f "$SRC/$T/build.sh" ] || continue
  ( cd "$SRC/$T" && bash build.sh )
  echo "$T 构建完成"
done
echo "全部完成"
`];

  const sh = spawn('bash', args, { cwd: DIR });
  sh.stdout.on('data', (d) => {
    String(d).split('\n').forEach((l) => { if (l.trim()) log('build', l); });
  });
  sh.stderr.on('data', (d) => {
    String(d).split('\n').forEach((l) => { if (l.trim()) log('err', l); });
  });
  sh.on('exit', (code) => {
    state.building = false;
    if (code === 0) {
      log('ok', '出包完成！APK 在：' + path.join(SRC, '..'));
    } else {
      log('err', '出包失败（code=' + code + '）');
    }
  });
}

/* ------------------------------------------------------------------ HTTP */

function json(res, code, obj) {
  const b = Buffer.from(JSON.stringify(obj), 'utf8');
  res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Content-Length': b.length, 'Cache-Control': 'no-store' });
  res.end(b);
}

function proxy(res, srvUrl, p, method, body, hdr) {
  const u = new URL(srvUrl + p);
  const opts = {
    hostname: u.hostname, port: u.port, path: u.pathname + u.search,
    method: method || 'GET', headers: Object.assign({}, hdr || {}),
  };
  const rq = http.request(opts, (rs) => {
    const chunks = [];
    rs.on('data', (c) => chunks.push(c));
    rs.on('end', () => {
      res.writeHead(rs.statusCode, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
      res.end(Buffer.concat(chunks));
    });
  });
  rq.on('error', (e) => json(res, 502, { code: 502, msg: '无法连接服务端：' + e.message }));
  if (body) rq.write(body);
  rq.end();
}

const server = http.createServer((req, res) => {
  const u = new URL(req.url, 'http://localhost');
  const p = u.pathname;

  if (p === '/' || p === '/index.html') {
    const f = path.join(DIR, '控制台.html');
    if (!fs.existsSync(f)) { json(res, 404, { code: 404, msg: '缺少 控制台.html' }); return; }
    const b = fs.readFileSync(f);
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Content-Length': b.length, 'Cache-Control': 'no-store' });
    res.end(b);
    return;
  }

  // 控制台自身接口
  if (p === '/api/state') {
    json(res, 200, {
      code: 0,
      serverUrl: state.serverUrl,
      lanUrl: 'http://' + lanIp() + ':' + SERVER_PORT,
      adminToken: state.adminToken,
      running: !!state.serverProc,
      building: state.building,
      src: SRC,
      apkDir: SRC ? path.join(SRC, '..') : '',
      uptime: Math.floor((Date.now() - state.startedAt) / 1000),
      logs: state.logs.slice(-200),
    });
    return;
  }

  if (p === '/api/start' && req.method === 'POST') { startServer(); json(res, 200, { code: 0 }); return; }
  if (p === '/api/stop' && req.method === 'POST') { stopServer(); json(res, 200, { code: 0 }); return; }

  if (p === '/api/build' && req.method === 'POST') {
    let body = '';
    req.on('data', (c) => { body += c; });
    req.on('end', () => {
      let url = '';
      try { url = JSON.parse(body || '{}').url || ''; } catch (e) { }
      runBuild(url);
      json(res, 200, { code: 0 });
    });
    return;
  }

  // 透传到服务端（核销、订单、设备列表等）
  if (p.startsWith('/srv/')) {
    let body = '';
    req.on('data', (c) => { body += c; });
    req.on('end', () => {
      const rest = p.slice(4);
      const hdr = {};
      const tok = req.headers['x-admin-token'];
      if (tok) hdr['X-Admin-Token'] = tok;
      if (body) hdr['Content-Type'] = 'application/json';
      proxy(res, state.serverUrl, rest, req.method, body || null, hdr);
    });
    return;
  }

  json(res, 404, { code: 404, msg: 'not found' });
});

/* ------------------------------------------------------------------ 启动 */

if (!SRC) {
  console.log('\x1b[33m[提示]\x1b[0m 未找到 App 源码目录（需要 app/ 与 app_phone/），出包功能不可用，其余功能正常。');
} else {
  console.log('\x1b[36m[信息]\x1b[0m 已找到源码：' + SRC);
}

startServer();

server.listen(CONSOLE_PORT, () => {
  const url = 'http://127.0.0.1:' + CONSOLE_PORT;
  console.log('');
  console.log('\x1b[32m==============================================\x1b[0m');
  console.log('\x1b[32m 哔小趣 · 作者控制台\x1b[0m');
  console.log('\x1b[32m==============================================\x1b[0m');
  console.log(' 控制台地址 : ' + url);
  console.log(' 核验后台   : http://' + lanIp() + ':' + SERVER_PORT + '/admin');
  console.log(' 出包目录   : ' + (SRC ? path.join(SRC, '..') : '(未找到源码)'));
  console.log('');
  console.log(' 浏览器会自动打开；若没打开请手动访问上面的地址');
  console.log(' 关闭本窗口即停止服务');
  console.log('');

  // 自动打开浏览器
  const cmd = process.platform === 'win32' ? 'start'
    : process.platform === 'darwin' ? 'open' : 'xdg-open';
  try {
    spawn(cmd, [url], { detached: true, stdio: 'ignore' }).unref();
  } catch (e) { }
});

process.on('SIGINT', () => { stopServer(); process.exit(0); });
process.on('SIGTERM', () => { stopServer(); process.exit(0); });
