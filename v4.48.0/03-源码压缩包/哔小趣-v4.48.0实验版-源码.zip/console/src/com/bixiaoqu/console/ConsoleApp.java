package com.bixiaoqu.console;

import android.app.Application;
import android.content.Context;

/**
 * 【作者控制台】应用入口。
 * 只做两件事：持有 Context、确保密钥已生成。
 */
public class ConsoleApp extends Application {
    @Override public void onCreate() {
        super.onCreate();
        AppCtx.ctx = this;
        try { DonateServer.ensureKeys(this); } catch (Throwable ignore) { }
    }
}
