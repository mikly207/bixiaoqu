package com.bixiaoqu.console;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioAttributes;
import android.media.RingtoneManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * 【作者控制台】主界面。
 *
 * 这是给软件作者本人用的工具 App，装在作者自己的手机上：
 *   · 内嵌捐赠核验服务（监听内网 8788），主 App 连它做状态校验
 *   · 任何用户扫了付款码并点「我已支付，申请开通」→ 这里立刻弹出提示（声音 + 横幅）
 *   · 粘贴用户设备 ID → 点「立即开通」→ 用户约 3 秒后即可登录
 *   · 显示本机内网地址与公钥，供主 App 打包时内置
 */
public class ConsoleActivity extends Activity {

    static final int C_BG = 0xFF16181d, C_CARD = 0xFF1f2229, C_FG = 0xFFe8eaf0,
            C_SUB = 0xFF9aa0ab, C_ACC = 0xFFfb7299, C_OK = 0xFF5FD08A, C_WARN = 0xFFFFB020;

    DonateServer server;
    Handler handler = new Handler(Looper.getMainLooper());

    TextView statusTv, addrTv, tokenTv, pubTv, noticeTv, countTv;
    LinearLayout noticeBox, deviceBox, logBox, pendingBox;
    View noticeDot;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        AppCtx.ctx = this;
        setContentView(build());
        DonateServer.ensureKeys(this);
        server = new DonateServer();
        server.setCallback(new DonateServer.Callback() {
            @Override public void onStarted(int port, String lanIp) {
                handler.post(new Runnable() { @Override public void run() {
                    refreshStatus();
                    toast("核验服务已启动：" + lanIp + ":" + port);
                } });
            }
            @Override public void onStopped() {
                handler.post(new Runnable() { @Override public void run() {
                    refreshStatus();
                    toast("核验服务已停止");
                } });
            }
        });
        DonateServer.setNoticeListener(new DonateServer.NoticeListener() {
            @Override public void onNotice(final String title, final String text, final JSONObject order) {
                handler.post(new Runnable() { @Override public void run() {
                    onNotice(title, text, order);
                } });
            }
        });
        refreshStatus();
        handler.postDelayed(refreshTask, 1500);
    }

    final Runnable refreshTask = new Runnable() { @Override public void run() {
        if (isFinishing()) return;
        refreshStatus();
        loadDevices();
        handler.postDelayed(this, 2500);
    } };

    @Override protected void onDestroy() {
        if (server != null) server.stop();
        super.onDestroy();
    }

    int dp(float v) { return (int) (getResources().getDisplayMetrics().density * v + 0.5f); }

    GradientDrawable round(int color, float rdp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(rdp));
        return g;
    }

    // ===================== 界面 =====================

    View build() {
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(C_BG);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(16), dp(16), dp(30));
        sv.addView(root, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // ---- 标题 ----
        TextView title = new TextView(this);
        title.setText("哔小趣 · 作者控制台");
        title.setTextColor(C_FG);
        title.setTextSize(21);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        root.addView(title, lp(0, 0));

        TextView sub = new TextView(this);
        sub.setText("捐赠核验服务端 · 扫码付款即时提醒");
        sub.setTextColor(C_SUB);
        sub.setTextSize(12.5f);
        root.addView(sub, lp(0, 14));

        // ---- 提醒横幅 ----
        noticeBox = new LinearLayout(this);
        noticeBox.setOrientation(LinearLayout.VERTICAL);
        noticeBox.setPadding(dp(14), dp(12), dp(14), dp(12));
        noticeBox.setBackground(round(0xFF2A2118, 12));
        noticeBox.setVisibility(View.GONE);
        LinearLayout nrow = new LinearLayout(this);
        nrow.setGravity(Gravity.CENTER_VERTICAL);
        noticeDot = new View(this);
        noticeDot.setBackground(round(C_ACC, 8));
        LinearLayout.LayoutParams dotp = new LinearLayout.LayoutParams(dp(10), dp(10));
        dotp.rightMargin = dp(9);
        nrow.addView(noticeDot, dotp);
        noticeTv = new TextView(this);
        noticeTv.setTextColor(C_FG);
        noticeTv.setTextSize(14);
        noticeTv.setTypeface(Typeface.DEFAULT_BOLD);
        nrow.addView(noticeTv, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        noticeBox.addView(nrow, lp(0, 0));
        countTv = new TextView(this);
        countTv.setTextColor(C_SUB);
        countTv.setTextSize(12);
        countTv.setPadding(0, dp(6), 0, 0);
        noticeBox.addView(countTv, lp(0, 0));
        LinearLayout.LayoutParams nbp = lp(0, 14);
        root.addView(noticeBox, nbp);

        // ---- 待核验订单（扫码付款后自动出现在这里）----
        LinearLayout pendCard = card();
        TextView pt = new TextView(this);
        pt.setText("待核验订单（用户扫码付款后自动出现）");
        pt.setTextColor(C_FG);
        pt.setTextSize(15);
        pt.setTypeface(Typeface.DEFAULT_BOLD);
        pendCard.addView(pt, lp(0, 0));
        pendingBox = new LinearLayout(this);
        pendingBox.setOrientation(LinearLayout.VERTICAL);
        pendCard.addView(pendingBox, lp(0, 6));
        root.addView(pendCard, lp(0, 14));

        // ---- 服务状态卡 ----
        LinearLayout card = card();
        statusTv = new TextView(this);
        statusTv.setTextColor(C_FG);
        statusTv.setTextSize(15);
        card.addView(statusTv, lp(0, 0));

        addrTv = kv(card, "主 App 连接地址", "");
        tokenTv = kv(card, "管理员令牌", "");
        pubTv = kv(card, "公钥（打包时内置）", "");

        TextView btnRow = new TextView(this);
        btnRow.setText("启动服务");
        btnRow.setTextColor(Color.WHITE);
        btnRow.setTextSize(14);
        btnRow.setGravity(Gravity.CENTER);
        btnRow.setPadding(dp(10), dp(11), dp(10), dp(11));
        btnRow.setBackground(round(C_ACC, 10));
        btnRow.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (server.isRunning()) { server.stop(); } else { server.start(); }
                refreshStatus();
            }
        });
        LinearLayout.LayoutParams bp = lp(0, 12);
        card.addView(btnRow, bp);

        TextView copyBtn = new TextView(this);
        copyBtn.setText("复制连接信息");
        copyBtn.setTextColor(C_FG);
        copyBtn.setTextSize(13);
        copyBtn.setGravity(Gravity.CENTER);
        copyBtn.setPadding(dp(10), dp(10), dp(10), dp(10));
        copyBtn.setBackground(round(C_CARD, 10));
        copyBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                String info = "地址：" + addrTv.getText() + "\n令牌：" + tokenTv.getText()
                        + "\n公钥：" + pubTv.getText();
                copy(info);
                toast("已复制，粘贴给用户或用于打包");
            }
        });
        card.addView(copyBtn, lp(0, 8));

        LinearLayout.LayoutParams cardp = lp(0, 14);
        root.addView(card, cardp);

        // ---- 手动开通 ----
        LinearLayout c2 = card();
        TextView t2 = new TextView(this);
        t2.setText("给用户开通（用户已付款）");
        t2.setTextColor(C_FG);
        t2.setTextSize(15);
        t2.setTypeface(Typeface.DEFAULT_BOLD);
        c2.addView(t2, lp(0, 0));
        TextView d2 = new TextView(this);
        d2.setText("让用户在 App 捐赠页复制「设备 ID」发给你，粘贴到下面即可开通。");
        d2.setTextColor(C_SUB);
        d2.setTextSize(12);
        d2.setPadding(0, dp(6), 0, dp(8));
        c2.addView(d2, lp(0, 0));

        final EditText devInput = new EditText(this);
        devInput.setInputType(InputType.TYPE_CLASS_TEXT);
        devInput.setHint("设备 ID，例如 d1795700507591u6097");
        devInput.setTextColor(C_FG);
        devInput.setHintTextColor(C_SUB);
        devInput.setPadding(dp(12), dp(10), dp(12), dp(10));
        devInput.setBackground(round(C_BG, 10));
        c2.addView(devInput, lp(0, 0));

        TextView amtRow = new TextView(this);
        amtRow.setText("1 元 · 微信");
        amtRow.setTextColor(C_FG);
        amtRow.setTextSize(13);
        amtRow.setGravity(Gravity.CENTER);
        amtRow.setPadding(dp(8), dp(9), dp(8), dp(9));
        amtRow.setBackground(round(C_CARD, 10));
        amtRow.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                new AlertDialog.Builder(ConsoleActivity.this)
                        .setTitle("金额与方式")
                        .setItems(new String[]{"1 元 · 微信", "1 元 · 支付宝", "5 元 · 微信", "5 元 · 支付宝",
                                "10 元 · 微信", "10 元 · 支付宝", "100 元 · 微信", "100 元 · 支付宝"},
                                new android.content.DialogInterface.OnClickListener() {
                                    @Override public void onClick(android.content.DialogInterface d, int which) {
                                        amtRow.setText(AMOUNTS[which / 2] + " 元 · "
                                                + (which % 2 == 0 ? "微信" : "支付宝"));
                                    }
                                })
                        .show();
            }
        });
        c2.addView(amtRow, lp(0, 8));

        TextView grantBtn = new TextView(this);
        grantBtn.setText("立即开通");
        grantBtn.setTextColor(Color.WHITE);
        grantBtn.setTextSize(15);
        grantBtn.setGravity(Gravity.CENTER);
        grantBtn.setPadding(dp(10), dp(12), dp(10), dp(12));
        grantBtn.setBackground(round(C_OK, 10));
        grantBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                String dev = devInput.getText().toString().trim();
                if (dev.length() == 0) { toast("请填写设备 ID"); return; }
                String[] am = amtRow.getText().toString().split(" ");
                int amount = 1;
                try { amount = Integer.parseInt(am[0]); } catch (Throwable ignore) { }
                String m = (am.length > 1 && am[1].contains("支付宝")) ? "alipay" : "wechat";
                grant(dev, amount, m);
            }
        });
        c2.addView(grantBtn, lp(0, 8));
        root.addView(c2, lp(0, 14));

        // ---- 设备列表 ----
        LinearLayout c3 = card();
        TextView t3 = new TextView(this);
        t3.setText("用户设备与开通状态");
        t3.setTextColor(C_FG);
        t3.setTextSize(15);
        t3.setTypeface(Typeface.DEFAULT_BOLD);
        c3.addView(t3, lp(0, 0));
        deviceBox = new LinearLayout(this);
        deviceBox.setOrientation(LinearLayout.VERTICAL);
        c3.addView(deviceBox, lp(0, 8));
        root.addView(c3, lp(0, 14));

        // ---- 日志 ----
        LinearLayout c4 = card();
        TextView t4 = new TextView(this);
        t4.setText("运行日志");
        t4.setTextColor(C_FG);
        t4.setTextSize(15);
        t4.setTypeface(Typeface.DEFAULT_BOLD);
        c4.addView(t4, lp(0, 0));
        logBox = new LinearLayout(this);
        logBox.setOrientation(LinearLayout.VERTICAL);
        c4.addView(logBox, lp(0, 8));
        root.addView(c4, lp(0, 14));

        return sv;
    }

    static final int[] AMOUNTS = {1, 1, 5, 5, 10, 10, 100, 100};

    LinearLayout card() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(16), dp(14), dp(16), dp(14));
        l.setBackground(round(C_CARD, 14));
        return l;
    }

    LinearLayout.LayoutParams lp(int h, int top) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.topMargin = dp(top);
        return p;
    }

    TextView kv(LinearLayout c, String k, String v) {
        TextView t = new TextView(this);
        t.setText(k + "：" + v);
        t.setTextColor(C_SUB);
        t.setTextSize(12);
        t.setPadding(0, dp(6), 0, dp(0));
        c.addView(t, lp(0, 0));
        return t;
    }

    // ===================== 行为 =====================

    void refreshStatus() {
        boolean on = server != null && server.isRunning();
        statusTv.setText(on ? "● 核验服务运行中" : "○ 核验服务已停止");
        statusTv.setTextColor(on ? C_OK : C_WARN);
        String ip = DonateServer.lanIp();
        addrTv.setText("http://" + ip + ":" + DonateServer.PORT);
        tokenTv.setText(DonateServer.adminToken(this));
        String pub = DonateServer.publicKeyB64(this);
        pubTv.setText(pub.length() > 20 ? pub.substring(0, 20) + "…" : pub);
        pubTv.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                new AlertDialog.Builder(ConsoleActivity.this).setTitle("服务端公钥")
                        .setMessage("把这段填进主 App 的 DonateConfig.PUB_KEY_B64：\n\n" + pub
                                + "\n\n（完整公钥，点此可复制）")
                        .setPositiveButton("复制", new android.content.DialogInterface.OnClickListener() {
                            @Override public void onClick(android.content.DialogInterface d, int w) {
                                copy(pub);
                                toast("已复制");
                            }
                        })
                        .setNegativeButton("关闭", null).show();
            }
        });
        // 待核验数量
        int pending = 0;
        synchronized (DonateServer.PENDING) { pending = DonateServer.PENDING.size(); }
        refreshPending();
        if (pending > 0) {
            noticeBox.setVisibility(View.VISIBLE);
            countTv.setText("待核验 " + pending + " 笔 · 最新：" + DonateServer.PENDING.get(0).optString("order_id"));
        } else {
            noticeBox.setVisibility(View.GONE);
        }
        refreshLogs();
    }

    /** 刷新待核验订单列表 */
    void refreshPending() {
        if (pendingBox == null) return;
        pendingBox.removeAllViews();
        java.util.List<JSONObject> list;
        synchronized (DonateServer.PENDING) { list = new ArrayList<>(DonateServer.PENDING); }
        if (list.isEmpty()) {
            TextView t = new TextView(this);
            t.setText("暂无待核验订单");
            t.setTextColor(C_SUB);
            t.setTextSize(12);
            pendingBox.addView(t, lp(0, 2));
            return;
        }
        for (JSONObject o : list) {
            final String dev = o.optString("device_id", "");
            final String oid = o.optString("order_id", "");
            final int amt = o.optInt("amount", 1);
            final String mth = "alipay".equals(o.optString("method", "")) ? "支付宝" : "微信";
            TextView t = new TextView(this);
            t.setText(amt + " 元 · " + mth + "\n" + dev + "\n订单 " + oid);
            t.setTextColor(C_ACC);
            t.setTextSize(12.5f);
            t.setPadding(0, dp(4), 0, dp(6));
            t.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    new AlertDialog.Builder(ConsoleActivity.this)
                            .setTitle("确认收款后开通")
                            .setMessage(amt + " 元 · " + mth + "\n设备：" + dev + "\n订单：" + oid
                                    + "\n\n点「立即开通」后，该用户约 3 秒即可登录。")
                            .setPositiveButton("立即开通",
                                    new android.content.DialogInterface.OnClickListener() {
                                        @Override public void onClick(android.content.DialogInterface d, int w) {
                                            grant(dev, amt, "alipay".equals(mth) ? "alipay" : "wechat");
                                        }
                                    })
                            .setNegativeButton("取消", null).show();
                }
            });
            pendingBox.addView(t, lp(0, 2));
        }
    }

    void refreshLogs() {
        if (logBox == null) return;
        logBox.removeAllViews();
        java.util.List<String> ls;
        synchronized (DonateServer.LOGS) { ls = new ArrayList<>(DonateServer.LOGS); }
        int from = Math.max(0, ls.size() - 12);
        for (int i = from; i < ls.size(); i++) {
            TextView t = new TextView(this);
            t.setText(ls.get(i));
            t.setTextColor(C_SUB);
            t.setTextSize(11);
            logBox.addView(t, lp(0, 2));
        }
    }

    void loadDevices() {
        if (deviceBox == null || server == null || !server.isRunning()) return;
        new Thread(new Runnable() { @Override public void run() {
            String r;
            try {
                r = http("GET", "/api/admin/devices", null, DonateServer.adminToken(ConsoleActivity.this));
            } catch (Throwable e) {
                return;
            }
            final JSONArray arr;
            try {
                JSONObject j = new JSONObject(r);
                JSONObject data = j.optJSONObject("data");
                arr = data == null ? null : data.optJSONArray("devices");
            } catch (Throwable e) {
                return;
            }
            handler.post(new Runnable() { @Override public void run() {
                deviceBox.removeAllViews();
                if (arr == null || arr.length() == 0) {
                    TextView tv = new TextView(ConsoleActivity.this);
                    tv.setText("还没有用户访问过");
                    tv.setTextColor(C_SUB);
                    tv.setTextSize(12);
                    deviceBox.addView(tv, lp(0, 4));
                    return;
                }
                for (int i = 0; i < arr.length(); i++) {
                    final JSONObject o = arr.optJSONObject(i);
                    if (o == null) continue;
                    final boolean paid = o.optLong("paid_at", 0L) > 0;
                    final String dev = o.optString("device_id", "");
                    TextView tv = new TextView(ConsoleActivity.this);
                    tv.setText((paid ? "\u2713 已开通  " : "\u00b7 待开通  ") + dev
                            + "  " + (paid ? (o.optInt("amount", 0) + " 元 " + o.optString("method", "")) : ""));
                    tv.setTextColor(paid ? C_OK : C_SUB);
                    tv.setTextSize(12.5f);
                    tv.setPadding(0, dp(4), 0, dp(4));
                    tv.setOnClickListener(new View.OnClickListener() {
                        @Override public void onClick(View v) {
                            new AlertDialog.Builder(ConsoleActivity.this)
                                    .setTitle(dev)
                                    .setMessage("状态：" + (paid ? "已开通" : "未开通")
                                            + "\n金额：" + o.optInt("amount", 0) + " 元"
                                            + "\n方式：" + o.optString("method", "")
                                            + "\n账号：" + o.optString("uid", ""))
                                    .setPositiveButton("复制设备 ID",
                                            new android.content.DialogInterface.OnClickListener() {
                                                @Override public void onClick(android.content.DialogInterface d, int w) {
                                                    copy(dev);
                                                    toast("已复制");
                                                }
                                            })
                                    .setNegativeButton("关闭", null).show();
                        }
                    });
                    deviceBox.addView(tv, lp(0, 2));
                }
            } });
        } }).start();
    }

    void grant(final String dev, final int amount, final String method) {
        if (server == null || !server.isRunning()) { toast("请先启动核验服务"); return; }
        new Thread(new Runnable() { @Override public void run() {
            String r;
            try {
                JSONObject b = new JSONObject();
                b.put("device_id", dev);
                b.put("amount", amount);
                b.put("method", method);
                r = http("POST", "/api/admin/grant", b.toString(),
                        DonateServer.adminToken(ConsoleActivity.this));
            } catch (Throwable e) {
                final String msg = "开通失败：" + e.getMessage();
                handler.post(new Runnable() { @Override public void run() { toast(msg); } });
                return;
            }
            final String res = r;
            handler.post(new Runnable() { @Override public void run() {
                String tip;
                try {
                    JSONObject j = new JSONObject(res);
                    tip = j.optInt("code", -1) == 0 ? "已开通，用户约 3 秒后可登录"
                            : "开通失败：" + j.optString("msg", "");
                } catch (Throwable e) {
                    tip = "开通失败";
                }
                toast(tip);
                loadDevices();
            } });
        } }).start();
    }

    /**
     * 【核心】收到新订单 → 立即提醒作者。
     * 任何用户扫了付款码并点「我已支付，申请开通」，作者这里都会立刻收到提示。
     */
    void onNotice(final String title, final String text, final JSONObject order) {
        noticeTv.setText(title);
        countTv.setText(text);
        noticeBox.setVisibility(View.VISIBLE);
        notifyBar(title, text);
        vibrate();
        // 响铃
        try {
            android.net.Uri u = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
            if (u != null) {
                android.media.MediaPlayer mp = android.media.MediaPlayer.create(this, u);
                if (mp != null) {
                    mp.setAudioAttributes(new AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_NOTIFICATION_EVENT).build());
                    mp.setOnCompletionListener(new android.media.MediaPlayer.OnCompletionListener() {
                        @Override public void onCompletion(android.media.MediaPlayer x) { x.release(); }
                    });
                    mp.start();
                }
            }
        } catch (Throwable ignore) { }
        refreshPending();
        loadDevices();
        // 弹窗提醒（带一键开通入口）
        if (order != null) {
            new AlertDialog.Builder(this)
                    .setTitle(title)
                    .setMessage(text + "\n\n订单号：" + order.optString("order_id")
                            + "\n\n确认收款后点「立即开通」，用户约 3 秒即可登录。")
                    .setPositiveButton("立即开通", new android.content.DialogInterface.OnClickListener() {
                        @Override public void onClick(android.content.DialogInterface d, int w) {
                            new AlertDialog.Builder(ConsoleActivity.this)
                                    .setTitle("选择金额")
                                    .setItems(new String[]{"1 元", "5 元", "10 元", "100 元"},
                                            new android.content.DialogInterface.OnClickListener() {
                                                @Override public void onClick(android.content.DialogInterface dd, int which) {
                                                    int[] ams = {1, 5, 10, 100};
                                                    grant(order.optString("device_id"), ams[which],
                                                            "alipay".equals(order.optString("method", "")) ? "alipay" : "wechat");
                                                }
                                            })
                                    .show();
                        }
                    })
                    .setNegativeButton("稍后", null)
                    .show();
        }
    }

    /** 系统通知栏提醒（App 在后台也能看到） */
    void notifyBar(String title, String text) {
        try {
            android.app.NotificationManager nm =
                    (android.app.NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (nm == null) return;
            android.app.Notification.Builder b;
            if (android.os.Build.VERSION.SDK_INT >= 26) {
                android.app.NotificationChannel ch = new android.app.NotificationChannel(
                        "donate", "捐赠提醒", android.app.NotificationManager.IMPORTANCE_HIGH);
                nm.createNotificationChannel(ch);
                b = new android.app.Notification.Builder(this, "donate");
            } else {
                b = new android.app.Notification.Builder(this);
            }
            b.setContentTitle(title)
                    .setContentText(text)
                    .setSmallIcon(android.R.drawable.ic_dialog_info)
                    .setAutoCancel(true);
            android.app.PendingIntent pi = android.app.PendingIntent.getActivity(this, 0,
                    new android.content.Intent(this, ConsoleActivity.class),
                    android.app.PendingIntent.FLAG_UPDATE_CURRENT
                            | (android.os.Build.VERSION.SDK_INT >= 23
                               ? android.app.PendingIntent.FLAG_IMMUTABLE : 0));
            b.setContentIntent(pi);
            nm.notify((int) (System.currentTimeMillis() % 100000), b.build());
        } catch (Throwable ignore) { }
    }

    /** 震动提醒 */
    void vibrate() {
        try {
            android.os.Vibrator v = (android.os.Vibrator) getSystemService(VIBRATOR_SERVICE);
            if (v != null && v.hasVibrator()) {
                if (android.os.Build.VERSION.SDK_INT >= 26) {
                    v.vibrate(android.os.VibrationEffect.createWaveform(
                            new long[]{0, 200, 100, 200}, -1));
                } else {
                    v.vibrate(200L);   // 低版本只支持单次时长
                }
            }
        } catch (Throwable ignore) { }
    }

    String http(String method, String path, String body, String token) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(
                "http://127.0.0.1:" + DonateServer.PORT + path).openConnection();
        c.setConnectTimeout(4000);
        c.setReadTimeout(6000);
        c.setRequestMethod(method);
        if (token != null) c.setRequestProperty("X-Admin-Token", token);
        if (body != null) {
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "application/json");
            c.getOutputStream().write(body.getBytes("UTF-8"));
        }
        java.io.InputStream in = c.getResponseCode() >= 400 ? c.getErrorStream() : c.getInputStream();
        java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
        byte[] buf = new byte[4096];
        int n;
        while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
        in.close();
        c.disconnect();
        return bo.toString("UTF-8");
    }

    void copy(String s) {
        try {
            ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("bxq", s));
        } catch (Throwable ignore) { }
    }

    void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }
}
