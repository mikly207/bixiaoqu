package com.bixiaoqu.console;

import android.content.Context;

/** 极简全局 Context 持有者（服务端需要访问 SharedPreferences） */
public final class AppCtx {
    public static volatile Context ctx;
    private AppCtx() { }
}
