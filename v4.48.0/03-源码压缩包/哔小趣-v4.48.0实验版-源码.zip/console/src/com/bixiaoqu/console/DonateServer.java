package com.bixiaoqu.console;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.math.BigInteger;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.Signature;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * 【作者控制台】内嵌捐赠核验服务端。
 *
 * 跑在作者自己的手机上，监听内网地址，供主 App（哔小趣）连上来查询捐赠状态。
 * 与 PC 端 server.js 使用**完全相同**的协议：
 *   · 状态查询 GET  /api/donate/status?device_id=&key=
 *   · 创建订单 POST /api/donate/order
 *   · 绑定账号 POST /api/donate/bind
 *   · 支付回调 POST /api/pay/notify
 *   · 管理接口 POST /api/admin/grant（按设备 ID 开通）、GET /api/admin/orders、/api/admin/devices
 *
 * 状态用 RSA-SHA256 签名，私钥只存在本机（SharedPreferences），公钥导出给主 App 内置。
 */
public class DonateServer {

    public static final int PORT = 8788;
    static final String SP = "bxq_author_console";

    private ServerSocket server;
    private Thread acceptThread;
    private ExecutorService pool;
    private final AtomicInteger seq = new AtomicInteger();

    /** 最近日志（供界面显示） */
    public static final List<String> LOGS = new ArrayList<>();
    static { synchronized (LOGS) { LOGS.clear(); } }

    /**
     * 【作者控制台】新订单/新设备提醒。
     * 任何用户扫码付款后都会在主 App 里点「我已支付，申请开通」，
     * 那一刻主 App 会向本服务创建订单 —— 服务端据此立刻通知作者，
     * 作者手机立刻弹出提示（声音 + 横幅），无需守着看。
     */
    public interface NoticeListener {
        void onNotice(String title, String text, JSONObject order);
    }

    private static NoticeListener noticeListener;

    public static void setNoticeListener(NoticeListener l) { noticeListener = l; }

    /** 待核验订单（供界面列表展示） */
    public static final List<JSONObject> PENDING = new ArrayList<>();

    public static void addPending(JSONObject o) {
        synchronized (PENDING) {
            // 手写移除（removeIf 需要 API 24，本 App minSdk 22）
            for (int i = PENDING.size() - 1; i >= 0; i--) {
                JSONObject x = PENDING.get(i);
                if (x != null && x.optString("order_id").equals(o.optString("order_id"))) {
                    PENDING.remove(i);
                }
            }
            PENDING.add(0, o);
            if (PENDING.size() > 100) PENDING.remove(PENDING.size() - 1);
        }
    }

    public interface Callback {
        void onStarted(int port, String lanIp);
        void onStopped();
    }

    private Callback cb;

    public static void log(String s) {
        synchronized (LOGS) {
            LOGS.add(s);
            if (LOGS.size() > 300) LOGS.remove(0);
        }
        android.util.Log.i("BxqDonate", s);
    }

    public void setCallback(Callback c) { this.cb = c; }

    public boolean isRunning() { return server != null && !server.isClosed(); }

    public int getPort() { return PORT; }

    // ===================== 启动 / 停止 =====================

    public void start() {
        if (isRunning()) return;
        try {
            server = new ServerSocket();
            server.setReuseAddress(true);
            server.bind(new InetSocketAddress(PORT), 64);
            pool = Executors.newFixedThreadPool(12, new java.util.concurrent.ThreadFactory() {
                @Override public Thread newThread(Runnable r) {
                    Thread t = new Thread(r, "donate-server-" + seq.incrementAndGet());
                    t.setDaemon(true);
                    return t;
                }
            });
            acceptThread = new Thread(new Runnable() { @Override public void run() {
                while (server != null && !server.isClosed()) {
                    try {
                        final Socket s = server.accept();
                        pool.submit(new Runnable() { @Override public void run() { handle(s); } });
                    } catch (Throwable e) {
                        if (server != null && !server.isClosed()) log("accept 失败：" + e.getMessage());
                    }
                }
            } }, "donate-accept");
            acceptThread.setDaemon(true);
            acceptThread.start();
            log("核验服务已启动，端口 " + PORT);
            if (cb != null) cb.onStarted(PORT, lanIp());
        } catch (Throwable e) {
            log("启动失败：" + e.getMessage());
            if (cb != null) cb.onStopped();
        }
    }

    public void stop() {
        try { if (server != null) server.close(); } catch (Throwable ignore) { }
        server = null;
        if (pool != null) pool.shutdownNow();
        log("核验服务已停止");
        if (cb != null) cb.onStopped();
    }

    /** 本机内网 IP（供主 App 连接） */
    public static String lanIp() {
        try {
            java.util.Enumeration<java.net.NetworkInterface> e =
                    java.net.NetworkInterface.getNetworkInterfaces();
            while (e.hasMoreElements()) {
                java.net.NetworkInterface ni = e.nextElement();
                if (ni.isLoopback() || !ni.isUp()) continue;
                java.util.Enumeration<java.net.InetAddress> as = ni.getInetAddresses();
                while (as.hasMoreElements()) {
                    java.net.InetAddress a = as.nextElement();
                    if (a instanceof java.net.Inet4Address && !a.isLoopbackAddress()) {
                        return a.getHostAddress();
                    }
                }
            }
        } catch (Throwable ignore) { }
        return "127.0.0.1";
    }

    // ===================== 密钥 =====================

    /** 生成并保存密钥对（私钥只在本机） */
    public static void ensureKeys(Context c) {
        SharedPreferences sp = c.getSharedPreferences(SP, Context.MODE_PRIVATE);
        if (sp.getString("priv", null) != null) return;
        try {
            KeyPairGenerator g = KeyPairGenerator.getInstance("RSA");
            g.initialize(2048);
            KeyPair kp = g.generateKeyPair();
            sp.edit()
                    .putString("priv", Base64E.encode(kp.getPrivate().getEncoded()))
                    .putString("pub", Base64E.encode(kp.getPublic().getEncoded()))
                    .apply();
            log("已生成 RSA-2048 密钥对（私钥仅存本机）");
        } catch (Throwable e) {
            log("生成密钥失败：" + e.getMessage());
        }
    }

    /** 公钥 Base64（导出给主 App 内置） */
    public static String publicKeyB64(Context c) {
        SharedPreferences sp = c.getSharedPreferences(SP, Context.MODE_PRIVATE);
        return sp.getString("pub", "");
    }

    static PrivateKey privateKey(Context c) {
        try {
            SharedPreferences sp = c.getSharedPreferences(SP, Context.MODE_PRIVATE);
            String b64 = sp.getString("priv", null);
            if (b64 == null) return null;
            byte[] der = Base64E.decode(b64);
            KeyStore ks = KeyStore.getInstance("PKCS8");
            // 直接用 PKCS8 解析
            return java.security.KeyFactory.getInstance("RSA")
                    .generatePrivate(new PKCS8EncodedKeySpec(der));
        } catch (Throwable e) {
            return null;
        }
    }

    // ===================== 签名 =====================

    /** 规范化 payload —— 必须与主 App、服务端 JS 完全一致 */
    static String canonical(String deviceId, String uid, boolean paid, int amount,
                            String method, String orderId, long issuedAt, long expiresAt) {
        return "v1|" + nz(deviceId) + "|" + nz(uid) + "|" + (paid ? "1" : "0") + "|"
                + amount + "|" + nz(method) + "|" + nz(orderId) + "|"
                + issuedAt + "|" + expiresAt;
    }

    static String nz(String s) { return s == null ? "" : s; }

    static String sign(Context c, String payload) {
        try {
            PrivateKey pk = privateKey(c);
            if (pk == null) return "";
            Signature sig = Signature.getInstance("SHA256withRSA");
            sig.initSign(pk);
            sig.update(payload.getBytes("UTF-8"));
            return hex(sig.sign());
        } catch (Throwable e) {
            return "";
        }
    }

    static String hex(byte[] b) {
        StringBuilder sb = new StringBuilder();
        for (byte x : b) {
            String h = Integer.toHexString(x & 0xFF);
            if (h.length() == 1) sb.append('0');
            sb.append(h);
        }
        return sb.toString();
    }

    // ===================== 数据 =====================

    static SharedPreferences sp(Context c) { return c.getSharedPreferences(SP, Context.MODE_PRIVATE); }

    static JSONObject db(Context c) {
        try {
            String s = sp(c).getString("db", "{}");
            return new JSONObject(s);
        } catch (Throwable e) {
            return new JSONObject();
        }
    }

    static void saveDb(Context c, JSONObject db) {
        try { sp(c).edit().putString("db", db.toString()).apply(); } catch (Throwable ignore) { }
    }

    static JSONObject device(Context c, String deviceId) {
        JSONObject d = db(c);
        try {
            JSONObject devs = d.optJSONObject("devices");
            if (devs == null) { devs = new JSONObject(); d.put("devices", devs); }
            return devs.optJSONObject(deviceId);
        } catch (Throwable e) { return null; }
    }

    static void putDevice(Context c, String deviceId, JSONObject rec) {
        try {
            JSONObject d = db(c);
            JSONObject devs = d.optJSONObject("devices");
            if (devs == null) { devs = new JSONObject(); d.put("devices", devs); }
            devs.put(deviceId, rec);
            saveDb(c, d);
        } catch (Throwable ignore) { }
    }

    // ===================== HTTP 处理 =====================

    void handle(Socket s) {
        try {
            s.setSoTimeout(15000);
            BufferedReader br = new BufferedReader(new InputStreamReader(s.getInputStream(), "UTF-8"));
            String reqLine = br.readLine();
            if (reqLine == null) return;
            String[] parts = reqLine.split(" ");
            if (parts.length < 2) return;
            String method = parts[0];
            String path = parts[1];
            int contentLength = 0;
            String adminHeader = "";
            String line;
            while ((line = br.readLine()) != null && line.length() > 0) {
                String low = line.toLowerCase();
                if (low.startsWith("content-length:")) {
                    try { contentLength = Integer.parseInt(line.substring(15).trim()); } catch (Throwable ignore) { }
                } else if (low.startsWith("x-admin-token:")) {
                    adminHeader = line.substring(15).trim();
                }
            }
            String body = "";
            if (contentLength > 0) {
                char[] buf = new char[contentLength];
                int n = 0;
                while (n < contentLength) {
                    int r = br.read(buf, n, contentLength - n);
                    if (r < 0) break;
                    n += r;
                }
                body = new String(buf, 0, n);
            }
            String qPath = path;
            String query = "";
            int qi = path.indexOf('?');
            if (qi >= 0) { qPath = path.substring(0, qi); query = path.substring(qi + 1); }

            JSONObject out = route(s, method, qPath, query, body, adminHeader);
            String json = out == null ? "{\"code\":404,\"msg\":\"not found\"}" : out.toString();
            respond(s, json);
        } catch (Throwable e) {
            try { respond(s, "{\"code\":500,\"msg\":\"server error\"}"); } catch (Throwable ignore) { }
        } finally {
            try { s.close(); } catch (Throwable ignore) { }
        }
    }

    JSONObject route(Socket s, String method, String path, String query, String body, String adminHeader) throws Exception {
        Context c = AppCtx.ctx;
        if (c == null) return new JSONObject().put("code", 500).put("msg", "no ctx");

        if (path.equals("/api/health")) {
            return new JSONObject().put("code", 0).put("msg", "ok").put("time", System.currentTimeMillis());
        }
        if (path.equals("/api/pubkey")) {
            return new JSONObject().put("code", 0)
                    .put("data", new JSONObject().put("pub_key_b64", publicKeyB64(c)));
        }
        if (path.equals("/api/donate/status") && method.equals("GET")) {
            String dev = param(query, "device_id");
            String key = param(query, "key");
            if (dev.length() == 0 || key.length() == 0) {
                return new JSONObject().put("code", 400).put("msg", "缺少 device_id 或 key");
            }
            JSONObject devRec = device(c, dev);
            long now = System.currentTimeMillis();
            boolean keyOk = devRec != null && (eq(devRec.optString("key"), key)
                    || (devRec.optBoolean("granted", false) && devRec.optString("key", "").length() == 0));
            boolean paid = keyOk && devRec.optLong("paid_at", 0L) > 0;
            String uid = paid ? devRec.optString("uid", "") : "";
            int amount = paid ? devRec.optInt("amount", 0) : 0;
            String method2 = paid ? devRec.optString("method", "") : "";
            String orderId = paid ? devRec.optString("order_id", "") : "";
            long expires = paid ? now + 72L * 3600 * 1000 : now + 10 * 60 * 1000;
            String payload = canonical(dev, uid, paid, amount, method2, orderId, now, expires);
            JSONObject data = new JSONObject();
            data.put("paid", paid);
            data.put("amount", amount);
            data.put("method", method2);
            data.put("order_id", orderId);
            data.put("device_id", dev);
            data.put("uid", uid);
            data.put("issued_at", now);
            data.put("expires_at", expires);
            data.put("receipt", payload);
            data.put("sign", sign(c, payload));
            log("状态查询 " + dev + " → " + (paid ? "已开通" : "未开通"));
            return new JSONObject().put("code", 0).put("data", data);
        }
        if (path.equals("/api/donate/order") && method.equals("POST")) {
            JSONObject b = new JSONObject(body);
            String dev = safeId(b.optString("device_id", ""));
            String key = safeId(b.optString("key", ""));
            if (dev.length() == 0 || key.length() == 0) {
                return new JSONObject().put("code", 400).put("msg", "缺少 device_id 或 key");
            }
            int amount = Math.max(1, b.optInt("amount", 1));
            String m = "alipay".equals(b.optString("method", "")) ? "alipay" : "wechat";
            String orderId = "BXQ" + Long.toString(System.currentTimeMillis(), 36).toUpperCase()
                    + UUID.randomUUID().toString().substring(0, 4).toUpperCase();
            JSONObject rec = device(c, dev);
            if (rec == null) {
                rec = new JSONObject();
                rec.put("device_id", dev);
                rec.put("key", key);
                rec.put("uid", "");
                rec.put("amount", 0);
                rec.put("method", "");
                rec.put("order_id", "");
                rec.put("paid_at", 0);
                rec.put("updated_at", 0);
            } else if (rec.optString("key", "").length() == 0) {
                rec.put("key", key);
            }
            rec.put("last_amount", amount);
            rec.put("last_method", m);
            rec.put("updated_at", System.currentTimeMillis());
            putDevice(c, dev, rec);
            JSONObject d = new JSONObject();
            d.put("order_id", orderId);
            d.put("amount", amount);
            d.put("method", m);
            d.put("created_at", System.currentTimeMillis());
            d.put("remark_hint", "转账时请在备注中填写订单号 " + orderId);
            log("创建订单 " + orderId + "（" + amount + " 元 " + m + "）设备 " + dev);
            // 【作者控制台】立刻通知作者：有用户扫码付款了
            try {
                JSONObject notice = new JSONObject();
                notice.put("order_id", orderId);
                notice.put("device_id", dev);
                notice.put("amount", amount);
                notice.put("method", m);
                notice.put("created_at", System.currentTimeMillis());
                addPending(notice);
                NoticeListener nl = noticeListener;
                if (nl != null) {
                    nl.onNotice("收到新的捐赠订单",
                            amount + " 元 · " + ("alipay".equals(m) ? "支付宝" : "微信")
                                    + " · 设备 " + dev, notice);
                }
            } catch (Throwable ignore) { }
            return new JSONObject().put("code", 0).put("data", d);
        }
        if (path.equals("/api/donate/bind") && method.equals("POST")) {
            JSONObject b = new JSONObject(body);
            String dev = safeId(b.optString("device_id", ""));
            String key = safeId(b.optString("key", ""));
            String uid = safeId(b.optString("uid", ""));
            JSONObject rec = device(c, dev);
            boolean ok = rec != null && eq(rec.optString("key"), key);
            if (ok) {
                rec.put("uid", uid);
                rec.put("updated_at", System.currentTimeMillis());
                putDevice(c, dev, rec);
            }
            return new JSONObject().put("code", ok ? 0 : 403).put("msg", ok ? "ok" : "绑定失败：设备密钥不匹配");
        }
        // 管理接口
        if (path.startsWith("/api/admin/")) {
            // 【安全】必须校验请求头里的 X-Admin-Token 与本机令牌一致
            String tok = adminToken(c);
            if (adminHeader == null || !tok.equals(adminHeader.trim())) {
                log("管理接口鉴权失败（令牌不匹配）");
                return new JSONObject().put("code", 401).put("msg", "管理员令牌无效");
            }
            if (path.equals("/api/admin/grant") && method.equals("POST")) {
                JSONObject b = new JSONObject(body);
                String dev = safeId(b.optString("device_id", ""));
                if (dev.length() == 0) return new JSONObject().put("code", 400).put("msg", "缺少 device_id");
                int amount = Math.max(1, b.optInt("amount", 1));
                String m = "alipay".equals(b.optString("method", "")) ? "alipay" : "wechat";
                JSONObject rec = device(c, dev);
                if (rec == null) {
                    rec = new JSONObject();
                    rec.put("device_id", dev);
                    rec.put("key", "");
                    rec.put("uid", "");
                    rec.put("order_id", "");
                    rec.put("granted", true);
                }
                rec.put("granted", true);
                rec.put("amount", amount);
                rec.put("method", m);
                rec.put("paid_at", System.currentTimeMillis());
                rec.put("updated_at", System.currentTimeMillis());
                if (rec.optString("order_id", "").length() == 0) {
                    rec.put("order_id", "GRANT" + Long.toString(System.currentTimeMillis(), 36).toUpperCase());
                }
                putDevice(c, dev, rec);
                log("【手动开通】设备 " + dev + " · " + amount + " 元 " + m);
                try {
                    NoticeListener nl = noticeListener;
                    if (nl != null) {
                        nl.onNotice("已开通", "设备 " + dev + " · " + amount + " 元 " + m, null);
                    }
                } catch (Throwable ignore) { }
                return new JSONObject().put("code", 0).put("msg", "ok").put("data", rec);
            }
            if (path.equals("/api/admin/devices") && method.equals("GET")) {
                JSONObject devs = db(c).optJSONObject("devices");
                JSONArray arr = new JSONArray();
                if (devs != null) {
                    java.util.Iterator<String> it = devs.keys();
                    while (it.hasNext()) {
                        String k = it.next();
                        JSONObject v = devs.optJSONObject(k);
                        if (v != null) arr.put(v);
                    }
                }
                return new JSONObject().put("code", 0).put("data", new JSONObject().put("devices", arr));
            }
        }
        return null;
    }

    static String adminToken(Context c) {
        String t = sp(c).getString("admin_token", "");
        if (t.length() == 0) {
            t = UUID.randomUUID().toString().replace("-", "").substring(0, 24);
            sp(c).edit().putString("admin_token", t).apply();
        }
        return t;
    }

    // ===================== 工具 =====================

    static boolean eq(String a, String b) { return a != null && a.equals(b); }

    static String param(String query, String key) {
        try {
            for (String kv : query.split("&")) {
                int i = kv.indexOf('=');
                if (i < 0) continue;
                if (kv.substring(0, i).equals(key)) {
                    return java.net.URLDecoder.decode(kv.substring(i + 1), "UTF-8");
                }
            }
        } catch (Throwable ignore) { }
        return "";
    }

    static String safeId(String s) {
        if (s == null) return "";
        s = s.trim();
        return s.matches("[A-Za-z0-9_.-]{1,64}") ? s : "";
    }

    void respond(Socket s, String json) {
        try {
            byte[] body = json.getBytes("UTF-8");
            StringBuilder head = new StringBuilder();
            head.append("HTTP/1.1 200 OK\r\n");
            head.append("Content-Type: application/json; charset=utf-8\r\n");
            head.append("Content-Length: ").append(body.length).append("\r\n");
            head.append("Access-Control-Allow-Origin: *\r\n");
            head.append("Cache-Control: no-store\r\n\r\n");
            OutputStream os = s.getOutputStream();
            os.write(head.toString().getBytes("UTF-8"));
            os.write(body);
            os.flush();
        } catch (Throwable ignore) { }
    }

    /** 简易 Base64（避免依赖 android.util 的 API 差异） */
    static class Base64E {
        private static final char[] TBL = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/".toCharArray();

        static String encode(byte[] b) {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < b.length; i += 3) {
                int v = (b[i] & 0xFF) << 16;
                if (i + 1 < b.length) v |= (b[i + 1] & 0xFF) << 8;
                if (i + 2 < b.length) v |= (b[i + 2] & 0xFF);
                sb.append(TBL[(v >> 18) & 63]).append(TBL[(v >> 12) & 63]);
                sb.append(i + 1 < b.length ? TBL[(v >> 6) & 63] : '=');
                sb.append(i + 2 < b.length ? TBL[v & 63] : '=');
            }
            return sb.toString();
        }

        static byte[] decode(String s) {
            String t = s.replaceAll("[^A-Za-z0-9+/=]", "");
            int pad = 0;
            if (t.endsWith("==")) pad = 2;
            else if (t.endsWith("=")) pad = 1;
            int outLen = t.length() / 4 * 3 - pad;
            if (outLen < 0) outLen = 0;
            byte[] out = new byte[outLen];
            int oi = 0;
            for (int i = 0; i + 3 < t.length(); i += 4) {
                int v0 = val(t.charAt(i)), v1 = val(t.charAt(i + 1));
                int v2 = t.charAt(i + 2) == '=' ? 0 : val(t.charAt(i + 2));
                int v3 = t.charAt(i + 3) == '=' ? 0 : val(t.charAt(i + 3));
                if (oi < out.length) out[oi++] = (byte) ((v0 << 2) | (v1 >> 4));
                if (oi < out.length) out[oi++] = (byte) (((v1 & 0xF) << 4) | (v2 >> 2));
                if (oi < out.length) out[oi++] = (byte) (((v2 & 0x3) << 6) | v3);
            }
            return out;
        }

        private static int val(char c) {
            if (c >= 'A' && c <= 'Z') return c - 'A';
            if (c >= 'a' && c <= 'z') return c - 'a' + 26;
            if (c >= '0' && c <= '9') return c - '0' + 52;
            if (c == '+') return 62;
            if (c == '/') return 63;
            return 0;
        }
    }
}
