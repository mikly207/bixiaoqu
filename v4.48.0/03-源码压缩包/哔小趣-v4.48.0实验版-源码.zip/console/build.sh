#!/bin/bash
# 哔小趣 · 作者控制台 APK 构建脚本
set -e
cd "$(dirname "$0")"
ASDK=/opt/asdk
AJ=$ASDK/platforms/android-22/android.jar
AJ34=$ASDK/android-34/android.jar
OUT="$(pwd)/build"
rm -rf $OUT && mkdir -p $OUT/classes $OUT/dex $OUT/gen

echo "== javac =="
find src -name "*.java" > $OUT/srcs.txt
# 用 android-34 的 bootclasspath 编译：它含 Java 8 lambda 支持
# （android-22 的 bootclasspath 缺 MethodHandles$Lookup，编不过 lambda），
# 产物再由 d8 按 --min-api 22 降级，运行时行为一致。
javac -encoding UTF-8 -source 8 -target 8 -nowarn -bootclasspath $AJ34 \
  -d $OUT/classes @$OUT/srcs.txt 2> $OUT/javac.log || { grep -v "^注:" $OUT/javac.log | head -30; exit 1; }
grep -v "^注:" $OUT/javac.log | head -20 || true

echo "== d8 =="
find $OUT/classes -name "*.class" > $OUT/classlist.txt
$ASDK/android-14/d8 --release --min-api 22 --lib $AJ34 --output $OUT/dex @$OUT/classlist.txt

echo "== manifest =="
cp AndroidManifest.xml $OUT/AndroidManifest.xml
VNAME="1.0.0"
APK="/workspace/哔小趣作者控制台.apk"

echo "== aapt2 =="
$ASDK/android-14/aapt2 compile --dir res -o $OUT/res.zip
$ASDK/android-14/aapt2 link -o $OUT/base.apk -I $AJ34 \
  --manifest $OUT/AndroidManifest.xml -R $OUT/res.zip \
  --java $OUT/gen --auto-add-overlay --min-sdk-version 22 --target-sdk-version 34 \
  --version-code 1 --version-name "$VNAME"

echo "== package =="
cp $OUT/base.apk $OUT/unsigned.apk
cd $OUT && zip -q -j unsigned.apk dex/classes.dex
$ASDK/android-14/zipalign -f 4 unsigned.apk aligned.apk
$ASDK/android-14/apksigner sign --ks /workspace/哔小趣签名密钥.jks --ks-pass pass:bxq202501 \
  --ks-key-alias bxq --key-pass pass:bxq202501 \
  --v1-signing-enabled true --v2-signing-enabled true --v3-signing-enabled true \
  --out "$APK" aligned.apk
$ASDK/android-14/apksigner verify "$APK" && echo "sign OK: $APK"
ls -la "$APK"
