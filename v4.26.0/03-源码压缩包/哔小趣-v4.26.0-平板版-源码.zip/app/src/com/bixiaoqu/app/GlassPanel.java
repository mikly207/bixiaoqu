package com.bixiaoqu.app;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.widget.LinearLayout;

/**
 * 【v4.25.0】液态玻璃容器 —— 去塑料感重写。
 *
 * 继承 LinearLayout，所以老的「竖着摞几行控件」的代码可以原地替换：
 *   ctrlBar = new LinearLayout(this)  →  ctrlBar = new GlassPanel(this)
 * 子 View 的排布、padding、addView 全部照旧，只是背景从一块死色换成了玻璃材质。
 *
 * 【v4.24.0 为什么还是像塑料】
 *   玻璃体内那层「乳白雾」（0x1E → 0x12 白）铺满了整个面板，
 *   顶部再加 0x26 白、左上再加 0x1C 白、噪点还叠了两层 30/22 的白点。
 *   四层白叠在一起 ≈ 40% 的均匀白 —— 那不是玻璃，是一块磨砂塑料板。
 *   再加上边缘一圈 0x8E 的纯白描边，就成了「塑料按钮」的教科书长相：
 *   均匀、灰白、边界硬、没有任何光学信息。
 *
 * 【v4.25.0 的做法：把玻璃的「存在感」全部挪到边缘】
 *   真实玻璃之所以像玻璃，靠的不是body有多白，而是边缘那几道光学：
 *     ① 边缘高光 —— 上缘被光打亮、越往下越弱（垂直渐变，不是均匀描边）；
 *     ② 接触暗线 —— 高光内侧紧挨一道细暗线，这是玻璃的厚度；
 *     ③ 边缘色散 —— 左冷右暖的一点彩色偏移，塑料永远没有；
 *     ④ 高光热点 —— 左上角有一处更亮的反射源，避免高光呆板成一条线；
 *     ⑤ 底部焦散 —— 下沿被「地面」反射托起的一线亮。
 *   身体只留极淡的一层受光（顶部 8% 白）+ 极细的磨砂颗粒，
 *   底下该是什么颜色就还是什么颜色。
 *
 * 【v4.26.0 —— 平板版液态玻璃再优化：给边缘补上「三明治厚度」】
 *   v4.25.0 的边缘是「亮线 → 暗线 → 色散」，仍是一根描边，
 *   真实玻璃的边缘其实能看见两个界面：外表面 + 内表面，
 *   所以看起来是一层有体积的液膜，而不是贴上去的一圈线。
 *   这一版在暗线内侧补一道**内表面二次反射**（更细、更淡），
 *   于是边缘变成：外亮线 → 暗线 → 内反射线，三层叠出厚度。
 *   同时补两道真玻璃才有的细节：
 *     ⑥ 顶面镜面带 —— 顶边中央一道更集中的短促高光（不是整圈均匀描边）；
 *     ⑦ 底部焦散加强 —— 下沿反光加宽加亮，并在其上方叠一层极淡的暖色散射。
 *   身体再通透一点点（雾 0x0A→0x08），底下画面能透得更干净。
 *
 * 全场只在「控件显示 / 按下 / 扫光」时重绘，静止时零开销；
 * 没有 RenderScript、没有 RenderEffect、没有额外线程，API22 起可用。
 */
public class GlassPanel extends LinearLayout {

    /** 圆角（dp） */
    private float radiusDp = 20f;
    /** 是否画外投影（浮在画面上时要有，嵌在页面流里可以关掉省一层绘制） */
    private boolean floating = true;
    /**
     * 基底浓度：0~255，直接就是「压暗层」的 alpha。
     * 玻璃本身几乎不压暗，压暗只是为了白字能读；压太多就变回塑料板。
     */
    private int tint = 0x46;
    /** 扫光进度：-1 表示不画 */
    private float sheen = -1f;

    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint edge = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint inner = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint disp = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint foot = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint inner2 = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint topSpec = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint noisePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint noisePaint2 = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint shadow = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();
    private final RectF tmp = new RectF();
    private final RectF innerR = new RectF();
    private final Path clip = new Path();

    private static Bitmap noise, noiseCoarse;

    private ValueAnimator sheenAnim;

    // ---- 着色器缓存：尺寸不变就不重建，扫光动画每帧重绘也不会产生垃圾 ----
    private int shW, shH;
    private Shader shFill, shSheen, shRadial, shRim, shRimHot, shInner, shDisp,
            shFootL, shBottom, shHaze, shInner2, shTopSpec, shCaustic;

    public GlassPanel(Context c) {
        super(c);
        setOrientation(VERTICAL);
        setWillNotDraw(false);          // ViewGroup 默认跳过 onDraw，材质必须自己画
        setClipChildren(false);
        setClipToPadding(false);
        edge.setStyle(Paint.Style.STROKE);
        inner.setStyle(Paint.Style.STROKE);
        disp.setStyle(Paint.Style.STROKE);
        inner2.setStyle(Paint.Style.STROKE);
        topSpec.setStyle(Paint.Style.STROKE);
        float d = getResources().getDisplayMetrics().density;
        ensureNoise();
        if (noise != null) {
            noisePaint.setShader(new android.graphics.BitmapShader(
                    noise, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT));
        }
        if (noiseCoarse != null) {
            noisePaint2.setShader(new android.graphics.BitmapShader(
                    noiseCoarse, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT));
        }
    }

    // ------------------------------------------------------------ 配置

    public GlassPanel radius(float dp) {
        this.radiusDp = dp;
        invalidate();
        return this;
    }

    /** 浮在画面上（画投影）；false = 嵌在页面流里，省一层阴影绘制 */
    public GlassPanel floating(boolean on) {
        this.floating = on;
        invalidate();
        return this;
    }

    /** 基底浓度 0~255（压暗层 alpha）。越大越实，越小越通透 */
    public GlassPanel tint(int alpha) {
        this.tint = Math.max(0, Math.min(255, alpha));
        shW = 0;   // 让着色器缓存失效
        invalidate();
        return this;
    }

    /** 控件出现时扫一道光，模拟玻璃被光扫过；只跑一次 700ms，不常驻 */
    public void playSheen() {
        if (sheenAnim != null) sheenAnim.cancel();
        sheenAnim = ValueAnimator.ofFloat(-0.35f, 1.35f);
        sheenAnim.setDuration(720);
        sheenAnim.setInterpolator(new DecelerateInterpolator(1.4f));
        sheenAnim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override public void onAnimationUpdate(ValueAnimator a) {
                sheen = (Float) a.getAnimatedValue();
                invalidate();
            }
        });
        sheenAnim.start();
    }

    private int dp(float v) {
        return (int) (getResources().getDisplayMetrics().density * v + 0.5f);
    }

    // ------------------------------------------------------------ 绘制

    @Override
    protected void onDraw(Canvas cv) {
        final int w = getWidth(), h = getHeight();
        if (w <= 0 || h <= 0) return;
        final float den = getResources().getDisplayMetrics().density;
        final float r = radiusDp * den;
        rect.set(0, 0, w, h);

        // ① 接触阴影：三层、范围大、alpha 极低。
        //    旧版四层小偏移高 alpha 的硬阴影，像一张贴纸浮在画面上；
        //    玻璃是「离表面很近地浮着」，影子要散、要淡。
        if (floating) {
            for (int i = 3; i >= 1; i--) {
                float off = dp(i * 2.2f);
                shadow.setColor(i == 1 ? 0x22000000 : (i == 2 ? 0x0E000000 : 0x05000000));
                tmp.set(off * 0.25f, off * 0.9f, w - off * 0.25f, h + off * 0.8f);
                cv.drawRoundRect(tmp, r * 0.95f, r * 0.95f, shadow);
            }
        }

        if (w != shW || h != shH) {
            shW = w;
            shH = h;
            // 基底压暗：上缘略透、下缘略实，玻璃才有「厚度」
            shFill = new LinearGradient(0, 0, 0, h,
                    withAlpha(0x000000, (int) (tint * 0.72f)),
                    withAlpha(0x000000, tint), Shader.TileMode.CLAMP);
            // 磨砂乳白雾：极淡，只给玻璃一点「自发光」的通透感。
            // 【v4.25.0】旧版这层是 0x1E → 0x12（四层白叠起来 ≈ 40% 均匀白），
            // 那就是塑料板。现在压到 0x0A → 0x04，玻璃的通透感交给边缘光学去表达。
            // 【v4.26.0】再降到 0x08 → 0x03 —— 平板版进一步提通透度，
            // 底下的视频画面能透得更干净，玻璃不再是「一层盖在画面上的板」。
            shHaze = new LinearGradient(0, 0, 0, h,
                    0x08FFFFFF, 0x03FFFFFF, Shader.TileMode.CLAMP);
            // 顶部受光：只占上缘一点点白，替代旧版那层厚白雾
            shSheen = new LinearGradient(0, 0, 0, h * 0.45f,
                    0x14FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP);
            // 左上斜向反光
            shRadial = new RadialGradient(w * 0.22f, -h * 0.35f, h * 1.9f,
                    0x1AFFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP);
            // 边缘高光：上强下弱（这是「玻璃」的第一眼，旧版是均匀一圈白）
            shRim = new LinearGradient(0, 0, 0, h,
                    0xC4FFFFFF, 0x1AFFFFFF, Shader.TileMode.CLAMP);
            // 高光热点：左上角更亮一点，避免高光呆板成一条直线
            shRimHot = new RadialGradient(w * 0.16f, -h * 0.25f, h * 2.2f,
                    0x78FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP);
            // 接触暗线：玻璃内侧的厚度
            shInner = new LinearGradient(0, 0, 0, h,
                    0x08000000, 0x30000000, Shader.TileMode.CLAMP);
            // 【v4.26.0】内表面二次反射：暗线内侧再一道更细更淡的亮线。
            // 真玻璃的边缘能看见两个界面（外表面 + 内表面），
            // 这道线让边缘从「一根描边」变成「一层有体积的液膜」。
            shInner2 = new LinearGradient(0, 0, 0, h,
                    0x30FFFFFF, 0x0AFFFFFF, Shader.TileMode.CLAMP);
            // 【v4.26.0】顶面镜面带：顶边中央一段更集中的短促高光
            shTopSpec = new LinearGradient(0, 0, 0, den * 5f,
                    0xC0FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP);
            // 【v4.26.0】底部焦散：下沿反光上方一层极淡的暖色散射
            shCaustic = new LinearGradient(0, h * 0.78f, 0, h,
                    0x00FFFFFF, 0x1CFFD9B0, Shader.TileMode.CLAMP);
            // 边缘色散：左冷右暖，塑料不会有
            shDisp = new LinearGradient(0, 0, w, 0,
                    new int[]{0x38A9D8FF, 0x00FFFFFF, 0x34FFC79A},
                    new float[]{0f, 0.5f, 1f}, Shader.TileMode.CLAMP);
            // 底部厚度暗部
            shBottom = new LinearGradient(0, h * 0.55f, 0, h,
                    0x00000000, 0x2E000000, Shader.TileMode.CLAMP);
            // 底缘反光：中间亮、两头淡，模拟地面在玻璃下沿的反射
            shFootL = new LinearGradient(w * 0.08f, 0, w * 0.92f, 0,
                    new int[]{0x00FFFFFF, 0x55FFFFFF, 0x00FFFFFF},
                    new float[]{0f, 0.5f, 1f}, Shader.TileMode.CLAMP);
        }

        clip.reset();
        clip.addRoundRect(rect, r, r, Path.Direction.CW);
        final int sc = cv.save();
        cv.clipPath(clip);

        // ② 基底压暗（很轻，只是为了白字能读）
        fill.setShader(shFill);
        cv.drawRect(rect, fill);
        fill.setShader(null);

        // ③ 磨砂雾 + 顶部受光 + 左上斜向反光
        glow.setShader(shHaze);
        cv.drawRect(rect, glow);
        glow.setShader(shSheen);
        cv.drawRect(rect, glow);
        glow.setShader(shRadial);
        cv.drawRect(rect, glow);
        glow.setShader(null);

        // ④ 磨砂颗粒：比旧版轻一半，颗粒太重会像砂纸（塑料感来源之一）
        if (noise != null) {
            noisePaint.setAlpha(12);
            cv.drawRect(rect, noisePaint);
        }
        if (noiseCoarse != null) {
            noisePaint2.setAlpha(8);
            cv.drawRect(rect, noisePaint2);
        }

        // ⑤ 底部厚度暗部
        glow.setShader(shBottom);
        cv.drawRect(rect, glow);
        glow.setShader(null);

        // 动态扫光：沿顶棱跑过的一道细亮光（不是整块擦白）
        if (sheen >= 0f) {
            final int sc2 = cv.save();
            cv.rotate(-14f, w * 0.5f, h * 0.5f);
            float cx = -w * 0.45f + sheen * (w * 1.9f);
            glow.setShader(new LinearGradient(cx, 0, cx + w * 0.16f, h * 0.6f,
                    0x00FFFFFF, 0x26FFFFFF, Shader.TileMode.CLAMP));
            cv.drawRect(-w, -h, w * 2, h * 2, glow);
            glow.setShader(null);
            cv.restoreToCount(sc2);
        }

        // ⑥ 按下提亮：手指按住时玻璃「吸一口光」（不是变实色）
        if (isPressed()) {
            glow.setShader(null);
            glow.setColor(0x12FFFFFF);
            cv.drawRoundRect(rect, r, r, glow);
        }

        cv.restoreToCount(sc);

        // ⑦ 边缘高光：上缘被光打亮，越往下越弱
        final float rimW = Math.max(1f, den * 1.3f);
        edge.setShader(shRim);
        edge.setStrokeWidth(rimW);
        innerR.set(rect.left + rimW * 0.4f, rect.top + rimW * 0.4f,
                rect.right - rimW * 0.4f, rect.bottom - rimW * 0.4f);
        cv.drawRoundRect(innerR, Math.max(0f, r - rimW * 0.4f),
                Math.max(0f, r - rimW * 0.4f), edge);
        // 左上高光热点
        edge.setShader(shRimHot);
        cv.drawRoundRect(innerR, Math.max(0f, r - rimW * 0.4f),
                Math.max(0f, r - rimW * 0.4f), edge);
        edge.setShader(null);

        // ⑧ 接触暗线：高光内侧紧挨的一道细暗线 —— 玻璃的厚度就在这一笔
        final float inW = Math.max(1f, den * 1.1f);
        inner.setShader(shInner);
        inner.setStrokeWidth(inW);
        innerR.set(rect.left + den * 1.7f, rect.top + den * 1.7f,
                rect.right - den * 1.7f, rect.bottom - den * 1.7f);
        cv.drawRoundRect(innerR, Math.max(0f, r - den * 1.7f),
                Math.max(0f, r - den * 1.7f), inner);
        inner.setShader(null);

        // 【v4.26.0】内表面二次反射：暗线内侧一道更细更淡的亮线。
        // 有了它，边缘是「外亮线 → 暗线 → 内亮线」三层，
        // 看起来才是一层有厚度的液膜，而不是贴上去的一圈描边。
        final float in2W = Math.max(0.5f, den * 0.55f);
        inner2.setShader(shInner2);
        inner2.setStrokeWidth(in2W);
        innerR.set(rect.left + den * 3.1f, rect.top + den * 3.1f,
                rect.right - den * 3.1f, rect.bottom - den * 3.1f);
        cv.drawRoundRect(innerR, Math.max(0f, r - den * 3.1f),
                Math.max(0f, r - den * 3.1f), inner2);
        inner2.setShader(null);

        // 【v4.26.0】顶面镜面带：顶边中央一段更集中的短促高光。
        // 真实玻璃的顶面被环境光直接照到，会有一小段特别亮的反光，
        // 这是"液体"和"平涂描边"最容易被眼睛分辨的地方。
        final float tsW = Math.max(0.5f, den * 0.7f);
        topSpec.setShader(shTopSpec);
        topSpec.setStrokeWidth(tsW);
        innerR.set(rect.left + den * 1.1f, rect.top + den * 1.1f,
                rect.right - den * 1.1f, rect.top + den * 1.1f + tsW);
        cv.drawRoundRect(innerR, tsW, tsW, topSpec);
        topSpec.setShader(null);

        // 【v4.26.0】底部焦散：下沿反光上方一层极淡的暖色散射，
        // 玻璃与背景接触的地方会有一圈被托起来的暖光。
        glow.setShader(shCaustic);
        cv.drawRect(rect, glow);
        glow.setShader(null);

        // ⑨ 边缘色散：左冷右暖 —— 塑料永远没有的一笔
        final float dpW = Math.max(1f, den * 0.9f);
        disp.setShader(shDisp);
        disp.setStrokeWidth(dpW);
        innerR.set(rect.left + den * 2.6f, rect.top + den * 2.6f,
                rect.right - den * 2.6f, rect.bottom - den * 2.6f);
        cv.drawRoundRect(innerR, Math.max(0f, r - den * 2.6f),
                Math.max(0f, r - den * 2.6f), disp);
        disp.setShader(null);

        // ⑩ 底缘反光：玻璃下沿被「地面」反射托起的一线亮 —— 悬浮感的关键一笔
        final float fh = Math.max(1f, den);
        foot.setShader(shFootL);
        cv.drawRect(rect.left + r * 0.45f, rect.bottom - fh - 1f,
                rect.right - r * 0.45f, rect.bottom - 1f, foot);
        foot.setShader(null);
    }

    @Override
    public boolean onTouchEvent(MotionEvent ev) {
        // 只是为了让 isPressed() 在整块面板范围内也能触发提亮；
        // 子控件自己消费掉事件的，走各自的按压态。
        return super.onTouchEvent(ev);
    }

    @Override
    public void setPressed(boolean pressed) {
        boolean changed = isPressed() != pressed;
        super.setPressed(pressed);
        if (changed) invalidate();
    }

    /** 上次扫光时间：控件反复显隐时也不会一直闪着 */
    private long lastSheenAt;

    /**
     * 控件从隐藏变可见时扫一道光。
     * 点一下画面唤出控制条，玻璃像被「重新注满」—— 这点微动效是液态感的关键，
     * 但只在显隐的那一刻跑一次，静止时一个属性动画都不挂。
     */
    @Override
    protected void onVisibilityChanged(View changedView, int visibility) {
        super.onVisibilityChanged(changedView, visibility);
        if (changedView == this && visibility == VISIBLE && getWindowVisibility() == VISIBLE) {
            long now = android.os.SystemClock.uptimeMillis();
            if (now - lastSheenAt > 1200) {
                lastSheenAt = now;
                playSheen();
            }
        }
    }

    @Override
    protected void onDetachedFromWindow() {
        if (sheenAnim != null) {
            sheenAnim.cancel();
            sheenAnim = null;
        }
        super.onDetachedFromWindow();
    }

    private static int withAlpha(int rgb, int alpha) {
        return (Math.max(0, Math.min(255, alpha)) << 24) | (rgb & 0x00FFFFFF);
    }

    /** 细颗粒 64×64（固定种子，每次启动颗粒一致） */
    private static void ensureNoise() {
        if (noise == null || noise.isRecycled()) {
            noise = makeNoise(64, 24, 20241126L);
        }
        if (noiseCoarse == null || noiseCoarse.isRecycled()) {
            noiseCoarse = makeNoise(22, 40, 20241127L);
        }
    }

    private static Bitmap makeNoise(int n, int maxA, long seed) {
        try {
            int[] px = new int[n * n];
            java.util.Random rnd = new java.util.Random(seed);
            for (int i = 0; i < px.length; i++) {
                int a = rnd.nextInt(maxA);
                px[i] = (a << 24) | 0x00FFFFFF;
            }
            return Bitmap.createBitmap(px, n, n, Bitmap.Config.ARGB_8888);
        } catch (Throwable ignore) {
            return null;
        }
    }
}
