package com.bixiaoqu.app;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Handler;
import android.os.Looper;
import android.util.LruCache;
import android.widget.ImageView;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * 轻量封面图加载器（不引入任何图片库，保持 APK 体积）：
 * · 内存 LRU（8MB）+ 磁盘缓存（cacheDir/img）
 * · 后台线程池下载，二次采样解码到目标尺寸附近
 * · 带 B 站图床要求的 Referer，避免 403
 */
public class ImgLoader {

    /**
     * 【v4.9 16MB → v4.14.8 24MB → v4.15.3 32MB】竖屏滑动要同时缓存
     * 「下一条 + 再下一条 + 上一条」的封面，一张全宽竖屏封面解码后约 4~5MB，
     * 缓存太小会导致预取的封面互相逐出，滑动时照样要等网络（等于白预取）。
     * 32MB 能稳定装下更多张，列表来回滑动命中率更高、更少走网络，体感更顺。
     */
    static final LruCache<String, Bitmap> mem =
            new LruCache<String, Bitmap>(32 * 1024 * 1024) {
                @Override protected int sizeOf(String k, Bitmap b) {
                    return b == null ? 0 : b.getByteCount();
                }
            };

    /** 【v4.12】图片下载线程提到高优先级：封面出图快慢直接决定「卡不卡」的体感 */
    static final ExecutorService pool = Executors.newFixedThreadPool(4,
            new java.util.concurrent.ThreadFactory() {
                @Override public Thread newThread(Runnable r) {
                    Thread t = new Thread(r, "bxq-img");
                    t.setPriority(Thread.NORM_PRIORITY + 1);
                    return t;
                }
            });
    static final Handler ui = new Handler(Looper.getMainLooper());
    static File dir;

    public static void init(File cacheDir) {
        try {
            dir = new File(cacheDir, "img");
            if (!dir.exists()) dir.mkdirs();
        } catch (Throwable ignore) { }
    }

    /** 绑定到 ImageView；离开视野后被复用也能通过 tag 校验避免错图 */
    public static void load(ImageView iv, String rawUrl, final int w, final int h) {
        if (iv == null) return;
        // 【v4.16.0】按控件实际像素挑分辨率：以前固定 @320w，平板横屏一列 500px 起步，
        // 320 宽的图被拉伸 2 倍，糊成一片。这里按目标宽自动换 @Nw_Nh。
        final String url = fit(https(rawUrl), w, h);
        if (url.isEmpty()) {
            iv.setTag(null);
            iv.setImageBitmap(null);
            return;
        }
        // 【v4.14.8】复用行时若当前显示的已是同一张图，直接跳过，避免重复 setImageBitmap
        // 触发的无谓重绘（列表快速滑动时这是主要的掉帧来源之一）。
        if (url.equals(iv.getTag()) && iv.getDrawable() != null) {
            Bitmap cur = mem.get(url);
            if (cur != null && iv.getDrawable() instanceof android.graphics.drawable.BitmapDrawable
                    && ((android.graphics.drawable.BitmapDrawable) iv.getDrawable()).getBitmap() == cur) {
                return;
            }
        }
        iv.setTag(url);
        Bitmap b = mem.get(url);
        if (b != null) {
            if (iv.getDrawable() instanceof android.graphics.drawable.BitmapDrawable
                    && ((android.graphics.drawable.BitmapDrawable) iv.getDrawable()).getBitmap() == b) {
                return;   // 已是这张，别重复设
            }
            iv.setImageBitmap(b);
            return;
        }
        iv.setImageBitmap(null);
        pool.execute(new Runnable() {
            @Override public void run() {
                final Bitmap bm = fetch(url, w, h);
                if (bm == null) return;
                mem.put(url, bm);
                ui.post(new Runnable() {
                    @Override public void run() {
                        if (url.equals(iv.getTag())) iv.setImageBitmap(bm);
                    }
                });
            }
        });
    }

    /**
     * 【v4.9 预取】只把图片下载并写入内存 LRU，不绑定任何 ImageView。
     *
     * 【为什么需要单独一个方法】fetch() 原来只落磁盘，不写 mem；
     * 而滑到下一条时要立刻显示封面，如果 mem 里没有就得重新走网络 → 卡一下。
     * 提前预取进 mem，滑动时 ImgLoader.load() 会直接命中内存，零等待。
     */
    public static void prefetch(String rawUrl, final int w, final int h) {
        final String url = fit(https(rawUrl), w, h);
        if (url.isEmpty()) return;
        if (mem.get(url) != null) return;   // 已在内存，不必重复
        pool.execute(new Runnable() {
            @Override public void run() {
                Bitmap bm = fetch(url, w, h);
                if (bm != null) mem.put(url, bm);
            }
        });
    }

    /** 本地视频缩略图。【v4.11.0】API 29 的 loadThumbnail 降到全版本走 MediaMetadataRetriever */
    public static void loadUri(final ImageView iv, final android.net.Uri uri,
                               final int w, final int h) {
        if (iv == null || uri == null) return;
        final String key = "uri:" + uri;
        iv.setTag(key);
        Bitmap b = mem.get(key);
        if (b != null) { iv.setImageBitmap(b); return; }
        pool.execute(new Runnable() {
            @Override public void run() {
                Bitmap bm = Compat.videoThumb(iv.getContext(), uri, w, h);
                if (bm == null) return;
                mem.put(key, bm);
                final Bitmap fb = bm;
                ui.post(new Runnable() {
                    @Override public void run() {
                        if (key.equals(iv.getTag())) iv.setImageBitmap(fb);
                    }
                });
            }
        });
    }

    /** B 站图床的尺寸后缀：...@320w_200h_1c.jpg */
    static final java.util.regex.Pattern PIC_SIZE =
            java.util.regex.Pattern.compile("@(\\d+)w_(\\d+)h_1c\\.(jpg|png|webp)$");

    /**
     * 【v4.16.0】按显示像素重写图床尺寸参数。
     *
     * VideoItem.thumb() 一律拼 @320w_200h_1c，手机双列（约 500px）就已经偏糊，
     * 平板横屏四列 / 竖屏三列时更明显。这里在真正下载前把尺寸换成
     * 「控件像素 × 1.15」（轻微超采样），并夹在 1080px 以内避免浪费流量。
     * 原本就是 480w 以上的高清图不动。
     */
    static String fit(String url, int w, int h) {
        if (url == null || url.isEmpty() || w <= 0 || h <= 0) return url;
        try {
            java.util.regex.Matcher m = PIC_SIZE.matcher(url);
            if (!m.find()) return url;
            int cw = Integer.parseInt(m.group(1));
            int need = (int) (Math.min(1080, Math.max(w, cw)) * 1.15f);
            if (cw >= need - 32) return url;               // 已经够清晰，别多下一份
            int nh = Math.max(1, (int) ((long) need * h / w));
            return url.substring(0, m.start()) + "@" + need + "w_" + nh + "h_1c." + m.group(3);
        } catch (Throwable e) {
            return url;
        }
    }

    /**
     * 【v4.10.2】把封面地址统一成 https。
     * B 站老接口（space/arc/search、动态 feed）返回的 pic 常是 http://i0.hdslb.com/...，
     * 而 targetSdk 34 默认禁止明文 HTTP（nsc 只放行 127.0.0.1），
     * 结果「我的」投稿与动态页的封面全部加载失败、只剩灰块。
     * 图床本身支持 https，这里直接升级协议，一处修复所有页面。
     */
    public static String https(String url) {
        if (url == null) return "";
        String u = url.trim();
        if (u.isEmpty()) return "";
        if (u.startsWith("//")) return "https:" + u;
        if (u.startsWith("http://")) return "https://" + u.substring("http://".length());
        return u;
    }

    static Bitmap fetch(String url, int w, int h) {
        if (dir == null) return null;
        try {
            File f = new File(dir, md5(url) + ".img");
            if (f.exists() && f.length() > 0) {
                Bitmap b = decode(f, w, h);
                if (b != null) return b;
                f.delete();
            }
            HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
            c.setConnectTimeout(8000);
            c.setReadTimeout(12000);
            c.setRequestProperty("User-Agent", BiliApi.UA);
            c.setRequestProperty("Referer", "https://www.bilibili.com/");
            c.setRequestProperty("Accept", "image/avif,image/webp,image/*,*/*;q=0.8");
            if (c.getResponseCode() != 200) { c.disconnect(); return null; }
            InputStream in = c.getInputStream();
            File tmp = new File(dir, md5(url) + ".tmp");
            FileOutputStream out = new FileOutputStream(tmp);
            byte[] buf = new byte[16 * 1024];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            out.close();
            in.close();
            c.disconnect();
            if (!tmp.renameTo(f)) { tmp.delete(); return null; }
            return decode(f, w, h);
        } catch (Throwable e) {
            return null;
        }
    }

    static Bitmap decode(File f, int w, int h) {
        try {
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeFile(f.getAbsolutePath(), o);
            if (o.outWidth <= 0) return null;
            int sample = 1;
            while (o.outWidth / (sample * 2) >= w && o.outHeight / (sample * 2) >= h) sample *= 2;
            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = sample;
            o2.inPreferredConfig = Bitmap.Config.RGB_565; // 封面不需要 alpha，省一半内存
            return BitmapFactory.decodeFile(f.getAbsolutePath(), o2);
        } catch (Throwable e) {
            return null;
        }
    }

    static String md5(String s) {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            byte[] d = md.digest(s.getBytes("UTF-8"));
            StringBuilder sb = new StringBuilder();
            for (byte b : d) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Throwable e) {
            return String.valueOf(s.hashCode());
        }
    }

    /** 清空磁盘封面缓存（设置里可调用） */
    public static void clearDisk() {
        try {
            if (dir == null) return;
            File[] fs = dir.listFiles();
            if (fs == null) return;
            for (File f : fs) f.delete();
        } catch (Throwable ignore) { }
    }

    /** 磁盘缓存占用（字节） */
    public static long diskSize() {
        long n = 0;
        try {
            if (dir == null) return 0;
            File[] fs = dir.listFiles();
            if (fs == null) return 0;
            for (File f : fs) n += f.length();
        } catch (Throwable ignore) { }
        return n;
    }

    /** 清空内存缓存（清磁盘时一起做） */
    public static void clearMem() {
        try { mem.evictAll(); } catch (Throwable ignore) { }
    }
}
