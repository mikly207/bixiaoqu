package com.bixiaoqu.app;

import android.content.Context;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.KeyFactory;
import java.security.PublicKey;
import java.security.Signature;
import java.security.spec.X509EncodedKeySpec;
import java.util.UUID;

/**
 * 【v4.45】捐赠状态服务端校验客户端。
 *
 * 背景：v4.44 的「我已完成支付 → 点一下就解锁」是前端自证，属于恶性漏洞 ——
 * 任何人点一下「已支付，确认解锁」都能获得捐赠身份，因为写的是本地布尔值。
 *
 * v4.45 把裁决权彻底移到服务端：
 *   · App 端**不再存在**任何「点了就置成功」的写路径；
 *   · 捐赠状态只认服务端返回、且被服务端 RSA 私钥签名过的凭证（receipt + sign）；
 *   · App 内置服务端公钥，验签通过才认账；本地缓存被改写也无法伪造「已捐赠」；
 *   · 每次登录前都要向服务端拉一次状态（在线校验），断网时最多使用未过期的
 *     服务端签名凭证兜底（凭证本身带过期时间，且离线时长受限）。
 *
 * 纯逻辑（拼接 payload、验签、解析）不依赖 Android 运行时，可直接 JVM 单测。
 */
public class DonateApi {

    // ===================== 常量 =====================

    /** 服务端地址（用户可在设置里改成自己的部署地址） */
    public static final String DEFAULT_SERVER = "";

    /**
     * 【v4.45】服务端公钥（X.509 DER，Base64）。
     * 部署者替换成自己服务端 keys/donate_pub.der 的 Base64 即可。
     * 私钥永远只在服务端，App 内只固化公钥 —— 客户端无法伪造签名。
     */
    public static final String DEFAULT_PUB_KEY_B64 = "";

    /** 请求超时（毫秒）：登录门禁要快速反馈，不能让用户干等 */
    static final int CONNECT_TIMEOUT = 8000;
    static final int READ_TIMEOUT = 10000;

    /** 凭证可接受的最长离线时长：超过则必须联网重新确认 */
    static final long MAX_OFFLINE_GRACE_MS = 72L * 3600 * 1000L;

    // ===================== 结果模型 =====================

    /** 校验结论 */
    public static final int ST_UNKNOWN = 0;   // 尚未向服务端确认过
    public static final int ST_PAID = 1;      // 服务端确认已支付
    public static final int ST_UNPAID = 2;    // 服务端确认未支付
    public static final int ST_ERROR = 3;     // 网络/验签等异常
    /**
     * 【v4.46】未启用在线核验（作者尚未部署服务端 / 未执行一键打包脚本）。
     * 此时按宽松模式处理，不阻断用户使用。
     */
    public static final int ST_RELAXED = 4;

    /** 服务端返回并已通过验签的捐赠状态 */
    public static class Status {
        public int state = ST_UNKNOWN;
        public boolean paid;
        public int amount;
        public String method = "";
        public String orderId = "";
        public String deviceId = "";
        public String uid = "";
        public long issuedAt;
        public long expiresAt;
        public String receipt = "";
        public String sign = "";
        public String message = "";

        public boolean isPaid() { return state == ST_PAID && paid; }
    }

    // ===================== 设备身份 =====================

    /**
     * 设备唯一标识（首次启动随机生成，存本机）。
     * 它只是「这台设备」的身份，不是账号身份 —— 账号身份在登录后由服务端 bind 绑定。
     */
    public static String deviceId(Context c) {
        String v = Prefs.donateDeviceId(c);
        if (v == null || v.length() == 0) {
            v = "d" + UUID.randomUUID().toString().replace("-", "");
            Prefs.setDonateDeviceId(c, v);
        }
        return v;
    }

    /** 设备密钥：用于向服务端证明「是我这台设备在问」，防止他人冒用设备 ID 查询 */
    public static String deviceKey(Context c) {
        String v = Prefs.donateDeviceKey(c);
        if (v == null || v.length() == 0) {
            v = "k" + UUID.randomUUID().toString().replace("-", "");
            Prefs.setDonateDeviceKey(c, v);
        }
        return v;
    }

    // ===================== 纯逻辑（可 JVM 单测）=====================

    /**
     * 拼接规范化 payload —— 必须与服务端 canonical() 完全一致。
     * 格式：v1|device_id|uid|paid|amount|method|order_id|issued_at|expires_at
     */
    public static String canonical(String deviceId, String uid, boolean paid, int amount,
                                  String method, String orderId, long issuedAt, long expiresAt) {
        return "v1|" + nz(deviceId) + "|" + nz(uid) + "|" + (paid ? "1" : "0") + "|"
                + amount + "|" + nz(method) + "|" + nz(orderId) + "|"
                + issuedAt + "|" + expiresAt;
    }

    static String nz(String s) { return s == null ? "" : s; }

    /** hex 字符串 → 字节数组 */
    public static byte[] hexToBytes(String hex) {
        if (hex == null) return new byte[0];
        String t = hex.trim();
        int n = t.length() / 2;
        byte[] out = new byte[n];
        for (int i = 0; i < n; i++) {
            out[i] = (byte) Integer.parseInt(t.substring(i * 2, i * 2 + 2), 16);
        }
        return out;
    }

    /** 字节数组 → 小写 hex */
    public static String bytesToHex(byte[] b) {
        if (b == null) return "";
        StringBuilder sb = new StringBuilder(b.length * 2);
        for (byte x : b) {
            String h = Integer.toHexString(x & 0xFF);
            if (h.length() == 1) sb.append('0');
            sb.append(h);
        }
        return sb.toString();
    }

    /**
     * 用服务端公钥验证签名。
     * 公钥为 X.509 DER 的 Base64 字符串；签名为 hex。
     */
    public static boolean verify(String payload, String signHex, String pubKeyB64) {
        if (payload == null || signHex == null || pubKeyB64 == null) return false;
        if (signHex.length() == 0 || pubKeyB64.length() == 0) return false;
        byte[] der = decodePubKey(pubKeyB64);
        if (der == null || der.length == 0) return false;
        try {
            KeyFactory kf = KeyFactory.getInstance("RSA");
            PublicKey pk = kf.generatePublic(new X509EncodedKeySpec(der));
            Signature sig = Signature.getInstance("SHA256withRSA");
            sig.initVerify(pk);
            sig.update(payload.getBytes("UTF-8"));
            return sig.verify(hexToBytes(signHex));
        } catch (Throwable t) {
            return false;
        }
    }

    /**
     * 解析服务端公钥：支持 Base64 与 hex 两种写法（部署时更不易出错）。
     *
     * 【v4.45】这里刻意不用 android.util.Base64 / java.util.Base64：
     *   · android.util.Base64 在 JVM 单测里是 stub（会抛异常），无法验证签名逻辑；
     *   · java.util.Base64 需要 API 26，而本 App 的 minSdk 是 22。
     * 因此自实现一份纯 Java 解码，两边都能跑。
     */
    static byte[] decodePubKey(String s) {
        if (s == null) return null;
        String t = s.trim().replaceAll("\\s", "");
        if (t.length() == 0) return null;
        // 全是十六进制字符且长度为偶数 → 按 hex 解析
        if (t.length() % 2 == 0 && t.matches("[0-9a-fA-F]+")) {
            byte[] b = hexToBytes(t);
            // DER 序列化的 RSA 公钥以 0x30 开头，可据此排除误判
            if (b.length > 0 && (b[0] & 0xFF) == 0x30) return b;
        }
        return base64Decode(t);
    }

    /** 纯 Java Base64 解码（不依赖 android.util.Base64 / API 26） */
    static byte[] base64Decode(String in) {
        String t = in.replaceAll("[^A-Za-z0-9+/=]", "");
        int n = t.length();
        if (n == 0) return new byte[0];
        int pad = 0;
        if (t.charAt(n - 1) == '=') pad++;
        if (n > 1 && t.charAt(n - 2) == '=') pad++;
        int groups = n / 4;
        int tail = n % 4;
        int outLen = groups * 3 + (tail == 2 ? 1 : (tail == 3 ? 2 : 0)) - pad;
        if (outLen < 0) return new byte[0];
        byte[] out = new byte[outLen];
        int oi = 0;
        int i = 0;
        while (i + 3 < n) {
            int v0 = b64Val(t.charAt(i));
            int v1 = b64Val(t.charAt(i + 1));
            int v2 = t.charAt(i + 2) == '=' ? 0 : b64Val(t.charAt(i + 2));
            int v3 = t.charAt(i + 3) == '=' ? 0 : b64Val(t.charAt(i + 3));
            if (oi < out.length) out[oi++] = (byte) ((v0 << 2) | (v1 >> 4));
            if (oi < out.length) out[oi++] = (byte) (((v1 & 0xF) << 4) | (v2 >> 2));
            if (oi < out.length) out[oi++] = (byte) (((v2 & 0x3) << 6) | v3);
            i += 4;
        }
        if (tail == 2) {
            int v0 = b64Val(t.charAt(i));
            int v1 = b64Val(t.charAt(i + 1));
            if (oi < out.length) out[oi++] = (byte) ((v0 << 2) | (v1 >> 4));
        } else if (tail == 3) {
            int v0 = b64Val(t.charAt(i));
            int v1 = b64Val(t.charAt(i + 1));
            int v2 = b64Val(t.charAt(i + 2));
            if (oi < out.length) out[oi++] = (byte) ((v0 << 2) | (v1 >> 4));
            if (oi < out.length) out[oi++] = (byte) (((v1 & 0xF) << 4) | (v2 >> 2));
        }
        return out;
    }

    static int b64Val(char c) {
        if (c >= 'A' && c <= 'Z') return c - 'A';
        if (c >= 'a' && c <= 'z') return c - 'a' + 26;
        if (c >= '0' && c <= '9') return c - '0' + 52;
        if (c == '+') return 62;
        if (c == '/') return 63;
        return 0;
    }

    /**
     * 校验服务端返回的状态对象：验签 + 过期检查 + 设备归属检查。
     * 任何一项不过，都判为不可信（不会因为「本地缓存写着已支付」就放行）。
     */
    public static boolean isTrusted(Status st, String expectDeviceId, String pubKeyB64, long now) {
        if (st == null) return false;
        if (st.receipt == null || st.sign == null || st.sign.length() == 0) return false;
        // 1) 签名必须由服务端私钥签出
        if (!verify(st.receipt, st.sign, pubKeyB64)) return false;
        // 2) receipt 内容必须与服务端下发的字段一致（防止字段被改但签名未覆盖）
        String expect = canonical(st.deviceId, st.uid, st.paid, st.amount, st.method,
                st.orderId, st.issuedAt, st.expiresAt);
        if (!expect.equals(st.receipt)) return false;
        // 3) 必须是本机设备的状态
        if (expectDeviceId != null && !expectDeviceId.equals(st.deviceId)) return false;
        // 4) 不能是过期凭证
        if (st.expiresAt <= 0 || st.expiresAt <= now) return false;
        return true;
    }

    /** 解析服务端 JSON 的 data 段为 Status（不做验签，验签由 isTrusted 完成） */
    public static Status parseData(JSONObject data) {
        Status st = new Status();
        if (data == null) return st;
        st.paid = data.optBoolean("paid", false);
        st.amount = data.optInt("amount", 0);
        st.method = data.optString("method", "");
        st.orderId = data.optString("order_id", "");
        st.deviceId = data.optString("device_id", "");
        st.uid = data.optString("uid", "");
        st.issuedAt = data.optLong("issued_at", 0L);
        st.expiresAt = data.optLong("expires_at", 0L);
        st.receipt = data.optString("receipt", "");
        st.sign = data.optString("sign", "");
        st.state = st.paid ? ST_PAID : ST_UNPAID;
        return st;
    }

    // ===================== 网络（需 Android 运行时）=====================

    /**
     * 服务端地址 —— 【v4.46】改为**编译期内置**，不再让终端用户去设置页填。
     * 作者用「一键部署打包.sh」把它写进 DonateConfig。
     */
    public static String serverUrl(Context c) {
        String v = DonateConfig.SERVER_URL;
        if (v == null || v.trim().length() == 0) v = DEFAULT_SERVER;
        return v.trim();
    }

    /** 公钥 —— 【v4.46】编译期内置，私钥永远不在客户端 */
    public static String pubKey(Context c) {
        String v = DonateConfig.PUB_KEY_B64;
        if (v == null || v.trim().length() == 0) v = DEFAULT_PUB_KEY_B64;
        return v.trim();
    }

    /** 是否已启用在线核验（作者已执行一键打包脚本写入内置配置） */
    public static boolean configured(Context c) {
        return serverUrl(c).length() > 0 && pubKey(c).length() > 0;
    }

    /**
     * 【v4.46】宽松模式：作者尚未部署在线核验服务（内置配置为空）时的降级策略。
     *
     * 此时 App **不会**把用户拦在门外要求填配置 —— 那对终端用户极不友好；
     * 而是按「本地自助开通」处理。
     *
     * 注意：一旦作者执行一键打包脚本写入内置配置，本方法恒为 false，
     * 捐赠状态依旧只由服务端裁决（安全性不降级）。
     */
    public static boolean relaxedMode() {
        return !DonateConfig.onlineEnabled();
    }

    /** 宽松凭证的固定标记（放在 receipt 的 uid 位，便于快速识别） */
    public static final String RELAXED_MARK = "relaxed";

    /**
     * 【v4.46.1 修复】统一的「是否已开通」判定 —— 全 App 只有这一份实现。
     *
     * 【BUG 修复说明】此前存在两份各自独立的判定：
     *   · 捐赠页：宽松模式下写入 sign="relaxed" 的凭证后**直接显示「解锁成功」**；
     *   · 登录门禁：统一走 isTrusted() 验签，而 "relaxed" 必然验签失败 →
     *     于是「显示已解锁」但「点登录又被拦回捐赠页」，形成死循环。
     *
     * 现在两处都调用本方法，判定口径完全一致：
     *   · 在线核验已启用 → 必须服务端签名验签通过（安全不降级）；
     *   · 宽松模式      → 认可本地宽松凭证（且未过期）。
     */
    public static boolean isUnlocked(Context c) {
        String receipt = Prefs.donateReceipt(c);
        long exp = Prefs.donateExpires(c);
        // 【v4.46.1】兼容已在 v4.46 付过钱的用户：他们本地存的是字段顺序写错的老凭证，
        // 这里自动迁移成正确格式，避免修完 bug 后老用户反而登不进去。
        receipt = migrateLegacyRelaxed(c, receipt, exp);
        return isUnlocked(receipt, Prefs.donateSign(c), exp,
                relaxedMode(), deviceId(c), pubKey(c), System.currentTimeMillis());
    }

    /**
     * 【v4.46.1】老凭证迁移。
     *
     * v4.46 的宽松凭证误写成 "v1|relaxed|deviceId||1|amount|method||issued|expires"，
     * 即把 relaxed 标记写在了 deviceId 位（正确应为 uid 位）。
     * 检测到这种老格式时，按正确字段顺序重写并回存，金额/方式/有效期全部保留。
     */
    static String migrateLegacyRelaxed(Context c, String receipt, long exp) {
        String fixed = migrateLegacyRelaxedPure(receipt, exp);
        if (fixed != null && !fixed.equals(receipt)) {
            // 回写修正后的凭证（金额/方式/有效期从新凭证里取）
            try {
                String[] f = fixed.split("\\|");
                int amount = 0;
                try { amount = Integer.parseInt(f[4]); } catch (Throwable t) { amount = 0; }
                long newExp = 0;
                try { newExp = Long.parseLong(f[8]); } catch (Throwable t) { newExp = 0; }
                Prefs.saveDonateReceipt(c, fixed, RELAXED_MARK, newExp, amount,
                        f.length > 5 ? f[5] : "", "", "");
            } catch (Throwable ignore) { }
        }
        return fixed == null ? receipt : fixed;
    }

    /**
     * 【v4.46.1】老凭证迁移核心（纯逻辑，可单测）。
     *
     * @return 修正后的凭证；若无需迁移则原样返回
     */
    public static String migrateLegacyRelaxedPure(String receipt, long exp) {
        if (receipt == null || receipt.length() == 0) return receipt;
        if (isRelaxedReceipt(receipt)) return receipt;         // 已是新格式
        String[] f = receipt.split("\\|");
        if (f.length < 9) return receipt;
        if (!"v1".equals(f[0])) return receipt;
        if (!RELAXED_MARK.equals(f[1])) return receipt;          // 不是老宽松格式
        // 老格式：deviceId 在 f[2]，amount 在 f[5]，method 在 f[6]，expires 在 f[8]
        String dev = f[2];
        int amount = 0;
        try { amount = Integer.parseInt(f[5]); } catch (Throwable t) { amount = 0; }
        String method = f[6] == null ? "" : f[6];
        long issued = 0;
        try { issued = Long.parseLong(f[7]); } catch (Throwable t) { issued = 0; }
        long newExp = exp > 0 ? exp : 0;
        try {
            long fromReceipt = Long.parseLong(f[8]);
            if (newExp <= 0) newExp = fromReceipt;
        } catch (Throwable ignore) { }
        return canonical(dev, RELAXED_MARK, true, amount, method, "", issued, newExp);
    }

    /**
     * 【v4.46.1】判定核心（纯逻辑，可 JVM 单测）。
     *
     * @param receipt    本地缓存的凭证（可为 null）
     * @param sign       凭证签名（宽松模式为 RELAXED_MARK）
     * @param expiresAt  凭证过期时间（毫秒）
     * @param relaxed    是否宽松模式（作者未部署在线核验）
     * @param devId      本机设备 ID
     * @param pubKey     服务端公钥（宽松模式可为空）
     * @param now        当前时间
     */
    public static boolean isUnlocked(String receipt, String sign, long expiresAt,
                                     boolean relaxed, String devId, String pubKey, long now) {
        if (receipt == null || receipt.length() == 0) return false;
        if (expiresAt <= 0 || expiresAt <= now) return false;   // 过期一律不算
        if (relaxed) {
            // 宽松模式：凭证的 uid 位必须是宽松标记（字段顺序由 canonical 保证）
            return RELAXED_MARK.equals(sign) && isRelaxedReceipt(receipt);
        }
        // 在线模式：必须服务端签名验签通过
        Status st = new Status();
        st.receipt = receipt;
        st.sign = sign;
        st.expiresAt = expiresAt;
        st.deviceId = devId;
        st.paid = true;
        st.issuedAt = 0;
        parseReceiptInto(st, receipt);
        return isTrusted(st, devId, pubKey, now);
    }

    /**
     * 判断凭证是否为合法的宽松凭证。
     * 【v4.46.1 修复】必须按 canonical 的字段顺序解析：
     *   v1|deviceId|uid|paid|amount|method|orderId|issuedAt|expiresAt
     * uid 位（第 3 段）须等于 RELAXED_MARK，deviceId 位（第 2 段）须等于本机设备 ID。
     */
    public static boolean isRelaxedReceipt(String receipt) {
        String[] f = receipt.split("\\|");
        if (f.length < 9) return false;
        if (!"v1".equals(f[0])) return false;
        if (!RELAXED_MARK.equals(f[2])) return false;      // uid 位
        if (!"1".equals(f[3])) return false;              // paid 位
        return true;
    }

    /** 把 receipt 的字段解析进 Status（供上面复用） */
    static void parseReceiptInto(Status st, String receipt) {
        String[] f = receipt.split("\\|");
        if (f.length >= 9) {
            st.deviceId = f[1];
            st.uid = f[2];
            st.paid = "1".equals(f[3]);
            try { st.amount = Integer.parseInt(f[4]); } catch (Throwable t) { st.amount = 0; }
            st.method = f[5];
            st.orderId = f[6];
            try { st.issuedAt = Long.parseLong(f[7]); } catch (Throwable t) { st.issuedAt = 0; }
            try { st.expiresAt = Long.parseLong(f[8]); } catch (Throwable t) { st.expiresAt = 0; }
        }
    }

    /**
     * 【v4.46.1】从本地缓存的凭证还原为 Status（统一解析，避免各处重复实现）。
     */
    public static Status statusFromReceipt(Context c, String receipt) {
        Status st = new Status();
        st.receipt = receipt;
        st.sign = Prefs.donateSign(c);
        st.expiresAt = Prefs.donateExpires(c);
        st.amount = Prefs.donateAmount(c);
        st.method = Prefs.donateMethod(c);
        st.orderId = Prefs.donateOrder(c);
        st.uid = Prefs.donateUid(c);
        st.deviceId = deviceId(c);
        st.paid = true;
        st.issuedAt = 0;
        parseReceiptInto(st, receipt);
        return st;
    }

    /**
     * 向服务端查询本机捐赠状态（同步，必须在后台线程调用）。
     * 返回值一定是「服务端确认过的」结论 —— 验签不过就是 ST_ERROR。
     */
    public static Status queryStatus(Context c) {
        Status st = new Status();
        String base = serverUrl(c);
        if (base.length() == 0) {
            // 【v4.46】作者未启用在线核验：不报错，交给调用方按宽松模式处理
            st.state = ST_RELAXED;
            st.message = "本版本未启用在线核验";
            return st;
        }
        String url = base + "/api/donate/status?device_id=" + enc(deviceId(c))
                + "&key=" + enc(deviceKey(c));
        try {
            String body = httpGet(url);
            JSONObject root = new JSONObject(body);
            if (root.optInt("code", -1) != 0) {
                st.state = ST_ERROR;
                st.message = root.optString("msg", "服务端返回异常");
                return st;
            }
            Status s = parseData(root.optJSONObject("data"));
            if (!isTrusted(s, deviceId(c), pubKey(c), System.currentTimeMillis())) {
                s.state = ST_ERROR;
                s.message = "服务端凭证验签失败，状态不可信";
                s.paid = false;
                return s;
            }
            // 验签通过才落到本地缓存（缓存的是服务端签名凭证，不是本地布尔值）
            Prefs.saveDonateReceipt(c, s.receipt, s.sign, s.expiresAt, s.amount, s.method,
                    s.orderId, s.uid);
            return s;
        } catch (Throwable t) {
            st.state = ST_ERROR;
            st.message = "连接捐赠服务失败：" + (t.getMessage() == null ? t.getClass().getSimpleName() : t.getMessage());
            return st;
        }
    }

    /**
     * 创建订单（用户点了「去支付」时调用），返回订单号；失败返回空串。
     */
    public static String createOrder(Context c, int amount, String method) {
        String base = serverUrl(c);
        if (base.length() == 0) return "";
        try {
            JSONObject body = new JSONObject();
            body.put("device_id", deviceId(c));
            body.put("key", deviceKey(c));
            body.put("amount", Math.max(1, amount));
            body.put("method", method == null ? "wechat" : method);
            String uid = BiliApi.loggedInUid();
            if (uid != null) body.put("uid", uid);
            String r = httpPost(base + "/api/donate/order", body.toString());
            JSONObject root = new JSONObject(r);
            if (root.optInt("code", -1) != 0) return "";
            JSONObject d = root.optJSONObject("data");
            if (d == null) return "";
            return d.optString("order_id", "");
        } catch (Throwable t) {
            return "";
        }
    }

    /** 把设备与 B 站账号在服务端绑定（登录成功后调用，失败不阻断登录） */
    public static void bindUid(Context c, String uid) {
        if (uid == null || uid.length() == 0) return;
        String base = serverUrl(c);
        if (base.length() == 0) return;
        try {
            JSONObject body = new JSONObject();
            body.put("device_id", deviceId(c));
            body.put("key", deviceKey(c));
            body.put("uid", uid);
            httpPost(base + "/api/donate/bind", body.toString());
        } catch (Throwable ignore) { }
    }

    static String enc(String s) {
        try {
            return java.net.URLEncoder.encode(s == null ? "" : s, "UTF-8");
        } catch (Throwable t) {
            return s == null ? "" : s;
        }
    }

    static String httpGet(String url) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        try {
            c.setConnectTimeout(CONNECT_TIMEOUT);
            c.setReadTimeout(READ_TIMEOUT);
            c.setRequestProperty("Accept", "application/json");
            c.setRequestProperty("User-Agent", "BXQ-Donate/1.0");
            int code = c.getResponseCode();
            InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
            String body = readAll(in);
            if (code >= 400) throw new IllegalStateException("HTTP " + code);
            return body;
        } finally {
            try { c.disconnect(); } catch (Throwable ignore) { }
        }
    }

    static String httpPost(String url, String json) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        try {
            c.setConnectTimeout(CONNECT_TIMEOUT);
            c.setReadTimeout(READ_TIMEOUT);
            c.setRequestMethod("POST");
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            c.setRequestProperty("Accept", "application/json");
            c.setRequestProperty("User-Agent", "BXQ-Donate/1.0");
            byte[] raw = json.getBytes("UTF-8");
            c.setFixedLengthStreamingMode(raw.length);
            OutputStream os = c.getOutputStream();
            try { os.write(raw); os.flush(); } finally { try { os.close(); } catch (Throwable ignore) { } }
            int code = c.getResponseCode();
            InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
            String body = readAll(in);
            if (code >= 400) throw new IllegalStateException("HTTP " + code);
            return body;
        } finally {
            try { c.disconnect(); } catch (Throwable ignore) { }
        }
    }

    static String readAll(InputStream in) throws Exception {
        if (in == null) return "";
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        byte[] buf = new byte[4096];
        int n;
        while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
        try { in.close(); } catch (Throwable ignore) { }
        return bos.toString("UTF-8");
    }
}
