#!/bin/bash
# 哔小趣 · 捐赠校验服务 一键部署打包
# 用法：bash 一键部署打包.sh https://donate.example.com
# 作用：生成密钥 → 写入 App 内置配置 → 编译双 APK
# 终端用户无需任何配置，扫码捐赠即自动开通。
set -e
URL="${1:-http://127.0.0.1:8788}"; URL="${URL%/}"
D="$(cd "$(dirname "$0")" && pwd)"

# 定位 App 源码（本脚本可放在 捐赠校验服务/ 或 源码包根目录）
for S in "$D/../.." "$D/.." "$D"; do
  [ -d "$S/app" ] && [ -d "$S/app_phone" ] && SRC="$(cd "$S" && pwd)" && break
done
[ -n "${SRC:-}" ] || { echo "找不到 app/ 源码目录"; exit 1; }

# 1. 密钥
mkdir -p "$D/keys"
if [ ! -f "$D/keys/donate_priv.pem" ]; then
  node -e "
const {generateKeyPairSync}=require('crypto'),fs=require('fs');
const {publicKey,privateKey}=generateKeyPairSync('rsa',{modulusLength:2048,
  publicKeyEncoding:{type:'spki',format:'der'},privateKeyEncoding:{type:'pkcs8',format:'pem'}});
fs.writeFileSync('$D/keys/donate_priv.pem',privateKey);
fs.writeFileSync('$D/keys/donate_pub.der',publicKey);"
  echo "✓ 已生成密钥 keys/donate_priv.pem（私钥勿外传）"
fi

# 2. 写入内置配置（服务地址 + 公钥 Base64）
PUB=$(node -e "console.log(require('fs').readFileSync('$D/keys/donate_pub.der').toString('base64'))")
for T in app app_phone; do
  F="$SRC/$T/src/com/bixiaoqu/app/DonateConfig.java"
  [ -f "$F" ] || continue
  node -e "
const fs=require('fs');const f='$F';let s=fs.readFileSync(f,'utf8');
s=s.replace(/(public static final String SERVER_URL = \")[^\"]*(\")/, '\$1$URL\$2');
s=s.replace(/(public static final String PUB_KEY_B64 = \")[^\"]*(\")/, '\$1$PUB\$2');
fs.writeFileSync(f,s);"
  echo "✓ $T 已写入内置配置"
done

# 3. 打包
for T in app app_phone; do
  [ -f "$SRC/$T/build.sh" ] || continue
  ( cd "$SRC/$T" && bash build.sh >/tmp/bxq_$T.log 2>&1 ) \
    && echo "✓ $T 构建完成" \
    || { echo "✗ $T 构建失败："; tail -20 /tmp/bxq_$T.log; exit 1; }
done

cat <<EOF

==============================================
 ✅ 打包完成
==============================================
 服务地址 : $URL

 ① 启动服务：cd $D && ADMIN_TOKEN=你的强口令 node server.js
 ② 核对到账：$URL/admin  （输入管理员令牌后点「核销」）
 ③ 分发 APK ：用户无需任何配置，扫码捐赠即自动开通

 提示：服务器请用 HTTPS；私钥 keys/donate_priv.pem 勿外传、勿提交 Git。
==============================================
EOF
