/**
 * 【v4.46.1】回归测试：修复「付了钱显示解锁成功，却登录不进去」的死循环。
 *
 * 复现的用户场景：
 *   1) 终端用户扫码支付（作者未部署在线核验 → 宽松模式）
 *   2) 捐赠页写入本地凭证后显示「✓ 解锁成功」
 *   3) 用户点「登录」→ 必须能进，不能再被弹回捐赠页
 *
 * 根因：捐赠页与登录门禁各写一套判定 —— 捐赠页认宽松凭证，
 *      门禁用 isTrusted() 验签（宽松凭证必然失败）→ 状态显示与实际判定不一致。
 *
 * 本测试确保：
 *   · 宽松凭证能被统一判定识别（字段顺序必须符合 canonical）
 *   · 状态条显示「已解锁」与门禁放行永远一致
 *   · 在线模式下安全性不降级（仍须服务端签名验签）
 */
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.Signature;

import com.bixiaoqu.app.DonateApi;

public class DonateUnlockFixTest {

    static int passed = 0, failed = 0;

    static void check(String name, boolean ok) {
        if (ok) { passed++; System.out.println("  ✓ " + name); }
        else { failed++; System.out.println("  ✗ " + name); }
    }

    /** 构造一个「服务端凭证」样式的字符串（用于验证不会被误迁移） */
    static String svcReceiptStub() {
        return "v1|drealuser01|10086|1|10|wechat|ORD7|1700000000000|1700003600000";
    }

    static String sign(PrivateKey priv, String payload) throws Exception {
        Signature s = Signature.getInstance("SHA256withRSA");
        s.initSign(priv);
        s.update(payload.getBytes("UTF-8"));
        return DonateApi.bytesToHex(s.sign());
    }

    public static void main(String[] args) throws Exception {
        System.out.println("=== DonateUnlockFixTest（v4.46.1 解锁后仍登录不了）===");

        long now = 1_700_000_000_000L;
        long exp = now + 365L * 24 * 3600 * 1000;
        String dev = "drealuser01";

        // ================= 场景 A：宽松模式（当前交付的 APK 状态）=================
        System.out.println("\n-- 场景A：宽松模式，付钱后必须能登录 --");

        // A1) 宽松凭证按 canonical 正确构造（这就是修复后的写法）
        String good = DonateApi.canonical(dev, DonateApi.RELAXED_MARK, true, 1,
                "wechat", "", now, exp);
        check("宽松凭证字段顺序正确（uid 位是 relaxed 标记）",
                good.equals("v1|" + dev + "|relaxed|1|1|wechat||" + now + "|" + exp));
        check("宽松凭证被识别为宽松凭证", DonateApi.isRelaxedReceipt(good));

        // A2) 【核心】显示已解锁 == 门禁放行
        boolean gate = DonateApi.isUnlocked(good, DonateApi.RELAXED_MARK, exp,
                true, dev, "", now);
        check("宽松模式下门禁放行（不会再被弹回捐赠页）", gate);

        // A3) 修复前的错误写法（relaxed 落在 deviceId 位）必须被识别为无效
        String buggy = "v1|relaxed|" + dev + "||1|1||" + now + "|" + exp;
        check("修复前的错误字段顺序不再被误判为宽松凭证",
                !DonateApi.isRelaxedReceipt(buggy));
        check("修复前的错误凭证不再放行（避免误判）",
                !DonateApi.isUnlocked(buggy, DonateApi.RELAXED_MARK, exp, true, dev, "", now));

        // A4) 过期凭证不放行
        check("过期宽松凭证不放行",
                !DonateApi.isUnlocked(good, DonateApi.RELAXED_MARK, now - 1,
                        true, dev, "", now));

        // A5) 无凭证不放行
        check("无凭证不放行",
                !DonateApi.isUnlocked("", DonateApi.RELAXED_MARK, exp, true, dev, "", now));
        check("null 凭证不放行",
                !DonateApi.isUnlocked(null, DonateApi.RELAXED_MARK, exp, true, dev, "", now));

        // A6) 签名标记不对（宽松模式必须带 RELAXED_MARK）
        check("签名标记非 relaxed 时不放行",
                !DonateApi.isUnlocked(good, "deadbeef", exp, true, dev, "", now));

        // ================= 场景 A2：老用户升级迁移（当前用户的处境）=================
        System.out.println("\n-- 场景A2：已在 v4.46 付过钱的老用户升级后必须能登录 --");
        // v4.46 实际写入的老格式（relaxed 落在 deviceId 位）
        String legacy = "v1|relaxed|" + dev + "||1|1|wechat||" + now + "|" + exp;
        check("老凭证确实不是新格式", !DonateApi.isRelaxedReceipt(legacy));

        String migrated = DonateApi.migrateLegacyRelaxedPure(legacy, exp);
        check("老凭证被迁移成正确格式", DonateApi.isRelaxedReceipt(migrated));
        check("迁移后金额保留", migrated.contains("|1|wechat|"));
        check("迁移后设备 ID 保留", migrated.startsWith("v1|" + dev + "|"));
        check("迁移后过期时间保留", migrated.endsWith("|" + exp));

        // 迁移后门禁必须放行 —— 这正是用户「付了钱却登不进」的修复点
        boolean migratedGate = DonateApi.isUnlocked(migrated, DonateApi.RELAXED_MARK, exp,
                true, dev, "", now);
        check("【核心】老用户迁移后门禁放行（付过钱就能登录）", migratedGate);

        // 迁移是幂等的：再迁一次结果不变
        check("迁移幂等（重复迁移结果一致）",
                DonateApi.migrateLegacyRelaxedPure(migrated, exp).equals(migrated));

        // 非老格式的凭证不应被误改
        check("服务端凭证不被误迁移",
                DonateApi.migrateLegacyRelaxedPure(svcReceiptStub(), exp).equals(svcReceiptStub()));
        check("乱码凭证不被误迁移",
                DonateApi.migrateLegacyRelaxedPure("garbage", exp).equals("garbage"));

        // ================= 场景 B：在线模式（作者已部署服务端）=================
        System.out.println("\n-- 场景B：在线模式，安全性不降级 --");
        KeyPairGenerator g = KeyPairGenerator.getInstance("RSA");
        g.initialize(2048);
        KeyPair kp = g.generateKeyPair();
        String pubB64 = java.util.Base64.getEncoder().encodeToString(kp.getPublic().getEncoded());

        String svcReceipt = DonateApi.canonical(dev, "10086", true, 10,
                "wechat", "ORD7", now, now + 3600_000L);
        String svcSig = sign(kp.getPrivate(), svcReceipt);

        check("服务端签名凭证放行（在线模式）",
                DonateApi.isUnlocked(svcReceipt, svcSig, now + 3600_000L,
                        false, dev, pubB64, now));

        // B2) 在线模式下，宽松凭证绝不能放行（防止绕过服务端校验）
        check("在线模式下宽松凭证不放行（安全不降级）",
                !DonateApi.isUnlocked(good, DonateApi.RELAXED_MARK, exp,
                        false, dev, pubB64, now));

        // B3) 在线模式下篡改 paid 必须被拒
        String forged = svcReceipt.replaceFirst("\\|1\\|10\\|", "|0|10|");
        check("在线模式篡改 paid 后不放行",
                !DonateApi.isUnlocked(forged, svcSig, now + 3600_000L,
                        false, dev, pubB64, now));

        // B4) 在线模式下换公钥必须被拒
        KeyPair other = g.generateKeyPair();
        String otherPub = java.util.Base64.getEncoder().encodeToString(other.getPublic().getEncoded());
        check("在线模式用非服务端公钥不放行",
                !DonateApi.isUnlocked(svcReceipt, svcSig, now + 3600_000L,
                        false, dev, otherPub, now));

        // B5) 在线模式下过期凭证不放行
        check("在线模式过期凭证不放行",
                !DonateApi.isUnlocked(svcReceipt, svcSig, now + 3600_000L,
                        false, dev, pubB64, now + 3600_000L + 1));

        System.out.println("\n通过 " + passed + " / 失败 " + failed);
        if (failed > 0) System.exit(1);
    }
}
