/**
 * 【v4.46】配置内置化与极简开通体验 —— 纯逻辑单测。
 *
 * 覆盖重点：
 *   1. DonateConfig.onlineEnabled()：两个常量都填了才算启用在线核验；
 *   2. DonateApi.relaxedMode()：未启用时为 true（不把用户拦在门外）；
 *   3. 宽松模式下写入的凭证不会让「服务端已确认」文案误显示（不应伪装成服务端确认）；
 *   4. 服务端签名凭证的字段解析（parseReceiptFields 等价逻辑）正确；
 *   5. 端到端：服务端签名 → App 验签 → 判定已支付。
 */
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.Signature;

import com.bixiaoqu.app.DonateApi;
import com.bixiaoqu.app.DonateConfig;

public class DonateConfigTest {

    static int passed = 0, failed = 0;

    static void check(String name, boolean ok) {
        if (ok) { passed++; System.out.println("  ✓ " + name); }
        else { failed++; System.out.println("  ✗ " + name); }
    }

    static String sign(PrivateKey priv, String payload) throws Exception {
        Signature s = Signature.getInstance("SHA256withRSA");
        s.initSign(priv);
        s.update(payload.getBytes("UTF-8"));
        return DonateApi.bytesToHex(s.sign());
    }

    public static void main(String[] args) throws Exception {
        System.out.println("=== DonateConfigTest（v4.46 配置内置化）===");

        // ---------- 1) onlineEnabled 语义 ----------
        // 当前交付态：两个常量均为空 → 未启用在线核验
        boolean enabled = DonateConfig.onlineEnabled();
        check("交付态常量默认为空（作者需执行一键脚本写入）",
                !DonateConfig.SERVER_URL.trim().isEmpty() || !enabled);
        check("常量都为空时 onlineEnabled=false", !enabled);
        check("常量都为空时 relaxedMode=true（不拦用户）",
                DonateApi.relaxedMode() == !enabled);

        // ---------- 2) 常量非空时语义相反 ----------
        // 用反射无法改 final，这里直接验证判定函数的表达式语义
        boolean wouldEnable = DonateConfig.SERVER_URL.trim().length() > 0
                && DonateConfig.PUB_KEY_B64.trim().length() > 0;
        check("两常量均非空时 onlineEnabled 应为 true（脚本写入后成立）", !wouldEnable || enabled);
        check("relaxedMode 与 onlineEnabled 互斥",
                DonateApi.relaxedMode() != wouldEnable || wouldEnable == enabled);

        // ---------- 3) 宽松模式凭证不会被误认为服务端确认 ----------
        // 宽松模式写入的 sign 是 "relaxed"（非真实签名），验签必然失败
        long now = 1_700_000_000_000L;
        String relaxedReceipt = "v1|devrelaxed||1|1|wechat||" + now + "|" + (now + 1000L);
        check("宽松模式凭证无法通过服务端验签（不会被当成已确认）",
                !DonateApi.verify(relaxedReceipt, "relaxed", "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAtest"));

        // ---------- 4) 真实服务端签名的凭证可以被接受 ----------
        KeyPairGenerator g = KeyPairGenerator.getInstance("RSA");
        g.initialize(2048);
        KeyPair kp = g.generateKeyPair();
        String pubB64 = java.util.Base64.getEncoder().encodeToString(kp.getPublic().getEncoded());

        String dev = "devcfg1";
        String receipt = DonateApi.canonical(dev, "10086", true, 10, "wechat", "ORD9",
                now, now + 3600_000L);
        String sig = sign(kp.getPrivate(), receipt);

        DonateApi.Status st = new DonateApi.Status();
        st.receipt = receipt; st.sign = sig;
        String[] f = receipt.split("\\|");
        st.deviceId = f[1]; st.uid = f[2]; st.paid = "1".equals(f[3]);
        st.amount = Integer.parseInt(f[4]); st.method = f[5]; st.orderId = f[6];
        st.issuedAt = Long.parseLong(f[7]); st.expiresAt = Long.parseLong(f[8]);
        st.state = st.paid ? DonateApi.ST_PAID : DonateApi.ST_UNPAID;

        check("服务端签名凭证验签通过", DonateApi.verify(receipt, sig, pubB64));
        check("isTrusted 判定可信", DonateApi.isTrusted(st, dev, pubB64, now));
        check("状态判定为已支付", st.isPaid());
        check("金额/方式解析正确", st.amount == 10 && "wechat".equals(st.method));

        // ---------- 5) 过期与异机凭证仍被拒（安全不降级）----------
        check("过期凭证被拒", !DonateApi.isTrusted(st, dev, pubB64, now + 3600_000L + 1));
        check("异机凭证被拒", !DonateApi.isTrusted(st, "devother", pubB64, now));

        System.out.println("通过 " + passed + " / 失败 " + failed);
        if (failed > 0) System.exit(1);
    }
}
