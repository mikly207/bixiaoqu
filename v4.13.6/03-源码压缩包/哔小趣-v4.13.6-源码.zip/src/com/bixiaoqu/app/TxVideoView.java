package com.bixiaoqu.app;

import android.content.Context;
import android.media.MediaPlayer;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.VideoView;

/**
 * 视频显示控件。
 *
 * 【v4.9.3 最终方案：内核用系统 VideoView】
 *
 * 前面两版在这个问题上绕了弯路，记录清楚以免再犯：
 *  · v4.9  用 TextureView → 部分设备「有声音、画面全黑」（渲染通道没接上，非解码问题）
 *  · v4.9.2 用自写 SurfaceView → 把建流绑死在 surfaceCreated 上，Surface 迟迟不来时
 *           连 prepare 都不执行，表现是「一直转圈、声画全无」
 *
 * 结论：视频输出这条链路上的坑（Surface 生命周期、prepare 时序、厂商定制）比想象的多，
 * 自己实现一遍等于把所有机型的兼容性重新踩一遍。系统 VideoView 内部就是
 * SurfaceView + MediaPlayer，已经把「Surface 没就绪先建流、就绪后补 setDisplay」
 * 等边界全部处理好了，v4.8 也实测可用。
 *
 * 所以这里改成「包装 VideoView」，对外接口保持不变（PlayActivity 无需改动）。
 * 代价：VideoView 是独立图层，父容器位移时画面跟随会晚 1~2 帧（Android 7+ 支持变换）。
 */
public class TxVideoView extends FrameLayout {

    final VideoView vv;
    /** 是否已渲染出第一帧（画面自检用） */
    boolean firstFrame = false;

    public TxVideoView(Context c) {
        super(c);
        setBackgroundColor(0xFF000000);
        vv = new VideoView(c);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT);
        lp.gravity = android.view.Gravity.CENTER;
        vv.setLayoutParams(lp);
        addView(vv);
        // 首帧信号用 VideoView 暴露的 setOnInfoListener（内部会链式转发，
        // 不会破坏 VideoView 自身的状态机；直接动 MediaPlayer 的 listener 有风险）
        try {
            vv.setOnInfoListener(new MediaPlayer.OnInfoListener() {
                @Override public boolean onInfo(MediaPlayer m, int what, int extra) {
                    if (what == MediaPlayer.MEDIA_INFO_VIDEO_RENDERING_START) firstFrame = true;
                    return false;
                }
            });
        } catch (Throwable ignore) { }
    }

    // ------------------------------------------------------------ 对外接口（与 VideoView 对齐）

    public void setVideoPath(String path) {
        if (path == null || path.isEmpty()) return;
        firstFrame = false;
        vv.setVideoPath(path);
    }

    public void start() {
        try { vv.start(); } catch (Throwable ignore) { }
    }

    public void pause() {
        try { if (vv.isPlaying()) vv.pause(); } catch (Throwable ignore) { }
    }

    public void seekTo(int ms) {
        try { vv.seekTo(ms); } catch (Throwable ignore) { }
    }

    public int getCurrentPosition() {
        try { return vv.getCurrentPosition(); } catch (Throwable e) { return 0; }
    }

    public int getDuration() {
        try { return vv.getDuration(); } catch (Throwable e) { return 0; }
    }

    public boolean isPlaying() {
        try { return vv.isPlaying(); } catch (Throwable e) { return false; }
    }

    public void stopPlayback() {
        firstFrame = false;
        try { vv.stopPlayback(); } catch (Throwable ignore) { }
    }

    public void setOnPreparedListener(MediaPlayer.OnPreparedListener l) {
        vv.setOnPreparedListener(l);
    }

    public void setOnErrorListener(MediaPlayer.OnErrorListener l) {
        vv.setOnErrorListener(l);
    }

    /** 是否已经渲染出第一帧 */
    public boolean hasRenderedFrame() {
        if (firstFrame) return true;
        // 部分设备不回调 MEDIA_INFO_VIDEO_RENDERING_START，用进度兜底，避免看门狗误报
        try {
            if (vv.isPlaying() && vv.getCurrentPosition() > 800) return true;
        } catch (Throwable ignore) { }
        return false;
    }

    /** 兼容旧接口：VideoView 自己会管理 Surface，无需外部重绑 */
    public void rebindSurface() {
        // 空实现，保留方法签名避免调用方报错
    }
}
