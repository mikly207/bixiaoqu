package com.bixiaoqu.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

/**
 * 【v4.45】捐赠页 —— 捐赠状态由服务端裁决后解锁登录。
 *
 * 说明文字由需求方给定；金额档位：1 / 5 / 10 / 100 元 + 自定义（最低 1 元）。
 * 收款码为需求方提供的微信 / 支付宝静态收款码（裁剪自原图，保留四角定位符与白边）。
 *
 * 【v4.45 安全修复】v4.44 的「我已完成支付 → 点一下就解锁」是前端自证漏洞：
 * 写的是本地布尔值，任何人点一下都能冒充已捐赠。现在：
 *   · 页面**没有**任何「点了就置成功」的路径；
 *   · 状态只认服务端返回、并被服务端 RSA 私钥签名过的凭证（App 内置公钥验签）；
 *   · 点「刷新状态」只是向服务端查询，服务器说没收到回调就仍然显示未支付；
 *   · 已支付只能来自：支付网关回调（微信/支付宝官方异步通知）或管理员后台核销。
 */
public class DonateActivity extends Activity {

    final int[] AMOUNTS = {1, 5, 10, 100};
    int selectedAmount = 1;          // 当前选中金额（元），自定义时为用户输入值
    boolean customSelected = false;  // 是否处于自定义金额
    String method = "wechat";        // wechat | alipay

    int C_BG = 0xFF16181d, C_CARD = 0xFF1f2229, C_FG = 0xFFe8eaf0,
            C_SUB = 0xFF9aa0ab, C_ACC = 0xFFfb7299;
    int appliedStamp = -1;

    LinearLayout amountRow;
    TextView[] amountViews = new TextView[4];
    TextView customBtn;
    ImageView qrImage;
    TextView payHint;
    TextView wechatTab, alipayTab;
    TextView stateText;
    TextView orderHint;      // 【v4.45】当前订单号提示
    String orderId = "";     // 【v4.45】服务端生成的订单号
    TextView applyBtn;       // 【v4.46】申请开通按钮
    Handler pollHandler;     // 【v4.46】自动轮询
    boolean polling = false; // 【v4.46】是否正在轮询
    int pollCount = 0;       // 【v4.46】已轮询次数

    int dp(float v) { return (int) (getResources().getDisplayMetrics().density * v + 0.5f); }

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        MainActivity.applyTheme(this);
        syncTheme();
        appliedStamp = MainActivity.themeStampOf(this);
        setContentView(build());
    }

    void syncTheme() {
        try {
            C_BG = MainActivity.C_BG; C_CARD = MainActivity.C_CARD;
            C_FG = MainActivity.C_FG; C_SUB = MainActivity.C_SUB; C_ACC = MainActivity.C_ACC;
        } catch (Throwable ignore) {}
    }

    @Override protected void onResume() {
        super.onResume();
        if (appliedStamp != MainActivity.themeStampOf(this)) recreate();
        // 【v4.46】回到本页时静默向服务端确认一次（用户可能在别处付的款）
        refreshStateText();
    }

    @Override protected void onDestroy() {
        // 【v4.46】停止自动轮询，避免后台空转
        stopPolling();
        super.onDestroy();
    }

    GradientDrawable round(int color, float rdp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(rdp));
        return g;
    }

    View build() {
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(C_BG);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(12), dp(16), dp(28));

        // ---- 顶栏 ----
        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        ImageView back = Ic.view(this, "back", C_FG, 22);
        back.setPadding(dp(6), dp(6), dp(10), dp(6));
        back.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { finish(); }
        });
        top.addView(back, new LinearLayout.LayoutParams(dp(40), dp(44)));
        TextView title = new TextView(this);
        title.setText("支持我们");
        title.setTextColor(C_FG);
        title.setTextSize(19);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        top.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        root.addView(top, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // ---- 已解锁状态条（已捐赠时显示）----
        stateText = new TextView(this);
        stateText.setTextSize(12.5f);
        stateText.setPadding(dp(12), dp(10), dp(12), dp(10));
        stateText.setBackground(round(C_CARD, 10));
        refreshStateText();
        root.addView(stateText, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // ---- 说明文字（需求方给定原文）----
        final String desc = "这款软件投入了海量资源与精力打磨，无广告商业化。为持续承载服务、维护更新，"
                + "设置最低1元捐赠，捐赠后即可正常登录使用，您的每一份支持都十分珍贵";
        TextView descTv = new TextView(this);
        descTv.setText(desc);
        descTv.setTextColor(C_FG);
        descTv.setTextSize(14.5f);
        descTv.setLineSpacing(dp(5), 1f);
        descTv.setPadding(dp(14), dp(14), dp(14), dp(14));
        descTv.setBackground(round(C_CARD, 12));
        root.addView(descTv, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // ---- 金额选择 ----
        TextView amountTitle = new TextView(this);
        amountTitle.setText("选择捐赠金额（最低 1 元）");
        amountTitle.setTextColor(C_SUB);
        amountTitle.setTextSize(13);
        amountTitle.setPadding(dp(2), dp(18), dp(2), dp(8));
        root.addView(amountTitle, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        amountRow = new LinearLayout(this);
        amountRow.setOrientation(LinearLayout.HORIZONTAL);
        for (int i = 0; i < AMOUNTS.length; i++) {
            final int idx = i;
            TextView t = amountChip(AMOUNTS[i] + " 元");
            t.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    customSelected = false;
                    selectedAmount = AMOUNTS[idx];
                    refreshAmountChips();
                }
            });
            amountViews[i] = t;
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            if (i > 0) lp.leftMargin = dp(8);
            amountRow.addView(t, lp);
        }
        root.addView(amountRow, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        customBtn = amountChip("自定义");
        customBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showCustomAmountDialog(); }
        });
        LinearLayout.LayoutParams cbp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        cbp.topMargin = dp(10);
        root.addView(customBtn, cbp);

        // ---- 支付方式 Tab ----
        TextView payTitle = new TextView(this);
        payTitle.setText("选择支付方式，扫码捐赠");
        payTitle.setTextColor(C_SUB);
        payTitle.setTextSize(13);
        payTitle.setPadding(dp(2), dp(20), dp(2), dp(10));
        root.addView(payTitle, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout tabs = new LinearLayout(this);
        tabs.setOrientation(LinearLayout.HORIZONTAL);
        wechatTab = payTab("微信支付", 0xFF07C160);
        alipayTab = payTab("支付宝", 0xFF1677FF);
        wechatTab.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { switchMethod("wechat"); }
        });
        alipayTab.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { switchMethod("alipay"); }
        });
        tabs.addView(wechatTab, new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        alipayTab.setPadding(dp(10), dp(10), dp(10), dp(10));
        LinearLayout.LayoutParams atp = new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        atp.leftMargin = dp(10);
        tabs.addView(alipayTab, atp);
        root.addView(tabs, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // ---- 收款码卡片 ----
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackgroundColor(Color.WHITE);
        card.setPadding(dp(18), dp(18), dp(18), dp(18));
        qrImage = new ImageView(this);
        qrImage.setScaleType(ImageView.ScaleType.FIT_CENTER);
        qrImage.setAdjustViewBounds(true);
        card.addView(qrImage, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(300)));
        payHint = new TextView(this);
        payHint.setTextColor(0xFF333333);
        payHint.setTextSize(12.5f);
        payHint.setGravity(Gravity.CENTER);
        payHint.setPadding(0, dp(10), 0, 0);
        card.addView(payHint, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        LinearLayout.LayoutParams ccp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        ccp.topMargin = dp(12);
        root.addView(card, ccp);

        // ---- 支付说明 ----
        TextView tip = new TextView(this);
        tip.setText("支付方式：打开对应 App 扫码 → 支付 " + selectedAmount + " 元 → 回到本页点「我已支付，申请开通」");
        tip.setTextColor(C_SUB);
        tip.setTextSize(11.5f);
        tip.setGravity(Gravity.CENTER);
        tip.setPadding(dp(4), dp(14), dp(4), dp(4));
        root.addView(tip, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // ---- 订单号提示（转账备注填订单号，便于后台核销）----
        orderHint = new TextView(this);
        orderHint.setTextColor(C_SUB);
        orderHint.setTextSize(11);
        orderHint.setGravity(Gravity.CENTER);
        orderHint.setPadding(dp(4), dp(2), dp(4), dp(4));
        orderHint.setVisibility(View.GONE);
        root.addView(orderHint, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // ---- 申请开通按钮（只向服务端查询，不会在本地置成功）----
        TextView confirm = new TextView(this);
        confirm.setText("我已支付，申请开通");
        applyBtn = confirm;
        confirm.setTextColor(Color.WHITE);
        confirm.setTextSize(15);
        confirm.setTypeface(Typeface.DEFAULT_BOLD);
        confirm.setGravity(Gravity.CENTER);
        confirm.setPadding(dp(12), dp(14), dp(12), dp(14));
        confirm.setBackground(round(C_ACC, 12));
        confirm.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { applyUnlock(); }
        });
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        cp.topMargin = dp(16);
        root.addView(confirm, cp);

        // ---- 【v4.47.1】设备 ID 区块：用户付完款把这段发给作者即可开通 ----
        LinearLayout devBox = new LinearLayout(this);
        devBox.setOrientation(LinearLayout.VERTICAL);
        devBox.setPadding(dp(14), dp(12), dp(14), dp(12));
        devBox.setBackground(round(C_CARD, 12));
        TextView devTitle = new TextView(this);
        devTitle.setText("付款后请把下面这串「设备 ID」发给作者");
        devTitle.setTextColor(C_FG);
        devTitle.setTextSize(13);
        devTitle.setTypeface(Typeface.DEFAULT_BOLD);
        devBox.addView(devTitle, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        TextView devId = new TextView(this);
        devId.setText(DonateApi.deviceId(this));
        devId.setTextColor(C_ACC);
        devId.setTextSize(13);
        devId.setPadding(0, dp(8), 0, dp(8));
        devId.setTextIsSelectable(true);
        devBox.addView(devId, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        TextView devCopy = new TextView(this);
        devCopy.setText("复制设备 ID");
        devCopy.setTextColor(Color.WHITE);
        devCopy.setTextSize(13);
        devCopy.setGravity(Gravity.CENTER);
        devCopy.setPadding(dp(10), dp(9), dp(10), dp(9));
        devCopy.setBackground(round(C_ACC, 10));
        final String devIdText = DonateApi.deviceId(this);
        devCopy.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                copyToClipboard(devIdText);
                Toast.makeText(DonateActivity.this, "已复制，发给作者即可", Toast.LENGTH_SHORT).show();
            }
        });
        devBox.addView(devCopy, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        LinearLayout.LayoutParams devLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        devLp.topMargin = dp(16);
        root.addView(devBox, devLp);

        // ---- 底部小字 ----
        TextView foot = new TextView(this);
        foot.setText("捐赠状态由服务端校验后生效，本地仅缓存服务端签名凭证");
        foot.setTextColor(C_SUB);
        foot.setTextSize(10.5f);
        foot.setGravity(Gravity.CENTER);
        foot.setPadding(0, dp(14), 0, 0);
        root.addView(foot, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        sv.addView(root, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        refreshAmountChips();
        switchMethod(method);
        return sv;
    }

    TextView amountChip(String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(13.5f);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(6), dp(11), dp(6), dp(11));
        return t;
    }

    void refreshAmountChips() {
        for (int i = 0; i < amountViews.length; i++) {
            boolean on = !customSelected && selectedAmount == AMOUNTS[i];
            amountViews[i].setTextColor(on ? Color.WHITE : C_FG);
            amountViews[i].setBackground(round(on ? C_ACC : C_CARD, 10));
        }
        customBtn.setText(customSelected ? ("自定义 " + selectedAmount + " 元") : "自定义");
        customBtn.setTextColor(customSelected ? Color.WHITE : C_FG);
        customBtn.setBackground(round(customSelected ? C_ACC : C_CARD, 10));
    }

    TextView payTab(String text, int brand) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(14);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(10), dp(11), dp(10), dp(11));
        t.setTag(brand);
        return t;
    }

    void switchMethod(String m) {
        method = m;
        boolean wc = "wechat".equals(m);
        int active = wc ? 0xFF07C160 : 0xFF1677FF;
        wechatTab.setTextColor(wc ? Color.WHITE : 0xFF07C160);
        wechatTab.setBackground(round(wc ? active : 0x2207C160, 10));
        alipayTab.setTextColor(wc ? 0xFF1677FF : Color.WHITE);
        alipayTab.setBackground(round(wc ? 0x221677FF : active, 10));

        int rid = getResources().getIdentifier(
                wc ? "donate_wechat_qr" : "donate_alipay_qr", "drawable", getPackageName());
        if (rid != 0) qrImage.setImageResource(rid);
        payHint.setText(wc ? "打开微信扫一扫 · 捐赠 " + selectedAmount + " 元"
                : "打开支付宝扫一扫 · 捐赠 " + selectedAmount + " 元");
    }

    void showCustomAmountDialog() {
        final EditText et = new EditText(this);
        et.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        et.setHint("输入金额（元，最低 1 元）");
        et.setTextColor(C_FG);
        et.setHintTextColor(C_SUB);
        new AlertDialog.Builder(this)
                .setTitle("自定义捐赠金额")
                .setView(et)
                .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int w) {
                        String s = et.getText().toString().trim();
                        int v;
                        try { v = (int) Math.floor(Double.parseDouble(s)); }
                        catch (Throwable e) { v = 0; }
                        if (v < 1) {
                            Toast.makeText(DonateActivity.this, "金额不能低于 1 元", Toast.LENGTH_SHORT).show();
                            return;
                        }
                        customSelected = true;
                        selectedAmount = v;
                        refreshAmountChips();
                        switchMethod(method);
                    }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    // ===================== 【v4.45】服务端校验 =====================

    /**
     * 【v4.46】申请开通 —— 用户视角只有这一个动作。
     *
     * 【v4.45 安全修复保留】原先这里是「我已完成支付 → 二次确认 → 本地写凭证 → 解锁」，
     * 属于前端自证，任何人点一下都能冒充已捐赠。该路径已彻底删除，本方法不会在本地置成功。
     *
     * 【v4.46 体验简化】用户不该被要求填任何配置，也不该看到报错弹窗。
     * 现在点按钮后：自动向服务端申请订单 → 自动轮询等待核销 → 服务端确认后自动开通。
     */
    void applyUnlock() {
        if (selectedAmount < 1) {
            Toast.makeText(this, "请先选择至少 1 元的金额", Toast.LENGTH_SHORT).show();
            return;
        }
        // 【v4.47 关键】未配置服务端时**绝不放行**。
        // v4.46 曾在此处写本地凭证直接开通，导致「没付款点一下就能登录」。
        // 现在没有服务端就无法核验支付，只能提示作者去配置，不给用户任何假成功。
        if (!DonateApi.configured(this)) {
            // 【v4.47.1】让用户把「设备 ID」交给作者 —— 作者据此即可直接开通，
            // 不要求用户先做任何其它操作。这是作者侧「手动开通」功能的配套。
            final String devId = DonateApi.deviceId(this);
            new AlertDialog.Builder(this)
                    .setTitle("请把设备 ID 发给作者")
                    .setMessage("本版本暂由作者人工确认到账。\n\n"
                            + "请把下面的设备 ID 复制发给作者，作者确认收款后即可为你开通：\n\n"
                            + devId)
                    .setPositiveButton("复制设备 ID", new DialogInterface.OnClickListener() {
                        @Override public void onClick(DialogInterface d, int w) {
                            copyToClipboard(devId);
                            Toast.makeText(DonateActivity.this,
                                    "已复制，请发给作者", Toast.LENGTH_LONG).show();
                        }
                    })
                    .setNegativeButton("知道了", null)
                    .show();
            return;
        }
        // 已有服务端确认的凭证：直接开通
        if (hasServerVerifiedDonation()) {
            showUnlocked();
            return;
        }
        startPolling();
    }

    /** 是否已有服务端确认（且验签通过）的捐赠状态 */
    boolean hasServerVerifiedDonation() {
        // 【v4.46.1】统一走 DonateApi.isUnlocked —— 与登录门禁完全同一套判定。
        return DonateApi.isUnlocked(this);
    }

    /**
     * 自动轮询等待服务端核销。
     * 静态收款码需要作者在后台核对一次，因此这里做成「等待中」而非「失败」，
     * 每 2.5 秒查一次，最多约 2 分钟。
     */
    void startPolling() {
        stopPolling();
        polling = true;
        pollCount = 0;
        if (pollHandler == null) pollHandler = new Handler(Looper.getMainLooper());
        if (applyBtn != null) {
            applyBtn.setText("等待确认到账…");
            applyBtn.setBackground(round(0xFF8a8f99, 12));
        }
        stateText.setText("已收到你的申请，正在等待到账确认…");
        stateText.setTextColor(C_ACC);
        Toast.makeText(this, "已提交，正在等待到账确认…", Toast.LENGTH_SHORT).show();
        pollHandler.postDelayed(pollTick, 800);
    }

    void stopPolling() {
        polling = false;
        if (pollHandler != null) pollHandler.removeCallbacks(pollTick);
        if (applyBtn != null) {
            applyBtn.setText("我已支付，申请开通");
            applyBtn.setBackground(round(C_ACC, 12));
        }
    }

    final Runnable pollTick = new Runnable() { @Override public void run() {
        if (!polling || isFinishing()) return;
        pollCount++;
        new Thread(new Runnable() { @Override public void run() {
            // 首次轮询时先确保服务端有一笔对应订单（便于后台按订单号核对到账）
            if (orderId.length() == 0) {
                final String oid = DonateApi.createOrder(DonateActivity.this, selectedAmount, method);
                runOnUiThread(new Runnable() { @Override public void run() {
                    if (!isFinishing() && oid != null && oid.length() > 0) {
                        orderId = oid;
                        showOrderHint(oid);
                    }
                } });
            }
            final DonateApi.Status st = DonateApi.queryStatus(DonateActivity.this);
            runOnUiThread(new Runnable() { @Override public void run() {
                if (!polling || isFinishing()) return;
                if (st.state == DonateApi.ST_PAID) {
                    stopPolling();
                    showUnlocked();
                    return;
                }
                if (pollCount >= 48) {          // 约 2 分钟
                    polling = false;
                    if (applyBtn != null) {
                        applyBtn.setText("我已支付，申请开通");
                        applyBtn.setBackground(round(C_ACC, 12));
                    }
                    stateText.setText("仍在等待到账确认 · 若已转账请稍后再点一次，或稍后重进本页面");
                    stateText.setTextColor(C_ACC);
                    return;
                }
                pollHandler.postDelayed(pollTick, 2500);
            } });
        } }).start();
    } };

    /** 显示订单号（转账备注填它，方便作者核对到账） */
    void showOrderHint(String oid) {
        if (orderHint == null) return;
        orderHint.setVisibility(View.VISIBLE);
        orderHint.setText("订单号 " + oid + "\n转账时在备注里填这个号，作者核对后自动开通");
    }

    /** 服务端已确认 → 展示开通成功 */
    void showUnlocked() {
        String m = "微信".equals(Prefs.donateMethod(this)) ? "微信" : "支付宝";
        int amt = Prefs.donateAmount(this);
        if (amt <= 0) amt = selectedAmount;
        stateText.setText("✓ 感谢你的支持 · 服务端已确认" + m + "捐赠 "
                + amt + " 元，登录已解锁");
        stateText.setTextColor(0xFF5FD08A);
        Toast.makeText(DonateActivity.this, "已开通，登录与全部功能已解锁", Toast.LENGTH_LONG).show();
        setResult(RESULT_OK);
    }

    /** 复制文本到剪贴板（供用户把设备 ID 发给作者） */
    void copyToClipboard(String text) {
        try {
            android.content.ClipboardManager cm =
                    (android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            if (cm != null) cm.setPrimaryClip(android.content.ClipData.newPlainText("device_id", text));
        } catch (Throwable ignore) { }
    }

    /** 依据本地缓存的「服务端签名凭证」刷新状态条（不产生任何置成功效果） */
    void refreshStateText() {
        if (stateText == null) return;
        String receipt = Prefs.donateReceipt(this);
        if (receipt.length() == 0) {
            stateText.setText("尚未解锁登录 · 最低 1 元捐赠即可解锁全部功能");
            stateText.setTextColor(C_ACC);
            return;
        }
        // 【v4.46.1】状态条与登录门禁共用同一套判定（DonateApi.isUnlocked），
        // 保证「显示已解锁」与「真能登录」永远一致。
        if (!DonateApi.isUnlocked(this)) {
            stateText.setText("上次的开通记录需要重新确认 · 点下方按钮即可");
            stateText.setTextColor(C_ACC);
            return;
        }
        DonateApi.Status st = DonateApi.statusFromReceipt(this, receipt);
        String m = "微信".equals(st.method) ? "微信" : "支付宝";
        stateText.setText("✓ 感谢你的支持 · 服务端已确认" + m + "捐赠 "
                + st.amount + " 元，登录已解锁");
        stateText.setTextColor(0xFF5FD08A);
    }

    /** 从 receipt 字符串还原字段（格式与服务端 canonical 一致） */
    void parseReceiptFields(DonateApi.Status st) {
        try {
            String[] p = st.receipt.split("\\|");
            if (p.length < 9) return;
            st.deviceId = p[1];
            st.uid = p[2];
            st.paid = "1".equals(p[3]);
            st.amount = parseIntSafe(p[4]);
            st.method = p[5];
            st.orderId = p[6];
            st.issuedAt = parseLongSafe(p[7]);
            st.expiresAt = parseLongSafe(p[8]);
        } catch (Throwable ignore) { }
    }

    static int parseIntSafe(String s) {
        try { return Integer.parseInt(s); } catch (Throwable t) { return 0; }
    }

    static long parseLongSafe(String s) {
        try { return Long.parseLong(s); } catch (Throwable t) { return 0L; }
    }
}
