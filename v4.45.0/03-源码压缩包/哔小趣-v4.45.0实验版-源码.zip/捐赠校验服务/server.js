#!/usr/bin/env node
/**
 * 哔小趣 · 捐赠校验服务端
 * ---------------------------------------------------------------------------
 * 解决「客户端点击『已支付』就能自证成功」的恶性 bug。
 *
 * 核心原则：**捐赠状态的唯一裁决者是本服务**。
 *   · App 端不做任何「点了就置成功」的前端逻辑；
 *   · 支付成功只能来自两处：
 *       1) 支付网关回调  POST /api/pay/notify   （微信/支付宝官方异步通知，需验签）
 *       2) 管理员人工核销 POST /api/admin/confirm（静态个人收款码场景，后台带令牌核销）
 *   · App 查询状态 GET /api/donate/status 时，返回值由服务端用 RSA-SHA256 私钥签名；
 *     App 内置公钥验签后才认账，因此本地缓存 / 本地改值都无法伪造「已捐赠」。
 *
 * 零第三方依赖，只用 Node 内置模块。数据落盘在同目录 data.json（可直接迁移到 MySQL/PG）。
 *
 * 启动：
 *   node server.js                 # 默认 8788 端口
 *   PORT=9000 node server.js
 *   ADMIN_TOKEN=xxx PAY_SECRET=yyy node server.js
 */

'use strict';

const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const DIR = __dirname;
const DATA_FILE = path.join(DIR, 'data.json');
const KEY_DIR = path.join(DIR, 'keys');
const PRIV_FILE = path.join(KEY_DIR, 'donate_priv.pem');
const PUB_FILE = path.join(KEY_DIR, 'donate_pub.der');
const PUB_HEX_FILE = path.join(KEY_DIR, 'donate_pub.hex');

const PORT = parseInt(process.env.PORT || '8788', 10);
const ADMIN_TOKEN = process.env.ADMIN_TOKEN || '';   // 空则自动生成并写入 data.json
const PAY_SECRET = process.env.PAY_SECRET || '';     // 支付网关回调验签密钥（空则自动生成）
const RECEIPT_TTL_MS = 72 * 3600 * 1000;             // 离线凭证有效期：72 小时

/* ------------------------------------------------------------------ 数据层 */

function defaultDb() {
  return {
    admin_token: '',
    pay_secret: '',
    orders: {},   // order_id -> 订单
    devices: {},  // device_id -> 设备记录（含 key 与已支付信息）
    uids: {},     // uid      -> 账号记录（含已支付信息）
  };
}

let db = defaultDb();

function loadDb() {
  try {
    if (fs.existsSync(DATA_FILE)) {
      const raw = JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
      db = Object.assign(defaultDb(), raw);
    }
  } catch (e) {
    console.error('[warn] data.json 解析失败，使用空库：', e.message);
  }
  // 环境变量优先：便于部署时用固定令牌 / 固定网关密钥覆盖本地随机值
  if (ADMIN_TOKEN) db.admin_token = ADMIN_TOKEN;
  else if (!db.admin_token) db.admin_token = crypto.randomBytes(16).toString('hex');
  if (PAY_SECRET) db.pay_secret = PAY_SECRET;
  else if (!db.pay_secret) db.pay_secret = crypto.randomBytes(16).toString('hex');
  saveDb();
}

function saveDb() {
  fs.writeFileSync(DATA_FILE, JSON.stringify(db, null, 2));
}

/* ------------------------------------------------------------------ 密钥层 */

function ensureKeys() {
  if (!fs.existsSync(KEY_DIR)) fs.mkdirSync(KEY_DIR, { recursive: true });
  if (!fs.existsSync(PRIV_FILE) || !fs.existsSync(PUB_FILE)) {
    const { publicKey, privateKey } = crypto.generateKeyPairSync('rsa', {
      modulusLength: 2048,
      publicKeyEncoding: { type: 'spki', format: 'der' },
      privateKeyEncoding: { type: 'pkcs8', format: 'pem' },
    });
    fs.writeFileSync(PRIV_FILE, privateKey);
    fs.writeFileSync(PUB_FILE, publicKey);
    console.log('[init] 已生成新的 RSA-2048 密钥对（私钥仅存于服务端，切勿提交 Git）');
  }
  const hex = fs.readFileSync(PUB_FILE).toString('hex');
  fs.writeFileSync(PUB_HEX_FILE, hex);
  return hex;
}

/* ------------------------------------------------------------------ 协议层 */

/**
 * 规范化 payload —— 服务端签名与 App 验签必须使用完全一致的拼接规则。
 * 字段顺序固定、分隔符为 |、布尔用 1/0。
 *   v1|device_id|uid|paid|amount|method|order_id|issued_at|expires_at
 */
function canonical(o) {
  return [
    'v1',
    String(o.device_id || ''),
    String(o.uid || ''),
    o.paid ? '1' : '0',
    String(o.amount || 0),
    String(o.method || ''),
    String(o.order_id || ''),
    String(o.issued_at || 0),
    String(o.expires_at || 0),
  ].join('|');
}

function signPayload(payload) {
  // 注意：sign() 传「文件路径」会被 Node 当成待签名数据，必须显式加载成 KeyObject。
  const key = crypto.createPrivateKey(fs.readFileSync(PRIV_FILE, 'utf8'));
  return crypto.createSign('RSA-SHA256').update(payload, 'utf8').sign(key).toString('hex');
}

const ID_RE = /^[A-Za-z0-9_.-]{1,64}$/;

function safeId(v) {
  const s = String(v == null ? '' : v).trim();
  return ID_RE.test(s) ? s : '';
}

/* ------------------------------------------------------------------ 业务层 */

function deviceRecord(deviceId) {
  return db.devices[deviceId] || null;
}

/** 登记设备（首次下单时调用），key 为客户端生成并保管的设备密钥 */
function registerDevice(deviceId, key) {
  if (!deviceId || !key) return null;
  if (!db.devices[deviceId]) {
    db.devices[deviceId] = {
      device_id: deviceId,
      key: key,
      uid: '',
      amount: 0,
      method: '',
      order_id: '',
      paid_at: 0,
      updated_at: 0,
    };
    saveDb();
  }
  return db.devices[deviceId];
}

/** 绑定设备与 B 站 uid（登录成功后调用） */
function bindUid(deviceId, key, uid) {
  if (!deviceId || !key || !uid) return false;
  const dev = deviceRecord(deviceId);
  if (!dev || dev.key !== key) return false;      // 只有持有设备密钥的一方能绑定
  dev.uid = uid;
  if (!db.uids[uid]) db.uids[uid] = { uid, device_id: deviceId, amount: 0, paid_at: 0, updated_at: 0 };
  db.uids[uid].device_id = deviceId;
  db.uids[uid].updated_at = Date.now();
  saveDb();
  return true;
}

/** 标记一笔订单已支付（支付网关回调 / 管理员核销都走这里） */
function markPaid(orderId, amount, method, channel) {
  const ord = db.orders[orderId];
  if (!ord) return false;
  if (ord.status === 'paid') return true;         // 幂等
  ord.status = 'paid';
  ord.paid_at = Date.now();
  ord.channel = channel || '';
  ord.paid_amount = amount || ord.amount;
  // 同步到设备与账号
  const dev = deviceRecord(ord.device_id);
  if (dev) {
    dev.amount = ord.paid_amount;
    dev.method = ord.method;
    dev.order_id = ord.order_id;
    dev.paid_at = ord.paid_at;
    dev.updated_at = ord.paid_at;
    if (ord.uid && !db.uids[ord.uid]) {
      db.uids[ord.uid] = { uid: ord.uid, device_id: ord.device_id, amount: 0, paid_at: 0, updated_at: 0 };
    }
    if (ord.uid) {
      db.uids[ord.uid].amount = ord.paid_amount;
      db.uids[ord.uid].paid_at = ord.paid_at;
      db.uids[ord.uid].updated_at = ord.paid_at;
    }
  }
  saveDb();
  return true;
}

/** 计算某设备的捐赠状态（已支付才有意义） */
function statusOf(deviceId, key) {
  const dev = deviceRecord(deviceId);
  const now = Date.now();
  const paid = !!(dev && dev.key === key && dev.paid_at > 0);
  const o = {
    device_id: deviceId,
    uid: paid && dev.uid ? dev.uid : '',
    paid: paid,
    amount: paid ? dev.amount : 0,
    method: paid ? dev.method : '',
    order_id: paid ? dev.order_id : '',
    issued_at: now,
    // 未支付时给一个短有效期，避免旧凭证被长期复用
    expires_at: paid ? now + RECEIPT_TTL_MS : now + 10 * 60 * 1000,
  };
  return o;
}

/* ------------------------------------------------------------------ HTTP 层 */

function send(res, code, obj, headers) {
  const body = Buffer.from(JSON.stringify(obj), 'utf8');
  res.writeHead(code, Object.assign({
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': body.length,
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type, X-Admin-Token',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Cache-Control': 'no-store',
  }, headers || {}));
  res.end(body);
}

function sendHtml(res, code, html) {
  const body = Buffer.from(html, 'utf8');
  res.writeHead(code, {
    'Content-Type': 'text/html; charset=utf-8',
    'Content-Length': body.length,
    'Cache-Control': 'no-store',
  });
  res.end(body);
}

function readBody(req) {
  return new Promise((resolve) => {
    let raw = '';
    req.on('data', (c) => {
      raw += c;
      if (raw.length > 64 * 1024) { req.destroy(); }
    });
    req.on('end', () => {
      let obj = {};
      try { obj = raw ? JSON.parse(raw) : {}; } catch (e) { obj = {}; }
      resolve(obj);
    });
    req.on('error', () => resolve({}));
  });
}

function adminOk(req, body) {
  const t = (req.headers['x-admin-token'] || (body && body.token) || '').toString().trim();
  return t && t === db.admin_token;
}

const server = http.createServer(async (req, res) => {
  const u = new URL(req.url, 'http://localhost');
  const p = u.pathname;

  if (req.method === 'OPTIONS') { send(res, 204, {}); return; }

  try {
    /* ---------- 健康检查 ---------- */
    if (p === '/api/health') {
      send(res, 200, { code: 0, msg: 'ok', time: Date.now() });
      return;
    }

    /* ---------- 公钥（便于配置，不影响 App 内置公钥的锚定作用）---------- */
    if (p === '/api/pubkey') {
      const hex = fs.existsSync(PUB_HEX_FILE) ? fs.readFileSync(PUB_HEX_FILE, 'utf8').trim() : '';
      const b64 = fs.existsSync(PUB_FILE) ? fs.readFileSync(PUB_FILE).toString('base64') : '';
      send(res, 200, { code: 0, data: { pub_key_hex: hex, pub_key_b64: b64 } });
      return;
    }

    /* ---------- 查询捐赠状态（App 每次登录都会调用）---------- */
    if (p === '/api/donate/status' && req.method === 'GET') {
      const deviceId = safeId(u.searchParams.get('device_id'));
      const key = safeId(u.searchParams.get('key'));
      if (!deviceId || !key) { send(res, 400, { code: 400, msg: '缺少 device_id 或 key' }); return; }
      const st = statusOf(deviceId, key);
      const payload = canonical(st);
      send(res, 200, {
        code: 0,
        data: {
          paid: st.paid,
          amount: st.amount,
          method: st.method,
          order_id: st.order_id,
          device_id: st.device_id,
          uid: st.uid,
          issued_at: st.issued_at,
          expires_at: st.expires_at,
          receipt: payload,
          sign: signPayload(payload),
        },
      });
      return;
    }

    /* ---------- 创建订单（扫码支付前调用，服务端生成订单号）---------- */
    if (p === '/api/donate/order' && req.method === 'POST') {
      const b = await readBody(req);
      const deviceId = safeId(b.device_id);
      const key = safeId(b.key);
      const method = safeId(b.method) === 'alipay' ? 'alipay' : 'wechat';
      const amount = Math.max(1, Math.floor(Number(b.amount) || 0));
      if (!deviceId || !key) { send(res, 400, { code: 400, msg: '缺少 device_id 或 key' }); return; }
      registerDevice(deviceId, key);
      const orderId = 'BXQ' + Date.now().toString(36).toUpperCase()
        + crypto.randomBytes(4).toString('hex').toUpperCase();
      db.orders[orderId] = {
        order_id: orderId,
        device_id: deviceId,
        uid: safeId(b.uid),
        amount: amount,
        method: method,
        status: 'pending',
        created_at: Date.now(),
        paid_at: 0,
        channel: '',
      };
      saveDb();
      send(res, 200, {
        code: 0,
        data: {
          order_id: orderId,
          amount: amount,
          method: method,
          created_at: db.orders[orderId].created_at,
          // 静态个人收款码场景：请把订单号填进转账备注，便于后台核对
          remark_hint: '转账时请在备注中填写订单号 ' + orderId,
        },
      });
      return;
    }

    /* ---------- 绑定设备与 B 站账号（登录成功后调用）---------- */
    if (p === '/api/donate/bind' && req.method === 'POST') {
      const b = await readBody(req);
      const ok = bindUid(safeId(b.device_id), safeId(b.key), safeId(b.uid));
      send(res, ok ? 200 : 403, { code: ok ? 0 : 403, msg: ok ? 'ok' : '绑定失败：设备密钥不匹配' });
      return;
    }

    /* ---------- 支付网关回调（微信/支付宝官方异步通知的适配入口）---------- */
    if (p === '/api/pay/notify' && req.method === 'POST') {
      const b = await readBody(req);
      const orderId = safeId(b.order_id);
      const amount = Math.floor(Number(b.amount) || 0);
      const channel = safeId(b.channel);
      const sign = String(b.sign || '');
      const expect = crypto.createHmac('sha256', db.pay_secret)
        .update(`${orderId}|${amount}|${channel}`, 'utf8').digest('hex');
      if (!sign || sign !== expect) {
        send(res, 401, { code: 401, msg: '验签失败' });
        return;
      }
      const ok = markPaid(orderId, amount, safeId(b.method), channel);
      send(res, ok ? 200 : 404, { code: ok ? 0 : 404, msg: ok ? 'ok' : '订单不存在' });
      return;
    }

    /* ---------- 管理员人工核销（静态个人收款码场景）---------- */
    if (p === '/api/admin/confirm' && req.method === 'POST') {
      const b = await readBody(req);
      if (!adminOk(req, b)) { send(res, 401, { code: 401, msg: '管理员令牌无效' }); return; }
      const orderId = safeId(b.order_id);
      const amount = Math.floor(Number(b.amount) || 0);
      const ok = orderId ? markPaid(orderId, amount, safeId(b.method), 'manual') : false;
      send(res, ok ? 200 : 404, { code: ok ? 0 : 404, msg: ok ? 'ok' : '订单不存在' });
      return;
    }

    /* ---------- 管理员：订单列表 ---------- */
    if (p === '/api/admin/orders' && req.method === 'GET') {
      if (!adminOk(req, {})) { send(res, 401, { code: 401, msg: '管理员令牌无效' }); return; }
      const list = Object.values(db.orders).sort((a, b) => b.created_at - a.created_at).slice(0, 200);
      send(res, 200, { code: 0, data: { orders: list } });
      return;
    }

    /* ---------- 管理后台页面 ---------- */
    if (p === '/admin') {
      sendHtml(res, 200, adminHtml());
      return;
    }

    send(res, 404, { code: 404, msg: 'not found' });
  } catch (e) {
    console.error('[error]', e);
    send(res, 500, { code: 500, msg: 'server error' });
  }
});

function adminHtml() {
  return `<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>哔小趣 · 捐赠核销后台</title>
<style>
 body{margin:0;padding:20px;background:#f5f6f8;color:#1f2329;font:14px/1.6 -apple-system,"PingFang SC","Microsoft YaHei",sans-serif}
 h1{font-size:20px;margin:0 0 4px}
 .bar{display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin:14px 0}
 input,button{font:inherit;padding:7px 11px;border:1px solid #d6d9de;border-radius:8px;background:#fff}
 button{cursor:pointer;background:#fb7299;color:#fff;border:0}
 button.ghost{background:#fff;color:#1f2329;border:1px solid #d6d9de}
 table{width:100%;border-collapse:collapse;background:#fff;border-radius:10px;overflow:hidden}
 th,td{padding:9px 10px;border-bottom:1px solid #eceef1;text-align:left;font-size:13px}
 th{background:#fafbfc;color:#646a73;font-weight:600}
 code{background:#f2f3f5;padding:1px 5px;border-radius:4px;font-size:12px}
 .paid{color:#00a76f;font-weight:700}
 .pending{color:#d97706}
 .muted{color:#8a9099;font-size:12px;margin-top:10px}
</style></head><body>
<h1>捐赠核销后台</h1>
<div class="muted">静态个人收款码没有自动回调：收到转账后，在微信/支付宝账单里核对订单号，然后在下面点「核销」。</div>
<div class="bar">
  <input id="tok" placeholder="管理员令牌" style="flex:1;min-width:220px">
  <button onclick="load()">刷新订单</button>
</div>
<div id="tip" class="muted"></div>
<table><thead><tr>
<th>订单号</th><th>金额</th><th>方式</th><th>状态</th><th>创建时间</th><th>操作</th>
</tr></thead><tbody id="tb"></tbody></table>
<script>
function esc(s){return String(s==null?'':s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]))}
function fmt(ts){return ts?new Date(ts).toLocaleString('zh-CN'):'-'}
async function load(){
  const tok=document.getElementById('tok').value.trim();
  if(!tok){document.getElementById('tip').textContent='请先填写管理员令牌';return}
  const r=await fetch('/api/admin/orders',{headers:{'X-Admin-Token':tok}});
  const j=await r.json();
  if(j.code!==0){document.getElementById('tip').textContent=j.msg||'读取失败';return}
  document.getElementById('tip').textContent='共 '+j.data.orders.length+' 条订单';
  document.getElementById('tb').innerHTML=j.data.orders.map(o=>{
    const done=o.status==='paid';
    return '<tr><td><code>'+esc(o.order_id)+'</code></td><td>￥'+esc(o.amount)+'</td>'
      +'<td>'+esc(o.method==='alipay'?'支付宝':'微信')+'</td>'
      +'<td class="'+(done?'paid':'pending')+'">'+(done?'已支付':'待支付')+'</td>'
      +'<td>'+fmt(o.created_at)+'</td>'
      +'<td>'+(done?'—':'<button onclick="cf(\\''+esc(o.order_id)+'\\','+o.amount+',\\''+esc(o.method)+'\\')">核销</button>')+'</td></tr>';
  }).join('');
}
async function cf(id,amt,m){
  const tok=document.getElementById('tok').value.trim();
  const r=await fetch('/api/admin/confirm',{method:'POST',
    headers:{'Content-Type':'application/json','X-Admin-Token':tok},
    body:JSON.stringify({order_id:id,amount:amt,method:m})});
  const j=await r.json();
  document.getElementById('tip').textContent=j.code===0?'已核销 '+id:(j.msg||'核销失败');
  load();
}
</script></body></html>`;
}

loadDb();
ensureKeys();
server.listen(PORT, () => {
  console.log('哔小趣 捐赠校验服务已启动');
  console.log('  监听端口 : ' + PORT);
  console.log('  数据文件 : ' + DATA_FILE);
  console.log('  密钥目录 : ' + KEY_DIR + '（私钥切勿外传/勿提交 Git）');
  console.log('  管理后台 : http://127.0.0.1:' + PORT + '/admin');
  console.log('  管理员令牌: ' + db.admin_token);
  console.log('  网关回调密钥: ' + db.pay_secret);
  console.log('  App 内置公钥(X.509 DER hex):');
  console.log('    ' + (fs.existsSync(PUB_HEX_FILE) ? fs.readFileSync(PUB_HEX_FILE, 'utf8').trim() : ''));
});
