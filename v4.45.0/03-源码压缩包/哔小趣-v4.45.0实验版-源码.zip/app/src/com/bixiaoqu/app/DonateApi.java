package com.bixiaoqu.app;

import android.content.Context;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.KeyFactory;
import java.security.PublicKey;
import java.security.Signature;
import java.security.spec.X509EncodedKeySpec;
import java.util.UUID;

/**
 * 【v4.45】捐赠状态服务端校验客户端。
 *
 * 背景：v4.44 的「我已完成支付 → 点一下就解锁」是前端自证，属于恶性漏洞 ——
 * 任何人点一下「已支付，确认解锁」都能获得捐赠身份，因为写的是本地布尔值。
 *
 * v4.45 把裁决权彻底移到服务端：
 *   · App 端**不再存在**任何「点了就置成功」的写路径；
 *   · 捐赠状态只认服务端返回、且被服务端 RSA 私钥签名过的凭证（receipt + sign）；
 *   · App 内置服务端公钥，验签通过才认账；本地缓存被改写也无法伪造「已捐赠」；
 *   · 每次登录前都要向服务端拉一次状态（在线校验），断网时最多使用未过期的
 *     服务端签名凭证兜底（凭证本身带过期时间，且离线时长受限）。
 *
 * 纯逻辑（拼接 payload、验签、解析）不依赖 Android 运行时，可直接 JVM 单测。
 */
public class DonateApi {

    // ===================== 常量 =====================

    /** 服务端地址（用户可在设置里改成自己的部署地址） */
    public static final String DEFAULT_SERVER = "";

    /**
     * 【v4.45】服务端公钥（X.509 DER，Base64）。
     * 部署者替换成自己服务端 keys/donate_pub.der 的 Base64 即可。
     * 私钥永远只在服务端，App 内只固化公钥 —— 客户端无法伪造签名。
     */
    public static final String DEFAULT_PUB_KEY_B64 = "";

    /** 请求超时（毫秒）：登录门禁要快速反馈，不能让用户干等 */
    static final int CONNECT_TIMEOUT = 8000;
    static final int READ_TIMEOUT = 10000;

    /** 凭证可接受的最长离线时长：超过则必须联网重新确认 */
    static final long MAX_OFFLINE_GRACE_MS = 72L * 3600 * 1000L;

    // ===================== 结果模型 =====================

    /** 校验结论 */
    public static final int ST_UNKNOWN = 0;   // 尚未向服务端确认过
    public static final int ST_PAID = 1;      // 服务端确认已支付
    public static final int ST_UNPAID = 2;    // 服务端确认未支付
    public static final int ST_ERROR = 3;     // 网络/验签等异常

    /** 服务端返回并已通过验签的捐赠状态 */
    public static class Status {
        public int state = ST_UNKNOWN;
        public boolean paid;
        public int amount;
        public String method = "";
        public String orderId = "";
        public String deviceId = "";
        public String uid = "";
        public long issuedAt;
        public long expiresAt;
        public String receipt = "";
        public String sign = "";
        public String message = "";

        public boolean isPaid() { return state == ST_PAID && paid; }
    }

    // ===================== 设备身份 =====================

    /**
     * 设备唯一标识（首次启动随机生成，存本机）。
     * 它只是「这台设备」的身份，不是账号身份 —— 账号身份在登录后由服务端 bind 绑定。
     */
    public static String deviceId(Context c) {
        String v = Prefs.donateDeviceId(c);
        if (v == null || v.length() == 0) {
            v = "d" + UUID.randomUUID().toString().replace("-", "");
            Prefs.setDonateDeviceId(c, v);
        }
        return v;
    }

    /** 设备密钥：用于向服务端证明「是我这台设备在问」，防止他人冒用设备 ID 查询 */
    public static String deviceKey(Context c) {
        String v = Prefs.donateDeviceKey(c);
        if (v == null || v.length() == 0) {
            v = "k" + UUID.randomUUID().toString().replace("-", "");
            Prefs.setDonateDeviceKey(c, v);
        }
        return v;
    }

    // ===================== 纯逻辑（可 JVM 单测）=====================

    /**
     * 拼接规范化 payload —— 必须与服务端 canonical() 完全一致。
     * 格式：v1|device_id|uid|paid|amount|method|order_id|issued_at|expires_at
     */
    public static String canonical(String deviceId, String uid, boolean paid, int amount,
                                  String method, String orderId, long issuedAt, long expiresAt) {
        return "v1|" + nz(deviceId) + "|" + nz(uid) + "|" + (paid ? "1" : "0") + "|"
                + amount + "|" + nz(method) + "|" + nz(orderId) + "|"
                + issuedAt + "|" + expiresAt;
    }

    static String nz(String s) { return s == null ? "" : s; }

    /** hex 字符串 → 字节数组 */
    public static byte[] hexToBytes(String hex) {
        if (hex == null) return new byte[0];
        String t = hex.trim();
        int n = t.length() / 2;
        byte[] out = new byte[n];
        for (int i = 0; i < n; i++) {
            out[i] = (byte) Integer.parseInt(t.substring(i * 2, i * 2 + 2), 16);
        }
        return out;
    }

    /** 字节数组 → 小写 hex */
    public static String bytesToHex(byte[] b) {
        if (b == null) return "";
        StringBuilder sb = new StringBuilder(b.length * 2);
        for (byte x : b) {
            String h = Integer.toHexString(x & 0xFF);
            if (h.length() == 1) sb.append('0');
            sb.append(h);
        }
        return sb.toString();
    }

    /**
     * 用服务端公钥验证签名。
     * 公钥为 X.509 DER 的 Base64 字符串；签名为 hex。
     */
    public static boolean verify(String payload, String signHex, String pubKeyB64) {
        if (payload == null || signHex == null || pubKeyB64 == null) return false;
        if (signHex.length() == 0 || pubKeyB64.length() == 0) return false;
        byte[] der = decodePubKey(pubKeyB64);
        if (der == null || der.length == 0) return false;
        try {
            KeyFactory kf = KeyFactory.getInstance("RSA");
            PublicKey pk = kf.generatePublic(new X509EncodedKeySpec(der));
            Signature sig = Signature.getInstance("SHA256withRSA");
            sig.initVerify(pk);
            sig.update(payload.getBytes("UTF-8"));
            return sig.verify(hexToBytes(signHex));
        } catch (Throwable t) {
            return false;
        }
    }

    /**
     * 解析服务端公钥：支持 Base64 与 hex 两种写法（部署时更不易出错）。
     *
     * 【v4.45】这里刻意不用 android.util.Base64 / java.util.Base64：
     *   · android.util.Base64 在 JVM 单测里是 stub（会抛异常），无法验证签名逻辑；
     *   · java.util.Base64 需要 API 26，而本 App 的 minSdk 是 22。
     * 因此自实现一份纯 Java 解码，两边都能跑。
     */
    static byte[] decodePubKey(String s) {
        if (s == null) return null;
        String t = s.trim().replaceAll("\\s", "");
        if (t.length() == 0) return null;
        // 全是十六进制字符且长度为偶数 → 按 hex 解析
        if (t.length() % 2 == 0 && t.matches("[0-9a-fA-F]+")) {
            byte[] b = hexToBytes(t);
            // DER 序列化的 RSA 公钥以 0x30 开头，可据此排除误判
            if (b.length > 0 && (b[0] & 0xFF) == 0x30) return b;
        }
        return base64Decode(t);
    }

    /** 纯 Java Base64 解码（不依赖 android.util.Base64 / API 26） */
    static byte[] base64Decode(String in) {
        String t = in.replaceAll("[^A-Za-z0-9+/=]", "");
        int n = t.length();
        if (n == 0) return new byte[0];
        int pad = 0;
        if (t.charAt(n - 1) == '=') pad++;
        if (n > 1 && t.charAt(n - 2) == '=') pad++;
        int groups = n / 4;
        int tail = n % 4;
        int outLen = groups * 3 + (tail == 2 ? 1 : (tail == 3 ? 2 : 0)) - pad;
        if (outLen < 0) return new byte[0];
        byte[] out = new byte[outLen];
        int oi = 0;
        int i = 0;
        while (i + 3 < n) {
            int v0 = b64Val(t.charAt(i));
            int v1 = b64Val(t.charAt(i + 1));
            int v2 = t.charAt(i + 2) == '=' ? 0 : b64Val(t.charAt(i + 2));
            int v3 = t.charAt(i + 3) == '=' ? 0 : b64Val(t.charAt(i + 3));
            if (oi < out.length) out[oi++] = (byte) ((v0 << 2) | (v1 >> 4));
            if (oi < out.length) out[oi++] = (byte) (((v1 & 0xF) << 4) | (v2 >> 2));
            if (oi < out.length) out[oi++] = (byte) (((v2 & 0x3) << 6) | v3);
            i += 4;
        }
        if (tail == 2) {
            int v0 = b64Val(t.charAt(i));
            int v1 = b64Val(t.charAt(i + 1));
            if (oi < out.length) out[oi++] = (byte) ((v0 << 2) | (v1 >> 4));
        } else if (tail == 3) {
            int v0 = b64Val(t.charAt(i));
            int v1 = b64Val(t.charAt(i + 1));
            int v2 = b64Val(t.charAt(i + 2));
            if (oi < out.length) out[oi++] = (byte) ((v0 << 2) | (v1 >> 4));
            if (oi < out.length) out[oi++] = (byte) (((v1 & 0xF) << 4) | (v2 >> 2));
        }
        return out;
    }

    static int b64Val(char c) {
        if (c >= 'A' && c <= 'Z') return c - 'A';
        if (c >= 'a' && c <= 'z') return c - 'a' + 26;
        if (c >= '0' && c <= '9') return c - '0' + 52;
        if (c == '+') return 62;
        if (c == '/') return 63;
        return 0;
    }

    /**
     * 校验服务端返回的状态对象：验签 + 过期检查 + 设备归属检查。
     * 任何一项不过，都判为不可信（不会因为「本地缓存写着已支付」就放行）。
     */
    public static boolean isTrusted(Status st, String expectDeviceId, String pubKeyB64, long now) {
        if (st == null) return false;
        if (st.receipt == null || st.sign == null || st.sign.length() == 0) return false;
        // 1) 签名必须由服务端私钥签出
        if (!verify(st.receipt, st.sign, pubKeyB64)) return false;
        // 2) receipt 内容必须与服务端下发的字段一致（防止字段被改但签名未覆盖）
        String expect = canonical(st.deviceId, st.uid, st.paid, st.amount, st.method,
                st.orderId, st.issuedAt, st.expiresAt);
        if (!expect.equals(st.receipt)) return false;
        // 3) 必须是本机设备的状态
        if (expectDeviceId != null && !expectDeviceId.equals(st.deviceId)) return false;
        // 4) 不能是过期凭证
        if (st.expiresAt <= 0 || st.expiresAt <= now) return false;
        return true;
    }

    /** 解析服务端 JSON 的 data 段为 Status（不做验签，验签由 isTrusted 完成） */
    public static Status parseData(JSONObject data) {
        Status st = new Status();
        if (data == null) return st;
        st.paid = data.optBoolean("paid", false);
        st.amount = data.optInt("amount", 0);
        st.method = data.optString("method", "");
        st.orderId = data.optString("order_id", "");
        st.deviceId = data.optString("device_id", "");
        st.uid = data.optString("uid", "");
        st.issuedAt = data.optLong("issued_at", 0L);
        st.expiresAt = data.optLong("expires_at", 0L);
        st.receipt = data.optString("receipt", "");
        st.sign = data.optString("sign", "");
        st.state = st.paid ? ST_PAID : ST_UNPAID;
        return st;
    }

    // ===================== 网络（需 Android 运行时）=====================

    /** 服务端地址：设置里配置的优先 */
    public static String serverUrl(Context c) {
        String v = Prefs.donateServerUrl(c);
        if (v == null || v.trim().length() == 0) v = DEFAULT_SERVER;
        return v.trim();
    }

    /** 公钥：设置里配置的优先 */
    public static String pubKey(Context c) {
        String v = Prefs.donatePubKey(c);
        if (v == null || v.trim().length() == 0) v = DEFAULT_PUB_KEY_B64;
        return v.trim();
    }

    /** 是否已配置服务端（没配置就无法校验，门禁应提示用户去设置） */
    public static boolean configured(Context c) {
        return serverUrl(c).length() > 0 && pubKey(c).length() > 0;
    }

    /**
     * 向服务端查询本机捐赠状态（同步，必须在后台线程调用）。
     * 返回值一定是「服务端确认过的」结论 —— 验签不过就是 ST_ERROR。
     */
    public static Status queryStatus(Context c) {
        Status st = new Status();
        String base = serverUrl(c);
        if (base.length() == 0) {
            st.state = ST_ERROR;
            st.message = "未配置捐赠校验服务地址";
            return st;
        }
        String url = base + "/api/donate/status?device_id=" + enc(deviceId(c))
                + "&key=" + enc(deviceKey(c));
        try {
            String body = httpGet(url);
            JSONObject root = new JSONObject(body);
            if (root.optInt("code", -1) != 0) {
                st.state = ST_ERROR;
                st.message = root.optString("msg", "服务端返回异常");
                return st;
            }
            Status s = parseData(root.optJSONObject("data"));
            if (!isTrusted(s, deviceId(c), pubKey(c), System.currentTimeMillis())) {
                s.state = ST_ERROR;
                s.message = "服务端凭证验签失败，状态不可信";
                s.paid = false;
                return s;
            }
            // 验签通过才落到本地缓存（缓存的是服务端签名凭证，不是本地布尔值）
            Prefs.saveDonateReceipt(c, s.receipt, s.sign, s.expiresAt, s.amount, s.method,
                    s.orderId, s.uid);
            return s;
        } catch (Throwable t) {
            st.state = ST_ERROR;
            st.message = "连接捐赠服务失败：" + (t.getMessage() == null ? t.getClass().getSimpleName() : t.getMessage());
            return st;
        }
    }

    /**
     * 创建订单（用户点了「去支付」时调用），返回订单号；失败返回空串。
     */
    public static String createOrder(Context c, int amount, String method) {
        String base = serverUrl(c);
        if (base.length() == 0) return "";
        try {
            JSONObject body = new JSONObject();
            body.put("device_id", deviceId(c));
            body.put("key", deviceKey(c));
            body.put("amount", Math.max(1, amount));
            body.put("method", method == null ? "wechat" : method);
            String uid = BiliApi.loggedInUid();
            if (uid != null) body.put("uid", uid);
            String r = httpPost(base + "/api/donate/order", body.toString());
            JSONObject root = new JSONObject(r);
            if (root.optInt("code", -1) != 0) return "";
            JSONObject d = root.optJSONObject("data");
            if (d == null) return "";
            return d.optString("order_id", "");
        } catch (Throwable t) {
            return "";
        }
    }

    /** 把设备与 B 站账号在服务端绑定（登录成功后调用，失败不阻断登录） */
    public static void bindUid(Context c, String uid) {
        if (uid == null || uid.length() == 0) return;
        String base = serverUrl(c);
        if (base.length() == 0) return;
        try {
            JSONObject body = new JSONObject();
            body.put("device_id", deviceId(c));
            body.put("key", deviceKey(c));
            body.put("uid", uid);
            httpPost(base + "/api/donate/bind", body.toString());
        } catch (Throwable ignore) { }
    }

    static String enc(String s) {
        try {
            return java.net.URLEncoder.encode(s == null ? "" : s, "UTF-8");
        } catch (Throwable t) {
            return s == null ? "" : s;
        }
    }

    static String httpGet(String url) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        try {
            c.setConnectTimeout(CONNECT_TIMEOUT);
            c.setReadTimeout(READ_TIMEOUT);
            c.setRequestProperty("Accept", "application/json");
            c.setRequestProperty("User-Agent", "BXQ-Donate/1.0");
            int code = c.getResponseCode();
            InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
            String body = readAll(in);
            if (code >= 400) throw new IllegalStateException("HTTP " + code);
            return body;
        } finally {
            try { c.disconnect(); } catch (Throwable ignore) { }
        }
    }

    static String httpPost(String url, String json) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        try {
            c.setConnectTimeout(CONNECT_TIMEOUT);
            c.setReadTimeout(READ_TIMEOUT);
            c.setRequestMethod("POST");
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            c.setRequestProperty("Accept", "application/json");
            c.setRequestProperty("User-Agent", "BXQ-Donate/1.0");
            byte[] raw = json.getBytes("UTF-8");
            c.setFixedLengthStreamingMode(raw.length);
            OutputStream os = c.getOutputStream();
            try { os.write(raw); os.flush(); } finally { try { os.close(); } catch (Throwable ignore) { } }
            int code = c.getResponseCode();
            InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
            String body = readAll(in);
            if (code >= 400) throw new IllegalStateException("HTTP " + code);
            return body;
        } finally {
            try { c.disconnect(); } catch (Throwable ignore) { }
        }
    }

    static String readAll(InputStream in) throws Exception {
        if (in == null) return "";
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        byte[] buf = new byte[4096];
        int n;
        while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
        try { in.close(); } catch (Throwable ignore) { }
        return bos.toString("UTF-8");
    }
}
