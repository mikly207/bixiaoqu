package com.bixiaoqu.app;

import android.os.Handler;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.Socket;
import java.security.SecureRandom;
import java.util.concurrent.atomic.AtomicBoolean;

import android.util.Base64;

import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;

/**
 * 【v4.41】B 站直播实时弹幕客户端（纯 Java，无第三方依赖）。
 *
 * 协议：WSS 握手 broadcastlv.chat.bilibili.com/sub → 二进制帧认证(op=7) →
 *      心跳(op=2, 每 15s) → 解析服务器推送包(op=5) 中的 DANMU_MSG。
 * 包结构：4B 包长(大端) + 2B 头长 + 2B 版本 + 4B 操作码 + 4B 序号 + body。
 *
 * 设计要点（避免卡死）：
 *  - 全部在独立守护线程；网络失败自动重连（指数退避，最多次数限制）；
 *  - 每条消息回调切回主线程 Handler，Activity 销毁时 stop() 彻底释放；
 *  - 客户端→服务端帧必须 mask，服务端→客户端帧不 mask。
 */
public class LiveDanmakuClient {

    public interface Listener {
        void onDanmaku(String user, String text);
        void onState(String state);   // 连接状态提示
    }

    static final String HOST = "broadcastlv.chat.bilibili.com";
    static final int PORT = 443;

    final long roomId;
    final Handler ui;
    final Listener listener;
    final AtomicBoolean running = new AtomicBoolean(false);
    Thread worker;
    Socket socket;

    public LiveDanmakuClient(long roomId, Handler ui, Listener listener) {
        this.roomId = roomId;
        this.ui = ui;
        this.listener = listener;
    }

    public void start() {
        if (running.getAndSet(true)) return;
        worker = new Thread(new Runnable() { @Override public void run() { loop(); } }, "live-dm");
        worker.setDaemon(true);
        worker.start();
    }

    public void stop() {
        running.set(false);
        try { if (socket != null) socket.close(); } catch (Throwable ignore) {}
        if (worker != null) worker.interrupt();
    }

    void state(final String s) {
        if (listener == null || ui == null) return;
        ui.post(new Runnable() { @Override public void run() { listener.onState(s); } });
    }

    void danmaku(final String user, final String text) {
        if (listener == null || ui == null) return;
        ui.post(new Runnable() { @Override public void run() { listener.onDanmaku(user, text); } });
    }

    void loop() {
        int retry = 0;
        while (running.get()) {
            try {
                connect();
                retry = 0;                 // 连上后重置退避
                readLoop();                // 阻塞读，直到断线
            } catch (Throwable e) {
                retry++;
            } finally {
                closeSocket();
            }
            if (!running.get()) break;
            // 指数退避：1s, 2s, 4s ... 上限 15s，避免疯狂重连
            long delay = Math.min(15000L, 1000L << Math.min(retry, 4));
            state("弹幕重连中…");
            try { Thread.sleep(delay); } catch (InterruptedException e) { break; }
        }
    }

    void connect() throws Exception {
        SSLSocketFactory f = (SSLSocketFactory) SSLSocketFactory.getDefault();
        SSLSocket ss = (SSLSocket) f.createSocket(HOST, PORT);
        ss.setEnabledProtocols(new String[]{"TLSv1.2"});
        ss.setSoTimeout(20000);
        ss.setTcpNoDelay(true);
        socket = ss;
        OutputStream os = socket.getOutputStream();

        // ---- WebSocket HTTP Upgrade 握手 ----
        byte[] keyBytes = new byte[16];
        new SecureRandom().nextBytes(keyBytes);
        String key = Base64.encodeToString(keyBytes, Base64.NO_WRAP);
        String req = "GET /sub HTTP/1.1\r\n"
                + "Host: " + HOST + ":" + PORT + "\r\n"
                + "Upgrade: websocket\r\n"
                + "Connection: Upgrade\r\n"
                + "Sec-WebSocket-Key: " + key + "\r\n"
                + "Sec-WebSocket-Version: 13\r\n"
                + "Origin: https://live.bilibili.com\r\n"
                + "Referer: https://live.bilibili.com/\r\n"
                + "User-Agent: " + BiliApi.UA + "\r\n\r\n";
        os.write(req.getBytes("UTF-8"));
        os.flush();

        BufferedReader br = new BufferedReader(new InputStreamReader(socket.getInputStream(), "ISO-8859-1"));
        String status = br.readLine();
        if (status == null || !status.contains("101")) throw new Exception("WS握手失败: " + status);
        String ln;
        while ((ln = br.readLine()) != null && !ln.trim().isEmpty()) { /* 读完响应头 */ }

        // ---- 认证包 op=7 ----
        String auth = "{\"uid\":0,\"roomid\":" + roomId
                + ",\"protover\":1,\"platform\":\"web\",\"type\":2}";
        sendBinary(auth.getBytes("UTF-8"), 7);
        state("弹幕已连接");

        // ---- 心跳守护线程 ----
        Thread hb = new Thread(new Runnable() {
            @Override public void run() {
                while (running.get()) {
                    try {
                        sendBinary(new byte[0], 2);
                        Thread.sleep(15000);
                    } catch (Throwable e) { break; }
                }
            }
        }, "live-dm-hb");
        hb.setDaemon(true);
        hb.start();
    }

    /** 读取服务器 WebSocket 帧并解析 B 站包 */
    void readLoop() throws Exception {
        InputStream in = socket.getInputStream();
        while (running.get()) {
            int b0 = in.read();
            if (b0 < 0) throw new Exception("连接关闭");
            int b1 = in.read();
            if (b1 < 0) throw new Exception("连接关闭");
            boolean fin = (b0 & 0x80) != 0;
            int opcode = b0 & 0x0F;
            boolean masked = (b1 & 0x80) != 0;
            long len = b1 & 0x7F;
            if (len == 126) {
                len = ((long) (in.read() & 0xFF) << 8) | (in.read() & 0xFF);
            } else if (len == 127) {
                len = 0;
                for (int i = 0; i < 8; i++) len = (len << 8) | (in.read() & 0xFF);
            }
            if (len <= 0 || len > 8 * 1024 * 1024) continue;   // 丢弃异常大帧
            byte[] mask = null;
            if (masked) { mask = new byte[4]; readFully(in, mask); }
            byte[] payload = new byte[(int) len];
            readFully(in, payload);
            if (masked) for (int i = 0; i < payload.length; i++) payload[i] ^= mask[i % 4];
            if (opcode == 8) throw new Exception("服务器关闭帧");  // CLOSE
            if (opcode == 9) continue;                            // PING，忽略
            if (opcode == 2) parseBiliPacket(payload);            // 二进制包
        }
    }

    /** 解析 B 站二进制包（一个 WebSocket 帧可能含多个包） */
    void parseBiliPacket(byte[] data) {
        int off = 0;
        while (off + 16 <= data.length) {
            int plen = readI32(data, off);
            if (plen < 16 || off + plen > data.length) break;
            int op = readI32(data, off + 8);
            if (op == 5) {
                String body = new String(data, off + 16, plen - 16, java.nio.charset.Charset.forName("UTF-8"));
                parseDanmakuJson(body);
            }
            off += plen;
        }
    }

    /** 从 op=5 的 JSON body 里提取 DANMU_MSG */
    void parseDanmakuJson(String body) {
        try {
            org.json.JSONObject j = new org.json.JSONObject(body);
            if (!"DANMU_MSG".equals(j.optString("cmd"))) return;
            org.json.JSONArray info = j.optJSONArray("info");
            if (info == null || info.length() < 3) return;
            String text = String.valueOf(info.opt(1));
            String user = "";
            org.json.JSONArray u = info.optJSONArray(2);
            if (u != null && u.length() > 1) user = String.valueOf(u.opt(1));
            if (text.length() > 0) danmaku(user, text);
        } catch (Throwable ignore) {}
    }

    static int readI32(byte[] b, int off) {
        return ((b[off] & 0xFF) << 24) | ((b[off + 1] & 0xFF) << 16)
                | ((b[off + 2] & 0xFF) << 8) | (b[off + 3] & 0xFF);
    }

    /** 发送二进制 WebSocket 帧（客户端必须 mask） */
    void sendBinary(byte[] body, int op) throws Exception {
        if (socket == null || socket.isClosed()) throw new Exception("socket closed");
        // 先做 B 站封包
        byte[] payload = new byte[16 + body.length];
        writeI32(payload, 0, payload.length);
        writeI16(payload, 4, 16);       // headerLen
        writeI16(payload, 6, 1);        // version
        writeI32(payload, 8, op);       // operation
        writeI32(payload, 12, 1);       // sequence
        System.arraycopy(body, 0, payload, 16, body.length);

        OutputStream os = socket.getOutputStream();
        int len = payload.length;
        byte[] mask = new byte[4];
        new SecureRandom().nextBytes(mask);

        os.write(0x82);   // FIN + binary opcode
        int maskBit = 0x80;
        if (len < 126) {
            os.write(maskBit | len);
        } else if (len < 65536) {
            os.write(maskBit | 126);
            os.write((len >>> 8) & 0xFF);
            os.write(len & 0xFF);
        } else {
            os.write(maskBit | 127);
            for (int i = 7; i >= 0; i--) os.write((len >>> (8 * i)) & 0xFF);
        }
        os.write(mask);
        for (int i = 0; i < len; i++) os.write(payload[i] ^ mask[i % 4]);
        os.flush();
    }

    static void writeI32(byte[] b, int off, int v) {
        b[off] = (byte) (v >>> 24); b[off + 1] = (byte) (v >>> 16);
        b[off + 2] = (byte) (v >>> 8); b[off + 3] = (byte) v;
    }
    static void writeI16(byte[] b, int off, int v) {
        b[off] = (byte) (v >>> 8); b[off + 1] = (byte) v;
    }

    static void readFully(InputStream in, byte[] b) throws Exception {
        int off = 0;
        while (off < b.length) {
            int n = in.read(b, off, b.length - off);
            if (n < 0) throw new Exception("连接中断");
            off += n;
        }
    }

    void closeSocket() {
        try { if (socket != null) socket.close(); } catch (Throwable ignore) {}
        socket = null;
    }
}
