package com.bixiaoqu.app;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * 【v4.41】直播内嵌专用本地代理（重写版，修复卡死）。
 *
 * 旧版 v4.40 卡死根因：
 *   - 线程池仅 6 个且无 socket 超时：m3u8 反复刷新 + 并发分片把线程占满；
 *   - 退出再进时旧请求还在跑，把线程池彻底堵死 → 恢复不了；
 *   - 慢 CDN 的 read 无熔断，单个请求挂住就拖垮整个池。
 *
 * v4.41 对策：
 *   1) 线程池扩到 20 + 有界队列 + 丢弃最旧，过载时快速失败而非全体卡死；
 *   2) 每个 socket 设 soTimeout，读请求头不永久阻塞；
 *   3) 分片转发加总时长熔断（25s）+ 客户端断连检测，慢线路立即放弃；
 *   4) 代际隔离：每次进入播放 newGeneration()，旧代际请求快速返回 410，不占线程；
 *   5) 线路亲和：把胜出的 CDN host 记住，后续分片优先走同一条好线路；
 *   6) m3u8 1 秒短缓存，抵消 VideoView 的重复刷新请求；
 *   7) 多线路择优：playUrl 返回的 2 条 m3u8 逐条尝试，第一条可用即用。
 *
 * 与点播 LocalProxy 完全分离，不影响原有点播链路。
 */
public class LiveProxy implements Runnable {

    private static volatile LiveProxy INSTANCE;

    private ServerSocket server;
    private static volatile int PORT = 0;
    private volatile boolean running = true;
    private final ExecutorService pool;

    /** 播放代际：进入新一次播放时递增，旧代际请求立即失败 */
    private static volatile int GEN = 1;
    /** CDN 线路亲和：path -> 胜出的 host */
    private static final ConcurrentHashMap<String, String> AFFINITY =
            new ConcurrentHashMap<String, String>();
    /** m3u8 短缓存：url -> (时间戳, 内容)，单位 ms */
    private static final ConcurrentHashMap<String, byte[]> PL_CACHE =
            new ConcurrentHashMap<String, byte[]>();
    private static final ConcurrentHashMap<String, Long> PL_TIME =
            new ConcurrentHashMap<String, Long>();
    private static final long PL_TTL = 900L;
    /** 当前活跃 socket，newGeneration 时强制关闭旧连接 */
    private final Set<Socket> ACTIVE = Collections.newSetFromMap(
            new ConcurrentHashMap<Socket, Boolean>());

    private LiveProxy() {
        final AtomicInteger seq = new AtomicInteger();
        pool = new ThreadPoolExecutor(8, 20, 60L, TimeUnit.SECONDS,
                new ArrayBlockingQueue<Runnable>(48),
                new ThreadFactory() {
                    @Override public Thread newThread(Runnable r) {
                        Thread t = new Thread(r, "live-proxy-" + seq.incrementAndGet());
                        t.setDaemon(true);
                        return t;
                    }
                },
                new ThreadPoolExecutor.DiscardOldestPolicy());
        try {
            server = new ServerSocket(0, 256, InetAddress.getByName("127.0.0.1"));
            PORT = server.getLocalPort();
            Thread acceptThread = new Thread(this, "live-proxy-accept");
            acceptThread.setDaemon(true);   // 守护线程：不阻止进程退出，避免线程泄漏
            acceptThread.start();
        } catch (Exception e) {
            running = false;
        }
    }

    public static synchronized LiveProxy get() {
        if (INSTANCE == null || !INSTANCE.running) INSTANCE = new LiveProxy();
        return INSTANCE;
    }

    public boolean available() { return server != null && running; }

    /**
     * 进入新一次播放：递增代际并强制关闭所有旧连接，
     * 让上一场直播遗留的请求立刻失败、释放线程，保证「退出再进可恢复」。
     */
    public int newGeneration() {
        GEN++;
        PL_CACHE.clear();
        PL_TIME.clear();
        try {
            for (Socket s : new ArrayList<Socket>(ACTIVE)) close(s);
        } catch (Throwable ignore) {}
        ACTIVE.clear();
        return GEN;
    }

    public int generation() { return GEN; }

    /** 包装单条 m3u8（兼容旧调用） */
    public String wrap(String rawM3u8) {
        return wrap(new String[]{rawM3u8});
    }

    /** 包装多条候选线路，代理会择优 */
    public String wrap(String[] urls) {
        if (urls == null || urls.length == 0) return null;
        StringBuilder sb = new StringBuilder("http://127.0.0.1:").append(PORT)
                .append("/m3u8?u=").append(enc(urls[0]));
        for (int i = 1; i < urls.length && i <= 4; i++) {
            sb.append("&u").append(i + 1).append("=").append(enc(urls[i]));
        }
        sb.append("&g=").append(GEN);
        return sb.toString();
    }

    public static String enc(String s) {
        try { return URLEncoder.encode(s, "UTF-8"); }
        catch (Exception e) { return s; }
    }

    public static String dec(String s) {
        try { return URLDecoder.decode(s, "UTF-8"); }
        catch (Exception e) { return s; }
    }

    @Override public void run() {
        while (running) {
            try {
                final Socket s = server.accept();
                pool.execute(new Runnable() {
                    @Override public void run() { handle(s); }
                });
            } catch (Exception e) {
                if (!running) break;
            }
        }
    }

    public void shutdown() {
        running = false;
        try { if (server != null) server.close(); } catch (Throwable ignore) {}
        pool.shutdownNow();
    }

    /** 从请求行取参数值，遇到 & 或空格结束 */
    public static String param(String line, String key) {
        int idx = -1, from = 0;
        while (true) {
            int p = line.indexOf(key, from);
            if (p < 0) break;
            boolean boundary = (p == 0) || (line.charAt(p - 1) == '?') || (line.charAt(p - 1) == '&');
            if (boundary) { idx = p; break; }
            from = p + 1;
        }
        if (idx < 0) return null;
        int st = idx + key.length();
        int en = st;
        while (en < line.length()) {
            char c = line.charAt(en);
            if (c == ' ' || c == '&' || c == '\r' || c == '\n') break;
            en++;
        }
        return dec(line.substring(st, en));
    }

    void handle(Socket s) {
        ACTIVE.add(s);
        HttpURLConnection upstream = null;
        try {
            s.setSoTimeout(9000);   // 读请求头超时：客户端连上不发请求不永久占线程
            BufferedReader br = new BufferedReader(new InputStreamReader(s.getInputStream(), "UTF-8"));
            String line = br.readLine();
            if (line == null) { close(s); return; }
            String range = null, rl;
            while ((rl = br.readLine()) != null && !rl.isEmpty()) {
                if (rl.regionMatches(true, 0, "Range:", 0, 6)) range = rl.substring(6).trim();
            }
            // 代际校验：旧请求快速失败，绝不让上一场直播的请求占用新播放的线程
            int g = -1;
            try { String gs = param(line, "g="); if (gs != null) g = Integer.parseInt(gs.trim()); }
            catch (Throwable ignore) {}
            if (g > 0 && g != GEN) {
                send(s, 410, "text/plain", "stale generation".getBytes("UTF-8"));
                return;
            }
            String raw = param(line, "u=");
            if (raw == null || raw.length() == 0) {
                send(s, 400, "text/plain", "missing url".getBytes("UTF-8"));
                return;
            }
            if (line.contains("/m3u8")) {
                servePlaylist(s, line, raw);
            } else {
                upstream = serveSegment(s, raw, range);
            }
        } catch (SocketTimeoutException e) {
            try { send(s, 408, "text/plain", "timeout".getBytes("UTF-8")); } catch (Throwable ignore) {}
        } catch (Throwable e) {
            try { close(s); } catch (Throwable ignore) {}
        } finally {
            ACTIVE.remove(s);
            if (upstream != null) { try { upstream.disconnect(); } catch (Throwable ignore) {} }
            close(s);
        }
    }

    /** 解析请求行里的所有候选线路（u / u2 ~ u5） */
    public static String[] collectUrls(String line) {
        List<String> list = new ArrayList<String>();
        String u = param(line, "u=");
        if (u != null && u.length() > 0) list.add(u);
        for (int i = 2; i <= 5; i++) {
            String alt = param(line, "u" + i + "=");
            if (alt != null && alt.length() > 0) list.add(alt);
        }
        return list.toArray(new String[list.size()]);
    }

    /** 把亲缘 host 的线路排到最前 */
    static String[] preferAffinity(String[] urls) {
        final String[] arr = urls.clone();
        java.util.Arrays.sort(arr, new Comparator<String>() {
            @Override public int compare(String a, String b) {
                boolean pa = AFFINITY.containsKey(pathOf(a)) && hostOf(a).equals(AFFINITY.get(pathOf(a)));
                boolean pb = AFFINITY.containsKey(pathOf(b)) && hostOf(b).equals(AFFINITY.get(pathOf(b)));
                return (pb ? 0 : 1) - (pa ? 0 : 1);
            }
        });
        return arr;
    }

    /** 拉取播放列表：多线路择优 + 短缓存 + 记录亲和线路 */
    void servePlaylist(Socket s, String line, String firstUrl) throws Exception {
        String[] urls = preferAffinity(collectUrls(line));
        if (urls.length == 0) urls = new String[]{firstUrl};

        // 短缓存命中（相同 url 900ms 内）直接回，抵消 VideoView 重复刷新
        String key = urls[0];
        Long t = PL_TIME.get(key);
        byte[] cached = PL_CACHE.get(key);
        if (cached != null && t != null && System.currentTimeMillis() - t < PL_TTL) {
            send(s, 200, "application/vnd.apple.mpegurl", cached);
            return;
        }

        byte[] body = null;
        String used = null;
        for (String u : urls) {
            try {
                byte[] b = fetch(u, 9000);
                if (b != null && b.length > 0 && new String(b, "UTF-8").contains("#EXTM3U")) {
                    body = b; used = u; break;
                }
            } catch (Throwable ignore) {}
        }
        if (body == null) {
            send(s, 502, "text/plain", "playlist unavailable".getBytes("UTF-8"));
            return;
        }
        PL_CACHE.put(key, body);
        PL_TIME.put(key, System.currentTimeMillis());

        // 记录胜出线路 host；后续分片基于该 host 改写，天然走同一条好线路
        String host = hostOf(used);
        if (host != null && !host.isEmpty()) AFFINITY.put(pathOf(used), host);

        String text = new String(body, "UTF-8");
        String rewritten = rewrite(text, used);
        send(s, 200, "application/vnd.apple.mpegurl", rewritten.getBytes("UTF-8"));
    }

    static String hostOf(String url) {
        try { return new URL(url).getHost(); } catch (Throwable e) { return ""; }
    }

    static String pathOf(String url) {
        try {
            URL u = new URL(url);
            String p = u.getPath();
            return u.getHost() + (p == null ? "" : p);
        } catch (Throwable e) { return url; }
    }

    /**
     * 把 m3u8 里的相对分片 / 密钥路径改成本代理绝对地址。
     * 保留 "/seg?u=" 标记（供守卫检查与分片路由）。
     */
    public static String rewrite(String playlist, String baseUrl) {
        StringBuilder out = new StringBuilder();
        String[] lines = playlist.split("\\r?\\n");
        for (String ln : lines) {
            String line = ln.trim();
            if (line.length() == 0) { out.append(ln).append('\n'); continue; }
            if (line.startsWith("#")) {
                if (line.startsWith("#EXT-X-KEY") && line.contains("URI=\"")) {
                    int a = line.indexOf("URI=\"") + 5;
                    int b = line.indexOf('"', a);
                    if (a >= 5 && b > a) {
                        String abs = absolute(line.substring(a, b), baseUrl);
                        line = line.substring(0, a) + segUrl(abs) + line.substring(b);
                    }
                }
                out.append(line).append('\n');
            } else {
                out.append(segUrl(absolute(line, baseUrl))).append('\n');
            }
        }
        return out.toString();
    }

    public static String absolute(String ref, String base) {
        try { return new URL(new URL(base), ref).toString(); }
        catch (Exception e) { return ref; }
    }

    /** 生成分片代理地址（带当前代际，退出后旧地址立即失效） */
    static String segUrl(String abs) {
        return "http://127.0.0.1:" + PORT + "/seg?u=" + enc(abs) + "&g=" + GEN;
    }

    /**
     * 流式转发分片：边收边发、支持 Range、总时长熔断、检测客户端断连。
     * 返回 upstream 供调用方在 finally 中强制断开。
     */
    HttpURLConnection serveSegment(Socket s, String url, String range) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setConnectTimeout(9000);
        c.setReadTimeout(9000);
        c.setInstanceFollowRedirects(true);
        c.setRequestProperty("User-Agent", BiliApi.UA);
        c.setRequestProperty("Referer", BiliApi.REFERER);
        c.setRequestProperty("Accept", "*/*");
        if (range != null && range.length() > 0) c.setRequestProperty("Range", range);
        int code = c.getResponseCode();
        String ct = c.getContentType();
        if (ct == null || ct.length() == 0) ct = "video/mp2t";
        if (code >= 400) {
            send(s, code, "text/plain", ("upstream " + code).getBytes("UTF-8"));
            return c;
        }
        StringBuilder head = new StringBuilder();
        head.append("HTTP/1.1 ").append(code).append(" OK\r\n");
        head.append("Content-Type: ").append(ct).append("\r\n");
        head.append("Accept-Ranges: bytes\r\n");
        head.append("Access-Control-Allow-Origin: *\r\n");
        head.append("Connection: close\r\n");
        String cr = c.getHeaderField("Content-Range");
        if (cr != null) head.append("Content-Range: ").append(cr).append("\r\n");
        head.append("\r\n");
        OutputStream os = s.getOutputStream();
        os.write(head.toString().getBytes("UTF-8"));
        InputStream in = c.getInputStream();
        byte[] buf = new byte[64 * 1024];
        int n;
        long t0 = System.currentTimeMillis();
        while ((n = in.read(buf)) != -1) {
            // 客户端已断开 → 立即停止读上游，释放连接回池
            if (s.isClosed() || !s.isConnected()) break;
            os.write(buf, 0, n);
            // 单分片总时长熔断：慢 CDN 不拖垮线程
            if (System.currentTimeMillis() - t0 > 25000L) break;
        }
        os.flush();
        try { in.close(); } catch (Throwable ignore) {}
        return c;
    }

    /** 一次性拉取小体积文本（播放列表），带超时 */
    byte[] fetch(String url, int timeoutMs) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setConnectTimeout(timeoutMs);
        c.setReadTimeout(timeoutMs);
        c.setInstanceFollowRedirects(true);
        c.setRequestProperty("User-Agent", BiliApi.UA);
        c.setRequestProperty("Referer", BiliApi.REFERER);
        c.setRequestProperty("Accept", "*/*");
        try {
            int code = c.getResponseCode();
            InputStream in = code < 400 ? c.getInputStream() : c.getErrorStream();
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            if (in != null) {
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) != -1) bos.write(buf, 0, n);
                in.close();
            }
            return bos.toByteArray();
        } finally {
            c.disconnect();
        }
    }

    void send(Socket s, int code, String ct, byte[] body) throws Exception {
        StringBuilder h = new StringBuilder();
        h.append("HTTP/1.1 ").append(code).append(' ').append(code == 200 ? "OK" : "ERR").append("\r\n");
        h.append("Content-Type: ").append(ct).append("\r\n");
        h.append("Content-Length: ").append(body.length).append("\r\n");
        h.append("Access-Control-Allow-Origin: *\r\n");
        h.append("Cache-Control: no-store\r\n");
        h.append("Connection: close\r\n\r\n");
        OutputStream os = s.getOutputStream();
        os.write(h.toString().getBytes("UTF-8"));
        os.write(body);
        os.flush();
    }

    void close(Socket s) { try { if (s != null) s.close(); } catch (Throwable ignore) {} }
}
