#!/bin/bash
# =============================================================================
# 哔小趣 · 捐赠校验服务「一键部署 + 打包」
# =============================================================================
#
# 用途：把「配置服务端地址和公钥」这件技术活儿全部前置到打包阶段，
#       终端用户拿到 APK 后**不需要做任何配置**，扫码捐赠即可开通。
#
# 用法：
#   bash 一键部署打包.sh <服务地址>
#
#   例：bash 一键部署打包.sh https://donate.example.com
#
#   省略地址时，默认用 http://127.0.0.1:8788（仅本机调试用，正式发布请填域名）。
#
# 本脚本会做四件事：
#   1. 生成服务端 RSA 密钥对（私钥留在服务端，绝不进 APK）
#   2. 把「服务地址 + 公钥」写进 App 源码的 DonateConfig.java
#   3. 编译打包平板版 / 手机版 APK
#   4. 打印后续操作提示（启动服务 / 取管理员令牌 / 核销订单）
#
# 依赖：node（生成密钥）、JDK + Android SDK（编译 APK，见 tools/build 环境）
# =============================================================================
set -euo pipefail

SERVER_URL="${1:-http://127.0.0.1:8788}"
SERVER_URL="${SERVER_URL%/}"   # 去掉末尾斜杠

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SRC_DIR="$(cd "$SCRIPT_DIR/../androidsrc" 2>/dev/null && pwd || echo "")"

# 允许脚本放在源码包内（源码包结构：<root>/捐赠校验服务/一键部署打包.sh）
if [ -z "$SRC_DIR" ] || [ ! -d "$SRC_DIR/app" ]; then
  if [ -d "$SCRIPT_DIR/../app" ]; then
    SRC_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
  elif [ -d "$SCRIPT_DIR/../../androidsrc/app" ]; then
    SRC_DIR="$(cd "$SCRIPT_DIR/../../androidsrc" && pwd)"
  fi
fi

echo "=============================================="
echo " 哔小趣 · 捐赠校验服务 一键部署打包"
echo "=============================================="
echo " 服务地址 : $SERVER_URL"

# ----------------------------------------------------------------------------
# 1) 生成密钥
# ----------------------------------------------------------------------------
if ! command -v node >/dev/null 2>&1; then
  echo "❌ 未找到 node，请先安装 Node.js（16+）"
  exit 1
fi

mkdir -p "$SCRIPT_DIR/keys"
if [ ! -f "$SCRIPT_DIR/keys/donate_priv.pem" ]; then
  echo "→ 生成 RSA-2048 密钥对…"
  node -e "
const {generateKeyPairSync}=require('crypto');const fs=require('fs');
const {publicKey,privateKey}=generateKeyPairSync('rsa',{
  modulusLength:2048,
  publicKeyEncoding:{type:'spki',format:'der'},
  privateKeyEncoding:{type:'pkcs8',format:'pem'}});
fs.writeFileSync('$SCRIPT_DIR/keys/donate_priv.pem',privateKey);
fs.writeFileSync('$SCRIPT_DIR/keys/donate_pub.der',publicKey);
fs.writeFileSync('$SCRIPT_DIR/keys/donate_pub.hex',publicKey.toString('hex'));
"
  echo "  ✓ 已生成 keys/donate_priv.pem（私钥，请勿外传/勿提交 Git）"
else
  echo "→ 复用已有密钥 keys/donate_priv.pem"
fi

PUB_HEX="$(cat "$SCRIPT_DIR/keys/donate_pub.hex")"
PUB_B64="$(base64 -w0 "$SCRIPT_DIR/keys/donate_pub.der" 2>/dev/null || base64 "$SCRIPT_DIR/keys/donate_pub.der" | tr -d '\n')"

# ----------------------------------------------------------------------------
# 2) 写入 App 内置配置
# ----------------------------------------------------------------------------
if [ -z "$SRC_DIR" ] || [ ! -d "$SRC_DIR/app" ]; then
  echo "❌ 找不到 App 源码目录（app/），请把本脚本放在源码包的 捐赠校验服务/ 目录下再运行"
  exit 1
fi

echo "→ 写入内置配置 DonateConfig.java …"
for TARGET in app app_phone; do
  CFG="$SRC_DIR/$TARGET/src/com/bixiaoqu/app/DonateConfig.java"
  [ -f "$CFG" ] || { echo "  ! 跳过 $TARGET（未找到 $CFG）"; continue; }
  python3 - "$CFG" "$SERVER_URL" "$PUB_B64" <<'PYEOF'
import re, sys
path, url, pub = sys.argv[1], sys.argv[2], sys.argv[3]
s = open(path, encoding='utf-8').read()
s = re.sub(r'(public static final String SERVER_URL = ")[^"]*(")',
           lambda m: m.group(1) + url + m.group(2), s, count=1)
s = re.sub(r'(public static final String PUB_KEY_B64 = ")[^"]*(")',
           lambda m: m.group(1) + pub + m.group(2), s, count=1)
open(path, 'w', encoding='utf-8').write(s)
print("  ✓ " + path)
PYEOF
done

# ----------------------------------------------------------------------------
# 3) 编译打包
# ----------------------------------------------------------------------------
echo "→ 编译打包 APK …"
for TARGET in app app_phone; do
  if [ -d "$SRC_DIR/$TARGET" ] && [ -f "$SRC_DIR/$TARGET/build.sh" ]; then
    ( cd "$SRC_DIR/$TARGET" && bash build.sh >/tmp/bxq_build_$TARGET.log 2>&1 ) \
      && echo "  ✓ $TARGET 构建完成" \
      || { echo "  ✗ $TARGET 构建失败，日志：/tmp/bxq_build_$TARGET.log"; tail -20 /tmp/bxq_build_$TARGET.log; exit 1; }
  fi
done

# ----------------------------------------------------------------------------
# 4) 提示
# ----------------------------------------------------------------------------
ADMIN_TOKEN=""
if [ -f "$SCRIPT_DIR/data.json" ]; then
  ADMIN_TOKEN="$(python3 -c "import json;print(json.load(open('$SCRIPT_DIR/data.json')).get('admin_token',''))" 2>/dev/null || true)"
fi

echo ""
echo "=============================================="
echo " ✅ 打包完成"
echo "=============================================="
echo " APK 输出目录： $SRC_DIR/../  （哔小趣.apk / 哔小趣-手机版.apk）"
echo ""
echo " 接下来三步："
echo ""
echo " ① 启动服务端（在 $SCRIPT_DIR 下执行）"
echo "    ADMIN_TOKEN=你的强口令 node server.js"
echo ""
echo " ② 打开管理后台核对到账并点「核销」"
echo "    $SERVER_URL/admin"
[ -n "$ADMIN_TOKEN" ] && echo "    管理员令牌：$ADMIN_TOKEN"
echo ""
echo " ③ 把 APK 发给用户即可 —— 用户无需任何配置，扫码捐赠即自动开通。"
echo ""
echo " 提示：服务器请务必使用 HTTPS；私钥 keys/donate_priv.pem 请勿外传。"
echo "=============================================="
