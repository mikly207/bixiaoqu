package com.bixiaoqu.app;

import java.io.ByteArrayOutputStream;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URL;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * 【v4.40 实验版】直播内嵌专用本地代理。
 *
 * 背景：B 站直播 HLS 流（platform=h5 返回的 .m3u8）CDN 校验 Referer，
 * 系统 VideoView 无法设置 Referer 头，直接播放会被 403；且 m3u8 播放列表里的
 * .ts 分片是「相对路径」，VideoView 会基于 m3u8 的地址去拼分片地址。
 *
 * 方案（与点播 LocalProxy 分离，互不干扰）：
 *  1) 本机 127.0.0.1 起 ServerSocket，把 m3u8 原始地址编码进 URL 参数；
 *  2) 收到 /m3u8 请求时，拉取原始播放列表，把其中每一行相对分片/密钥路径
 *     改写为「本代理的绝对地址」（仍带原始 CDN host），写回给 VideoView；
 *  3) 收到 /seg?u=... 请求时，带 Referer/UA 转发到 CDN，边收边发（流式），
 *     支持 Range，首包即达。
 *
 * 这样 VideoView 只需要认本地地址，所有防盗链头由本代理补齐，直播得以在
 * App 内嵌播放，无需跳转第三方浏览器。
 */
public class LiveProxy implements Runnable {

    private static volatile LiveProxy INSTANCE;

    private ServerSocket server;
    private static volatile int PORT = 0;
    private volatile boolean running = true;
    private final ExecutorService pool;

    private LiveProxy() {
        final AtomicInteger seq = new AtomicInteger();
        pool = Executors.newFixedThreadPool(6, new ThreadFactory() {
            @Override public Thread newThread(Runnable r) {
                Thread t = new Thread(r, "live-proxy-" + seq.incrementAndGet());
                t.setDaemon(true);
                return t;
            }
        });
        try {
            server = new ServerSocket(0, 128, InetAddress.getByName("127.0.0.1"));
            PORT = server.getLocalPort();
            new Thread(this, "live-proxy-accept").start();
        } catch (Exception e) {
            running = false;
        }
    }

    /** 单例（进程内一个直播代理即可） */
    public static synchronized LiveProxy get() {
        if (INSTANCE == null || !INSTANCE.running) INSTANCE = new LiveProxy();
        return INSTANCE;
    }

    /** 是否已成功启动 */
    public boolean available() { return server != null && running; }

    /**
     * 把直播流原始地址包装成本地代理地址。
     * @param rawM3u8 CDN 返回的 .m3u8 原始地址
     * @return http://127.0.0.1:port/m3u8?u=<encoded>
     */
    public String wrap(String rawM3u8) {
        return "http://127.0.0.1:" + server.getLocalPort() + "/m3u8?u=" + enc(rawM3u8);
    }

    public static String enc(String s) {
        try { return URLEncoder.encode(s, "UTF-8"); }
        catch (Exception e) { return s; }
    }

    public static String dec(String s) {
        try { return URLDecoder.decode(s, "UTF-8"); }
        catch (Exception e) { return s; }
    }

    @Override public void run() {
        while (running) {
            try {
                final Socket s = server.accept();
                pool.execute(new Runnable() { @Override public void run() { handle(s); } });
            } catch (Exception e) {
                if (!running) break;
            }
        }
    }

    /** 关闭代理（退出直播页时调用；保留实例以便复用，仅停止当前监听无必要，故空实现） */
    public void shutdown() { /* 进程级单例，随 App 生命周期，不主动关闭 */ }

    /** 解析请求行里的 u= 参数 */
    static String param(String line, String key) {
        int idx = -1, from = 0;
        while (true) {
            int p = line.indexOf(key, from);
            if (p < 0) break;
            boolean boundary = (p == 0) || (line.charAt(p - 1) == '?') || (line.charAt(p - 1) == '&');
            if (boundary) { idx = p; break; }
            from = p + 1;
        }
        if (idx < 0) return null;
        int st = idx + key.length();
        int en = line.indexOf(' ', st);
        String raw = en > 0 ? line.substring(st, en) : line.substring(st);
        return dec(raw);
    }

    void handle(Socket s) {
        BufferedReader br = null;
        try {
            br = new BufferedReader(new InputStreamReader(s.getInputStream(), "UTF-8"));
            String line = br.readLine();
            if (line == null) { close(s); return; }
            String range = null;
            String rl;
            while ((rl = br.readLine()) != null && !rl.isEmpty()) {
                if (rl.regionMatches(true, 0, "Range:", 0, 6)) range = rl.substring(6).trim();
            }
            String raw = param(line, "u=");
            if (raw == null || raw.length() == 0) {
                send(s, 400, "text/plain", "missing url".getBytes("UTF-8"), null);
                return;
            }
            if (line.contains("/m3u8")) {
                servePlaylist(s, raw);
            } else {
                serveSegment(s, raw, range);
            }
        } catch (Throwable e) {
            try { close(s); } catch (Throwable ignore) {}
        }
    }

    /** 拉取 m3u8 播放列表并改写分片路径为本代理绝对地址 */
    void servePlaylist(Socket s, String url) throws Exception {
        byte[] body = fetch(url, null);
        String text = new String(body, "UTF-8");
        String rewritten = rewrite(text, url);
        send(s, 200, "application/vnd.apple.mpegurl", rewritten.getBytes("UTF-8"), null);
    }

    /**
     * 把 m3u8 里的相对分片 / 密钥路径改成本代理绝对地址：
     *  - 以 # 开头的是标签行；其中 #EXT-X-KEY 的 URI="..." 也要改写；
     *  - 其余非空行是分片地址，相对路径基于 m3u8 目录解析成绝对 URL，
     *    再包成本代理 /seg?u=...；绝对 http(s) 地址同样包一层。
     */
    public static String rewrite(String playlist, String baseUrl) {
        StringBuilder out = new StringBuilder();
        String[] lines = playlist.split("\\r?\\n");
        for (String ln : lines) {
            String line = ln.trim();
            if (line.length() == 0) { out.append(ln).append('\n'); continue; }
            if (line.startsWith("#")) {
                // 密钥 URI 改写（直播通常无加密，保险处理）
                if (line.startsWith("#EXT-X-KEY") && line.contains("URI=")) {
                    int a = line.indexOf("URI=\"") + 5;
                    int b = line.indexOf('"', a);
                    if (a >= 5 && b > a) {
                        String u = line.substring(a, b);
                        String abs = absolute(u, baseUrl);
                        line = line.substring(0, a) + segUrl(abs) + line.substring(b);
                    }
                }
                out.append(line).append('\n');
            } else {
                String abs = absolute(line, baseUrl);
                out.append(segUrl(abs)).append('\n');
            }
        }
        return out.toString();
    }

    /** 相对路径解析为绝对 URL */
    public static String absolute(String ref, String base) {
        try { return new URL(new URL(base), ref).toString(); }
        catch (Exception e) { return ref; }
    }

    /** 生成分片代理地址 */
    static String segUrl(String abs) {
        return "http://127.0.0.1:" + PORT + "/seg?u=" + enc(abs);
    }

    /** 拉取分片（流式边收边发，支持 Range） */
    void serveSegment(Socket s, String url, String range) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setConnectTimeout(12000);
        c.setReadTimeout(15000);
        c.setInstanceFollowRedirects(true);
        c.setRequestProperty("User-Agent", BiliApi.UA);
        c.setRequestProperty("Referer", BiliApi.REFERER);
        c.setRequestProperty("Accept", "*/*");
        if (range != null && range.length() > 0) c.setRequestProperty("Range", range);
        int code = c.getResponseCode();
        String ct = c.getContentType();
        if (ct == null || ct.length() == 0) ct = "video/mp2t";
        if (code >= 400) {
            send(s, code, "text/plain", ("upstream " + code).getBytes("UTF-8"), null);
            c.disconnect();
            return;
        }
        StringBuilder head = new StringBuilder();
        head.append("HTTP/1.1 ").append(code).append(" OK\r\n");
        head.append("Content-Type: ").append(ct).append("\r\n");
        head.append("Accept-Ranges: bytes\r\n");
        head.append("Access-Control-Allow-Origin: *\r\n");
        head.append("Connection: close\r\n");
        String cr = c.getHeaderField("Content-Range");
        if (cr != null) head.append("Content-Range: ").append(cr).append("\r\n");
        head.append("\r\n");
        OutputStream os = s.getOutputStream();
        os.write(head.toString().getBytes("UTF-8"));
        InputStream in = c.getInputStream();
        byte[] buf = new byte[64 * 1024];
        int n;
        while ((n = in.read(buf)) != -1) os.write(buf, 0, n);
        os.flush();
        try { in.close(); } catch (Throwable ignore) {}
        c.disconnect();
    }

    /** 一次性拉取小体积文本（m3u8） */
    byte[] fetch(String url, String range) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setConnectTimeout(12000);
        c.setReadTimeout(15000);
        c.setInstanceFollowRedirects(true);
        c.setRequestProperty("User-Agent", BiliApi.UA);
        c.setRequestProperty("Referer", BiliApi.REFERER);
        c.setRequestProperty("Accept", "*/*");
        int code = c.getResponseCode();
        InputStream in = code < 400 ? c.getInputStream() : c.getErrorStream();
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        if (in != null) {
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) != -1) bos.write(buf, 0, n);
            in.close();
        }
        c.disconnect();
        return bos.toByteArray();
    }

    void send(Socket s, int code, String ct, byte[] body, String extra) throws Exception {
        StringBuilder h = new StringBuilder();
        h.append("HTTP/1.1 ").append(code).append(' ').append(code == 200 ? "OK" : "ERR").append("\r\n");
        h.append("Content-Type: ").append(ct).append("\r\n");
        h.append("Content-Length: ").append(body.length).append("\r\n");
        h.append("Access-Control-Allow-Origin: *\r\n");
        h.append("Cache-Control: no-store\r\n");
        if (extra != null) h.append(extra);
        h.append("Connection: close\r\n\r\n");
        OutputStream os = s.getOutputStream();
        os.write(h.toString().getBytes("UTF-8"));
        os.write(body);
        os.flush();
    }

    void close(Socket s) { try { s.close(); } catch (Throwable ignore) {} }
}
