package com.bixiaoqu.app;

import android.app.Activity;
import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.MediaController;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * 【v4.40 实验版】内嵌直播页 —— 全部在 App 内播放，不跳转第三方浏览器。
 *
 * 布局：
 *  - 列表态：顶栏（返回 + 标题 + 画质）+ 分区横滑 + 直播间两列网格（封面/标题/主播/人气）
 *  - 播放态：全屏视频（TxVideoView 硬解 m3u8，经 LiveProxy 补 Referer）+ 悬浮控制条
 *     · 播放/暂停、画质切换、弹幕开关、返回、横竖屏切换
 *
 * 全部纯 Java 动态建 UI，兼容 minSdk 22；与平板/手机版共用（Activity 不区分目标，
 * 双目标差异仅在 Main/Search/Play 三个 Activity，本页不受影响）。
 */
public class LiveActivity extends Activity {

    final Handler ui = new Handler(Looper.getMainLooper());
    int dp(float v) { return (int) (getResources().getDisplayMetrics().density * v + 0.5f); }

    // ---- 主题（跟随 App）----
    int C_BG = 0xFF16181d, C_FG = 0xFFe8eaf0, C_SUB = 0xFF9aa0ab,
            C_ACC = 0xFFfb7299, C_CARD = 0xFF1f2229;
    int appliedStamp = -1;

    // ---- 分区/房间数据 ----
    static class Zone { int parent, area; String name; Zone(int p, int a, String n) { parent = p; area = a; name = n; } }
    static class Room {
        long roomId; String title, uname, cover; long online;
        Room(long r, String t, String u, String c, long o) { roomId = r; title = t; uname = u; cover = c; online = o; }
    }
    final List<Zone> zones = new ArrayList<>();
    final List<Room> rooms = new ArrayList<>();
    int zoneIndex = 0;
    int page = 1;
    final int[] QNS = {10000, 80, 64};
    final String[] QN_LABEL = {"原画", "高清", "流畅"};
    int qnIndex = 0;

    // ---- 视图 ----
    LinearLayout root;
    LinearLayout zoneBar;
    GridView grid;
    RoomAdapter adapter;
    View listLayer;
    View playLayer;
    TextView qualityBtn;
    TextView loadingTip;

    // ---- 播放器 ----
    LiveProxy proxy;
    TxVideoView video;
    MediaController mc;
    boolean playing = false;
    Room curRoom;
    boolean dmOn = true;
    DanmakuView dmView;
    TextView dmToggle;
    TextView lockHint;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        MainActivity.applyTheme(this);
        syncTheme();
        appliedStamp = MainActivity.themeStampOf(this);
        try {
            setContentView(buildList());
        } catch (Throwable e) {
            TextView tv = new TextView(this);
            tv.setText("直播页加载失败：\n" + android.util.Log.getStackTraceString(e));
            tv.setTextColor(Color.WHITE);
            tv.setPadding(dp(24), dp(60), dp(24), dp(24));
            setContentView(tv);
        }
        proxy = LiveProxy.get();
        loadZones();
    }

    void syncTheme() {
        try {
            C_BG = MainActivity.C_BG; C_FG = MainActivity.C_FG; C_SUB = MainActivity.C_SUB;
            C_ACC = MainActivity.C_ACC; C_CARD = MainActivity.C_CARD;
        } catch (Throwable ignore) {}
    }

    @Override protected void onResume() {
        super.onResume();
        if (appliedStamp != MainActivity.themeStampOf(this)) recreate();
    }

    @Override public void onBackPressed() {
        if (playing) { exitPlayer(); return; }
        super.onBackPressed();
    }

    @Override protected void onDestroy() {
        releasePlayer();
        super.onDestroy();
    }

    // ============================================================ 列表 UI

    View buildList() {
        FrameLayout frame = new FrameLayout(this);
        frame.setBackgroundColor(C_BG);

        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(C_BG);
        frame.addView(root, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // 顶栏
        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(6), dp(10), dp(10), dp(10));
        ImageView back = Ic.view(this, "back", C_FG, 22);
        back.setPadding(dp(8), dp(6), dp(10), dp(6));
        back.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { finish(); } });
        top.addView(back, new LinearLayout.LayoutParams(dp(44), dp(44)));
        TextView title = new TextView(this);
        title.setText("直播");
        title.setTextColor(C_FG);
        title.setTextSize(19);
        title.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        top.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        qualityBtn = new TextView(this);
        qualityBtn.setText(QN_LABEL[qnIndex]);
        qualityBtn.setTextColor(C_ACC);
        qualityBtn.setTextSize(13);
        qualityBtn.setPadding(dp(10), dp(6), dp(10), dp(6));
        qualityBtn.setBackground(round(C_ACC & 0x22FFFFFF | 0xFF000000, 14));
        qualityBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                qnIndex = (qnIndex + 1) % QNS.length;
                qualityBtn.setText(QN_LABEL[qnIndex]);
                Toast.makeText(LiveActivity.this, "画质：" + QN_LABEL[qnIndex] + "（下次进入直播间生效）", Toast.LENGTH_SHORT).show();
                if (playing) Toast.makeText(LiveActivity.this, "播放中切换请退出再进入", Toast.LENGTH_SHORT).show();
            }
        });
        top.addView(qualityBtn, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(top, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // 分区横滑
        android.widget.HorizontalScrollView zs = new android.widget.HorizontalScrollView(this);
        zs.setHorizontalScrollBarEnabled(false);
        zoneBar = new LinearLayout(this);
        zoneBar.setOrientation(LinearLayout.HORIZONTAL);
        zoneBar.setPadding(dp(8), dp(2), dp(8), dp(8));
        zs.addView(zoneBar, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(zs, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // 提示
        loadingTip = new TextView(this);
        loadingTip.setTextColor(C_SUB);
        loadingTip.setTextSize(13);
        loadingTip.setGravity(Gravity.CENTER);
        loadingTip.setPadding(dp(12), dp(6), dp(12), dp(6));
        root.addView(loadingTip, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // 房间网格
        grid = new GridView(this);
        grid.setNumColumns(2);
        grid.setHorizontalSpacing(dp(8));
        grid.setVerticalSpacing(dp(10));
        grid.setPadding(dp(8), dp(2), dp(8), dp(16));
        grid.setBackgroundColor(C_BG);
        grid.setSelector(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
        adapter = new RoomAdapter();
        grid.setAdapter(adapter);
        grid.setOnItemClickListener(new android.widget.AdapterView.OnItemClickListener() {
            @Override public void onItemClick(android.widget.AdapterView<?> p, View v, int pos, long id) {
                if (pos < rooms.size()) openPlayer(rooms.get(pos));
            }
        });
        root.addView(grid, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        listLayer = root;
        return frame;
    }

    GradientDrawable round(int color, float rdp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(rdp));
        return g;
    }

    String fmtNum(long n) {
        if (n >= 10000) return String.format("%.1f万", n / 10000f);
        return String.valueOf(n);
    }

    // ============================================================ 数据加载

    void loadZones() {
        new Thread(new Runnable() { @Override public void run() {
            try {
                JSONArray arr = BiliApi.liveAreas();
                final List<Zone> zs = new ArrayList<>();
                zs.add(new Zone(0, 0, "推荐"));
                if (arr != null) {
                    for (int i = 0; i < arr.length(); i++) {
                        JSONObject o = arr.optJSONObject(i);
                        if (o == null) continue;
                        int pid = o.optInt("id");
                        String pname = o.optString("name");
                        JSONArray sub = o.optJSONArray("list");
                        // 每个一级分区取前若干个二级分区
                        int lim = Math.min(sub == null ? 0 : sub.length(), 6);
                        for (int j = 0; j < lim; j++) {
                            JSONObject so = sub.optJSONObject(j);
                            int aid = so.optInt("id");
                            String aname = so.optString("name");
                            zs.add(new Zone(pid, aid, aname.isEmpty() ? pname : aname));
                        }
                    }
                }
                ui.post(new Runnable() { @Override public void run() { applyZones(zs); } });
            } catch (final Throwable e) {
                ui.post(new Runnable() { @Override public void run() {
                    // 分区接口失败也要能用：只留「推荐」
                    List<Zone> zs = new ArrayList<>();
                    zs.add(new Zone(0, 0, "推荐"));
                    applyZones(zs);
                    loadingTip.setText("分区加载失败，已使用推荐流：" + e.getMessage());
                } });
            }
        } }).start();
    }

    void applyZones(List<Zone> zs) {
        zones.clear(); zones.addAll(zs);
        zoneBar.removeAllViews();
        for (int i = 0; i < zones.size(); i++) {
            final int idx = i;
            TextView t = new TextView(this);
            t.setText(zones.get(i).name);
            t.setTextSize(14);
            t.setPadding(dp(12), dp(6), dp(12), dp(6));
            t.setTag(i);
            t.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) {
                if (zoneIndex == idx) return;
                zoneIndex = idx; page = 1; refreshZoneStyle(); loadRooms(true);
            } });
            zoneBar.addView(t, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        }
        refreshZoneStyle();
        loadRooms(true);
    }

    void refreshZoneStyle() {
        for (int i = 0; i < zoneBar.getChildCount(); i++) {
            TextView t = (TextView) zoneBar.getChildAt(i);
            boolean on = i == zoneIndex;
            t.setTextColor(on ? C_ACC : C_SUB);
            t.setTypeface(on ? android.graphics.Typeface.DEFAULT_BOLD : android.graphics.Typeface.DEFAULT);
            t.setBackground(on ? round((C_ACC & 0x00FFFFFF) | 0x22FFFFFF, 13) : null);
        }
    }

    void loadRooms(final boolean reset) {
        if (zones.isEmpty()) return;
        final Zone z = zones.get(zoneIndex);
        if (reset) { page = 1; rooms.clear(); adapter.notifyDataSetChanged(); }
        loadingTip.setText("正在加载直播间…");
        final int p = page;
        new Thread(new Runnable() { @Override public void run() {
            try {
                final JSONArray arr = BiliApi.liveRooms(z.parent, z.area, p);
                ui.post(new Runnable() { @Override public void run() {
                    if (arr == null || arr.length() == 0) {
                        loadingTip.setText(reset ? "该分区暂无直播间，试试其他分区" : "没有更多了");
                        return;
                    }
                    if (reset) rooms.clear();
                    for (int i = 0; i < arr.length(); i++) {
                        JSONObject o = arr.optJSONObject(i);
                        if (o == null) continue;
                        long rid = o.optLong("roomid");
                        String title = o.optString("title");
                        String uname = o.optString("uname");
                        String cover = o.optString("user_cover");
                        if (cover.isEmpty()) cover = o.optString("cover");
                        long online = o.optLong("online");
                        rooms.add(new Room(rid, title, uname, cover, online));
                    }
                    adapter.notifyDataSetChanged();
                    loadingTip.setText("");
                } });
            } catch (final Throwable e) {
                ui.post(new Runnable() { @Override public void run() {
                    loadingTip.setText("加载失败：" + e.getMessage() + "（点此重试）");
                    loadingTip.setOnClickListener(new View.OnClickListener() {
                        @Override public void onClick(View v) { loadRooms(true); }
                    });
                } });
            }
        } }).start();
    }

    void loadMore() {
        page++;
        loadRooms(false);
    }

    // ============================================================ 房间网格适配器

    class RoomAdapter extends BaseAdapter {
        @Override public int getCount() { return rooms.size(); }
        @Override public Object getItem(int i) { return rooms.get(i); }
        @Override public long getItemId(int i) { return rooms.get(i).roomId; }

        @Override public View getView(int i, View cv, ViewGroup parent) {
            Holder h;
            View v = cv;
            if (v == null) {
                v = new LinearLayout(LiveActivity.this);
                LinearLayout card = (LinearLayout) v;
                card.setOrientation(LinearLayout.VERTICAL);
                card.setBackground(round(C_CARD, 10));
                card.setPadding(0, 0, 0, dp(8));

                FrameLayout coverWrap = new FrameLayout(LiveActivity.this);
                h = new Holder();
                h.cover = new ImageView(LiveActivity.this);
                h.cover.setScaleType(ImageView.ScaleType.CENTER_CROP);
                h.cover.setBackgroundColor(0xFF2a2e37);
                coverWrap.addView(h.cover, new FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, dp(100)));
                h.online = new TextView(LiveActivity.this);
                h.online.setTextColor(Color.WHITE);
                h.online.setTextSize(11);
                h.online.setBackground(round(0x99000000, 8));
                h.online.setPadding(dp(6), dp(2), dp(6), dp(2));
                coverWrap.addView(h.online, new FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                        Gravity.BOTTOM | Gravity.END));
                card.addView(coverWrap, new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, dp(100)));

                h.title = new TextView(LiveActivity.this);
                h.title.setTextColor(C_FG);
                h.title.setTextSize(13);
                h.title.setMaxLines(2);
                h.title.setEllipsize(android.text.TextUtils.TruncateAt.END);
                h.title.setPadding(dp(8), dp(6), dp(8), 0);
                card.addView(h.title, new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
                h.uname = new TextView(LiveActivity.this);
                h.uname.setTextColor(C_SUB);
                h.uname.setTextSize(11);
                h.uname.setMaxLines(1);
                h.uname.setEllipsize(android.text.TextUtils.TruncateAt.END);
                h.uname.setPadding(dp(8), dp(2), dp(8), 0);
                card.addView(h.uname, new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
                v.setTag(h);
            } else h = (Holder) v.getTag();
            Room r = rooms.get(i);
            ImgLoader.load(h.cover, r.cover, 360, 200);
            h.title.setText(r.title);
            h.uname.setText("UP " + r.uname);
            h.online.setText("● " + fmtNum(r.online));
            // 滚动到底部加载更多
            if (i == rooms.size() - 1 && rooms.size() >= 10 && page < 50) loadMore();
            return v;
        }
        class Holder { ImageView cover; TextView title, uname, online; }
    }

    // ============================================================ 播放

    void openPlayer(final Room room) {
        if (!proxy.available()) { Toast.makeText(this, "直播代理启动失败", Toast.LENGTH_SHORT).show(); return; }
        curRoom = room;
        loadingTip.setText("正在获取直播流…");
        new Thread(new Runnable() { @Override public void run() {
            try {
                final String m3u8 = BiliApi.livePlayUrl(room.roomId, QNS[qnIndex]);
                ui.post(new Runnable() { @Override public void run() {
                    if (m3u8 == null) {
                        loadingTip.setText("该直播间未开播或暂不可播");
                        return;
                    }
                    startPlay(proxy.wrap(m3u8));
                } });
            } catch (final Throwable e) {
                ui.post(new Runnable() { @Override public void run() {
                    loadingTip.setText("获取直播流失败：" + e.getMessage());
                } });
            }
        } }).start();
    }

    void startPlay(String localUrl) {
        // 播放层
        if (playLayer == null) {
            playLayer = buildPlayer();
            ((FrameLayout) findViewById(android.R.id.content)).addView(playLayer, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        }
        playLayer.setVisibility(View.VISIBLE);
        playing = true;
        loadingTip.setText("");
        video.setVisibility(View.VISIBLE);
        try { video.reset(); } catch (Throwable ignore) {}
        video.setVideoPath(localUrl);
        mc.show(3500);
        try {
            video.start();
        } catch (Throwable e) {
            Toast.makeText(this, "播放启动失败：" + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
        // 直播弹幕：用本地欢迎弹幕营造氛围（真实弹幕需 WebSocket，实验版先做视觉层）
        if (dmOn && dmView != null && curRoom != null) {
            dmView.clear();
            String nm = curRoom.uname.isEmpty() ? "观众" : curRoom.uname;
            dmView.addLocal("欢迎来到 " + nm + " 的直播间");
            dmView.addLocal("主播加油！");
            dmView.addLocal("前排占座 ~");
        }
    }

    View buildPlayer() {
        FrameLayer fl = new FrameLayer(this);
        fl.setBackgroundColor(Color.BLACK);

        video = new TxVideoView(this);
        fl.addView(video, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        mc = new MediaController(this);
        mc.setAnchorView(video);
        mc.setMediaPlayer(video.innerView());

        // 弹幕层
        dmView = new DanmakuView(this);
        dmView.setClickable(false);
        dmView.setFocusable(false);
        fl.addView(dmView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // 顶部返回 + 标题 + 画质
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(8), dp(10), dp(8), dp(6));
        bar.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0xCC000000, 0x00000000}));
        ImageView back = Ic.view(this, "back", Color.WHITE, 22);
        back.setPadding(dp(8), dp(6), dp(8), dp(6));
        back.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { exitPlayer(); } });
        bar.addView(back, new LinearLayout.LayoutParams(dp(42), dp(42)));
        TextView t = new TextView(this);
        t.setText(curRoom != null ? curRoom.title : "直播");
        t.setTextColor(Color.WHITE);
        t.setTextSize(15);
        t.setMaxLines(1);
        t.setEllipsize(android.text.TextUtils.TruncateAt.END);
        bar.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        dmToggle = new TextView(this);
        dmToggle.setText(dmOn ? "弹幕 开" : "弹幕 关");
        dmToggle.setTextColor(Color.WHITE);
        dmToggle.setTextSize(12);
        dmToggle.setPadding(dp(8), dp(6), dp(8), dp(6));
        dmToggle.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) {
            dmOn = !dmOn;
            dmToggle.setText(dmOn ? "弹幕 开" : "弹幕 关");
            dmView.setVisibility(dmOn ? View.VISIBLE : View.GONE);
        } });
        bar.addView(dmToggle, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        ImageView qbtn = new ImageView(this);
        qbtn.setImageDrawable(Ic.drawable(this, "next", Color.WHITE));
        qbtn.setPadding(dp(8), dp(6), dp(4), dp(6));
        qbtn.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) {
            qnIndex = (qnIndex + 1) % QNS.length;
            Toast.makeText(LiveActivity.this, "画质切到 " + QN_LABEL[qnIndex] + "，正在重连…", Toast.LENGTH_SHORT).show();
            if (curRoom != null) openPlayer(curRoom);
        } });
        bar.addView(qbtn, new LinearLayout.LayoutParams(dp(42), dp(42)));
        fl.addView(bar, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP));

        // 底部横竖屏切换提示
        lockHint = new TextView(this);
        lockHint.setText("旋转屏幕可切换横竖屏 · 点按画面呼出控制");
        lockHint.setTextColor(0xAAFFFFFF);
        lockHint.setTextSize(11);
        lockHint.setPadding(dp(12), dp(8), dp(12), dp(8));
        fl.addView(lockHint, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL));

        video.setOnPreparedListener(new android.media.MediaPlayer.OnPreparedListener() {
            @Override public void onPrepared(android.media.MediaPlayer mp) {
                lockHint.setVisibility(View.GONE);
                mc.show(3500);
            }
        });
        video.setOnErrorListener(new android.media.MediaPlayer.OnErrorListener() {
            @Override public boolean onError(android.media.MediaPlayer mp, int what, int extra) {
                Toast.makeText(LiveActivity.this, "直播流中断，正在重试…", Toast.LENGTH_SHORT).show();
                if (curRoom != null) openPlayer(curRoom);
                return true;
            }
        });
        return fl;
    }

    /** 视频层容器：拦截点击以呼出 MediaController */
    static class FrameLayer extends FrameLayout {
        LiveActivity act;
        FrameLayer(LiveActivity a) { super(a); act = a; setClickable(true); }
        @Override public boolean onTouchEvent(android.view.MotionEvent e) {
            if (act.mc != null) act.mc.show();
            return super.onTouchEvent(e);
        }
    }

    void exitPlayer() {
        releasePlayer();
        if (playLayer != null) playLayer.setVisibility(View.GONE);
        playing = false;
        // 竖屏回到列表
        try { setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT); } catch (Throwable ignore) {}
    }

    void releasePlayer() {
        if (video != null) {
            try { video.stopPlayback(); } catch (Throwable ignore) {}
            try { video.setVisibility(View.GONE); } catch (Throwable ignore) {}
        }
        if (dmView != null) dmView.clear();
    }
}
