package com.bixiaoqu.app;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.widget.LinearLayout;

/**
 * 【v4.24.0】液态玻璃容器（去塑料感重写）。
 *
 * 继承 LinearLayout，所以老的「竖着摞几行控件」的代码可以原地替换：
 *   ctrlBar = new LinearLayout(this)  →  ctrlBar = new GlassPanel(this)
 * 子 View 的排布、padding、addView 全部照旧，只是背景从一块死色换成了玻璃材质。
 *
 * 【v4.23.0 为什么还是像塑料】
 *   旧版基底是一层 64%~75% 不透明的深灰蓝实色（0x1A1C24 / 0x0A0C11），
 *   加上 26/255 的噪点。这两样加在一起就是「半透明的深灰塑料板」：
 *   颜色是实的、边界是硬的、光没有落在上面。
 *
 * 【v4.24.0 的做法：把「颜色」换成「光学」
 *   玻璃之所以是玻璃，不是因为它是灰的，而是因为它会：
 *     ① 透 —— 身体几乎不留颜色，底下的画面要能看见；
 *     ② 化 —— 磨砂雾感把透过来的画面「化开」，这是玻璃和贴纸的分水岭；
 *     ③ 折 —— 边缘一圈折射亮线，紧挨着一道暗线（玻璃倒角被光切开的样子）；
 *     ④ 受光 —— 顶棱一道高光，底缘聚一层暗。
 *   于是这版把 75% 的实色压到 ~29%，换来另外四层光学细节。
 *   代价是白字可读性，所以所有控件文字都补了投影 —— 见 PlayActivity.glassText()。
 *
 * 全场只在「控件显示 / 按下 / 扫光」时重绘，静止时零开销；
 * 没有 RenderScript、没有 RenderEffect、没有额外线程，API22 起可用。
 */
public class GlassPanel extends LinearLayout {

    /** 圆角（dp） */
    private float radiusDp = 20f;
    /** 是否画外投影（浮在画面上时要有，嵌在页面流里可以关掉省一层绘制） */
    private boolean floating = true;
    /**
     * 基底浓度：0~255，直接就是「压暗层」的 alpha。
     * v4.23.0 用的是 190（75%），那正是塑料感的来源；现在降到 ~74（29%）。
     */
    private int tint = 0x46;
    /** 扫光进度：-1 表示不画 */
    private float sheen = -1f;

    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint edge = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint spec = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint foot = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint noisePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint noisePaint2 = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint shadow = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();
    private final RectF tmp = new RectF();
    private final RectF inner = new RectF();
    private final Path clip = new Path();

    private static Bitmap noise, noiseCoarse;

    private ValueAnimator sheenAnim;

    // ---- 着色器缓存：尺寸不变就不重建，扫光动画每帧重绘也不会产生垃圾 ----
    private int shW, shH;
    private Shader shFill, shTop, shBottom, shRadial, shEdge, shSpec, shHaze, shFootL;

    public GlassPanel(Context c) {
        super(c);
        setOrientation(VERTICAL);
        setWillNotDraw(false);          // ViewGroup 默认跳过 onDraw，材质必须自己画
        setClipChildren(false);
        setClipToPadding(false);
        edge.setStyle(Paint.Style.STROKE);
        spec.setStyle(Paint.Style.STROKE);
        float d = getResources().getDisplayMetrics().density;
        ensureNoise();
        if (noise != null) {
            noisePaint.setShader(new android.graphics.BitmapShader(
                    noise, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT));
        }
        if (noiseCoarse != null) {
            noisePaint2.setShader(new android.graphics.BitmapShader(
                    noiseCoarse, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT));
        }
    }

    // ------------------------------------------------------------ 配置

    public GlassPanel radius(float dp) {
        this.radiusDp = dp;
        invalidate();
        return this;
    }

    /** 浮在画面上（画投影）；false = 嵌在页面流里，省一层阴影绘制 */
    public GlassPanel floating(boolean on) {
        this.floating = on;
        invalidate();
        return this;
    }

    /** 基底浓度 0~255（压暗层 alpha）。越大越实，越小越通透 */
    public GlassPanel tint(int alpha) {
        this.tint = Math.max(0, Math.min(255, alpha));
        shW = 0;   // 让着色器缓存失效
        invalidate();
        return this;
    }

    /** 控件出现时扫一道光，模拟玻璃被光扫过；只跑一次 700ms，不常驻 */
    public void playSheen() {
        if (sheenAnim != null) sheenAnim.cancel();
        sheenAnim = ValueAnimator.ofFloat(-0.35f, 1.35f);
        sheenAnim.setDuration(720);
        sheenAnim.setInterpolator(new DecelerateInterpolator(1.4f));
        sheenAnim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override public void onAnimationUpdate(ValueAnimator a) {
                sheen = (Float) a.getAnimatedValue();
                invalidate();
            }
        });
        sheenAnim.start();
    }

    private int dp(float v) {
        return (int) (getResources().getDisplayMetrics().density * v + 0.5f);
    }

    // ------------------------------------------------------------ 绘制

    @Override
    protected void onDraw(Canvas cv) {
        final int w = getWidth(), h = getHeight();
        if (w <= 0 || h <= 0) return;
        final float den = getResources().getDisplayMetrics().density;
        final float r = radiusDp * den;
        rect.set(0, 0, w, h);

        // ① 外投影：四层、范围更大更柔。
        //    旧版三层小偏移高 alpha 的硬阴影，像一张贴纸浮在画面上；
        //    玻璃是「离画面很近地浮着」，影子要散、要淡。
        if (floating) {
            for (int i = 4; i >= 1; i--) {
                float off = dp(i * 1.6f);
                shadow.setColor(i == 1 ? 0x2E000000 : (i == 2 ? 0x1A000000
                        : (i == 3 ? 0x0D000000 : 0x06000000)));
                tmp.set(off * 0.3f, off * 0.85f, w - off * 0.3f, h + off * 0.7f);
                cv.drawRoundRect(tmp, r * 0.9f, r * 0.9f, shadow);
            }
        }

        if (w != shW || h != shH) {
            shW = w;
            shH = h;
            // 基底：只做「轻度压暗」保证白字可读，不再是实色板
            shFill = new LinearGradient(0, 0, 0, h,
                    withAlpha(0x000000, tint),
                    withAlpha(0x000000, Math.max(0, tint - 18)), Shader.TileMode.CLAMP);
            // 磨砂乳白雾：把透过来的画面「化开」，这是玻璃和半透明色块的分水岭
            shHaze = new LinearGradient(0, 0, 0, h,
                    0x1EFFFFFF, 0x12FFFFFF, Shader.TileMode.CLAMP);
            // 顶部受光面
            shTop = new LinearGradient(0, 0, 0, h * 0.45f, 0x26FFFFFF, 0x00FFFFFF,
                    Shader.TileMode.CLAMP);
            // 左上斜向反光（弧面受光）
            shRadial = new RadialGradient(w * 0.26f, -h * 0.28f, h * 1.65f,
                    0x1CFFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP);
            // 底缘内暗：玻璃下沿的厚度折射
            shBottom = new LinearGradient(0, h * 0.52f, 0, h, 0x00000000, 0x3A000000,
                    Shader.TileMode.CLAMP);
            // 边缘折射亮线：上强下弱
            shEdge = new LinearGradient(0, 0, 0, h, 0x8EFFFFFF, 0x1CFFFFFF,
                    Shader.TileMode.CLAMP);
            // 顶棱高光：一道更亮的细线，玻璃感主要来自这一笔
            shSpec = new LinearGradient(0, 0, 0, den * 4f, 0xC4FFFFFF, 0x00FFFFFF,
                    Shader.TileMode.CLAMP);
            // 底缘反光：中间亮、两头淡，模拟地面在玻璃下沿的反射
            shFootL = new LinearGradient(w * 0.08f, 0, w * 0.92f, 0,
                    new int[]{0x00FFFFFF, 0x40FFFFFF, 0x00FFFFFF},
                    new float[]{0f, 0.5f, 1f}, Shader.TileMode.CLAMP);
        }

        clip.reset();
        clip.addRoundRect(rect, r, r, Path.Direction.CW);
        final int sc = cv.save();
        cv.clipPath(clip);

        // ② 基底压暗（不是实色，是一层很淡的墨）
        fill.setShader(shFill);
        cv.drawRect(rect, fill);
        fill.setShader(null);

        // ③ 磨砂：乳白雾 + 双层颗粒（细颗粒 + 粗颗粒交叉，不规则才像磨砂）
        glow.setShader(shHaze);
        cv.drawRect(rect, glow);
        glow.setShader(null);

        if (noise != null) {
            noisePaint.setAlpha(30);
            cv.drawRect(rect, noisePaint);
        }
        if (noiseCoarse != null) {
            noisePaint2.setAlpha(22);
            cv.drawRect(rect, noisePaint2);
        }

        // ④ 顶部受光 + 左上斜向反光
        glow.setShader(shTop);
        cv.drawRect(rect, glow);
        glow.setShader(shRadial);
        cv.drawRect(rect, glow);
        glow.setShader(null);

        // ⑤ 底缘内暗
        glow.setShader(shBottom);
        cv.drawRect(rect, glow);
        glow.setShader(null);

        // 动态扫光：沿顶棱跑过的一道细亮光（不是整块擦白）
        if (sheen >= 0f) {
            final int sc2 = cv.save();
            cv.rotate(-14f, w * 0.5f, h * 0.5f);
            float cx = -w * 0.45f + sheen * (w * 1.9f);
            glow.setShader(new LinearGradient(cx, 0, cx + w * 0.16f, h * 0.6f,
                    0x00FFFFFF, 0x30FFFFFF, Shader.TileMode.CLAMP));
            cv.drawRect(-w, -h, w * 2, h * 2, glow);
            glow.setShader(null);
            cv.restoreToCount(sc2);
        }

        // ⑥ 按下提亮：手指按住时整块玻璃「吸一口光」
        if (isPressed()) {
            glow.setShader(null);
            glow.setColor(0x16FFFFFF);
            cv.drawRoundRect(rect, r, r, glow);
        }

        cv.restoreToCount(sc);

        // ⑦ 边缘折射：外侧一道暗线（厚度）+ 内侧一道亮线（受光）
        edge.setStrokeWidth(Math.max(1f, den));
        edge.setShader(null);
        edge.setColor(0x30000000);
        cv.drawRoundRect(rect, r, r, edge);

        final float in = Math.max(1f, den);
        inner.set(rect.left + in, rect.top + in, rect.right - in, rect.bottom - in);
        edge.setShader(shEdge);
        cv.drawRoundRect(inner, Math.max(0f, r - in), Math.max(0f, r - in), edge);
        edge.setShader(null);

        // 顶棱高光
        final float sp = Math.max(0.5f, den * 0.5f);
        inner.set(rect.left + sp, rect.top + sp, rect.right - sp, rect.bottom - sp);
        spec.setStrokeWidth(Math.max(1f, den * 0.8f));
        spec.setShader(shSpec);
        cv.drawRoundRect(inner, Math.max(0f, r - sp), Math.max(0f, r - sp), spec);
        spec.setShader(null);

        // ⑧ 底缘反光：玻璃下沿被「地面」反射托起的一线亮 —— 悬浮感的关键一笔
        final float fh = Math.max(1f, den);
        foot.setShader(shFootL);
        cv.drawRect(rect.left + r * 0.45f, rect.bottom - fh - 1f,
                rect.right - r * 0.45f, rect.bottom - 1f, foot);
        foot.setShader(null);
    }

    @Override
    public boolean onTouchEvent(MotionEvent ev) {
        // 只是为了让 isPressed() 在整块面板范围内也能触发提亮；
        // 子控件自己消费掉事件的，走各自的按压态。
        return super.onTouchEvent(ev);
    }

    @Override
    public void setPressed(boolean pressed) {
        boolean changed = isPressed() != pressed;
        super.setPressed(pressed);
        if (changed) invalidate();
    }

    /** 上次扫光时间：控件反复显隐时也不会一直闪着 */
    private long lastSheenAt;

    /**
     * 控件从隐藏变可见时扫一道光。
     * 点一下画面唤出控制条，玻璃像被「重新注满」—— 这点微动效是液态感的关键，
     * 但只在显隐的那一刻跑一次，静止时一个属性动画都不挂。
     */
    @Override
    protected void onVisibilityChanged(View changedView, int visibility) {
        super.onVisibilityChanged(changedView, visibility);
        if (changedView == this && visibility == VISIBLE && getWindowVisibility() == VISIBLE) {
            long now = android.os.SystemClock.uptimeMillis();
            if (now - lastSheenAt > 1200) {
                lastSheenAt = now;
                playSheen();
            }
        }
    }

    @Override
    protected void onDetachedFromWindow() {
        if (sheenAnim != null) {
            sheenAnim.cancel();
            sheenAnim = null;
        }
        super.onDetachedFromWindow();
    }

    private static int withAlpha(int rgb, int alpha) {
        return (Math.max(0, Math.min(255, alpha)) << 24) | (rgb & 0x00FFFFFF);
    }

    /** 细颗粒 64×64（固定种子，每次启动颗粒一致） */
    private static void ensureNoise() {
        if (noise == null || noise.isRecycled()) {
            noise = makeNoise(64, 24, 20241126L);
        }
        if (noiseCoarse == null || noiseCoarse.isRecycled()) {
            noiseCoarse = makeNoise(22, 40, 20241127L);
        }
    }

    private static Bitmap makeNoise(int n, int maxA, long seed) {
        try {
            int[] px = new int[n * n];
            java.util.Random rnd = new java.util.Random(seed);
            for (int i = 0; i < px.length; i++) {
                int a = rnd.nextInt(maxA);
                px[i] = (a << 24) | 0x00FFFFFF;
            }
            return Bitmap.createBitmap(px, n, n, Bitmap.Config.ARGB_8888);
        } catch (Throwable ignore) {
            return null;
        }
    }
}
