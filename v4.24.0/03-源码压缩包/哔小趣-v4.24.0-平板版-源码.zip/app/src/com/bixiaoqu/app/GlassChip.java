package com.bixiaoqu.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;
import android.widget.ImageView;
import android.widget.LinearLayout;

/**
 * 【v4.24.0】薄玻璃片材质：控制条上的胶囊按钮、圆形按钮。
 *
 * 【为什么旧版一眼就是塑料】
 *   旧版胶囊背景是 0x992A2F3A → 0x8C1D2129 —— 60% 不透明的深灰蓝实色块，
 *   外加一圈 1px 白描边。实色块 + 描边 = 塑料按钮的三个特征，一个不落。
 *   更糟的是它压在同样深灰的玻璃板上，两层实色叠一起，整条控制条就成了
 *   「一块贴在画面上的深灰塑料板」。
 *
 * 【真玻璃长什么样】
 *   玻璃板本身几乎是无色的，它的存在感全靠三件事传达：
 *     ① 边缘折射 —— 亮线 + 紧挨着的暗线，像玻璃倒角被光切开；
 *     ② 磨砂雾感 —— 一层极淡的乳白雾 + 细颗粒，把背景「化开」；
 *     ③ 受光 —— 顶棱一道高光，底缘聚一层暗。
 *   身体颜色要留空，让底下的视频透出来 —— 这才叫「一片玻璃」而不是「一块塑料」。
 *
 * 本类只画上面这三样，主体颜色保持透明；
 * API22 起可用，没有 RenderScript / RenderEffect / 额外线程。
 */
public class GlassChip extends Drawable {

    private final Paint pFill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pEdge = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint pSpec = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF box = new RectF();
    private final RectF inset = new RectF();
    private final Path clipPath = new Path();
    private final float den;

    /** 圆角（px）；circle=true 时忽略 */
    private final float radiusPx;
    private final boolean circle;
    /** 浅色主题：玻璃发灰、发暗（白雾换黑雾、白边换暗边） */
    private final boolean light;

    private boolean pressed;
    private int alpha = 255;

    // 着色器按尺寸缓存：静止时零开销，按下态也不重建
    private int shW, shH;
    private Shader shFog, shEdge, shSpec, shFoot, shFootL;

    public GlassChip(Context c, float radiusDp, boolean circle, boolean light) {
        den = c.getResources().getDisplayMetrics().density;
        radiusPx = radiusDp * den;
        this.circle = circle;
        this.light = light;
        pEdge.setStyle(Paint.Style.STROKE);
        pSpec.setStyle(Paint.Style.STROKE);
    }

    // ------------------------------------------------------------ 工厂

    /** 胶囊形玻璃片（按钮） */
    public static GlassChip pill(Context c, float radiusDp) {
        return new GlassChip(c, radiusDp, false, false);
    }

    /** 浅色主题下的胶囊 */
    public static GlassChip pillLight(Context c, float radiusDp) {
        return new GlassChip(c, radiusDp, false, true);
    }

    /** 正圆玻璃片（播放 / 全屏 / 更多） */
    public static GlassChip round(Context c) {
        return new GlassChip(c, 0, true, false);
    }

    /**
     * 玻璃圆钮图标：图标本体缩到 76%，四周留白由背景的柔光补足，
     * 视觉上比「图标塞满一个深色圆饼」轻得多。
     */
    public static ImageView icon(Context c, String name, int sizeDp) {
        ImageView v = new ImageView(c);
        float d = c.getResources().getDisplayMetrics().density;
        int px = (int) (sizeDp * d + 0.5f);
        v.setBackground(round(c));
        v.setScaleType(ImageView.ScaleType.CENTER);
        int pad = (int) (px * 0.22f);
        v.setPadding(pad, pad, pad, pad);
        int r = Ic.id(c, name);
        if (r != 0) v.setImageResource(r);
        v.setColorFilter(0xFFFFFFFF);
        v.setLayoutParams(new LinearLayout.LayoutParams(px, px));
        return v;
    }

    // ------------------------------------------------------------ 状态

    @Override
    public boolean isStateful() {
        return true;
    }

    @Override
    protected boolean onStateChange(int[] s) {
        boolean p = false;
        for (int i = 0; i < s.length; i++) {
            if (s[i] == android.R.attr.state_pressed) {
                p = true;
                break;
            }
        }
        if (p != pressed) {
            pressed = p;
            invalidateSelf();
        }
        return true;
    }

    @Override
    protected void onBoundsChange(Rect b) {
        shW = 0;   // 尺寸变了，着色器缓存作废
        super.onBoundsChange(b);
    }

    // ------------------------------------------------------------ 绘制

    @Override
    public void draw(Canvas cv) {
        final Rect b = getBounds();
        final int w = b.width(), h = b.height();
        if (w <= 0 || h <= 0) return;

        if (circle) {
            final float s = Math.min(w, h);
            box.set(b.left + (w - s) / 2f, b.top + (h - s) / 2f,
                    b.left + (w + s) / 2f, b.top + (h + s) / 2f);
        } else {
            box.set(b);
        }
        final float r = circle ? box.width() / 2f : Math.min(radiusPx, box.width() / 2f);

        if (w != shW || h != shH) {
            shW = w;
            shH = h;
            if (light) {
                shFog = new LinearGradient(0, box.top, 0, box.bottom,
                        0x1C000000, 0x0A000000, Shader.TileMode.CLAMP);
                shEdge = new LinearGradient(0, box.top, 0, box.bottom,
                        0x34000000, 0x12000000, Shader.TileMode.CLAMP);
                shSpec = new LinearGradient(0, box.top, 0, box.top + 3 * den,
                        0x38000000, 0x00000000, Shader.TileMode.CLAMP);
                shFoot = new LinearGradient(0, box.bottom - h * 0.55f, 0, box.bottom,
                        0x00000000, 0x14000000, Shader.TileMode.CLAMP);
            } else {
                // ① 磨砂雾：极淡的乳白，把底下画面「化开」而不是盖住
                shFog = new LinearGradient(0, box.top, 0, box.bottom,
                        0x28FFFFFF, 0x14FFFFFF, Shader.TileMode.CLAMP);
                // ② 边缘折射亮线：顶强底弱
                shEdge = new LinearGradient(0, box.top, 0, box.bottom,
                        0x8EFFFFFF, 0x1CFFFFFF, Shader.TileMode.CLAMP);
                // ③ 顶棱高光
                shSpec = new LinearGradient(0, box.top, 0, box.top + 3.5f * den,
                        0xC6FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP);
                // ④ 底缘聚暗
                shFoot = new LinearGradient(0, box.bottom - h * 0.55f, 0, box.bottom,
                        0x00000000, 0x34000000, Shader.TileMode.CLAMP);
                shFootL = new LinearGradient(box.left + w * 0.12f, 0, box.right - w * 0.12f, 0,
                        new int[]{0x00FFFFFF, 0x42FFFFFF, 0x00FFFFFF},
                        new float[]{0f, 0.5f, 1f}, Shader.TileMode.CLAMP);
            }
        }

        // ---- 主体：雾 + 底缘暗（都被圆角裁掉）
        clipPath.reset();
        clipPath.addRoundRect(box, r, r, Path.Direction.CW);
        final int sc = cv.save();
        cv.clipPath(clipPath);
        pFill.setAlpha(alpha);
        pFill.setShader(shFog);
        cv.drawRect(box, pFill);
        pFill.setShader(shFoot);
        cv.drawRect(box, pFill);
        pFill.setShader(null);
        cv.restoreToCount(sc);

        // ---- 边缘折射：内缩一道亮线
        final float in = Math.max(1f, den);
        inset.set(box.left + in, box.top + in, box.right - in, box.bottom - in);
        pEdge.setAlpha(alpha);
        pEdge.setStrokeWidth(Math.max(1f, den));
        pEdge.setShader(shEdge);
        cv.drawRoundRect(inset, Math.max(0f, r - in), Math.max(0f, r - in), pEdge);
        pEdge.setShader(null);

        // ---- 顶棱：一道更亮的细线，玻璃感主要来自这一笔
        final float sp = Math.max(0.5f, den * 0.5f);
        inset.set(box.left + sp, box.top + sp, box.right - sp, box.bottom - sp);
        pSpec.setAlpha(alpha);
        pSpec.setStrokeWidth(Math.max(1f, den * 0.8f));
        pSpec.setShader(shSpec);
        cv.drawRoundRect(inset, Math.max(0f, r - sp), Math.max(0f, r - sp), pSpec);
        pSpec.setShader(null);

        // ---- 底缘反光：玻璃片下沿被地面反射托起的一线亮
        final float fh = Math.max(1f, den);
        pSpec.setAlpha(alpha);
        pSpec.setShader(shFootL);
        cv.drawRect(box.left + box.width() * 0.12f, box.bottom - fh - 0.5f,
                box.right - box.width() * 0.12f, box.bottom - 0.5f, pSpec);
        pSpec.setShader(null);

        // ---- 按下：整片玻璃吸一口光（不是变实色，是变亮）
        if (pressed) {
            pFill.setShader(null);
            pFill.setColor(light ? 0x14000000 : 0x1CFFFFFF);
            cv.drawRoundRect(box, r, r, pFill);
        }
    }

    @Override
    public int getOpacity() {
        return android.graphics.PixelFormat.TRANSLUCENT;
    }

    /**
     * 玻璃片的颜色来自边缘光学（暗线 + 亮线 + 高光），不接受外部整体染色，
     * 否则会把通透的玻璃压成一块实色 —— 那正是要去掉的塑料感。
     */
    @Override
    public void setColorFilter(android.graphics.ColorFilter cf) {
        // no-op
    }

    @Override
    public void setAlpha(int alpha) {
        int a = Math.max(0, Math.min(255, alpha));
        if (a != this.alpha) {
            this.alpha = a;
            invalidateSelf();
        }
    }

    @Override
    public int getAlpha() {
        return alpha;
    }
}
