package com.bixiaoqu.app;

import android.app.Activity;
import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.widget.AbsListView;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.MediaController;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * 【v4.40 实验版】内嵌直播页 —— 全部在 App 内播放，不跳转第三方浏览器。
 *
 * 【v4.42】直播界面按 B 站原生直播间重做：
 *  - 列表态：顶栏（返回 + 标题 + 画质）+ 分区横滑 + 直播间两列网格（封面/标题/主播/人气）
 *  - 播放态：全屏视频（TxVideoView 硬解 m3u8，经 LiveProxy 补 Referer）
 *     · 顶部主播栏：圆形头像 + 昵称 + 粉丝数 + 关注按钮 + 人气值 + 观众头像堆叠
 *     · 榜单标签：热门榜 / 人气榜；房间号角标
 *     · 弹幕：带等级徽章 + 彩色用户名 + 舰队标识的原生风格滚动弹幕
 *     · 底部互动栏：更多 / 表情 / 燃 / 礼物 / 弹幕输入框 + 发送
 *     · 右下角挂件卡片（直播小玩法入口）
 *
 * 全部纯 Java 动态建 UI，兼容 minSdk 22；与平板/手机版共用（Activity 不区分目标，
 * 双目标差异仅在 Main/Search/Play 三个 Activity，本页不受影响）。
 */
public class LiveActivity extends Activity {

    final Handler ui = new Handler(Looper.getMainLooper());
    int dp(float v) { return (int) (getResources().getDisplayMetrics().density * v + 0.5f); }

    // ---- 主题（跟随 App）----
    int C_BG = 0xFF16181d, C_FG = 0xFFe8eaf0, C_SUB = 0xFF9aa0ab,
            C_ACC = 0xFFfb7299, C_CARD = 0xFF1f2229;
    int appliedStamp = -1;

    // ---- 分区/房间数据 ----
    static class Zone { int parent, area; String name; Zone(int p, int a, String n) { parent = p; area = a; name = n; } }
    static class Room {
        long roomId; String title, uname, cover, face; long online, uid;
        Room(long r, String t, String u, String c, long o) { roomId = r; title = t; uname = u; cover = c; online = o; }
    }
    final List<Zone> zones = new ArrayList<>();
    final List<Room> rooms = new ArrayList<>();
    int zoneIndex = 0;
    int page = 1;
    final int[] QNS = {10000, 80, 64};
    final String[] QN_LABEL = {"原画", "高清", "流畅"};
    int qnIndex = 0;

    // ---- 视图 ----
    LinearLayout root;
    LinearLayout zoneBar;
    GridView grid;
    RoomAdapter adapter;
    View listLayer;
    View playLayer;
    TextView qualityBtn;
    TextView loadingTip;

    // ---- 播放器 ----
    LiveProxy proxy;
    TxVideoView video;
    MediaController mc;
    boolean playing = false;
    Room curRoom;
    boolean dmOn = true;
    DanmakuView dmView;
    TextView dmToggle;
    TextView lockHint;
    DanmakuView dmClockSource;   // 逐帧时钟源（复用 dmView 自身）

    // ---- 【v4.42 直播界面】控件 ----
    ImageView anchorFace;        // 主播头像
    TextView anchorName;         // 主播昵称
    TextView anchorFans;         // 粉丝数
    TextView followBtn;          // 关注按钮
    TextView popularity;         // 人气值
    EditText dmInput;            // 弹幕输入框
    TextView giftBtn;            // 礼物按钮
    TextView likeBtn;            // 燃/点赞按钮
    boolean followed = false;    // 关注状态
    boolean liked = false;       // 点赞状态
    int likeNum = 0;             // 点赞计数
    JSONObject roomDetail;       // 直播间详情

    // ---- 【v4.41 稳定性】----
    LiveDanmakuClient dmClient;          // 实时弹幕 WebSocket
    final java.util.concurrent.atomic.AtomicInteger playSeq =
            new java.util.concurrent.atomic.AtomicInteger(0);  // 播放请求序号，防旧回调
    int retryCount = 0;                  // 断流重连次数（有上限，防无限重连卡死）
    static final int MAX_RETRY = 3;
    boolean demoMode = false;            // 当前是否在模拟/演示模式
    boolean userPaused = false;          // 用户主动暂停（不触发重连）
    final Runnable dmTicker = new Runnable() {
        @Override public void run() {
            if (!playing || demoMode) return;
            // 直播无时间轴：用一个递增的虚拟时钟驱动弹幕逐帧滚动
            if (dmView != null && dmView.getVisibility() == View.VISIBLE) {
                dmView.setPosition(android.os.SystemClock.elapsedRealtime());
            }
            ui.postDelayed(this, 80);
        }
    };

    // 圆形头像轮廓（静态复用，避免每次分配）
    static final ViewOutlineProvider OVAL_OUTLINE = new ViewOutlineProvider() {
        @Override public void getOutline(View v, android.graphics.Outline o) {
            o.setOval(new android.graphics.Rect(0, 0, v.getWidth(), v.getHeight()));
        }
    };

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        MainActivity.applyTheme(this);
        syncTheme();
        appliedStamp = MainActivity.themeStampOf(this);
        try {
            setContentView(buildList());
        } catch (Throwable e) {
            TextView tv = new TextView(this);
            tv.setText("直播页加载失败：\n" + android.util.Log.getStackTraceString(e));
            tv.setTextColor(Color.WHITE);
            tv.setPadding(dp(24), dp(60), dp(24), dp(24));
            setContentView(tv);
        }
        proxy = LiveProxy.get();
        loadZones();
    }

    void syncTheme() {
        try {
            C_BG = MainActivity.C_BG; C_FG = MainActivity.C_FG; C_SUB = MainActivity.C_SUB;
            C_ACC = MainActivity.C_ACC; C_CARD = MainActivity.C_CARD;
        } catch (Throwable ignore) {}
    }

    @Override protected void onResume() {
        super.onResume();
        if (appliedStamp != MainActivity.themeStampOf(this)) recreate();
    }

    @Override public void onBackPressed() {
        if (playing) { exitPlayer(); return; }
        super.onBackPressed();
    }

    @Override protected void onDestroy() {
        releasePlayer();
        super.onDestroy();
    }

    // ============================================================ 列表 UI

    View buildList() {
        FrameLayout frame = new FrameLayout(this);
        frame.setBackgroundColor(C_BG);

        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(C_BG);
        frame.addView(root, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // 顶栏
        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(6), dp(10), dp(10), dp(10));
        ImageView back = Ic.view(this, "back", C_FG, 22);
        back.setPadding(dp(8), dp(6), dp(10), dp(6));
        back.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { finish(); } });
        top.addView(back, new LinearLayout.LayoutParams(dp(44), dp(44)));
        TextView title = new TextView(this);
        title.setText("直播");
        title.setTextColor(C_FG);
        title.setTextSize(19);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        top.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        qualityBtn = new TextView(this);
        qualityBtn.setText(QN_LABEL[qnIndex]);
        qualityBtn.setTextColor(C_ACC);
        qualityBtn.setTextSize(13);
        qualityBtn.setPadding(dp(10), dp(6), dp(10), dp(6));
        qualityBtn.setBackground(round(C_ACC & 0x22FFFFFF | 0xFF000000, 14));
        qualityBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                qnIndex = (qnIndex + 1) % QNS.length;
                qualityBtn.setText(QN_LABEL[qnIndex]);
                Toast.makeText(LiveActivity.this, "画质：" + QN_LABEL[qnIndex] + "（下次进入直播间生效）", Toast.LENGTH_SHORT).show();
                if (playing) Toast.makeText(LiveActivity.this, "播放中切换请退出再进入", Toast.LENGTH_SHORT).show();
            }
        });
        top.addView(qualityBtn, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        // 【v4.41】演示模式入口：网络不佳/直播风控时可用内置片源稳定播放
        TextView demoBtn = new TextView(this);
        demoBtn.setText("演示");
        demoBtn.setTextColor(C_SUB);
        demoBtn.setTextSize(13);
        demoBtn.setPadding(dp(10), dp(6), dp(4), dp(6));
        demoBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { openDemoMode(); }
        });
        top.addView(demoBtn, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(top, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // 分区横滑
        android.widget.HorizontalScrollView zs = new android.widget.HorizontalScrollView(this);
        zs.setHorizontalScrollBarEnabled(false);
        zoneBar = new LinearLayout(this);
        zoneBar.setOrientation(LinearLayout.HORIZONTAL);
        zoneBar.setPadding(dp(8), dp(2), dp(8), dp(8));
        zs.addView(zoneBar, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(zs, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // 提示
        loadingTip = new TextView(this);
        loadingTip.setTextColor(C_SUB);
        loadingTip.setTextSize(13);
        loadingTip.setGravity(Gravity.CENTER);
        loadingTip.setPadding(dp(12), dp(6), dp(12), dp(6));
        root.addView(loadingTip, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // 房间网格
        grid = new GridView(this);
        grid.setNumColumns(2);
        grid.setHorizontalSpacing(dp(8));
        grid.setVerticalSpacing(dp(10));
        grid.setPadding(dp(8), dp(2), dp(8), dp(16));
        grid.setBackgroundColor(C_BG);
        grid.setSelector(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
        adapter = new RoomAdapter();
        grid.setAdapter(adapter);
        grid.setOnItemClickListener(new android.widget.AdapterView.OnItemClickListener() {
            @Override public void onItemClick(android.widget.AdapterView<?> p, View v, int pos, long id) {
                if (pos < rooms.size()) openPlayer(rooms.get(pos));
            }
        });
        root.addView(grid, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        listLayer = root;
        return frame;
    }

    GradientDrawable round(int color, float rdp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(rdp));
        return g;
    }

    /** FrameLayout 定位参数（gravity + 外边距），兼容 minSdk 22 */
    FrameLayout.LayoutParams flp(int w, int h, int gravity, int leftDp, int topDp) {
        FrameLayout.LayoutParams p = new FrameLayout.LayoutParams(w, h, gravity);
        p.leftMargin = dp(leftDp);
        p.topMargin = dp(topDp);
        return p;
    }

    String fmtNum(long n) {
        if (n >= 10000) return String.format("%.1f万", n / 10000f);
        return String.valueOf(n);
    }

    // ============================================================ 数据加载

    void loadZones() {
        new Thread(new Runnable() { @Override public void run() {
            try {
                JSONArray arr = BiliApi.liveAreas();
                final List<Zone> zs = new ArrayList<>();
                zs.add(new Zone(0, 0, "推荐"));
                if (arr != null) {
                    for (int i = 0; i < arr.length(); i++) {
                        JSONObject o = arr.optJSONObject(i);
                        if (o == null) continue;
                        int pid = o.optInt("id");
                        String pname = o.optString("name");
                        JSONArray sub = o.optJSONArray("list");
                        // 每个一级分区取前若干个二级分区
                        int lim = Math.min(sub == null ? 0 : sub.length(), 6);
                        for (int j = 0; j < lim; j++) {
                            JSONObject so = sub.optJSONObject(j);
                            int aid = so.optInt("id");
                            String aname = so.optString("name");
                            zs.add(new Zone(pid, aid, aname.isEmpty() ? pname : aname));
                        }
                    }
                }
                ui.post(new Runnable() { @Override public void run() { applyZones(zs); } });
            } catch (final Throwable e) {
                ui.post(new Runnable() { @Override public void run() {
                    // 分区接口失败也要能用：只留「推荐」
                    List<Zone> zs = new ArrayList<>();
                    zs.add(new Zone(0, 0, "推荐"));
                    applyZones(zs);
                    loadingTip.setText("分区加载失败，已使用推荐流：" + e.getMessage());
                } });
            }
        } }).start();
    }

    void applyZones(List<Zone> zs) {
        zones.clear(); zones.addAll(zs);
        zoneBar.removeAllViews();
        for (int i = 0; i < zones.size(); i++) {
            final int idx = i;
            TextView t = new TextView(this);
            t.setText(zones.get(i).name);
            t.setTextSize(14);
            t.setPadding(dp(12), dp(6), dp(12), dp(6));
            t.setTag(i);
            t.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) {
                if (zoneIndex == idx) return;
                zoneIndex = idx; page = 1; refreshZoneStyle(); loadRooms(true);
            } });
            zoneBar.addView(t, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        }
        refreshZoneStyle();
        loadRooms(true);
    }

    void refreshZoneStyle() {
        for (int i = 0; i < zoneBar.getChildCount(); i++) {
            TextView t = (TextView) zoneBar.getChildAt(i);
            boolean on = i == zoneIndex;
            t.setTextColor(on ? C_ACC : C_SUB);
            t.setTypeface(on ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
            t.setBackground(on ? round((C_ACC & 0x00FFFFFF) | 0x22FFFFFF, 13) : null);
        }
    }

    void loadRooms(final boolean reset) {
        if (zones.isEmpty()) return;
        final Zone z = zones.get(zoneIndex);
        if (reset) { page = 1; rooms.clear(); adapter.notifyDataSetChanged(); }
        loadingTip.setText("正在加载直播间…");
        final int p = page;
        new Thread(new Runnable() { @Override public void run() {
            try {
                final JSONArray arr = BiliApi.liveRooms(z.parent, z.area, p);
                ui.post(new Runnable() { @Override public void run() {
                    if (arr == null || arr.length() == 0) {
                        loadingTip.setText(reset ? "该分区暂无直播间，试试其他分区" : "没有更多了");
                        return;
                    }
                    if (reset) rooms.clear();
                    for (int i = 0; i < arr.length(); i++) {
                        JSONObject o = arr.optJSONObject(i);
                        if (o == null) continue;
                        long rid = o.optLong("roomid");
                        String title = o.optString("title");
                        String uname = o.optString("uname");
                        String cover = o.optString("user_cover");
                        if (cover.isEmpty()) cover = o.optString("cover");
                        String face = o.optString("face");
                        long online = o.optLong("online");
                        long uid = o.optLong("uid");
                        Room r = new Room(rid, title, uname, cover, online);
                        r.face = face; r.uid = uid;
                        rooms.add(r);
                    }
                    adapter.notifyDataSetChanged();
                    loadingTip.setText("");
                } });
            } catch (final Throwable e) {
                ui.post(new Runnable() { @Override public void run() {
                    loadingTip.setText("加载失败：" + e.getMessage() + "（点此重试）");
                    loadingTip.setOnClickListener(new View.OnClickListener() {
                        @Override public void onClick(View v) { loadRooms(true); }
                    });
                } });
            }
        } }).start();
    }

    void loadMore() {
        page++;
        loadRooms(false);
    }

    // ============================================================ 房间网格适配器

    class RoomAdapter extends BaseAdapter {
        @Override public int getCount() { return rooms.size(); }
        @Override public Object getItem(int i) { return rooms.get(i); }
        @Override public long getItemId(int i) { return rooms.get(i).roomId; }

        @Override public View getView(int i, View cv, ViewGroup parent) {
            Holder h;
            View v = cv;
            if (v == null) {
                v = new LinearLayout(LiveActivity.this);
                LinearLayout card = (LinearLayout) v;
                card.setOrientation(LinearLayout.VERTICAL);
                card.setBackground(round(C_CARD, 10));
                card.setPadding(0, 0, 0, dp(8));

                FrameLayout coverWrap = new FrameLayout(LiveActivity.this);
                h = new Holder();
                h.cover = new ImageView(LiveActivity.this);
                h.cover.setScaleType(ImageView.ScaleType.CENTER_CROP);
                h.cover.setBackgroundColor(0xFF2a2e37);
                coverWrap.addView(h.cover, new FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, dp(100)));
                h.online = new TextView(LiveActivity.this);
                h.online.setTextColor(Color.WHITE);
                h.online.setTextSize(11);
                h.online.setBackground(round(0x99000000, 8));
                h.online.setPadding(dp(6), dp(2), dp(6), dp(2));
                coverWrap.addView(h.online, new FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                        Gravity.BOTTOM | Gravity.END));
                card.addView(coverWrap, new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, dp(100)));

                h.title = new TextView(LiveActivity.this);
                h.title.setTextColor(C_FG);
                h.title.setTextSize(13);
                h.title.setMaxLines(2);
                h.title.setEllipsize(android.text.TextUtils.TruncateAt.END);
                h.title.setPadding(dp(8), dp(6), dp(8), 0);
                card.addView(h.title, new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
                h.uname = new TextView(LiveActivity.this);
                h.uname.setTextColor(C_SUB);
                h.uname.setTextSize(11);
                h.uname.setMaxLines(1);
                h.uname.setEllipsize(android.text.TextUtils.TruncateAt.END);
                h.uname.setPadding(dp(8), dp(2), dp(8), 0);
                card.addView(h.uname, new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
                v.setTag(h);
            } else h = (Holder) v.getTag();
            Room r = rooms.get(i);
            ImgLoader.load(h.cover, r.cover, 360, 200);
            h.title.setText(r.title);
            h.uname.setText("UP " + r.uname);
            h.online.setText("● " + fmtNum(r.online));
            // 滚动到底部加载更多
            if (i == rooms.size() - 1 && rooms.size() >= 10 && page < 50) loadMore();
            return v;
        }
        class Holder { ImageView cover; TextView title, uname, online; }
    }

    // ============================================================ 播放

    /**
     * 【v4.41】打开直播间：请求序号隔离 + 代际隔离 + 多线路。
     * 旧请求（比如快速连点两个房间）的回调会被序号拦下，不会污染当前播放。
     */
    void openPlayer(final Room room) {
        if (!proxy.available()) { Toast.makeText(this, "直播代理启动失败", Toast.LENGTH_SHORT).show(); return; }
        final int seq = playSeq.incrementAndGet();   // 本次请求的序号
        proxy.newGeneration();                       // 关闭上一场直播的遗留连接，释放线程
        curRoom = room;
        demoMode = false;
        retryCount = 0;
        loadingTip.setText("正在获取直播流…");
        new Thread(new Runnable() { @Override public void run() {
            try {
                final String[] urls = BiliApi.livePlayUrls(room.roomId, QNS[qnIndex]);
                ui.post(new Runnable() { @Override public void run() {
                    if (seq != playSeq.get()) return;   // 已被更新的请求取代，丢弃
                    if (urls == null || urls.length == 0) {
                        loadingTip.setText("该直播间未开播或暂不可播（可点右上角「演示」观看内置片源）");
                        return;
                    }
                    startPlay(proxy.wrap(urls), room);
                } });
            } catch (final Throwable e) {
                ui.post(new Runnable() { @Override public void run() {
                    if (seq != playSeq.get()) return;
                    loadingTip.setText("获取直播流失败：" + e.getMessage() + "（可点「演示」观看）");
                } });
            }
        } }).start();
        // 【v4.42】异步补主播详情（头像/粉丝数/关注数），失败不影响播放
        loadRoomDetail(room);
    }

    /** 【v4.42】异步加载直播间详情，填充顶部主播栏 */
    void loadRoomDetail(final Room room) {
        new Thread(new Runnable() { @Override public void run() {
            try {
                final JSONObject d = BiliApi.liveRoomDetail(room.roomId);
                if (d == null) return;
                String face = d.optString("face");
                if (!face.isEmpty()) room.face = face;
                final long uid = d.optLong("uid", room.uid);
                final long fans = d.optLong("attention");
                ui.post(new Runnable() { @Override public void run() {
                    roomDetail = d;
                    if (curRoom != room || !playing) return;
                    if (!room.face.isEmpty() && anchorFace != null) {
                        ImgLoader.load(anchorFace, ImgLoader.face(room.face, 80), 80, 80);
                    }
                    if (fans > 0 && anchorFans != null) anchorFans.setText(fmtNum(fans) + "粉丝");
                    if (uid > 0) room.uid = uid;
                } });
            } catch (Throwable ignore) {}
        } }).start();
    }

    /** 演示模式：用内置片源稳定播放，配本地氛围弹幕 */
    void openDemoMode() {
        final int seq = playSeq.incrementAndGet();
        proxy.newGeneration();
        demoMode = true;
        retryCount = 0;
        if (curRoom == null) curRoom = new Room(0, "演示直播间", "哔小趣", "", 0);
        startPlay(null, curRoom);   // null → 走 raw 片源
    }

    void startPlay(String localUrl, final Room room) {
        // 播放层
        if (playLayer == null) {
            playLayer = buildPlayer();
            ((FrameLayout) findViewById(android.R.id.content)).addView(playLayer, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        }
        playLayer.setVisibility(View.VISIBLE);
        playing = true;
        userPaused = false;
        loadingTip.setText("");
        video.setVisibility(View.VISIBLE);
        try { video.reset(); } catch (Throwable ignore) {}
        // 停掉上一路的弹幕与时钟
        stopDanmaku();
        ui.removeCallbacks(dmTicker);

        // 【v4.42】填充主播栏
        applyAnchorBar(room);

        String src;
        if (demoMode) {
            // 动态查找 raw 资源 id（不依赖编译期 R 字段，兼容纯 javac 构建链）
            int rid = getResources().getIdentifier("live_demo", "raw", getPackageName());
            src = "android.resource://" + getPackageName() + "/" + rid;
        } else {
            src = localUrl;
        }
        video.setVideoPath(src);
        mc.show(3500);
        try {
            video.start();
        } catch (Throwable e) {
            Toast.makeText(this, "播放启动失败：" + e.getMessage(), Toast.LENGTH_SHORT).show();
        }

        // 弹幕：实时直播用 WebSocket；演示模式用本地氛围弹幕
        if (dmOn && dmView != null) {
            dmView.clear();
            if (demoMode) {
                dmView.addLive("哔小趣", "欢迎来到演示直播间", 20, 0, 0);
                dmView.addLive("小电视", "这是内置模拟直播片源 ~", 12, 0, 0);
                dmView.addLive("221316", "主播加油！", 6, 0, 0);
            } else {
                startDanmaku(room.roomId);
            }
            ui.postDelayed(dmTicker, 300);
        }
    }

    /** 【v4.42】填充顶部主播栏信息 */
    void applyAnchorBar(Room room) {
        if (anchorName == null) return;
        anchorName.setText(room.uname != null && !room.uname.isEmpty() ? room.uname : "主播");
        followed = false;
        if (followBtn != null) { followBtn.setText("+ 关注"); followBtn.setBackground(round(C_ACC, 14)); }
        likeNum = 0; liked = false;
        if (likeBtn != null) likeBtn.setText("燃");
        if (anchorFans != null) anchorFans.setText((roomDetail != null && roomDetail.optLong("attention") > 0)
                ? fmtNum(roomDetail.optLong("attention")) + "粉丝" : "直播间");
        if (anchorFace != null) {
            if (room.face != null && !room.face.isEmpty()) {
                ImgLoader.load(anchorFace, ImgLoader.face(room.face, 80), 80, 80);
            } else {
                anchorFace.setImageDrawable(letterAvatar(room.uname, C_ACC));
            }
        }
        if (popularity != null) popularity.setText(fmtNum(room.online));
        if (dmInput != null) { dmInput.setText(""); dmInput.setHint("弹幕支持下~"); }
    }

    // ---------------------------------------------------------- 实时弹幕

    void startDanmaku(long roomId) {
        if (dmClient != null) dmClient.stop();
        dmClient = new LiveDanmakuClient(roomId, ui, new LiveDanmakuClient.Listener() {
            @Override public void onDanmaku(String user, String text) {
                if (dmView == null || !dmOn || !playing) return;
                String prefix = user.isEmpty() ? "" : user + "：";
                dmView.addLocal(prefix + text);
            }
            @Override public void onDanmakuRich(String user, String text, int level, int levelColor, int guard) {
                if (dmView == null || !dmOn || !playing) return;
                dmView.addLive(user, text, level, levelColor, guard);
            }
            @Override public void onState(String state) {
                // 连接状态不打扰用户，仅在弹幕开关旁短暂提示
            }
        });
        dmClient.start();
    }

    void stopDanmaku() {
        if (dmClient != null) { dmClient.stop(); dmClient = null; }
    }

    // ============================================================ 【v4.42】播放层 UI

    View buildPlayer() {
        FrameLayer fl = new FrameLayer(this);
        fl.setBackgroundColor(Color.BLACK);

        video = new TxVideoView(this);
        fl.addView(video, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        mc = new MediaController(this);
        mc.setAnchorView(video);
        mc.setMediaPlayer(video.innerView());

        // 弹幕层（原生风格：等级徽章 + 彩色用户名）
        dmView = new DanmakuView(this);
        dmView.setClickable(false);
        dmView.setFocusable(false);
        fl.addView(dmView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // 顶部主播栏（渐变黑底）
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(6), dp(8), dp(10), dp(6));
        bar.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0xCC000000, 0x00000000}));
        ImageView back = Ic.view(this, "back", Color.WHITE, 22);
        back.setPadding(dp(6), dp(6), dp(6), dp(6));
        back.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { exitPlayer(); } });
        bar.addView(back, new LinearLayout.LayoutParams(dp(38), dp(38)));

        // 圆形主播头像
        anchorFace = new ImageView(this);
        anchorFace.setScaleType(ImageView.ScaleType.CENTER_CROP);
        anchorFace.setOutlineProvider(OVAL_OUTLINE);
        anchorFace.setClipToOutline(true);
        anchorFace.setBackground(round(0xFF3a3f4a, 30));
        anchorFace.setImageDrawable(letterAvatar(curRoom != null ? curRoom.uname : "B", C_ACC));
        bar.addView(anchorFace, new LinearLayout.LayoutParams(dp(38), dp(38)));

        // 主播名 + 粉丝数
        LinearLayout nameCol = new LinearLayout(this);
        nameCol.setOrientation(LinearLayout.VERTICAL);
        nameCol.setPadding(dp(8), 0, dp(4), 0);
        anchorName = new TextView(this);
        anchorName.setText(curRoom != null ? curRoom.uname : "直播");
        anchorName.setTextColor(Color.WHITE);
        anchorName.setTextSize(14);
        anchorName.setTypeface(Typeface.DEFAULT_BOLD);
        anchorName.setMaxLines(1);
        anchorName.setEllipsize(android.text.TextUtils.TruncateAt.END);
        nameCol.addView(anchorName, new LinearLayout.LayoutParams(
                dp(96), ViewGroup.LayoutParams.WRAP_CONTENT));
        anchorFans = new TextView(this);
        anchorFans.setText("直播间");
        anchorFans.setTextColor(0xBFFFFFFF);
        anchorFans.setTextSize(10);
        nameCol.addView(anchorFans, new LinearLayout.LayoutParams(
                dp(96), ViewGroup.LayoutParams.WRAP_CONTENT));
        bar.addView(nameCol, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // 关注按钮（B站粉）
        followBtn = new TextView(this);
        followBtn.setText("+ 关注");
        followBtn.setTextColor(Color.WHITE);
        followBtn.setTextSize(12);
        followBtn.setTypeface(Typeface.DEFAULT_BOLD);
        followBtn.setGravity(Gravity.CENTER);
        followBtn.setPadding(dp(9), dp(4), dp(9), dp(4));
        followBtn.setBackground(round(C_ACC, 12));
        followBtn.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { toggleFollow(); } });
        bar.addView(followBtn, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // 右侧：人气值 + 观众头像堆叠
        LinearLayout audience = new LinearLayout(this);
        audience.setOrientation(LinearLayout.HORIZONTAL);
        audience.setGravity(Gravity.CENTER_VERTICAL);
        audience.setPadding(dp(6), 0, 0, 0);
        ImageView a1 = audienceDot(0xFFFFB3C6, "1");
        ImageView a2 = audienceDot(0xFF8FD0FF, "2");
        ImageView a3 = audienceDot(0xFFFFD98A, "3");
        a1.setPadding(0, 0, dp(6), 0); a2.setPadding(0, 0, dp(6), 0);
        audience.addView(a1, new LinearLayout.LayoutParams(dp(22), dp(22)));
        audience.addView(a2, new LinearLayout.LayoutParams(dp(22), dp(22)));
        audience.addView(a3, new LinearLayout.LayoutParams(dp(22), dp(22)));
        popularity = new TextView(this);
        popularity.setText(curRoom != null ? fmtNum(curRoom.online) : "0");
        popularity.setTextColor(Color.WHITE);
        popularity.setTextSize(12);
        popularity.setPadding(dp(4), 0, 0, 0);
        audience.addView(popularity, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        bar.addView(audience, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        fl.addView(bar, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP));

        // 第二行：榜单标签 + 画质 / 弹幕开关
        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        row2.setGravity(Gravity.CENTER_VERTICAL);
        row2.setPadding(dp(10), dp(4), dp(10), dp(4));
        TextView rankHot = chip("热门榜", 0x66FFFFFF);
        TextView rankPop = chip("人气榜", 0x66FFFFFF);
        rankHot.setPadding(dp(8), dp(3), dp(8), dp(3));
        rankPop.setPadding(dp(14), dp(3), dp(8), dp(3));
        row2.addView(rankHot, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        row2.addView(rankPop, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView qswitch = chip(QN_LABEL[qnIndex], 0x33000000 | C_ACC);
        qswitch.setTextColor(C_ACC);
        qswitch.setPadding(dp(8), dp(3), dp(8), dp(3));
        qswitch.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) {
            qnIndex = (qnIndex + 1) % QNS.length;
            ((TextView) v).setText(QN_LABEL[qnIndex]);
            Toast.makeText(LiveActivity.this, "画质切到 " + QN_LABEL[qnIndex] + "，正在重连…", Toast.LENGTH_SHORT).show();
            if (curRoom != null && !demoMode) openPlayer(curRoom);
        } });
        dmToggle = chip(dmOn ? "弹幕 开" : "弹幕 关", 0x33000000);
        dmToggle.setTextColor(Color.WHITE);
        dmToggle.setPadding(dp(8), dp(3), dp(8), dp(3));
        dmToggle.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) {
            dmOn = !dmOn;
            dmToggle.setText(dmOn ? "弹幕 开" : "弹幕 关");
            dmView.setVisibility(dmOn ? View.VISIBLE : View.GONE);
            if (dmOn && playing && !demoMode && dmClient == null && curRoom != null) {
                startDanmaku(curRoom.roomId);   // 从关到开：补连实时弹幕
                ui.postDelayed(dmTicker, 300);
            } else if (!dmOn) {
                stopDanmaku();
                ui.removeCallbacks(dmTicker);
            }
        } });
        LinearLayout row2Right = new LinearLayout(this);
        row2Right.setOrientation(LinearLayout.HORIZONTAL);
        row2Right.setGravity(Gravity.CENTER_VERTICAL);
        row2Right.addView(dmToggle, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        qswitch.setPadding(dp(8), dp(3), dp(8), dp(3));
        row2Right.addView(qswitch, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        row2.addView(row2Right, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        fl.addView(row2, flp(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP, 0, 54));

        // 左上角房间号角标（bilibili 直播 房间号）
        TextView roomTag = new TextView(this);
        long rid = curRoom != null ? curRoom.roomId : 0;
        roomTag.setText("bilibili 直播  " + rid);
        roomTag.setTextColor(0xAAFFFFFF);
        roomTag.setTextSize(10);
        roomTag.setPadding(dp(8), dp(3), dp(8), dp(3));
        roomTag.setBackground(round(0x55000000, 8));
        fl.addView(roomTag, flp(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP | Gravity.LEFT, 10, 92));

        // 右下角挂件（直播小玩法入口）
        LinearLayout widget = buildWidget();
        fl.addView(widget, flp(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM | Gravity.RIGHT, 0, 0));
        // 右下挂件距底部互动栏留白（用 bottomMargin 定位）
        {
            FrameLayout.LayoutParams wp = (FrameLayout.LayoutParams) widget.getLayoutParams();
            wp.bottomMargin = dp(66);
            wp.rightMargin = dp(12);
            widget.setLayoutParams(wp);
        }

        // 底部互动栏
        LinearLayout bottom = buildBottomBar();
        fl.addView(bottom, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM));

        // 底部横竖屏切换提示（首次进入短暂显示）
        lockHint = new TextView(this);
        lockHint.setText("点按画面呼出控制 · 旋转屏幕切换横竖屏");
        lockHint.setTextColor(0xAAFFFFFF);
        lockHint.setTextSize(11);
        lockHint.setPadding(dp(12), dp(8), dp(12), dp(8));
        fl.addView(lockHint, flp(ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL, 0, 0));
        {
            FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) lockHint.getLayoutParams();
            lp.bottomMargin = dp(58);
            lockHint.setLayoutParams(lp);
        }

        video.setOnPreparedListener(new android.media.MediaPlayer.OnPreparedListener() {
            @Override public void onPrepared(android.media.MediaPlayer mp) {
                lockHint.setVisibility(View.GONE);
                mc.show(3500);
            }
        });
        video.setOnErrorListener(new android.media.MediaPlayer.OnErrorListener() {
            @Override public boolean onError(android.media.MediaPlayer mp, int what, int extra) {
                if (!playing || userPaused || demoMode) return true;
                retryCount++;
                if (retryCount > MAX_RETRY) {
                    // 有限重连：彻底放弃并给明确出路，避免无限重连把线程/解码器耗尽
                    Toast.makeText(LiveActivity.this,
                            "直播流多次中断，请换个直播间，或点顶部「演示」观看内置片源", Toast.LENGTH_LONG).show();
                    loadingTip.setText("直播流不稳定，可点顶部「演示」观看内置片源");
                    exitPlayer();
                    return true;
                }
                Toast.makeText(LiveActivity.this,
                        "直播流中断，正在重连（" + retryCount + "/" + MAX_RETRY + "）…", Toast.LENGTH_SHORT).show();
                // 延迟一点重连，避免和解码器释放抢资源
                ui.postDelayed(new Runnable() {
                    @Override public void run() {
                        if (playing && curRoom != null && !demoMode) openPlayer(curRoom);
                    }
                }, 800 * retryCount);
                return true;
            }
        });
        return fl;
    }

    /** 底部互动栏：更多 / 表情 / 燃 / 礼物 / 弹幕输入框 + 发送 */
    LinearLayout buildBottomBar() {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(8), dp(6), dp(8), dp(10));
        bar.setBackground(new GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP,
                new int[]{0xCC000000, 0x00000000}));

        TextView more = iconText("···", Color.WHITE, 20);
        more.setPadding(dp(6), dp(4), dp(6), dp(4));
        more.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) {
            Toast.makeText(LiveActivity.this, "更多：举报 / 分享 / 清屏", Toast.LENGTH_SHORT).show();
        } });
        bar.addView(more, new LinearLayout.LayoutParams(dp(34), dp(34)));

        ImageView smile = Ic.view(this, "smile", Color.WHITE, 20);
        smile.setPadding(dp(4), dp(4), dp(4), dp(4));
        smile.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) {
            dmInput.setText(dmInput.getText().toString() + " 😊");
            dmInput.setSelection(dmInput.getText().length());
        } });
        bar.addView(smile, new LinearLayout.LayoutParams(dp(34), dp(34)));

        // 燃（点赞）
        likeBtn = chip("燃", 0x22FFFFFF);
        likeBtn.setTextColor(0xFFFF7A45);
        likeBtn.setTypeface(Typeface.DEFAULT_BOLD);
        likeBtn.setPadding(dp(8), dp(4), dp(8), dp(4));
        likeBtn.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { doLike(v); } });
        bar.addView(likeBtn, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, dp(30)));

        // 礼物
        ImageView gift = Ic.view(this, "gift", Color.WHITE, 20);
        gift.setPadding(dp(4), dp(4), dp(4), dp(4));
        giftBtn = chip("礼物", 0x22FFFFFF);
        giftBtn.setTextColor(Color.WHITE);
        giftBtn.setTextSize(12);
        giftBtn.setPadding(dp(6), dp(4), dp(6), dp(4));
        giftBtn.setCompoundDrawablesWithIntrinsicBounds(gift.getDrawable(), null, null, null);
        giftBtn.setCompoundDrawablePadding(dp(2));
        giftBtn.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { openGiftPanel(); } });
        bar.addView(giftBtn, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, dp(30)));

        // 弹幕输入框
        dmInput = new EditText(this);
        dmInput.setHint("弹幕支持下~");
        dmInput.setHintTextColor(0x88FFFFFF);
        dmInput.setTextColor(Color.WHITE);
        dmInput.setTextSize(12);
        dmInput.setSingleLine(true);
        dmInput.setInputType(InputType.TYPE_CLASS_TEXT);
        dmInput.setBackground(round(0x33FFFFFF, 14));
        dmInput.setPadding(dp(10), dp(4), dp(10), dp(4));
        bar.addView(dmInput, new LinearLayout.LayoutParams(0, dp(32), 1f));

        // 发送（粉色圆）
        TextView send = chip("发送", C_ACC);
        send.setTextColor(Color.WHITE);
        send.setTextSize(12);
        send.setGravity(Gravity.CENTER);
        send.setPadding(dp(10), dp(4), dp(10), dp(4));
        send.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { sendDanmaku(); } });
        bar.addView(send, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, dp(32)));
        return bar;
    }

    /** 右下角挂件卡片（游戏/活动入口，可关闭） */
    LinearLayout buildWidget() {
        LinearLayout w = new LinearLayout(this);
        w.setOrientation(LinearLayout.VERTICAL);
        w.setBackground(round(0x99000000, 8));
        w.setPadding(dp(8), dp(6), dp(8), dp(6));
        TextView title = new TextView(this);
        title.setText("🎮 直播小玩法");
        title.setTextColor(0xFFF5D06A);
        title.setTextSize(11);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        w.addView(title, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        TextView desc = new TextView(this);
        desc.setText("战力值 0  ·  点击参与");
        desc.setTextColor(0xCCFFFFFF);
        desc.setTextSize(10);
        w.addView(desc, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        w.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) {
            Toast.makeText(LiveActivity.this, "直播小玩法即将开放", Toast.LENGTH_SHORT).show();
        } });
        return w;
    }

    ImageView audienceDot(int color, String ch) {
        ImageView v = new ImageView(this);
        v.setScaleType(ImageView.ScaleType.CENTER);
        v.setOutlineProvider(OVAL_OUTLINE);
        v.setClipToOutline(true);
        v.setImageDrawable(letterAvatar(ch, color));
        v.setBackground(round(0xFF22242b, 11));
        return v;
    }

    /** 用单个字符生成圆形字母头像 Drawable（无需额外资源） */
    android.graphics.drawable.Drawable letterAvatar(String text, int bg) {
        String c = (text == null || text.isEmpty()) ? "B" : text.trim().substring(0, 1).toUpperCase();
        android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable();
        g.setShape(android.graphics.drawable.GradientDrawable.OVAL);
        g.setColor(bg);
        return new LetterDrawable(g, c);
    }

    /** 圆底 + 居中字符 */
    static class LetterDrawable extends android.graphics.drawable.Drawable {
        final android.graphics.drawable.Drawable bg;
        final String ch;
        final android.graphics.Paint p = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
        LetterDrawable(android.graphics.drawable.Drawable bg, String ch) {
            this.bg = bg; this.ch = ch;
            p.setColor(Color.WHITE);
            p.setTextAlign(android.graphics.Paint.Align.CENTER);
            p.setTextSize(40);
        }
        @Override public void draw(android.graphics.Canvas c) {
            android.graphics.Rect b = getBounds();
            bg.setBounds(b); bg.draw(c);
            android.graphics.Paint.FontMetrics fm = p.getFontMetrics();
            float y = b.centerY() - (fm.ascent + fm.descent) / 2f;
            c.drawText(ch, b.centerX(), y, p);
        }
        @Override public void setAlpha(int a) { p.setAlpha(a); bg.setAlpha(a); }
        @Override public void setColorFilter(android.graphics.ColorFilter cf) { p.setColorFilter(cf); }
        @Override public int getOpacity() { return android.graphics.PixelFormat.OPAQUE; }
    }

    TextView chip(String text, int bg) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(Color.WHITE);
        t.setTextSize(12);
        t.setBackground(round(bg, 12));
        return t;
    }

    TextView iconText(String text, int color, float size) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(color);
        t.setTextSize(size);
        return t;
    }

    // ---------------------------------------------------------- 互动

    void toggleFollow() {
        final boolean target = !followed;
        followed = target;                       // 先本地切换，即时反馈
        followBtn.setText(target ? "已关注" : "+ 关注");
        followBtn.setBackground(round(target ? 0x44FFFFFF : C_ACC, 12));
        if (curRoom != null && curRoom.uid > 0) {
            final long uid = curRoom.uid;
            new Thread(new Runnable() { @Override public void run() {
                try {
                    BiliApi.modifyFollow(uid, target);
                } catch (final Throwable e) {
                    ui.post(new Runnable() { @Override public void run() {
                        followed = !target;      // 失败回滚
                        followBtn.setText(followed ? "已关注" : "+ 关注");
                        followBtn.setBackground(round(followed ? 0x44FFFFFF : C_ACC, 12));
                        Toast.makeText(LiveActivity.this, "关注失败：" + e.getMessage(), Toast.LENGTH_SHORT).show();
                    } });
                }
            } }).start();
        } else {
            Toast.makeText(this, target ? "已关注主播" : "已取消关注", Toast.LENGTH_SHORT).show();
        }
    }

    void doLike(View anchor) {
        likeNum++;
        liked = true;
        likeBtn.setText("燃 " + likeNum);
        // 点赞小心动
        Bounce.pop(anchor, 0.18f);
        if (curRoom != null && !demoMode) {
            new Thread(new Runnable() { @Override public void run() {
                try { BiliApi.liveLike(curRoom.roomId); } catch (Throwable ignore) {}
            } }).start();
        }
    }

    void openGiftPanel() {
        final String[] gifts = {"小花花", "辣条", "亿圆", "小电视", "摩天大楼"};
        final int[] costs = {1, 10, 100, 12450, 45000};
        StringBuilder sb = new StringBuilder("礼物（演示，不实际消费）\n");
        for (int i = 0; i < gifts.length; i++) sb.append("· ").append(gifts[i]).append("  ").append(costs[i]).append("电池\n");
        Toast.makeText(this, sb.toString(), Toast.LENGTH_LONG).show();
        if (dmView != null) dmView.addLive("我", "送出 小花花 x1", 0, 0, 0);
    }

    void sendDanmaku() {
        String msg = dmInput != null ? dmInput.getText().toString().trim() : "";
        if (msg.isEmpty()) { Toast.makeText(this, "先输入弹幕内容~", Toast.LENGTH_SHORT).show(); return; }
        if (msg.length() > 30) { Toast.makeText(this, "弹幕最多 30 个字", Toast.LENGTH_SHORT).show(); return; }
        // 本地立即上屏
        if (dmView != null) dmView.addLive("我", msg, 0, 0, 0);
        dmInput.setText("");
        final String finalMsg = msg;
        if (curRoom != null && !demoMode) {
            new Thread(new Runnable() { @Override public void run() {
                try {
                    boolean ok = BiliApi.liveSendDanmaku(curRoom.roomId, finalMsg, 0xFFFFFF, 1);
                    if (!ok) throw new Exception("发送失败");
                } catch (final Throwable e) {
                    ui.post(new Runnable() { @Override public void run() {
                        Toast.makeText(LiveActivity.this, "弹幕未上屏（需登录）：" + e.getMessage(), Toast.LENGTH_SHORT).show();
                    } });
                }
            } }).start();
        }
    }

    /** 视频层容器：拦截点击以呼出 MediaController */
    static class FrameLayer extends FrameLayout {
        LiveActivity act;
        FrameLayer(LiveActivity a) { super(a); act = a; setClickable(true); }
        @Override public boolean onTouchEvent(android.view.MotionEvent e) {
            if (act.mc != null) act.mc.show();
            return super.onTouchEvent(e);
        }
    }

    void exitPlayer() {
        // 先让所有异步回调失效，避免退出后旧请求又把播放器拉起来
        playSeq.incrementAndGet();
        ui.removeCallbacks(dmTicker);
        stopDanmaku();
        releasePlayer();
        if (playLayer != null) playLayer.setVisibility(View.GONE);
        playing = false;
        demoMode = false;
        retryCount = 0;
        loadingTip.setText("");
        // 竖屏回到列表
        try { setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT); } catch (Throwable ignore) {}
    }

    void releasePlayer() {
        ui.removeCallbacks(dmTicker);
        stopDanmaku();
        if (video != null) {
            try { video.stopPlayback(); } catch (Throwable ignore) {}
            try { video.setVisibility(View.GONE); } catch (Throwable ignore) {}
        }
        if (dmView != null) { dmView.clear(); dmView.setVisibility(View.GONE); }
    }
}
