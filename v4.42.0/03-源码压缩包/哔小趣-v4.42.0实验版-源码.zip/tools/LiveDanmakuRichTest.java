import com.bixiaoqu.app.DanmakuView;
import com.bixiaoqu.app.LiveDanmakuClient;

/**
 * 【v4.42】直播弹幕富文本纯逻辑单测：等级配色映射 + B站颜色值解析。
 * 不依赖 Android 运行时（只测静态纯函数），可在 JVM 直接跑。
 */
public class LiveDanmakuRichTest {

    static int pass = 0, fail = 0;
    static void ck(String name, boolean ok) {
        System.out.println((ok ? "  PASS " : "  FAIL ") + name);
        if (ok) pass++; else fail++;
    }

    public static void main(String[] args) {
        System.out.println("=== LiveDanmakuRichTest ===");

        // 等级配色：按 B站 UL 等级分段
        ck("Lv1 蓝色", DanmakuView.levelColorOf(1) == 0xFF6FA8FF);
        ck("Lv6 黄色", DanmakuView.levelColorOf(6) == 0xFFF5C93B);
        ck("Lv12 橙色", DanmakuView.levelColorOf(12) == 0xFFFF9A2E);
        ck("Lv18 品红", DanmakuView.levelColorOf(18) == 0xFFF073B4);
        ck("Lv25 粉色", DanmakuView.levelColorOf(25) == 0xFFFB7299);
        ck("Lv60 仍粉色(夹取)", DanmakuView.levelColorOf(60) == 0xFFFB7299);

        // B站颜色解析：十进制颜色值 → ARGB
        ck("白色 16777215", LiveDanmakuClient.parseColor(16777215) == 0xFFFFFFFF);
        ck("红色 16711680", LiveDanmakuClient.parseColor(16711680) == 0xFFFF0000);
        ck("字符串颜色", LiveDanmakuClient.parseColor("65535") == 0xFF00FFFF);
        ck("0 → 0(用默认色)", LiveDanmakuClient.parseColor(0) == 0);
        ck("非法值 → 0", LiveDanmakuClient.parseColor("abc") == 0);
        ck("负数 → 0", LiveDanmakuClient.parseColor(-1) == 0);

        System.out.println("结果: " + pass + " PASS / " + fail + " FAIL");
        if (fail > 0) System.exit(1);
    }
}
