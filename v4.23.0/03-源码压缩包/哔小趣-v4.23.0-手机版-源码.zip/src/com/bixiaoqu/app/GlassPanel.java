package com.bixiaoqu.app;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.widget.LinearLayout;

/**
 * 【v4.23.0】液态玻璃容器。
 *
 * 继承 LinearLayout，所以老的「竖着摞几行控件」的代码可以原地替换：
 *   ctrlBar = new LinearLayout(this)  →  ctrlBar = new GlassPanel(this)
 * 子 View 的排布、padding、addView 全部照旧，只是背景从一块死色换成了玻璃材质。
 *
 * 为什么是一层层画而不是一张背景图：
 *   苹果 Liquid Glass 的观感由「体积 + 受光 + 边缘 + 磨砂」四件事叠出来，
 *   单张纯色圆角图永远像塑料。这里按真实光学顺序叠：
 *     ① 外投影（三层递减）—— 悬浮感，越靠下越虚
 *     ② 主体染色（上浅下深的竖向渐变）—— 玻璃厚度
 *     ③ 磨砂颗粒（TileMode.REPEAT 的噪点）—— 这是「玻璃」和「半透明色块」的分界
 *     ④ 顶部柔光 + 左上一道斜向扫光 —— 受光面
 *     ⑤ 底部内暗边 —— 玻璃下缘的厚度折射
 *     ⑥ 1dp 上亮下暗的描边 —— 棱
 *     ⑦ 按下时的整体提亮 —— 触感反馈
 *
 * 全场只在「控件显示 / 按下 / 扫光」时重绘，静止时零开销；
 * 没有 RenderScript、没有 RenderEffect、没有额外线程，API22 起可用。
 */
public class GlassPanel extends LinearLayout {

    /** 圆角（dp） */
    private float radiusDp = 20f;
    /** 是否画外投影（浮在画面上时要有，嵌在页面流里可以关掉省一层绘制） */
    private boolean floating = true;
    /** 主体染色浓度：0~255。深色主题下 0.62 左右既通透又保证文字可读 */
    private int tint = 0xA0;
    /** 扫光进度：-1 表示不画 */
    private float sheen = -1f;

    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint edge = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint noisePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint shadow = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();
    private final RectF tmp = new RectF();
    private final Path clip = new Path();

    private static Bitmap noise;

    private ValueAnimator sheenAnim;

    // ---- 着色器缓存：尺寸不变就不重建，扫光动画每帧重绘也不会产生垃圾 ----
    private int shW, shH;
    private Shader shFill, shTop, shBottom, shRadial, shEdge;

    public GlassPanel(Context c) {
        super(c);
        setOrientation(VERTICAL);
        setWillNotDraw(false);          // ViewGroup 默认跳过 onDraw，材质必须自己画
        setClipChildren(false);
        setClipToPadding(false);
        edge.setStyle(Paint.Style.STROKE);
        float d = getResources().getDisplayMetrics().density;
        noise = ensureNoise();
        if (noise != null) noisePaint.setShader(new android.graphics.BitmapShader(
                noise, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT));
    }

    // ------------------------------------------------------------ 配置

    public GlassPanel radius(float dp) {
        this.radiusDp = dp;
        invalidate();
        return this;
    }

    /** 浮在画面上（画投影）；false = 嵌在页面流里，省一层阴影绘制 */
    public GlassPanel floating(boolean on) {
        this.floating = on;
        invalidate();
        return this;
    }

    /** 染色浓度 0~255 */
    public GlassPanel tint(int alpha) {
        this.tint = Math.max(0, Math.min(255, alpha));
        shW = 0;   // 让着色器缓存失效
        invalidate();
        return this;
    }

    /** 控件出现时扫一道光，模拟玻璃被光扫过；只跑一次 700ms，不常驻 */
    public void playSheen() {
        if (sheenAnim != null) sheenAnim.cancel();
        sheenAnim = ValueAnimator.ofFloat(-0.35f, 1.35f);
        sheenAnim.setDuration(720);
        sheenAnim.setInterpolator(new DecelerateInterpolator(1.4f));
        sheenAnim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override public void onAnimationUpdate(ValueAnimator a) {
                sheen = (Float) a.getAnimatedValue();
                invalidate();
            }
        });
        sheenAnim.start();
    }

    private int dp(float v) {
        return (int) (getResources().getDisplayMetrics().density * v + 0.5f);
    }

    // ------------------------------------------------------------ 绘制

    @Override
    protected void onDraw(Canvas cv) {
        final int w = getWidth(), h = getHeight();
        if (w <= 0 || h <= 0) return;
        final float r = radiusDp * getResources().getDisplayMetrics().density;
        rect.set(0, 0, w, h);

        // ① 外投影：三层递减，越往下越虚，制造「悬浮在画面之上」
        if (floating) {
            for (int i = 3; i >= 1; i--) {
                float off = dp(i * 2.0f);
                shadow.setColor(i == 1 ? 0x3D000000 : (i == 2 ? 0x1F000000 : 0x0F000000));
                tmp.set(off * 0.35f, off * 0.9f, w - off * 0.35f, h + off * 0.8f);
                cv.drawRoundRect(tmp, r * 0.85f, r * 0.85f, shadow);
            }
        }

        if (w != shW || h != shH) {
            shW = w;
            shH = h;
            shFill = new LinearGradient(0, 0, 0, h,
                    withAlpha(0x1A1C24, (int) (tint * 0.86f)),
                    withAlpha(0x0A0C11, tint), Shader.TileMode.CLAMP);
            shTop = new LinearGradient(0, 0, 0, h * 0.55f, 0x26FFFFFF, 0x00FFFFFF,
                    Shader.TileMode.CLAMP);
            shRadial = new RadialGradient(w * 0.22f, -h * 0.35f, h * 1.55f,
                    0x1EFFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP);
            shBottom = new LinearGradient(0, h * 0.62f, 0, h, 0x00000000, 0x38000000,
                    Shader.TileMode.CLAMP);
            shEdge = new LinearGradient(0, 0, 0, h, 0x52FFFFFF, 0x0DFFFFFF,
                    Shader.TileMode.CLAMP);
        }

        clip.reset();
        clip.addRoundRect(rect, r, r, Path.Direction.CW);
        final int sc = cv.save();
        cv.clipPath(clip);

        // ② 主体染色：上浅下深，玻璃有厚度才不会像贴纸
        fill.setShader(shFill);
        cv.drawRect(rect, fill);
        fill.setShader(null);

        // ③ 磨砂颗粒：整块面板最重要的一层，靠它把「半透明色块」变成「玻璃」
        if (noise != null) {
            noisePaint.setAlpha(26);
            cv.drawRect(rect, noisePaint);
        }

        // ④ 顶部柔光（受光面）+ 左上一道斜向扫光（弧面反光）
        glow.setShader(shTop);
        cv.drawRect(rect, glow);
        glow.setShader(shRadial);
        cv.drawRect(rect, glow);
        glow.setShader(null);

        // ⑤ 底部内暗边：玻璃下缘的折射，越靠底越沉
        glow.setShader(shBottom);
        cv.drawRect(rect, glow);
        glow.setShader(null);

        // 动态扫光（控件出现时的一道光，平时不画）
        if (sheen >= 0f) {
            final int sc2 = cv.save();
            cv.rotate(-16f, w * 0.5f, h * 0.5f);
            float cx = -w * 0.45f + sheen * (w * 1.9f);
            glow.setShader(new LinearGradient(cx, 0, cx + w * 0.34f, h * 0.5f,
                    0x00FFFFFF, 0x1EFFFFFF, Shader.TileMode.CLAMP));
            cv.drawRect(-w, -h, w * 2, h * 2, glow);
            glow.setShader(null);
            cv.restoreToCount(sc2);
        }

        // ⑦ 按下提亮：手指按住的瞬间整块玻璃「吸一口光」
        if (isPressed()) {
            glow.setShader(null);
            glow.setColor(0x14FFFFFF);
            cv.drawRoundRect(rect, r, r, glow);
        }

        cv.restoreToCount(sc);

        // ⑥ 棱：1dp 上亮下暗，避免「画了个框」的塑料感
        edge.setStrokeWidth(Math.max(1f, getResources().getDisplayMetrics().density));
        edge.setShader(shEdge);
        cv.drawRoundRect(rect, r, r, edge);
        edge.setShader(null);
    }

    @Override
    public boolean onTouchEvent(MotionEvent ev) {
        // 只是为了让 isPressed() 在整块面板范围内也能触发提亮；
        // 子控件自己消费掉事件的，走各自的按压态。
        return super.onTouchEvent(ev);
    }

    @Override
    public void setPressed(boolean pressed) {
        boolean changed = isPressed() != pressed;
        super.setPressed(pressed);
        if (changed) invalidate();
    }

    /** 上次扫光时间：控件反复显隐时也不会一直闪着 */
    private long lastSheenAt;

    /**
     * 控件从隐藏变可见时扫一道光。
     * 点一下画面唤出控制条，玻璃像被「重新注满」—— 这点微动效是液态感的关键，
     * 但只在显隐的那一刻跑一次，静止时一个属性动画都不挂。
     */
    @Override
    protected void onVisibilityChanged(View changedView, int visibility) {
        super.onVisibilityChanged(changedView, visibility);
        if (changedView == this && visibility == VISIBLE && getWindowVisibility() == VISIBLE) {
            long now = android.os.SystemClock.uptimeMillis();
            if (now - lastSheenAt > 1200) {
                lastSheenAt = now;
                playSheen();
            }
        }
    }

    @Override
    protected void onDetachedFromWindow() {
        if (sheenAnim != null) {
            sheenAnim.cancel();
            sheenAnim = null;
        }
        super.onDetachedFromWindow();
    }

    private static int withAlpha(int rgb, int alpha) {
        return (Math.max(0, Math.min(255, alpha)) << 24) | (rgb & 0x00FFFFFF);
    }

    /** 一次性生成 64×64 噪点（固定种子，保证每次启动颗粒一致），之后全局复用 */
    private static Bitmap ensureNoise() {
        if (noise != null && !noise.isRecycled()) return noise;
        try {
            final int n = 64;
            int[] px = new int[n * n];
            java.util.Random rnd = new java.util.Random(20241126L);
            for (int i = 0; i < px.length; i++) {
                int a = rnd.nextInt(30);
                px[i] = (a << 24) | 0x00FFFFFF;
            }
            noise = Bitmap.createBitmap(px, n, n, Bitmap.Config.ARGB_8888);
        } catch (Throwable ignore) {
            noise = null;
        }
        return noise;
    }
}
