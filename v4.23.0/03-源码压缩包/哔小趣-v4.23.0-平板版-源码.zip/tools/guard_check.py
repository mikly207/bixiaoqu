#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
【v4.21.0】源码回归守卫：检查「分屏被拆掉 / 黑屏」那几条危险写法有没有被重新引入。

运行：python3 tools/guard_check.py
"""
import re
import sys

ROOT = "app/src/com/bixiaoqu/app/"
PHONE = "app_phone/src/com/bixiaoqu/app/"

checks = []


def add(name, ok, detail=""):
    checks.append((name, ok, detail))


def read(p):
    with open(p, encoding="utf-8") as f:
        return f.read()


tab = read(ROOT + "PlayActivity.java")
phone = read(PHONE + "PlayActivity.java")
policy = read(ROOT + "LayoutPolicy.java")
tx = read(ROOT + "TxVideoView.java")

# 1) 平板：enterPortraitFill 只允许在 maybePortraitFill 内部被调用
calls = [m.start() for m in re.finditer(r"(?<!void )enterPortraitFill\(\);", tab)]
add("平板 enterPortraitFill 调用点 %d 处（应只在统一入口内）" % len(calls), len(calls) == 1,
    "多处直调 = 条件会写漏")

# 2) 平板：applyMeta 里不允许直接进铺满
m = re.search(r"void applyMeta\(", tab)
if m:
    seg = tab[m.start():m.start() + 8000]
    add("applyMeta 不再直接调用 enterPortraitFill", "enterPortraitFill()" not in seg,
        "旧版就是这里把分屏改成竖屏铺满")
    add("applyMeta 使用统一入口 maybePortraitFill", "maybePortraitFill()" in seg)
else:
    add("找到 applyMeta", False)

# 3) 平板：switchVideo 里不允许退出分屏
m = re.search(r"void switchVideo\(String bv, long cid, long durSec, String title, float aspect\)", tab)
if m:
    seg = tab[m.start():m.start() + 3000]
    add("switchVideo 不调用 exitSplitMode", "exitSplitMode" not in seg, "换片不许拆掉分屏")
    add("switchVideo 保留分屏画面盒", "applySplitSizeNow()" in seg)
else:
    add("找到 switchVideo(aspect)", False)

# 4) 平板：竖屏铺满自身带硬门槛
m = re.search(r"void enterPortraitFill\(\) \{", tab)
if m:
    seg = tab[m.start():m.start() + 900]
    add("enterPortraitFill 自带 splitMode 硬门槛", "splitMode" in seg)
    add("enterPortraitFill 自带横屏硬门槛", "isLandscapeNow()" in seg)
else:
    add("找到 enterPortraitFill", False)

# 5) 翻页只允许竖屏铺满
m = re.search(r"void enterSwipeMode\(\) \{", tab)
add("enterSwipeMode 有 portraitFill / 横屏门槛",
    bool(m) and "portraitFill" in tab[m.start():m.start() + 600],
    "翻页跑到分屏里会重排两槽")

# 6) 返回键语义集中在 LayoutPolicy
add("平板返回键走 LayoutPolicy.backAction", tab.count("LayoutPolicy.backAction") >= 2)
add("手机版返回键走 LayoutPolicy.backAction", phone.count("LayoutPolicy.backAction") >= 2)

# 7) 海报闸门 & 解码器释放
add("海报贴图前过 shouldShowPoster", "LayoutPolicy.shouldShowPoster" in tab
    and "LayoutPolicy.shouldShowPoster" in phone)
add("TxVideoView 有 reset 兜底释放", "releaseInnerPlayer" in tx and "mMediaPlayer" in tx)
add("TxVideoView 首帧判定检查视图尺寸", "getWidth() <= 0" in tx and "isShown()" in tx)
add("TxVideoView 提供 Surface 重建", "rebuildSurface" in tx)

# 8) 音轨起点不能直接用 -1
add("音轨起播位置走 audioStartTarget", "audioStartTarget" in tab and "audioStartTarget" in phone)

# 9) 两版都引入策略类
add("平板包含 LayoutPolicy", "public final class LayoutPolicy" in policy)
add("手机版包含 LayoutPolicy", "canPortraitFill" in phone)

# ---------------------------------------------------------------- v4.22.0
lproxy = read(ROOT + "LocalProxy.java")
app = read(ROOT + "BxqApp.java")
diag = read(ROOT + "StartupDiag.java")
cache = read(ROOT + "DiskCache.java")

# 10) 相关推荐不再被起播窗口推迟（「慢一拍」的根因）
add("平板推荐请求不再走 guardStartup", 'guardStartup("rec", new' not in tab,
    "推荐是几百字节 JSON，排队等首帧就是用户看到的「慢一拍」")
add("手机版推荐请求不再走 guardStartup", 'guardStartup("rec", new' not in phone)

# 11) 推荐缓存 + 骨架 + 换片刷新
for name, src, tag in (("平板", tab, ""), ("手机版", phone, "")):
    add(name + "推荐命中内存缓存", "BiliApi.relatedCached" in src)
    add(name + "推荐有骨架占位", "fillRecSkeleton" in src)
    add(name + "换片后刷新右栏", "if (!swipeMode) loadRec();" in src)

# 12) 相邻预加载 & 首片预热
add("预取前两条都带首片预热", "done < 2" in tab and "done < 2" in phone)
add("首片预热只读 96KB", "96 * 1024" in read(ROOT + "BiliApi.java"))
add("预热走独立低优先级线程池", "WARM_POOL" in read(ROOT + "BiliApi.java"))
add("封面异步预取在推荐上屏后触发", "prefetchCovers(got, 6)" in tab)

# 13) 磁盘缓存
add("DiskCache 单文件上限 48MB", "MAX_FILE = 48L * 1024 * 1024" in cache)
add("DiskCache 总量上限 400MB", "MAX_TOTAL = 400L * 1024 * 1024" in cache)
add("DiskCache key 用 URL path（跨会话可用）", "DiskCache.keyOfUrl" in lproxy)
add("代理先查磁盘缓存", "DiskCache.lookup" in lproxy)
add("代理边转发边落盘", "cww[0].write" in lproxy)
add("半截文件不提交", "bytes == len" in lproxy)
add("应用启动初始化磁盘缓存", "DiskCache.init" in app)

# 14) 网络/解码双诊断
add("起播打点三件套齐全",
    "StartupDiag.onClick" in tab and "StartupDiag.onFetch" in tab and "StartupDiag.onFrame" in tab)
add("手机版同样具备起播诊断",
    "StartupDiag.onClick" in phone and "StartupDiag.onFrame" in phone)
add("判定区分网络慢与解码慢", "DECODE_SLOW" in diag and "NET_SLOW" in diag)
add("自动降档需连续确认", "slowStreak >= CONFIRM" in diag)
add("选档走 chooseHeight 限幅", "chooseHeight(q, Prefs.qualityHeight(q))" in tab)
add("平板退出时反射释放解码器", "video.stopPlayback(); } catch (Throwable ignore) { }" in tab
    and "video.reset(); } catch (Throwable ignore) { }" in tab)
add("手机版退出时反射释放解码器", "video.reset(); } catch (Throwable ignore) { }" in phone)
add("骨架行会替换上一个视频的旧推荐", "stale" in tab and "stale" in phone)


# 13) 【v4.23.0】播放器液态玻璃 + 控件可读性
glass = read(ROOT + "GlassPanel.java")
blur = read(ROOT + "GlassBlur.java")
nav = read(ROOT + "LiquidNavBar.java")
add("玻璃面板是自绘 ViewGroup（可原地替换 LinearLayout）",
    "public class GlassPanel extends LinearLayout" in glass)
add("玻璃含磨砂颗粒层", "BitmapShader" in glass and "ensureNoise" in glass)
add("玻璃含顶部受光与棱描边", "RadialGradient" in glass and "edge.setStrokeWidth" in glass)
add("玻璃有扫光动画且随视图销毁取消", "playSheen" in glass and "sheenAnim.cancel()" in glass)
add("模糊内核抽成公共类", "class GlassBlur" in blur)
add("底栏复用公共模糊内核（不再各写一份）", "GlassBlur.blurInPlace" in nav and "boxBlur" not in nav)
add("横屏控制条用玻璃面板", "ctrlBar = new GlassPanel(this)" in tab)
add("竖屏控制条用玻璃面板", "vBottom = new GlassPanel(this)" in phone and "vBottom = new GlassPanel(this)" in tab)
add("染色浓度 75%（亮画面上白字可读）", ".tint(0xBE)" in tab and ".tint(0xB4)" in tab)
add("玻璃卡留外边距，圆角不贴屏幕", "cbp0.leftMargin" in tab and "lp.leftMargin = dp(10)" in tab)
add("弹窗统一玻璃材质", "void glassDialog" in tab and tab.count("glassDialog(") >= 4)

# 14) 【v4.23.0】控件一眼看懂
add("有图标+文字的胶囊按钮", "TextView pill(" in tab and "setCompoundDrawables" in tab)
add("播放键独立成 40dp 圆钮", 'Ic.glass(this, "pause"' in tab)
add("画质按钮带功能名", '"画质 " + qualityShort' in tab)
add("倍速按钮带功能名", '"倍速 " + rateLabel' in tab)
add("下一集带文字（不再是裸箭头）", '"下一集"' in tab and "nextBtn.setVisibility" in tab)
add("选集/下一集只在多P显示", "void syncPagesButtons" in tab and "pages > 1" in tab)
add("进度条加粗到 3dp/13dp 圆点", "styleSeek(seek, 3, 13)" in tab)
add("时间用「已播 / 总长」格式", 'mmss(pos) + " / " + mmss(len)' in tab)
add("常显的「解码」按钮已移除", "codecBtn" not in tab)

# 15) 【v4.23.0】启动与带宽
crash = read(ROOT + "CrashHandler.java")
add("日志写盘移出主线程（队列+批量）", "LinkedBlockingQueue" in crash and "flushPending" in crash)
add("崩溃前先冲刷日志队列", "flushPending();" in crash)
add("磁盘缓存容量统计在后台线程", "bxq-cache-scan" in cache and "MIN_PRIORITY" in cache)
add("预取并发 3", "Semaphore(3)" in read(ROOT + "BiliApi.java"))
add("代理 socket 缓冲 512KB", "setSendBufferSize(512 * 1024)" in lproxy)


add("切模式只调玻璃浓度，不盖实色背景", "ctrlBar.setBackgroundColor" not in tab)
add("手机版同样不盖实色背景", "ctrlBar.setBackgroundColor" not in phone)
add("玻璃着色器按尺寸缓存", "shFill" in glass and "shW = 0" in glass)
add("显隐时触发扫光", "onVisibilityChanged" in glass and "playSheen" in glass)
print("=== 源码回归守卫 v4.23.0 ===")
bad = 0
for name, ok, detail in checks:
    print(("  [PASS] " if ok else "  [FAIL] ") + name + ((" · " + detail) if (detail and not ok) else ""))
    if not ok:
        bad += 1
print("--------------------------------------")
print("通过 %d 项，失败 %d 项" % (len(checks) - bad, bad))
print("结果：" + ("ALL PASS" if bad == 0 else "FAIL"))
sys.exit(1 if bad else 0)
