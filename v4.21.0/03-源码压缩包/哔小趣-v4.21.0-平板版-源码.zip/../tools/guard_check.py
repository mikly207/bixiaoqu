#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
【v4.21.0】源码回归守卫：检查「分屏被拆掉 / 黑屏」那几条危险写法有没有被重新引入。

运行：python3 tools/guard_check.py
"""
import re
import sys

ROOT = "app/src/com/bixiaoqu/app/"
PHONE = "app_phone/src/com/bixiaoqu/app/"

checks = []


def add(name, ok, detail=""):
    checks.append((name, ok, detail))


def read(p):
    with open(p, encoding="utf-8") as f:
        return f.read()


tab = read(ROOT + "PlayActivity.java")
phone = read(PHONE + "PlayActivity.java")
policy = read(ROOT + "LayoutPolicy.java")
tx = read(ROOT + "TxVideoView.java")

# 1) 平板：enterPortraitFill 只允许在 maybePortraitFill 内部被调用
calls = [m.start() for m in re.finditer(r"(?<!void )enterPortraitFill\(\);", tab)]
add("平板 enterPortraitFill 调用点 %d 处（应只在统一入口内）" % len(calls), len(calls) == 1,
    "多处直调 = 条件会写漏")

# 2) 平板：applyMeta 里不允许直接进铺满
m = re.search(r"void applyMeta\(", tab)
if m:
    seg = tab[m.start():m.start() + 8000]
    add("applyMeta 不再直接调用 enterPortraitFill", "enterPortraitFill()" not in seg,
        "旧版就是这里把分屏改成竖屏铺满")
    add("applyMeta 使用统一入口 maybePortraitFill", "maybePortraitFill()" in seg)
else:
    add("找到 applyMeta", False)

# 3) 平板：switchVideo 里不允许退出分屏
m = re.search(r"void switchVideo\(String bv, long cid, long durSec, String title, float aspect\)", tab)
if m:
    seg = tab[m.start():m.start() + 3000]
    add("switchVideo 不调用 exitSplitMode", "exitSplitMode" not in seg, "换片不许拆掉分屏")
    add("switchVideo 保留分屏画面盒", "applySplitSizeNow()" in seg)
else:
    add("找到 switchVideo(aspect)", False)

# 4) 平板：竖屏铺满自身带硬门槛
m = re.search(r"void enterPortraitFill\(\) \{", tab)
if m:
    seg = tab[m.start():m.start() + 900]
    add("enterPortraitFill 自带 splitMode 硬门槛", "splitMode" in seg)
    add("enterPortraitFill 自带横屏硬门槛", "isLandscapeNow()" in seg)
else:
    add("找到 enterPortraitFill", False)

# 5) 翻页只允许竖屏铺满
m = re.search(r"void enterSwipeMode\(\) \{", tab)
add("enterSwipeMode 有 portraitFill / 横屏门槛",
    bool(m) and "portraitFill" in tab[m.start():m.start() + 600],
    "翻页跑到分屏里会重排两槽")

# 6) 返回键语义集中在 LayoutPolicy
add("平板返回键走 LayoutPolicy.backAction", tab.count("LayoutPolicy.backAction") >= 2)
add("手机版返回键走 LayoutPolicy.backAction", phone.count("LayoutPolicy.backAction") >= 2)

# 7) 海报闸门 & 解码器释放
add("海报贴图前过 shouldShowPoster", "LayoutPolicy.shouldShowPoster" in tab
    and "LayoutPolicy.shouldShowPoster" in phone)
add("TxVideoView 有 reset 兜底释放", "releaseInnerPlayer" in tx and "mMediaPlayer" in tx)
add("TxVideoView 首帧判定检查视图尺寸", "getWidth() <= 0" in tx and "isShown()" in tx)
add("TxVideoView 提供 Surface 重建", "rebuildSurface" in tx)

# 8) 音轨起点不能直接用 -1
add("音轨起播位置走 audioStartTarget", "audioStartTarget" in tab and "audioStartTarget" in phone)

# 9) 两版都引入策略类
add("平板包含 LayoutPolicy", "public final class LayoutPolicy" in policy)
add("手机版包含 LayoutPolicy", "canPortraitFill" in phone)

print("=== 源码回归守卫 v4.21.0 ===")
bad = 0
for name, ok, detail in checks:
    print(("  [PASS] " if ok else "  [FAIL] ") + name + ((" · " + detail) if (detail and not ok) else ""))
    if not ok:
        bad += 1
print("--------------------------------------")
print("通过 %d 项，失败 %d 项" % (len(checks) - bad, bad))
print("结果：" + ("ALL PASS" if bad == 0 else "FAIL"))
sys.exit(1 if bad else 0)
