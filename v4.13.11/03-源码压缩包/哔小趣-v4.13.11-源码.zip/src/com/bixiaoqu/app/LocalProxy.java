package com.bixiaoqu.app;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URL;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * 本地 HTTP 转发代理：VideoView/MediaPlayer 无法设置 Referer 头，
 * 而 B 站 CDN 校验 Referer，故在本机 127.0.0.1 起一个代理，
 * 把请求转发到 B 站 CDN 并补上 UA/Referer/Cookie 头（含 Range 断点续传）。
 *
 * 设计原则（v4.13.8 精简）：竞速线程池用 cached，每个竞速任务只做「建连+读响应头」
 * 后立即归还线程；真正的数据传输交给独立的 proxy-conn 线程，绝不占用竞速线程池。
 * 这样无论切换多少视频、旧连接是否释放，新视频的线路竞速都能立刻拿到线程，
 * 不会卡在「加载中」。断流续传保留，作为高码率流中途断网的兜底。
 */
public class LocalProxy implements Runnable {

    ServerSocket ss;
    volatile boolean running = true;
    final ExecutorService pool;

    public LocalProxy() throws Exception {
        ss = new ServerSocket(0, 32, InetAddress.getByName("127.0.0.1"));
        // cached 线程池：竞速任务极短暂（建连+读响应头），用完立即归还/复用，
        // 不会像 fixed(8) 那样被「预热读/长阻塞」占满导致新任务排队饿死。
        pool = Executors.newCachedThreadPool(new ThreadFactory() {
            @Override public Thread newThread(Runnable r) {
                Thread t = new Thread(r, "proxy-race");
                t.setDaemon(true);
                return t;
            }
        });
    }

    // ==================== 首片预缓冲（v4.13.11 竖屏秒播）====================
    /**
     * 相邻视频的首片数据缓存：观看当前视频时，后台把相邻视频流的前若干 KB
     * 预下载到内存。切换到该视频时，代理直接命中缓存吐出首片 → MediaPlayer
     * 立刻拿到关键帧解码，画面秒出，不再长时间停留在糊封面上。
     * key = 主视频流 URL（与正式播放 playUrlMulti 的 u= 完全一致）。
     */
    static class Prebuf {
        byte[] head;
        int headLen;
        long total;      // 完整长度（CDN Content-Length）
        String ct;       // Content-Type
        String cr;       // Content-Range
        long stamp;
    }
    static final java.util.LinkedHashMap<String, Prebuf> PREBUF_CACHE =
            new java.util.LinkedHashMap<String, Prebuf>(8, 0.75f, true) {
        @Override protected boolean removeEldestEntry(java.util.Map.Entry<String, Prebuf> eldest) {
            return size() > 4;
        }
    };
    static final java.util.HashSet<String> PREBUFING = new java.util.HashSet<String>();
    static final int PREBUF_BYTES = 1024 * 1024;   // 1MB，足够覆盖视频首帧关键帧

    /** 后台预下载首片（低优先级、错峰、去重）。urls 与正式播放完全同源。 */
    public void prebuffer(final String[] urls) {
        if (urls == null || urls.length == 0) return;
        final String key = urls[0];
        synchronized (PREBUF_CACHE) { if (PREBUF_CACHE.containsKey(key)) return; }
        synchronized (PREBUFING) {
            if (PREBUFING.contains(key)) return;
            PREBUFING.add(key);
        }
        Thread t = new Thread(new Runnable() { @Override public void run() {
            try { Thread.currentThread().setPriority(Thread.NORM_PRIORITY - 1); } catch (Throwable ignore) {}
            // 错峰：先让当前视频把首帧拉出来，别抢起播那几百毫秒的带宽
            try { Thread.sleep(250); } catch (InterruptedException ignore) { }
            HttpURLConnection c = null;
            InputStream in = null;
            try {
                // 顺序尝试线路，取第一条 2xx（预缓冲不急，不竞速，降低风控概率）
                for (String u : urls) {
                    try {
                        c = open(u, "bytes=0-");
                        int code = c.getResponseCode();
                        if (code < 200 || code >= 300) throw new Exception("HTTP " + code);
                        // API22 兼容：不用 getContentLengthLong（API24+），直接解析头
                        long total = -1;
                        String cl = c.getHeaderField("Content-Length");
                        try { if (cl != null) total = Long.parseLong(cl.trim()); } catch (Throwable ignore) {}
                        // 长度未知（分块编码）时不预热：否则正式播放只拿到首片就 EOF，视频被截断
                        if (total <= 0) throw new Exception("unknown length");
                        byte[] head = new byte[PREBUF_BYTES];
                        in = c.getInputStream();
                        int off = 0;
                        while (off < PREBUF_BYTES && running) {
                            int n = in.read(head, off, PREBUF_BYTES - off);
                            if (n <= 0) break;
                            off += n;
                        }
                        if (off > 0) {
                            Prebuf pb = new Prebuf();
                            pb.head = head; pb.headLen = off; pb.total = total;
                            pb.ct = c.getContentType(); pb.cr = c.getHeaderField("Content-Range");
                            pb.stamp = System.currentTimeMillis();
                            synchronized (PREBUF_CACHE) { PREBUF_CACHE.put(key, pb); }
                            CrashHandler.note("prebuf", "首片预热 " + off + "/" + total + " " + hostOf(key));
                        }
                        break;  // 成功一条即可
                    } catch (Throwable e) {
                        if (in != null) { try { in.close(); } catch (Throwable ig) {} } in = null;
                        if (c != null) { try { c.disconnect(); } catch (Throwable ig) {} } c = null;
                    }
                }
            } catch (Throwable ignore) {
            } finally {
                if (in != null) { try { in.close(); } catch (Throwable ignore) {} }
                if (c != null) { try { c.disconnect(); } catch (Throwable ignore) {} }
                synchronized (PREBUFING) { PREBUFING.remove(key); }
            }
        } }, "proxy-prebuf");
        try { t.setPriority(Thread.NORM_PRIORITY - 1); } catch (Throwable ignore) {}
        t.start();
    }

    /** 取走命中的首片缓存（TTL 5 分钟） */
    Prebuf takePrebuf(String key) {
        if (key == null) return null;
        synchronized (PREBUF_CACHE) {
            Prebuf pb = PREBUF_CACHE.get(key);
            if (pb == null) return null;
            if (!running || System.currentTimeMillis() - pb.stamp > 5 * 60 * 1000L) {
                PREBUF_CACHE.remove(key);
                return null;
            }
            return pb;
        }
    }

    /** 命中缓存的快速响应：先吐内存首片，再从网络续传剩余。返回后连接已处理完毕。 */
    void serveFromPrebuf(Socket s, Req req, Prebuf pb) throws Exception {
        OutputStream out = s.getOutputStream();
        StringBuilder h = new StringBuilder();
        long total = pb.total;
        boolean partial = req.range != null && total > 0;
        if (partial) {
            h.append("HTTP/1.1 206 Partial Content\r\n");
            h.append("Content-Length: ").append(total).append("\r\n");
            String cr = pb.cr;
            if (cr == null || cr.isEmpty()) cr = "bytes 0-" + (total - 1) + "/" + total;
            h.append("Content-Range: ").append(cr).append("\r\n");
        } else {
            h.append("HTTP/1.1 200 OK\r\n");
            h.append("Content-Length: ").append(total > 0 ? total : pb.headLen).append("\r\n");
        }
        if (pb.ct != null && !pb.ct.isEmpty()) h.append("Content-Type: ").append(pb.ct).append("\r\n");
        h.append("Accept-Ranges: bytes\r\nConnection: close\r\n\r\n");
        out.write(h.toString().getBytes("UTF-8"));
        out.write(pb.head, 0, pb.headLen);   // 首片秒出
        out.flush();
        long remain = total - pb.headLen;
        if (remain <= 0) return;             // 整段都在缓存里

        // 从网络续传 pb.headLen 之后的字节（断流走备用线路兜底）
        byte[] buf = new byte[256 * 1024];
        long written = 0;
        java.util.HashSet<String> used = new java.util.HashSet<String>();
        for (String u : req.urls) used.add(u);
        HttpURLConnection c = null;
        InputStream in = null;
        try {
            c = open(req.urls[0], "bytes=" + pb.headLen + "-");
            int code = c.getResponseCode();
            if (code < 200 || code >= 300) throw new Exception("HTTP " + code);
            in = c.getInputStream();
            while (running) {
                int n;
                try { n = in.read(buf); } catch (Throwable e) { n = -1; }
                if (n > 0) { out.write(buf, 0, n); written += n; continue; }
                String backup = null;
                for (String u : req.urls) if (!used.contains(u)) { backup = u; break; }
                if (backup == null || written >= remain) break;
                used.add(backup);
                try { if (in != null) in.close(); } catch (Throwable ig) {}
                try { if (c != null) c.disconnect(); } catch (Throwable ig) {}
                c = null; in = null;
                long from = pb.headLen + written;
                c = open(backup, "bytes=" + from + "-");
                int rc = c.getResponseCode();
                if (rc < 200 || rc >= 300) throw new Exception("HTTP " + rc);
                in = c.getInputStream();
            }
            out.flush();
        } catch (Throwable ignore) {
            // 续传失败也把已写部分交出去，播放器可自行再发 Range 请求兜底
            try { out.flush(); } catch (Throwable ig) {}
        } finally {
            if (in != null) { try { in.close(); } catch (Throwable ignore) {} }
            if (c != null) { try { c.disconnect(); } catch (Throwable ignore) {} }
        }
    }

    public int port() {
        return ss.getLocalPort();
    }

    /** 生成给 VideoView 的播放地址（单线路，兼容旧调用） */
    public String playUrl(String targetUrl) throws Exception {
        return playUrlMulti(new String[]{ targetUrl });
    }

    /**
     * 【多线路】生成播放地址，u=主线路，u2/u3/u4=备用线路。
     * 代理会并行竞速所有线路，谁快用谁。
     */
    public String playUrlMulti(String[] urls) throws Exception {
        StringBuilder sb = new StringBuilder("http://127.0.0.1:").append(port()).append("/p?u=");
        sb.append(URLEncoder.encode(urls[0], "UTF-8"));
        for (int i = 1; i < urls.length; i++) {
            sb.append("&u").append(i + 1).append("=").append(URLEncoder.encode(urls[i], "UTF-8"));
        }
        return sb.toString();
    }

    public void start() {
        new Thread(this, "bili-proxy").start();
    }

    public void stop() {
        running = false;
        try { ss.close(); } catch (Exception ignore) { }
        try { pool.shutdownNow(); } catch (Exception ignore) { }
        synchronized (PREBUF_CACHE) { PREBUF_CACHE.clear(); }
        synchronized (PREBUFING) { PREBUFING.clear(); }
    }

    @Override
    public void run() {
        while (running) {
            try {
                final Socket s = ss.accept();
                new Thread(new Runnable() {
                    @Override public void run() {
                        // 禁 Nagle：首块立刻下发，缩短起播缓冲等待
                        try { s.setTcpNoDelay(true); } catch (Exception ignore) { }
                        try { handle(s); }
                        catch (Exception ignore) { }
                        finally {
                            try { s.close(); } catch (Exception ignore) { }
                        }
                    }
                }, "proxy-conn").start();
            } catch (Exception e) {
                if (!running) return;
            }
        }
    }

    /** 解析请求行里的所有候选 URL 与 Range 头 */
    static class Req {
        String[] urls;
        String range;
        long start;   // 【v4.13.5】Range 起始绝对偏移，用于断流续传时计算 bytes=start+已读-
    }

    Req parseRequest(Socket s) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(s.getInputStream(), "UTF-8"));
        String line = br.readLine();
        if (line == null || !line.startsWith("GET ")) return null;
        String range = null;
        String rl;
        while ((rl = br.readLine()) != null && !rl.isEmpty()) {
            if (rl.regionMatches(true, 0, "Range:", 0, 6)) {
                range = rl.substring(6).trim();
            }
        }
        java.util.List<String> list = new java.util.ArrayList<String>();
        String main = paramFrom(line, "u=");
        if (main != null && !main.isEmpty()) list.add(main);
        for (int i = 2; i <= 4; i++) {
            String alt = paramFrom(line, "u" + i + "=");
            if (alt != null && !alt.isEmpty()) list.add(alt);
        }
        if (list.isEmpty()) return null;
        Req r = new Req();
        r.urls = list.toArray(new String[list.size()]);
        r.range = range;
        // 解析 Range 起点：bytes=12345-  → 12345；bytes=-500 / 无 → 0
        r.start = 0;
        if (range != null) {
            String rv = range.trim();
            if (rv.regionMatches(true, 0, "bytes=", 0, 6)) {
                String spec = rv.substring(6);
                int dash = spec.indexOf('-');
                if (dash > 0) {
                    try { r.start = Long.parseLong(spec.substring(0, dash).trim()); }
                    catch (Exception ignore) { r.start = 0; }
                }
            }
        }
        return r;
    }

    /** 从请求行里取某个查询参数的值（u2= 不会误匹配到 u= ） */
    String paramFrom(String line, String key) {
        int idx = -1;
        int searchFrom = 0;
        while (true) {
            int p = line.indexOf(key, searchFrom);
            if (p < 0) break;
            boolean boundary = (p == 0) || (line.charAt(p - 1) == '?') || (line.charAt(p - 1) == '&');
            if (boundary) { idx = p; break; }
            searchFrom = p + 1;
        }
        if (idx < 0) return null;
        int start = idx + key.length();
        int end = line.indexOf(' ', start);
        String raw = end > 0 ? line.substring(start, end) : line.substring(start);
        try { return URLDecoder.decode(raw, "UTF-8"); }
        catch (Exception e) { return raw; }
    }

    /** 一次线路竞速的结果 */
    static class Trial {
        HttpURLConnection conn;   // 成功拿到响应头的连接；非胜出者会被关闭并置 null
        String url;
        String err;
    }

    void handle(Socket s) throws Exception {
        Req req = parseRequest(s);
        if (req == null || req.urls == null || req.urls.length == 0) return;

        // 【v4.13.11 首片秒播】只对「从头请求」（start<=0）命中预缓冲缓存：
        // 首帧一定从 0 开始，命中后先吐内存首片、再网络续传，省掉竞速+首包等待。
        if (req.start <= 0) {
            Prebuf pb = takePrebuf(req.urls[0]);
            if (pb != null) {
                serveFromPrebuf(s, req, pb);
                return;
            }
        }

        final String range = req.range;
        final BlockingQueue<Trial> results = new LinkedBlockingQueue<Trial>();
        final AtomicBoolean claimed = new AtomicBoolean(false); // 保证只有一个胜出连接

        // 所有线路错峰开跑（降低同资源瞬时并发被 CDN 风控 403 的概率）
        for (int idx = 0; idx < req.urls.length; idx++) {
            final int trialIndex = idx;
            final String target = req.urls[idx];
            pool.execute(new Runnable() {
                @Override public void run() {
                    Trial t = new Trial();
                    t.url = target;
                    HttpURLConnection trial = null;
                    try {
                        // 【v4.13.9 错峰竞速】多条线路同时打同一资源会被 B 站 CDN 风控
                        // 返回 403 拦截页（实测 8 条并发时多数线路 403）。按序号错峰几十毫秒，
                        // 首条立刻发出，其余依次稍后，显著降低"同资源瞬时并发"被判风控的概率。
                        if (trialIndex > 0) Thread.sleep(trialIndex * 25L);
                        trial = open(target, range);
                        int code = trial.getResponseCode();   // 连接阶段失败会抛异常
                        // 【v4.13.9 致命 bug 修复】只接受 2xx！
                        // 旧版 `code >= 500` 漏判 4xx：CDN 风控返回的 403/412 页面被当成
                        // "胜出成功"原样转发给 MediaPlayer，播放器收到 HTML 而非视频 →
                        // 永远卡在「加载中喵~」。403/412/404/301 等一律判该线路失败，
                        // 继续等其它真正在吐视频数据的线路胜出。
                        if (code < 200 || code >= 300) throw new Exception("HTTP " + code);
                        // 拿到响应头即完成竞速，立刻归还线程。
                        // 关键：绝不在竞速线程里读数据体（read 会阻塞到 readTimeout，
                        // 把整个线程池占满 → 新视频竞速任务拿不到线程 → 卡「加载中」）。
                        // 真正的数据读取在下方独立的 proxy-conn / handle 线程中进行。
                        t.conn = trial;
                    } catch (Exception e) {
                        t.err = e.getMessage();
                        if (trial != null) { try { trial.disconnect(); } catch (Exception ignore) { } }
                        t.conn = null;
                    }
                    // 只有一个连接能成为胜者；迟到的成功者自行关闭，避免泄漏
                    if (t.conn != null && !claimed.compareAndSet(false, true)) {
                        try { t.conn.disconnect(); } catch (Exception ignore) { }
                        t.conn = null;
                    }
                    results.offer(t);
                }
            });
        }

        // 收结果：拿到第一个成功连接即用；全部失败则快速返回 502
        HttpURLConnection c = null;
        String usedUrl = null;
        int remaining = req.urls.length;
        long deadline = System.currentTimeMillis() + 8000L;
        while (remaining > 0) {
            long left = deadline - System.currentTimeMillis();
            if (left <= 0) break;
            Trial t = results.poll(left, TimeUnit.MILLISECONDS);
            if (t == null) break;
            remaining--;
            if (t.conn != null) {
                c = t.conn;
                usedUrl = t.url;
                CrashHandler.note("proxy", "竞速胜出 " + hostOf(usedUrl));
                break;
            } else if (t.err != null) {
                CrashHandler.note("proxy", "线路失败 " + hostOf(t.url) + "：" + t.err);
            }
        }

        if (c == null) {
            OutputStream out = s.getOutputStream();
            String body = "all lines failed";
            out.write(("HTTP/1.1 502 Bad Gateway\r\nContent-Length: " + body.length()
                    + "\r\nConnection: close\r\n\r\n" + body).getBytes("UTF-8"));
            out.flush();
            return;
        }

        try {
            long len = c.getContentLength();
            String cr = c.getHeaderField("Content-Range");
            String ct = c.getContentType();

            OutputStream out = s.getOutputStream();
            StringBuilder h = new StringBuilder();
            // 【v4.13.9】胜出连接已确认是 2xx，统一按 200/206 回复，
            // 杜绝旧版把异常状态码（如 403 OK）当成正常响应转发给播放器。
            int okCode = c.getResponseCode();
            if (okCode < 200 || okCode >= 300) okCode = 200;   // 兜底防御
            h.append("HTTP/1.1 ").append(okCode).append(' ')
             .append(okCode == 206 ? "Partial Content" : "OK").append("\r\n");
            if (len >= 0) h.append("Content-Length: ").append(len).append("\r\n");
            if (cr != null) h.append("Content-Range: ").append(cr).append("\r\n");
            if (ct != null) h.append("Content-Type: ").append(ct).append("\r\n");
            h.append("Accept-Ranges: bytes\r\nConnection: close\r\n\r\n");
            out.write(h.toString().getBytes("UTF-8"));
            out.flush();

            // 【v4.13.5】传输（含断流自动续传）：
            // 竞速胜出的线路若在中途断流，旧版 read() 直接结束，客户端收到的字节数少于
            // 响应头声明的 Content-Length，MediaPlayer 就判定「下载失败/加载不出来」——
            // 横屏高码率流更容易踩到。现在断流时改用备用线路按绝对 Range 续上，
            // 只发一次响应头，续传数据直接续写，对客户端完全透明。
            byte[] buf = new byte[256 * 1024];   // v4.12：64KB→256KB，高码率单次 read 更满
            long bytes = 0;
            long t0 = System.currentTimeMillis();
            HttpURLConnection cur = c;
            InputStream in = cur.getResponseCode() >= 400 ? cur.getErrorStream() : cur.getInputStream();

            // 已用过的线路不再重复续传（主线路 + 每条备用最多一次）
            java.util.HashSet<String> used = new java.util.HashSet<String>();
            if (usedUrl != null) used.add(usedUrl);
            int maxResume = req.urls.length;   // 最多尝试 = 线路总数，保证有限次、不死循环

            try {
                while (running) {
                    int n;
                    try {
                        n = in.read(buf);
                    } catch (Exception e) {
                        n = -1;   // 视作断流，交给续传逻辑
                    }
                    if (n > 0) {
                        out.write(buf, 0, n);
                        bytes += n;
                        continue;
                    }

                    // read 结束：判断是否传满。len<0（未知长度）无法判断，按 EOF 正常结束。
                    boolean incomplete = (len > 0 && bytes < len);
                    boolean canResume = incomplete && maxResume > 0;
                    String backup = null;
                    if (canResume) {
                        // 选一条没用过的备用线路
                        for (String u : req.urls) {
                            if (u != null && !used.contains(u)) { backup = u; break; }
                        }
                    }
                    if (backup == null) break;   // 传满或无备用可用 → 结束

                    // 用备用线路从断点续传。绝对偏移 = Range 起点 + 已读字节。
                    HttpURLConnection resume = null;
                    try {
                        long from = req.start + bytes;
                        resume = open(backup, "bytes=" + from + "-");
                        int rc = resume.getResponseCode();
                        if (rc != 200 && rc != 206) throw new Exception("HTTP " + rc);
                        InputStream rin = rc >= 400 ? resume.getErrorStream() : resume.getInputStream();
                        // 关闭旧连接，切换到续传连接（响应头只写过一次，不再重复写）
                        try { if (in != null) in.close(); } catch (Exception ignore) { }
                        try { cur.disconnect(); } catch (Exception ignore) { }
                        cur = resume;
                        in = rin;
                        used.add(backup);
                        maxResume--;
                        CrashHandler.note("proxy", "断流续传 " + hostOf(backup)
                                + " 从 " + from + " 继续（已传 " + bytes + "/" + len + ")");
                        continue;
                    } catch (Exception e) {
                        if (resume != null) { try { resume.disconnect(); } catch (Exception ignore) { } }
                        used.add(backup);
                        maxResume--;
                        CrashHandler.note("proxy", "续传失败 " + hostOf(backup) + "：" + e.getMessage());
                        // 继续尝试下一条备用线路
                    }
                }
                out.flush();   // 首块/末块立刻推出，不滞留在缓冲
                BiliApi.noteThroughput(bytes, System.currentTimeMillis() - t0);
            } finally {
                try { if (in != null) in.close(); } catch (Exception ignore) { }
                try { cur.disconnect(); } catch (Exception ignore) { }
                try { out.close(); } catch (Exception ignore) { }
            }
        } finally {
            // cur 可能已切换为续传连接，主连接 c 在这里兜底关闭（已关闭的重复 disconnect 无害）
            try { c.disconnect(); } catch (Exception ignore) { }
        }
    }

    /** 打开一条线路：缩短超时 + 完整请求头 */
    HttpURLConnection open(String target, String range) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(target).openConnection();
        c.setConnectTimeout(5000);     // v4.5：移动网络(5G)握手偶发偏慢，3.5s 收紧到 5s；并行竞速取最快，不影响快线路
        // 【v4.13.7 修卡顿】30s→12s：某条线路建连成功却中途「挂住不吐数据」时，
        // 旧版要干等 30s 才超时，画面就卡在加载中。收紧到 12s 后能更快判定该线路失效，
        // 触发竞速的其它线路 / 断流续传接管。12s 仍能覆盖正常分片下载间隔。
        c.setReadTimeout(12000);
        c.setInstanceFollowRedirects(true);
        c.setRequestProperty("User-Agent", BiliApi.UA);
        c.setRequestProperty("Referer", BiliApi.REFERER);
        StringBuilder ck = new StringBuilder();
        for (java.util.Map.Entry<String, String> e : BiliApi.COOKIES.entrySet()) {
            if (ck.length() > 0) ck.append("; ");
            ck.append(e.getKey()).append('=').append(e.getValue());
        }
        if (ck.length() > 0) c.setRequestProperty("Cookie", ck.toString());
        if (range != null) c.setRequestProperty("Range", range);
        return c;
    }

    String hostOf(String url) {
        try { return new URL(url).getHost(); } catch (Exception e) { return "unknown"; }
    }
}
