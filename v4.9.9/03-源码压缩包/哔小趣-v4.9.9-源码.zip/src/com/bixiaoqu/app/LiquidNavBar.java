package com.bixiaoqu.app;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewParent;
import android.widget.FrameLayout;

/**
 * 液态玻璃底栏（v4.9.9 重做）。
 *
 * 旧版是「纯黑胶囊 + 白色描边」，在深色界面里看上去就是一块不透明黑条，
 * 背后的卡片还会从圆角缝隙里露出一角，像被削掉一块。
 *
 * 现在：先把胶囊背后的界面抓成一张缩略图 → 降采样两次得到柔和模糊 →
 * 以胶囊形状裁剪绘制，再叠染色层、顶部高光、内倾暗边、外发光描边。
 * 视觉上就是一块真正「透出背后内容、但被打磨过」的玻璃。
 *
 * 交互保持不变：按住滑动出液态透镜（{@link LiquidLensLayer}），松手提交 tab。
 */
public class LiquidNavBar extends FrameLayout {

    /** 滑动交互回调 */
    public interface Callback {
        void onTouchDown(float x, float y);   // 触点坐标（相对本容器）
        void onTouchMove(float x, float y);
        void onTouchUp();
        void onHover(int tabIndex);           // 手指当前悬停的 tab（真实 tab 索引）
        void onCommit(int tabIndex);          // 松手提交的 tab
    }

    private Callback callback;
    /** 槽位 → 真实 tab 索引。底栏三格：{0,1,4} */
    private int[] slots = {0, 1, 2, 3, 4};

    private final Paint glassP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint tintP = new Paint();
    private final Paint glossP = new Paint();
    private final Paint edgeP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint innerP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint shadowP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();
    private final RectF tmp = new RectF();
    private final Path clipPath = new Path();
    private final Matrix shaderM = new Matrix();

    /** 背后的模糊缩略图（很小，约 40×8 px，放大后天然柔和） */
    private Bitmap blur;
    private boolean refreshing;
    private Runnable bgTick;
    private boolean dragging;

    public LiquidNavBar(Context c) {
        super(c);
        setClipChildren(false);
        setClipToPadding(false);
        edgeP.setStyle(Paint.Style.STROKE);
        innerP.setStyle(Paint.Style.STROKE);
        shadowP.setStyle(Paint.Style.FILL);
    }

    public void setCallback(Callback cb) {
        this.callback = cb;
    }

    /** 设置槽位到 tab 索引的映射（例如三格传 {0,1,4}） */
    public void setSlots(int[] s) {
        if (s != null && s.length > 0) slots = s;
    }

    int dp(float v) {
        return (int) (getResources().getDisplayMetrics().density * v + 0.5f);
    }

    // ==================== 背景抓取 ====================

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        startBackdropLoop();
    }

    @Override
    protected void onDetachedFromWindow() {
        stopBackdropLoop();
        if (blur != null) {
            blur.recycle();
            blur = null;
        }
        super.onDetachedFromWindow();
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        post(new Runnable() {
            @Override public void run() { refreshBackdrop(); }
        });
    }

    /**
     * 低频刷新背景：内容滚动后最多 900ms 就跟上，肉眼几乎察觉不到延迟，
     * 又不会因为每帧抓图把列表拖卡。
     */
    private void startBackdropLoop() {
        if (bgTick != null) return;
        bgTick = new Runnable() {
            @Override public void run() {
                if (isShown()) refreshBackdrop();
                postDelayed(this, 900);
            }
        };
        postDelayed(bgTick, 260);
    }

    private void stopBackdropLoop() {
        if (bgTick != null) {
            removeCallbacks(bgTick);
            bgTick = null;
        }
    }

    /** 立即抓一次背后的画面（切页、旋转后调用，不用等循环） */
    public void refreshBackdrop() {
        if (refreshing) return;
        final int w = getWidth(), h = getHeight();
        if (w <= 0 || h <= 0) return;
        ViewParent vp = getParent();
        if (!(vp instanceof View)) return;

        refreshing = true;
        int vis = getVisibility();
        try {
            View p = (View) vp;
            // 同一帧内隐藏自己 → 抓图 → 恢复。系统只在下一帧才真正绘制，
            // 所以这一步用户看不到闪烁。
            setVisibility(INVISIBLE);

            int sw = Math.max(8, w / 8);
            int sh = Math.max(4, h / 8);
            Bitmap small = Bitmap.createBitmap(sw, sh, Bitmap.Config.ARGB_8888);
            Canvas c0 = new Canvas(small);
            c0.scale(sw / (float) w, sh / (float) h);
            c0.translate(-getLeft(), -getTop());
            p.draw(c0);

            // 二次降采样：模糊更均匀，避免单次缩放的锯齿块
            int sw2 = Math.max(5, sw / 2);
            int sh2 = Math.max(3, sh / 2);
            Bitmap small2 = Bitmap.createBitmap(sw2, sh2, Bitmap.Config.ARGB_8888);
            Canvas c1 = new Canvas(small2);
            c1.drawBitmap(small, null, new RectF(0, 0, sw2, sh2),
                    new Paint(Paint.FILTER_BITMAP_FLAG));
            small.recycle();

            if (blur != null) blur.recycle();
            blur = small2;

            setVisibility(vis);
            invalidate();
        } catch (Throwable t) {
            setVisibility(VISIBLE);
        } finally {
            refreshing = false;
        }
    }

    // ==================== 绘制 ====================

    @Override
    protected void onDraw(Canvas cv) {
        final int w = getWidth(), h = getHeight();
        if (w <= 0 || h <= 0) return;
        final float r = h / 2f;
        rect.set(0, 0, w, h);

        // 1) 胶囊外的柔和投影：三层叠加，比单层更像真实阴影
        for (int i = 3; i >= 1; i--) {
            float off = dp(i * 3.2f);
            shadowP.setColor(0x11000000);
            tmp.set(-off, -off * 0.5f, w + off, h + off * 1.35f);
            cv.drawRoundRect(tmp, r + off, r + off, shadowP);
        }

        clipPath.reset();
        clipPath.addRoundRect(rect, r, r, Path.Direction.CW);
        final int sc = cv.save();
        cv.clipPath(clipPath);

        // 2) 玻璃底：背后的模糊画面
        if (blur != null && blur.getWidth() > 0) {
            BitmapShader bs = new BitmapShader(blur,
                    Shader.TileMode.CLAMP, Shader.TileMode.CLAMP);
            shaderM.reset();
            shaderM.setScale(w / (float) blur.getWidth(), h / (float) blur.getHeight());
            bs.setLocalMatrix(shaderM);
            glassP.setShader(bs);
            glassP.setAlpha(255);
            cv.drawRect(rect, glassP);
            glassP.setShader(null);
        } else {
            glassP.setShader(null);
            glassP.setColor(0xE6101216);
            cv.drawRect(rect, glassP);
        }

        // 3) 染色：玻璃本身是深色带一点蓝，压住背后的花色保证图标可读
        tintP.setShader(new LinearGradient(0, 0, 0, h,
                0xA8151920, 0xC70A0C10, Shader.TileMode.CLAMP));
        cv.drawRect(rect, tintP);
        tintP.setShader(null);

        // 4) 顶部高光：上半部白色渐隐，模拟玻璃受光
        glossP.setShader(new LinearGradient(0, 0, 0, h * 0.62f,
                0x3AFFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP));
        cv.drawRect(rect, glossP);
        glossP.setShader(null);

        // 5) 底部内倾暗边：让「玻璃有厚度」而不是一张平贴纸
        tintP.setShader(new LinearGradient(0, h * 0.55f, 0, h,
                0x00000000, 0x42000000, Shader.TileMode.CLAMP));
        cv.drawRect(rect, tintP);
        tintP.setShader(null);

        cv.restoreToCount(sc);

        // 6) 内缘细亮线（玻璃切边）
        innerP.setStrokeWidth(dp(0.8f));
        innerP.setColor(0x24FFFFFF);
        RectF in = new RectF(rect);
        in.inset(dp(1f), dp(1f));
        cv.drawRoundRect(in, r - dp(1f), r - dp(1f), innerP);

        // 7) 外描边：上亮下暗，边缘才有玻璃的「弧面反光」
        edgeP.setStrokeWidth(dp(1f));
        edgeP.setShader(new LinearGradient(0, 0, 0, h,
                0x66FFFFFF, 0x1AFFFFFF, Shader.TileMode.CLAMP));
        cv.drawRoundRect(rect, r, r, edgeP);
        edgeP.setShader(null);

        // 8) 按住时整体提亮一点，配合液态透镜
        if (dragging) {
            glossP.setShader(null);
            glossP.setColor(0x0DFFFFFF);
            cv.drawRoundRect(rect, r, r, glossP);
        }
    }

    // ==================== 触摸 ====================

    /** 把触点换算成真实 tab 索引；槽位等分胶囊宽度，超出左右边界时钳制 */
    private int tabAt(float x) {
        int n = slots.length;
        int idx = (int) (x / (getWidth() / (float) n));
        idx = idx < 0 ? 0 : (idx >= n ? n - 1 : idx);
        return slots[idx];
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        float x = ev.getX(), y = ev.getY();
        switch (ev.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                dragging = true;
                invalidate();
                if (callback != null) {
                    callback.onTouchDown(getLeft() + x, getTop() + y);
                    callback.onHover(tabAt(x));
                }
                break;
            case MotionEvent.ACTION_MOVE:
                if (callback != null) {
                    callback.onTouchMove(getLeft() + x, getTop() + y);
                    callback.onHover(tabAt(x));
                }
                break;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                if (dragging && callback != null) {
                    boolean up = ev.getActionMasked() == MotionEvent.ACTION_UP;
                    callback.onTouchUp();
                    if (up) callback.onCommit(tabAt(x));
                }
                dragging = false;
                invalidate();
                break;
        }
        return true;
    }
}
