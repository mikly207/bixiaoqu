package com.bixiaoqu.app;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.view.inputmethod.InputMethodManager;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

/**
 * 【v4.9.6】评论抽屉。
 *
 * 【为什么不再用独立 Activity】
 * 旧版点评论会 startActivity(CommentActivity)，整页被评论糊满，视频直接看不见，
 * 想对照画面看评论得退出去再进来。这里改成**从底部升起的抽屉**：
 *   · 高度约屏幕 62%，上方至少还有三分之一画面可见；
 *   · 视频继续播放（不暂停、不销毁）；
 *   · 顶部圆角 + 拖拽把手，下滑 / 点「×」收起；
 *   · 列表、发表、点赞数全部保留。
 *
 * 抽屉只创建一次，之后复用（open() 重新绑定 aid 并刷新）。
 */
public class CommentSheet {

    static final int C_BG = 0xFF131519;
    static final int C_CARD = 0xFF1B1E24;
    static final int C_FG = 0xFFE8EAF0;
    static final int C_SUB = 0xFF9AA0AB;
    static final int C_ACC = 0xFFFB7299;

    final Activity act;
    final FrameLayout host;

    LinearLayout panel;
    ListView list;
    TextView titleView, tipView, sortView;
    View dragBar;
    EditText input;
    Button send;

    final ArrayList<JSONObject> rows = new ArrayList<>();
    Adapter adapter;
    final Handler ui = new Handler(Looper.getMainLooper());

    long aid;
    String bvid = "";
    int total = 0;
    boolean showing = false;
    boolean loading = false;
    long lastLoadedAid = -1;

    public CommentSheet(Activity act, FrameLayout host) {
        this.act = act;
        this.host = host;
        build();
    }

    int dp(float v) {
        return (int) (act.getResources().getDisplayMetrics().density * v);
    }

    GradientDrawable round(int color, float radDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(radDp * act.getResources().getDisplayMetrics().density);
        return g;
    }

    int screenH() {
        return act.getResources().getDisplayMetrics().heightPixels;
    }

    /** 抽屉目标高度：62% 屏高；横屏时按屏高封顶，避免超过屏幕 */
    int sheetH() {
        int sh = screenH();
        int h = (int) (sh * 0.62f);
        int floor = Math.min(dp(380), (int) (sh * 0.9f));
        h = Math.max(h, floor);
        return Math.min(h, (int) (sh * 0.78f));
    }

    // ------------------------------------------------------------ 构建

    void build() {
        panel = new LinearLayout(act);
        panel.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(C_BG);
        float r = dp(20);
        // 只有上方两角圆角（下方贴着屏幕底边）
        bg.setCornerRadii(new float[]{r, r, r, r, 0, 0, 0, 0});
        panel.setBackground(bg);
        panel.setElevation(dp(16));
        panel.setVisibility(View.GONE);
        // 关键：面板要吃掉触摸。LinearLayout 默认不点击，空白处的事件会穿透到
        // 下层的视频 overlay，变成单击暂停 / 双击 / 上下滑翻页，非常容易误操作。
        panel.setClickable(true);
        panel.setFocusable(true);

        // ---- 顶部把手 ----
        FrameLayout dragArea = new FrameLayout(act);
        dragArea.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(26)));

        dragBar = new View(act);
        GradientDrawable barBg = new GradientDrawable();
        barBg.setColor(0xFF3A3F48);
        barBg.setCornerRadius(dp(3));
        dragBar.setBackground(barBg);
        FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(dp(38), dp(5), Gravity.CENTER);
        dragArea.addView(dragBar, bp);
        panel.addView(dragArea);

        // ---- 标题行 ----
        LinearLayout head = new LinearLayout(act);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        head.setPadding(dp(16), dp(2), dp(10), dp(8));

        titleView = new TextView(act);
        titleView.setText("评论");
        titleView.setTextColor(C_FG);
        titleView.setTextSize(15.5f);
        titleView.setTypeface(Typeface.DEFAULT_BOLD);
        head.addView(titleView);

        sortView = new TextView(act);
        sortView.setText("按热度");
        sortView.setTextColor(C_SUB);
        sortView.setTextSize(10.5f);
        LinearLayout.LayoutParams srt = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        srt.leftMargin = dp(8);
        head.addView(sortView, srt);

        View spacer = new View(act);
        head.addView(spacer, new LinearLayout.LayoutParams(0, 1, 1f));

        TextView close = new TextView(act);
        close.setText("×");
        close.setTextColor(C_SUB);
        close.setTextSize(20);
        close.setGravity(Gravity.CENTER);
        close.setPadding(dp(10), 0, dp(10), 0);
        close.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { hide(); }
        });
        head.addView(close);
        panel.addView(head);

        // ---- 列表 ----
        list = new ListView(act);
        list.setDivider(null);
        list.setDividerHeight(0);
        list.setPadding(dp(14), 0, dp(14), dp(8));
        list.setClipToPadding(false);
        list.setCacheColorHint(Color.TRANSPARENT);
        list.setSelector(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
        list.setOverScrollMode(View.OVER_SCROLL_NEVER);
        adapter = new Adapter(act);
        list.setAdapter(adapter);
        panel.addView(list, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        tipView = new TextView(act);
        tipView.setText("加载中…");
        tipView.setTextColor(C_SUB);
        tipView.setTextSize(12);
        tipView.setGravity(Gravity.CENTER);
        tipView.setPadding(0, dp(30), 0, dp(30));
        panel.addView(tipView, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // ---- 底部输入条 ----
        LinearLayout bottom = new LinearLayout(act);
        bottom.setOrientation(LinearLayout.HORIZONTAL);
        bottom.setGravity(Gravity.CENTER_VERTICAL);
        bottom.setBackgroundColor(C_CARD);
        bottom.setPadding(dp(12), dp(8), dp(12), dp(10));

        input = new EditText(act);
        input.setHint("发个友善的评论…");
        input.setHintTextColor(0xFF6F7581);
        input.setTextColor(Color.WHITE);
        input.setTextSize(13);
        input.setSingleLine(true);
        input.setBackground(round(0xFF1E2229, 18));
        input.setPadding(dp(14), dp(7), dp(14), dp(7));
        bottom.addView(input, new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        send = new Button(act);
        send.setText("发送");
        send.setTextColor(Color.WHITE);
        send.setTextSize(12);
        send.setAllCaps(false);
        send.setBackground(round(C_ACC, 16));
        send.setPadding(dp(16), 0, dp(16), 0);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, dp(34));
        sp.leftMargin = dp(8);
        bottom.addView(send, sp);
        send.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { doSend(); }
        });
        panel.addView(bottom, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // ---- 挂到 host 上 ----
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, sheetH(), Gravity.BOTTOM);
        host.addView(panel, lp);
        panel.setTranslationY(sheetH());

        // 把手区：下滑关闭（跟手位移，松手过半或速度够就收）
        dragArea.setOnTouchListener(new View.OnTouchListener() {
            float downY = 0, lastY = 0;
            long lastT = 0, downT = 0;
            float vel = 0;
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        downY = lastY = e.getY();
                        downT = lastT = System.currentTimeMillis();
                        vel = 0;
                        panel.animate().cancel();
                        return true;
                    case MotionEvent.ACTION_MOVE: {
                        float dy = e.getY() - lastY;
                        long now = System.currentTimeMillis();
                        if (now > lastT) vel = vel * 0.6f + (dy / (now - lastT) * 1000f) * 0.4f;
                        lastY = e.getY();
                        lastT = now;
                        float ty = (e.getY() - downY);
                        if (ty < 0) ty = ty * 0.25f;          // 上滑阻尼
                        panel.setTranslationY(Math.max(-dp(20), ty));
                        return true;
                    }
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL: {
                        float ty = e.getY() - downY;
                        boolean fast = vel > dp(700);
                        if (ty > sheetH() * 0.28f || fast) {
                            hide();
                        } else {
                            panel.animate().translationY(0)
                                    .setDuration(180)
                                    .setInterpolator(new DecelerateInterpolator())
                                    .start();
                        }
                        return true;
                    }
                }
                return false;
            }
        });
    }

    // ------------------------------------------------------------ 显示 / 收起

    public void open(long aid, String bvid, int total, String title) {
        this.aid = aid;
        this.bvid = bvid == null ? "" : bvid;
        this.total = total;
        showing = true;
        panel.setVisibility(View.VISIBLE);
        panel.animate().translationY(0)
                .setDuration(280)
                .setInterpolator(new DecelerateInterpolator())
                .start();
        refreshTitle();
        // 同一个视频再次打开不重复拉取（避免刚打开就整列表闪一下）；
        // 换视频后 aid 变了才重新加载。
        if (this.aid != lastLoadedAid) {
            lastLoadedAid = this.aid;
            rows.clear();
            adapter.notifyDataSetChanged();
            load();
        }
    }

    public void hide() {
        showing = false;
        hideKeyboard();
        panel.animate().translationY(sheetH())
                .setDuration(220)
                .setInterpolator(new DecelerateInterpolator())
                .withEndAction(new Runnable() {
                    @Override public void run() {
                        if (!showing) panel.setVisibility(View.GONE);
                    }
                })
                .start();
    }

    public boolean isShowing() { return showing; }

    void hideKeyboard() {
        try {
            InputMethodManager imm = (InputMethodManager)
                    act.getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm != null && input != null) {
                imm.hideSoftInputFromWindow(input.getWindowToken(), 0);
            }
        } catch (Throwable ignore) { }
    }

    void refreshTitle() {
        if (titleView != null) {
            titleView.setText(total > 0 ? "评论 " + total : "评论");
        }
    }

    // ------------------------------------------------------------ 数据

    void load() {
        if (loading) return;
        loading = true;
        if (rows.isEmpty()) {
            tipView.setText("加载中…");
            tipView.setVisibility(View.VISIBLE);
        }
        new Thread(new Runnable() { @Override public void run() {
            final long useAid;
            if (aid <= 0 && !bvid.isEmpty()) {
                long a = 0;
                try {
                    JSONObject v = BiliApi.archiveMeta(bvid);
                    a = v.optLong("aid", 0);
                } catch (Throwable ignore) { }
                aid = a;
            }
            useAid = aid;
            JSONArray arr = null;
            String err = null;
            if (useAid > 0) {
                try { arr = BiliApi.replies(useAid, 1); }
                catch (Throwable e) { err = e.getMessage(); }
            } else {
                err = "缺少视频 id";
            }
            final JSONArray fArr = arr;
            final String fErr = err;
            ui.post(new Runnable() { @Override public void run() {
                loading = false;
                rows.clear();
                if (fArr != null) {
                    for (int i = 0; i < fArr.length(); i++) {
                        JSONObject o = fArr.optJSONObject(i);
                        if (o != null) rows.add(o);
                    }
                }
                adapter.notifyDataSetChanged();
                if (fErr != null) {
                    tipView.setText("评论加载失败：" + fErr);
                    tipView.setVisibility(View.VISIBLE);
                } else if (rows.isEmpty()) {
                    tipView.setText("还没有评论，来抢个沙发");
                    tipView.setVisibility(View.VISIBLE);
                } else {
                    tipView.setVisibility(View.GONE);
                }
            } });
        } }).start();
    }

    void doSend() {
        final String txt = input.getText() != null ? input.getText().toString().trim() : "";
        if (txt.isEmpty()) {
            Toast.makeText(act, "先写点内容吧", Toast.LENGTH_SHORT).show();
            return;
        }
        if (BiliApi.loggedInUid() == null) {
            Toast.makeText(act, "请先登录 B 站账号", Toast.LENGTH_SHORT).show();
            return;
        }
        send.setEnabled(false);
        new Thread(new Runnable() { @Override public void run() {
            final String[] err = {null};
            try { BiliApi.sendReply(aid, txt); }
            catch (Throwable e) { err[0] = e.getMessage(); }
            ui.post(new Runnable() { @Override public void run() {
                send.setEnabled(true);
                if (err[0] != null) {
                    Toast.makeText(act, err[0], Toast.LENGTH_LONG).show();
                    return;
                }
                input.setText("");
                hideKeyboard();
                Toast.makeText(act, "评论已发布", Toast.LENGTH_SHORT).show();
                load();
            } });
        } }).start();
    }

    // ------------------------------------------------------------ 列表

    static String timeAgo(long sec) {
        if (sec <= 0) return "";
        long d = System.currentTimeMillis() / 1000L - sec;
        if (d < 60) return "刚刚";
        if (d < 3600) return (d / 60) + "分钟前";
        if (d < 86400) return (d / 3600) + "小时前";
        if (d < 86400 * 30) return (d / 86400) + "天前";
        java.text.SimpleDateFormat f = new java.text.SimpleDateFormat("yyyy-MM-dd");
        return f.format(new java.util.Date(sec * 1000L));
    }

    static String count(int n) {
        if (n >= 10000) return String.format("%.1f万", n / 10000f);
        return String.valueOf(n);
    }

    class Adapter extends BaseAdapter {
        final Context ctx;
        Adapter(Context c) { ctx = c; }

        @Override public int getCount() { return rows.size(); }
        @Override public Object getItem(int i) { return rows.get(i); }
        @Override public long getItemId(int i) { return i; }

        @Override public View getView(int pos, View convert, ViewGroup parent) {
            JSONObject o = rows.get(pos);
            LinearLayout row = new LinearLayout(ctx);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setPadding(0, dp(10), 0, dp(10));

            JSONObject member = o.optJSONObject("member");
            String face = member == null ? "" : member.optString("avatar", "");
            ImageView av = new ImageView(ctx);
            av.setScaleType(ImageView.ScaleType.CENTER_CROP);
            GradientDrawable ph = new GradientDrawable();
            ph.setShape(GradientDrawable.OVAL);
            ph.setColor(0xFF2A2E36);
            av.setBackground(ph);
            av.setClipToOutline(true);
            if (!face.isEmpty()) ImgLoader.load(av, face, dp(34), dp(34));
            LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(dp(34), dp(34));
            ap.rightMargin = dp(10);
            row.addView(av, ap);

            LinearLayout col = new LinearLayout(ctx);
            col.setOrientation(LinearLayout.VERTICAL);

            TextView name = new TextView(ctx);
            name.setText(member == null ? "用户" : member.optString("uname", "用户"));
            name.setTextColor(0xFFAEB4C0);
            name.setTextSize(12);
            name.setSingleLine(true);
            name.setEllipsize(TextUtils.TruncateAt.END);
            col.addView(name);

            TextView body = new TextView(ctx);
            JSONObject content = o.optJSONObject("content");
            body.setText(content == null ? "" : content.optString("message", ""));
            body.setTextColor(C_FG);
            body.setTextSize(13);
            body.setLineSpacing(dp(3), 1f);
            LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            bp.topMargin = dp(4);
            col.addView(body, bp);

            LinearLayout foot = new LinearLayout(ctx);
            foot.setOrientation(LinearLayout.HORIZONTAL);
            foot.setGravity(Gravity.CENTER_VERTICAL);
            LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            fp.topMargin = dp(5);

            TextView time = new TextView(ctx);
            time.setText(timeAgo(o.optLong("ctime", 0)) + "  " + count(o.optInt("like", 0)) + " 赞");
            time.setTextColor(0xFF6F7581);
            time.setTextSize(10);
            foot.addView(time, new LinearLayout.LayoutParams(0,
                    ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

            TextView reply = new TextView(ctx);
            reply.setText("回复");
            reply.setTextColor(0xFF8A909C);
            reply.setTextSize(10);
            foot.addView(reply);

            col.addView(foot, fp);
            row.addView(col, new LinearLayout.LayoutParams(
                    0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            return row;
        }
    }
}
