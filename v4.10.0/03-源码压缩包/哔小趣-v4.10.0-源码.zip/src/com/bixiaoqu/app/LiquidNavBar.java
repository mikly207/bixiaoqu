package com.bixiaoqu.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.view.MotionEvent;
import android.widget.FrameLayout;

/**
 * 液态玻璃底栏（v4.10.0）。
 *
 * 回到 v4.9.8 的实心胶囊路线：深色渐变底 + 白色描边 + 顶部高光。
 * 当时的观感是「厚实、干净」，比抓背景模糊那版更稳，所以保留它，
 * 只在光泽上做了加强：
 *
 *   1) 主体：自下而上的深色渐变，顶部更亮，形成体积感；
 *   2) 顶光：上 62% 整片白色渐隐，模拟玻璃受光面；
 *   3) 顶棱：贴着上边缘 1.5dp 的高亮线，这是「亮泽」最直接的来源；
 *   4) 外沿：1.2dp 上亮下暗的描边，端头弧面反光；
 *   5) 内沿：下缘内暗边，制造玻璃厚度；
 *   6) 外影：三层递减投影，悬浮感；
 *   7) 左右端侧光，让弧面立起来。
 *
 * 浅色模式下自动换成白玻璃（白渐变 + 深色弱描边）。
 */
public class LiquidNavBar extends FrameLayout {

    public interface Callback {
        void onTouchDown(float x, float y);
        void onTouchMove(float x, float y);
        void onTouchUp();
        void onHover(int tabIndex);
        void onCommit(int tabIndex);
    }

    private Callback callback;
    /** 槽位 → 真实 tab 索引。底栏三格：{0,1,4} */
    private int[] slots = {0, 1, 2, 3, 4};

    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint edge = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint gloss = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint rim = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint shadow = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();
    private final RectF tmp = new RectF();
    private final RectF t2 = new RectF();
    private final Path clip = new Path();

    private boolean dragging;

    public LiquidNavBar(Context c) {
        super(c);
        setClipChildren(false);
        setClipToPadding(false);
        edge.setStyle(Paint.Style.STROKE);
        rim.setStyle(Paint.Style.STROKE);
    }

    public void setCallback(Callback cb) {
        this.callback = cb;
    }

    public void setSlots(int[] s) {
        if (s != null && s.length > 0) slots = s;
    }

    /** 兼容旧调用：这一版材质是静态的，不需要抓背景 */
    public void refreshBackdrop() {
        invalidate();
    }

    int dp(float v) {
        return (int) (getResources().getDisplayMetrics().density * v + 0.5f);
    }

    @Override
    protected void onDraw(Canvas cv) {
        final int w = getWidth(), h = getHeight();
        if (w <= 0 || h <= 0) return;
        final float r = h / 2f;
        rect.set(0, 0, w, h);
        final boolean dark = MainActivity.DARK;

        // 1) 外投影：三层递减，越外越淡
        for (int i = 3; i >= 1; i--) {
            float off = dp(i * 2.6f);
            shadow.setColor(dark ? 0x12000000 : 0x0E000000);
            tmp.set(-off * 0.5f, -off * 0.4f, w + off * 0.5f, h + off * 1.1f);
            cv.drawRoundRect(tmp, r + off * 0.5f, r + off * 0.5f, shadow);
        }

        // 2) 主体渐变：顶部亮、底部沉
        fill.setShader(new LinearGradient(0, 0, 0, h,
                dark ? 0xF22E3340 : 0xFAFFFFFF,
                dark ? 0xE616181F : 0xF2E9ECF2, Shader.TileMode.CLAMP));
        cv.drawRoundRect(rect, r, r, fill);
        fill.setShader(null);

        // 3) 内部受光 / 下沉 / 侧光
        clip.reset();
        clip.addRoundRect(rect, r, r, Path.Direction.CW);
        final int sc = cv.save();
        cv.clipPath(clip);

        gloss.setShader(new LinearGradient(0, 0, 0, h * 0.62f,
                dark ? 0x42FFFFFF : 0x8CFFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP));
        cv.drawRect(rect, gloss);

        gloss.setShader(new LinearGradient(0, 0, 0, dp(9),
                0x59FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP));
        cv.drawRect(rect, gloss);

        gloss.setShader(new LinearGradient(0, h * 0.58f, 0, h,
                0x00000000, dark ? 0x50000000 : 0x1A000000, Shader.TileMode.CLAMP));
        cv.drawRect(rect, gloss);

        int sideA = dark ? 0x26FFFFFF : 0x40FFFFFF;
        gloss.setShader(new LinearGradient(0, 0, w * 0.16f, 0,
                sideA, 0x00FFFFFF, Shader.TileMode.CLAMP));
        cv.drawRect(0, 0, w * 0.16f, h, gloss);
        gloss.setShader(new LinearGradient(w, 0, w - w * 0.16f, 0,
                sideA, 0x00FFFFFF, Shader.TileMode.CLAMP));
        cv.drawRect(w - w * 0.16f, 0, w, h, gloss);
        gloss.setShader(null);

        cv.restoreToCount(sc);

        // 4) 顶棱高亮线
        rim.setStrokeWidth(dp(1.5f));
        rim.setColor(dark ? 0x7AFFFFFF : 0xCCFFFFFF);
        t2.set(rect);
        t2.inset(dp(1.2f), dp(0.9f));
        cv.drawRoundRect(t2, r - dp(1.2f), r - dp(1.2f), rim);

        // 5) 内沿暗边（下缘）
        rim.setStrokeWidth(dp(1.1f));
        rim.setColor(dark ? 0x33000000 : 0x1A000000);
        t2.set(rect);
        t2.inset(dp(0.9f), dp(0.9f));
        cv.drawRoundRect(t2, r - dp(0.9f), r - dp(0.9f), rim);

        // 6) 外描边：上亮下暗
        edge.setStrokeWidth(dp(1.2f));
        edge.setShader(new LinearGradient(0, 0, 0, h,
                dark ? 0x8CFFFFFF : 0x33000000,
                dark ? 0x1FFFFFFF : 0x0D000000, Shader.TileMode.CLAMP));
        cv.drawRoundRect(rect, r, r, edge);
        edge.setShader(null);

        // 7) 按下提亮
        if (dragging) {
            gloss.setShader(null);
            gloss.setColor(dark ? 0x14FFFFFF : 0x1AFFFFFF);
            cv.drawRoundRect(rect, r, r, gloss);
        }
    }

    private int tabAt(float x) {
        int n = slots.length;
        int idx = (int) (x / (getWidth() / (float) n));
        idx = idx < 0 ? 0 : (idx >= n ? n - 1 : idx);
        return slots[idx];
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        float x = ev.getX(), y = ev.getY();
        switch (ev.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                dragging = true;
                invalidate();
                if (callback != null) {
                    callback.onTouchDown(getLeft() + x, getTop() + y);
                    callback.onHover(tabAt(x));
                }
                break;
            case MotionEvent.ACTION_MOVE:
                if (callback != null) {
                    callback.onTouchMove(getLeft() + x, getTop() + y);
                    callback.onHover(tabAt(x));
                }
                break;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                if (dragging && callback != null) {
                    boolean up = ev.getActionMasked() == MotionEvent.ACTION_UP;
                    callback.onTouchUp();
                    if (up) callback.onCommit(tabAt(x));
                }
                dragging = false;
                invalidate();
                break;
        }
        return true;
    }
}
