package com.bixiaoqu.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;

/**
 * 哔小趣 · B 站轻量客户端
 * 底部三栏：推荐 / 我的 / 关注；顶部搜索；无广告、清爽界面。
 * 推荐页：封面图列表 + 下拉刷新（手写，不依赖 androidx SwipeRefreshLayout）
 */
public class MainActivity extends Activity {

    static final String VERSION = BxqApp.VERSION;

    // 【v4.10.0】改为可变静态字段：所有页面在 onCreate 里调 applyTheme() 重算，
    // 切主题后 recreate 就能整体换肤（原来是 final 常量，切了也不变）。
    static int C_BG = Color.parseColor("#16181d");
    static int C_CARD = Color.parseColor("#1f2229");
    static int C_FG = Color.parseColor("#e8eaf0");
    static int C_SUB = Color.parseColor("#9aa0ab");
    static int C_ACC = Color.parseColor("#fb7299");
    /** 当前是否为深色（浅色下底栏、卡片、分隔线要用另一套颜色） */
    static boolean DARK = true;
    /** 本页创建时的主题指纹 */
    int appliedStamp = -1;
    /** 因切主题而重建时，记住原来停在哪一页 */
    static int restoreTab = -1;

    // ===== 「我的」空间页控件（v4.10.0）=====
    android.widget.ImageView mineBanner;
    TextView mineSign, mineExp, mineVideoCount;
    View mineExpBarFill;
    LinearLayout mineVideoBox;
    String mineCoinsText = "—";
    /** 主题指纹，用于 onResume 检测变化 → recreate */
    static int themeStamp = 1;

    /** 主题指纹：mode*10 + 是否深色。变了就说明要重建界面。 */
    static int themeStampOf(android.content.Context c) {
        int mode = Prefs.themeMode(c);
        boolean dark;
        if (mode == Prefs.THEME_LIGHT) {
            dark = false;
        } else if (mode == Prefs.THEME_DARK) {
            dark = true;
        } else {
            int ui = c.getResources().getConfiguration().uiMode
                    & android.content.res.Configuration.UI_MODE_NIGHT_MASK;
            dark = ui == android.content.res.Configuration.UI_MODE_NIGHT_YES;
        }
        return mode * 10 + (dark ? 1 : 0);
    }

    /** 按设置算出这一屏的配色。任何 Activity 创建 UI 之前必须调用一次。 */
    static void applyTheme(android.content.Context c) {
        int st = themeStampOf(c);
        boolean dark = (st % 10) == 1;
        DARK = dark;
        C_ACC = Color.parseColor("#fb7299");
        if (dark) {
            C_BG = Color.parseColor("#16181d");
            C_CARD = Color.parseColor("#1f2229");
            C_FG = Color.parseColor("#e8eaf0");
            C_SUB = Color.parseColor("#9aa0ab");
        } else {
            C_BG = Color.parseColor("#f3f4f6");
            C_CARD = Color.parseColor("#ffffff");
            C_FG = Color.parseColor("#18191c");
            C_SUB = Color.parseColor("#61666d");
        }
        themeStamp = st;
    }

    LinearLayout content;
    LiquidNavBar nav;                    // 液态玻璃悬浮底栏
    LiquidLensLayer lensLayer;           // 全屏液态透镜（光晕可溢出胶囊）
    // 底部五栏：首页 / 动态 / 发布(+) / 消息 / 我的
    TextView[] tabs = new TextView[5];
    final String[] tabNames = {"首页", "动态", "", "消息", "我的"};
    ImageView[] tabIcons = new ImageView[5];
    int currentTab = 0;

    // 顶部频道栏（推荐/热门/动画/影视/新番，已去掉直播）
    final String[] channels = {"推荐", "热门", "动画", "影视", "新番"};
    final int[] channelRid = {0, -2, 1, 181, 13};
    LinearLayout channelBar;
    TextView[] channelViews = new TextView[5];
    int currentChannel = 0;   // 默认选中「推荐」

    final Handler ui = new Handler(Looper.getMainLooper());
    final ArrayList<VideoItem> rows = new ArrayList<>();

    TextView mineView;
    android.widget.AbsListView listView;
    TextView refreshTip;
    Button loginTop;
    ImageView avatarTop;              // 首页顶栏头像
    boolean appliedTwoCol = false;

    // 下拉刷新状态
    boolean pullArmed = false;
    boolean refreshing = false;
    float pullStartY = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        MainActivity.applyTheme(this);
        appliedStamp = themeStamp;
        try {
            loadLoginCookies();
            buildUi();
            switchTab(0);
            handleShare(getIntent());
            CrashHandler.note("boot", "MainActivity.onCreate OK");
        } catch (Throwable e) {
            // 兜底：启动任何一步出错都不闪退，直接把错误显示在屏幕上
            CrashHandler.note("fatal", android.util.Log.getStackTraceString(e));
            showErrorScreen(e);
        }
    }    /** 启动失败时显示错误页（不依赖主题/资源，只用最原始的 View） */
    void showErrorScreen(Throwable e) {
        try {
            android.widget.ScrollView sv = new android.widget.ScrollView(this);
            TextView tv = new TextView(this);
            tv.setTextColor(Color.WHITE);
            tv.setTextSize(11);
            tv.setTypeface(Typeface.MONOSPACE);
            tv.setPadding(28, 28, 28, 28);
            tv.setText("启动出错，但不闪退。\n把以下内容截图发我即可定位：\n\n"
                    + android.util.Log.getStackTraceString(e)
                    + "\n\n设备：" + android.os.Build.MODEL
                    + "  SDK：" + android.os.Build.VERSION.SDK_INT);
            sv.addView(tv);
            sv.setBackgroundColor(Color.BLACK);
            setContentView(sv);
        } catch (Throwable ignore) { }
    }

    @Override
    public void onConfigurationChanged(android.content.res.Configuration cfg) {
        super.onConfigurationChanged(cfg);
        // 旋转后重排当前页（双列卡片宽度按屏幕宽计算，必须重建）
        try { switchTab(currentTab); } catch (Throwable ignore) { }
    }

    @Override
    protected void onResume() {
        super.onResume();
        // 从设置页改完主题回来：整页重建一次，配色与底栏材质全部换新
        if (appliedStamp != themeStampOf(this)) {
            restoreTab = currentTab;
            recreate();
            return;
        }
        refreshLoginTop();
        loadTopAvatar();
        if (currentTab == 0 && Prefs.twoColumn(this) != appliedTwoCol) {
            switchTab(0);
            return;
        }
        if (currentTab == 4) refreshMine();
        else if (currentTab == 1 && !hasRealRow()) loadDynamic();
    }

    int dp(float v) {
        return (int) (getResources().getDisplayMetrics().density * v);
    }

    /** 列表里是否有真实条目（全是占位提示时视为需要重载） */
    boolean hasRealRow() {
        for (VideoItem it : rows) if (!it.isPlaceholder()) return true;
        return false;
    }

    /** 刷新顶栏登录态显示 */
    void refreshLoginTop() {
        if (loginTop == null) return;
        String uid = BiliApi.loggedInUid();
        loginTop.setText(uid != null ? "UID " + uid : "登录");
        loginTop.setTextColor(uid != null ? C_ACC : Color.WHITE);
    }

    /** 顶栏头像：异步加载当前登录用户的真实头像，失败显示默认图标 */
    void loadTopAvatar() {
        if (avatarTop == null) return;
        // 默认占位：粉色小人
        avatarTop.setImageDrawable(Ic.drawable(this, "g_avatar", C_ACC));
        if (BiliApi.loggedInUid() == null) return;
        new Thread(new Runnable() { @Override public void run() {
            final String[] face = {null};
            try {
                JSONObject nav = BiliApi.navInfo();
                String f = nav.optString("face", "");
                if (!f.isEmpty()) {
                    if (f.startsWith("//")) f = "https:" + f;
                    if (!f.contains("@")) f = f + "@80w_80h_1c.jpg";
                    face[0] = f;
                }
            } catch (Throwable ignore) { }
            final String url = face[0];
            if (url != null) {
                ui.post(new Runnable() { @Override public void run() {
                    if (avatarTop != null) ImgLoader.load(avatarTop, url, dp(36), dp(36));
                } });
            }
        } }).start();
    }

    void loadLoginCookies() {
        SharedPreferences sp = getSharedPreferences("bili_login", MODE_PRIVATE);
        String sess = sp.getString("SESSDATA", "");
        if (!sess.isEmpty()) {
            BiliApi.setLoginCookie(sess, sp.getString("bili_jct", ""),
                    sp.getString("DedeUserID", ""));
        }
    }

    void handleShare(Intent it) {
        if (it == null || !Intent.ACTION_SEND.equals(it.getAction())) return;
        CharSequence t = it.getCharSequenceExtra(Intent.EXTRA_TEXT);
        if (t == null) return;
        String bvid = null;
        try { bvid = BiliApi.extractBvid(t.toString()); } catch (Exception ignore) { }
        if (bvid == null) {
            String av = BiliApi.extractAvid(t.toString());
            if (av != null) bvid = "av" + av;
        }
        if (bvid != null) {
            Intent i = new Intent(this, PlayActivity.class);
            i.putExtra("bvid", bvid);
            startActivity(i);
        }
    }

    void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(C_BG);
        int pad = dp(12);

        // ============ 顶栏：头像 + 搜索框 + 游戏 + 信封 ============
        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(pad, pad, pad, (int) (pad * 0.5));

        // 顶栏头像（圆形，加载登录用户真实头像；点击进入个人空间）
        avatarTop = new ImageView(this);
        avatarTop.setScaleType(ImageView.ScaleType.CENTER_CROP);
        avatarTop.setClickable(true);
        avatarTop.setBackgroundColor(DARK ? Color.parseColor("#2A2E37")
                : Color.parseColor("#DDE1E8"));
        avatarTop.setClipToOutline(true);
        final float avatarRad = 18 * getResources().getDisplayMetrics().density;
        avatarTop.setOutlineProvider(new android.view.ViewOutlineProvider() {
            @Override public void getOutline(View v, android.graphics.Outline o) {
                o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), avatarRad);
            }
        });
        LinearLayout.LayoutParams avp = new LinearLayout.LayoutParams(dp(36), dp(36));
        avp.rightMargin = dp(10);
        top.addView(avatarTop, avp);
        avatarTop.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                String uid = BiliApi.loggedInUid();
                if (uid == null) {
                    promptLoginOrOut();
                } else {
                    Intent in = new Intent(MainActivity.this, UserActivity.class);
                    in.putExtra("mid", uid);
                    startActivity(in);
                }
            }
        });
        loadTopAvatar();
        avatarTop.setOnLongClickListener(new View.OnLongClickListener() {
            @Override public boolean onLongClick(View v) {
                startActivity(new Intent(MainActivity.this, SettingsActivity.class));
                return true;
            }
        });

        // 搜索胶囊
        LinearLayout search = new LinearLayout(this);
        search.setOrientation(LinearLayout.HORIZONTAL);
        search.setGravity(Gravity.CENTER_VERTICAL);
        android.graphics.drawable.GradientDrawable sg = new android.graphics.drawable.GradientDrawable();
        sg.setColor(DARK ? 0x14FFFFFF : 0x0D000000);
        sg.setCornerRadius(dp(19));
        sg.setStroke((int) dp(1), 0x1AFFFFFF);
        search.setBackground(sg);
        search.setPadding(dp(12), 0, dp(10), 0);
        ImageView sIcon = Ic.view(this, "g_search", C_SUB, 15);
        search.addView(sIcon);
        TextView sHint = new TextView(this);
        sHint.setText("搜索你感兴趣的内容");
        sHint.setTextColor(0x99AAB0BC);
        sHint.setTextSize(12.5f);
        sHint.setSingleLine(true);
        sHint.setEllipsize(android.text.TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams shp = new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        shp.leftMargin = dp(8);
        search.addView(sHint, shp);
        top.addView(search, new LinearLayout.LayoutParams(
                0, dp(38), 1f));
        search.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, SearchActivity.class));
            }
        });

        // 信封（私信）
        ImageView mail = Ic.glass(this, "g_mail", C_FG, DARK ? 0x14FFFFFF : 0x0F000000, 34, 17);
        LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(dp(34), dp(34));
        mp.leftMargin = dp(7);
        top.addView(mail, mp);
        mail.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, MsgActivity.class));
            }
        });

        root.addView(top, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // ============ 顶部频道栏 ============
        channelBar = new LinearLayout(this);
        channelBar.setOrientation(LinearLayout.HORIZONTAL);
        channelBar.setGravity(Gravity.CENTER_VERTICAL);
        channelBar.setPadding(dp(8), dp(4), dp(8), dp(6));
        final android.widget.HorizontalScrollView channelScroll = new android.widget.HorizontalScrollView(this);
        channelScroll.setHorizontalScrollBarEnabled(false);
        for (int i = 0; i < channels.length; i++) {
            final int ci = i;
            TextView ch = new TextView(this);
            ch.setText(channels[i]);
            ch.setTextSize(14.5f);
            ch.setGravity(Gravity.CENTER);
            ch.setPadding(dp(11), dp(7), dp(11), dp(9));
            ch.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { switchChannel(ci); }
            });
            channelViews[i] = ch;
            channelBar.addView(ch, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        }
        // 频道栏右侧更多按钮
        ImageView more = Ic.view(this, "more", C_SUB, 18);
        more.setClickable(true);
        more.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                channelScroll.smoothScrollTo(channelScroll.getWidth(), 0);
            }
        });
        LinearLayout.LayoutParams moreP = new LinearLayout.LayoutParams(dp(30), dp(34));
        more.setPadding(dp(6), 0, 0, 0);
        channelBar.addView(more, moreP);
        channelScroll.addView(channelBar, new android.widget.FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        root.addView(channelScroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        refreshChannelStyle();

        // ============ 内容区 ============
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        root.addView(content, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        // ============ 底部三栏 · 液态玻璃悬浮胶囊（首页 / 动态 / 我的）============
        // 结构：LiquidNavBar 负责玻璃胶囊 + 液态透镜；bar 承载 3 个 tab（索引 0/1/4）。
        LiquidNavBar nav = new LiquidNavBar(this);
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        // 只有上下内边距，左右留给三个 cell 均分，槽位边界与图标中心严格对齐
        bar.setPadding(0, dp(7), 0, dp(7));
        String[] icons = {"g_home", "g_dynamic", "g_plus", "g_mail", "g_mine"};
        final int[] order = {0, 1, 4};   // 【v4.9.8】底栏三格：首页 / 动态 / 我的
        // 游戏厅、留声机移到「我的 → 设置」下方；消息走顶部信封按钮和「我的」页入口
        for (int slot = 0; slot < order.length; slot++) {
            final int idx = order[slot];
            LinearLayout cell = new LinearLayout(this);
            cell.setOrientation(LinearLayout.VERTICAL);
            cell.setGravity(Gravity.CENTER_HORIZONTAL);
            cell.setClickable(true);
            // 图标行：固定高度 + 居中，三个 tab 的图标落在同一水平基线
            LinearLayout iconRow = new LinearLayout(this);
            iconRow.setOrientation(LinearLayout.HORIZONTAL);
            iconRow.setGravity(Gravity.CENTER);
            cell.addView(iconRow, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, dp(31)));

            int initColor = (idx == 0) ? C_ACC : C_SUB;  // 首页默认选中
            ImageView ic = Ic.view(this, icons[idx], initColor, 24);
            tabIcons[idx] = ic;
            iconRow.addView(ic);

            TextView lb = new TextView(this);
            lb.setText(tabNames[idx]);
            lb.setTextColor(initColor);
            lb.setTextSize(11.5f);
            lb.setGravity(Gravity.CENTER);
            tabs[idx] = lb;
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.topMargin = dp(3);
            cell.addView(lb, lp);

            cell.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { switchTab(idx); }
            });
            bar.addView(cell, new LinearLayout.LayoutParams(
                    0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        }
        nav.addView(bar, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM));
        // 槽位 → 真实 tab 索引（中间发布位已移除）
        nav.setSlots(order);
        this.nav = nav;
        // 内容区底部留出底栏高度，避免被悬浮胶囊遮挡
        content.setPadding(0, 0, 0, dp(92));

        refreshLoginTop();
        FrameLayout wrap = new FrameLayout(this);
        // 玻璃胶囊的投影与外描边会溢出自身边界一点点，父容器不能裁
        wrap.setClipChildren(false);
        wrap.addView(root, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        // 悬浮胶囊：左右 16dp、底部 26dp（整体上移），三项等分
        FrameLayout.LayoutParams navP = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM);
        navP.leftMargin = dp(16);
        navP.rightMargin = dp(16);
        navP.bottomMargin = dp(26);
        wrap.addView(nav, navP);

        // 液态透镜层：覆盖全屏但只在「底栏条带」内绘制（上下溢出约 3~4mm），
        // 不吃触摸，事件穿透给底栏。
        lensLayer = new LiquidLensLayer(this);
        lensLayer.setClickable(false);
        wrap.addView(lensLayer, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // 底栏滑动交互：按住出透镜 + 实时预览高亮，松手才真正切换页面
        nav.setCallback(new LiquidNavBar.Callback() {
            @Override public void onTouchDown(float x, float y) {
                // 透镜只允许出现在底栏所在条带，上下各溢出约 3mm（<5mm）
                lensLayer.setBand(nav.getTop() - dp(20), nav.getBottom() + dp(20));
                lensLayer.captureBehind(wrap);
                lensLayer.start(x, y);
            }
            @Override public void onTouchMove(float x, float y) {
                lensLayer.move(x, y);
            }
            @Override public void onTouchUp() {
                lensLayer.end();
                clearPreview();
            }
            @Override public void onHover(int tabIndex) {
                previewTab(tabIndex);
            }
            @Override public void onCommit(int tabIndex) {
                commitTab(tabIndex);
            }
        });

        setContentView(wrap);
        if (restoreTab > 0) {
            int t = restoreTab;
            restoreTab = -1;
            switchTab(t);
        }
        if (Prefs.splash(this)) showSplash(wrap);
    }

    /** 滑动预览：手指悬停的 tab 变粉，其余变淡（不改页面） */
    void previewTab(int idx) {
        for (int i = 0; i < 5; i++) {
            if (tabs[i] == null) continue;
            boolean on = (i == idx);
            int color = on ? C_ACC : 0xFF666B75;
            tabs[i].setTextColor(color);
            if (tabIcons[i] != null) {
                Ic.set(tabIcons[i], i == 0 ? "g_home" : (i == 1 ? "g_dynamic"
                        : (i == 3 ? "g_mail" : "g_mine")), color);
            }
        }
    }

    /** 取消预览：按当前 tab 恢复常规配色 */
    void clearPreview() {
        for (int i = 0; i < 5; i++) {
            if (tabs[i] == null) continue;
            boolean on = (i == currentTab);
            int color = on ? C_ACC : C_SUB;
            tabs[i].setTextColor(color);
            if (tabIcons[i] != null) {
                Ic.set(tabIcons[i], i == 0 ? "g_home" : (i == 1 ? "g_dynamic"
                        : (i == 3 ? "g_mail" : "g_mine")), color);
            }
        }
    }

    /** 松手提交：点到别的 tab 才真正切页；重复点当前 tab 回顶部 */
    void commitTab(int idx) {
        if (idx == currentTab) { clearPreview(); scrollContentTop(); return; }
        switchTab(idx);
    }

    /** 回到当前列表顶部（仅首页列表有效） */
    void scrollContentTop() {
        try {
            if (listView != null) listView.smoothScrollToPosition(0);
        } catch (Throwable ignore) { }
    }

    /**
     * 开屏动画：整屏插画（drawable/splash）+ 底部品牌与作者署名。
     * 总时长 2.5 秒：完整可见 2360ms，随后 140ms 淡出。
     */
    void showSplash(final FrameLayout host) {
        try {
            final FrameLayout layer = new FrameLayout(this);
            layer.setBackgroundColor(Color.BLACK);
            layer.setClickable(true);   // 开屏期间吞掉点击，避免误触底下的按钮

            // ---- 背景插画 ----
            final ImageView art = new ImageView(this);
            art.setScaleType(ImageView.ScaleType.CENTER_CROP);
            int rid = getResources().getIdentifier("splash", "drawable", getPackageName());
            if (rid != 0) art.setImageResource(rid);
            art.setPivotX(0.5f);
            art.setPivotY(0.42f);
            layer.addView(art, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

            // ---- 底部压暗，保证文字可读 ----
            View scrim = new View(this);
            scrim.setBackground(new android.graphics.drawable.GradientDrawable(
                    android.graphics.drawable.GradientDrawable.Orientation.BOTTOM_TOP,
                    new int[]{0xF2000000, 0xB3000000, 0x00000000}));
            FrameLayout.LayoutParams sp = new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, dp(300), Gravity.BOTTOM);
            layer.addView(scrim, sp);

            // ---- 文案：名称 + 作者 ----
            final LinearLayout box = new LinearLayout(this);
            box.setOrientation(LinearLayout.VERTICAL);
            box.setGravity(Gravity.CENTER_HORIZONTAL);

            TextView name = new TextView(this);
            name.setText("哔小趣");
            name.setTextColor(Color.WHITE);
            name.setTextSize(30);
            name.setTypeface(Typeface.DEFAULT_BOLD);
            name.setLetterSpacing(0.1f);
            name.setShadowLayer(dp(8), 0, dp(2), 0x99000000);
            name.setGravity(Gravity.CENTER);
            box.addView(name, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));

            TextView author = new TextView(this);
            author.setText("软件作者 Dynamo");
            author.setTextColor(0xE6FFFFFF);
            author.setTextSize(13);
            author.setLetterSpacing(0.06f);
            author.setShadowLayer(dp(6), 0, dp(1), 0x99000000);
            author.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            ap.topMargin = dp(10);
            box.addView(author, ap);

            // 细分割线 + 标语
            View line = new View(this);
            line.setBackgroundColor(0x66FB7299);
            LinearLayout.LayoutParams lpLine = new LinearLayout.LayoutParams(dp(34), dp(2));
            lpLine.topMargin = dp(14);
            box.addView(line, lpLine);

            TextView slogan = new TextView(this);
            slogan.setText("轻量 · 无广告 · 高清");
            slogan.setTextColor(0xB3FFFFFF);
            slogan.setTextSize(11);
            slogan.setLetterSpacing(0.12f);
            slogan.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams sg = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            sg.topMargin = dp(12);
            box.addView(slogan, sg);

            FrameLayout.LayoutParams lpBox = new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                    Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
            lpBox.bottomMargin = dp(56);
            layer.addView(box, lpBox);

            // ---- 底部粉色加载线 ----
            final View bar = new View(this);
            bar.setBackgroundColor(0xFFFB7299);
            bar.setPivotX(0f);
            bar.setScaleX(0.02f);
            int barW = getResources().getDisplayMetrics().widthPixels;
            layer.addView(bar, new FrameLayout.LayoutParams(
                    barW, dp(2), Gravity.BOTTOM));

            host.addView(layer, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

            // 入场：图片缓慢推近，文字淡入上浮，加载线走满全程（整体 2.5 秒）
            art.setScaleX(1f);
            art.setScaleY(1f);
            art.animate().scaleX(1.06f).scaleY(1.06f).setDuration(2360)
                    .setInterpolator(new android.view.animation.DecelerateInterpolator())
                    .start();

            box.setAlpha(0f);
            box.setTranslationY(dp(14));
            box.animate().alpha(1f).translationY(0f).setDuration(560)
                    .setStartDelay(80)
                    .setInterpolator(new android.view.animation.DecelerateInterpolator())
                    .start();

            bar.animate().scaleX(1f).setDuration(2360)
                    .setInterpolator(new android.view.animation.LinearInterpolator())
                    .start();

            layer.postDelayed(new Runnable() {
                @Override public void run() {
                    layer.animate().alpha(0f).setDuration(140)
                            .withEndAction(new Runnable() {
                                @Override public void run() {
                                    try { host.removeView(layer); } catch (Throwable ignore) { }
                                }
                            }).start();
                }
            }, 2360);
        } catch (Throwable e) {
            CrashHandler.note("splash", "开屏动画失败：" + e);
        }
    }

    /**
     * 下拉刷新容器：dispatchTouchEvent 在最外层，子 View（双列卡片）消费了事件也照样能观察到。
     * 只观察、不消费，列表滚动与卡片点击完全不受影响。
     */
    static class PullFrame extends FrameLayout {
        interface Watcher { void onTouch(MotionEvent ev); }
        Watcher watcher;

        PullFrame(Context c) { super(c); }

        @Override public boolean dispatchTouchEvent(MotionEvent ev) {
            if (watcher != null) {
                try { watcher.onTouch(ev); } catch (Throwable ignore) { }
            }
            return super.dispatchTouchEvent(ev);
        }
    }

    /** 品牌标：粉色渐变圆角方块 + 白色播放键 */
    static class LogoView extends View {
        final android.graphics.Paint p = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
        final android.graphics.Path tri = new android.graphics.Path();
        final android.graphics.RectF rect = new android.graphics.RectF();

        LogoView(Context c) { super(c); }

        @Override protected void onDraw(android.graphics.Canvas cv) {
            int w = getWidth(), h = getHeight();
            float pad = w * 0.04f;
            rect.set(pad, pad, w - pad, h - pad);
            p.setStyle(android.graphics.Paint.Style.FILL);
            p.setShader(new android.graphics.LinearGradient(0, 0, w, h,
                    new int[]{Color.parseColor("#ff9dbb"), Color.parseColor("#fb7299"),
                            Color.parseColor("#e85c86")},
                    new float[]{0f, 0.55f, 1f}, android.graphics.Shader.TileMode.CLAMP));
            cv.drawRoundRect(rect, w * 0.28f, w * 0.28f, p);
            p.setShader(null);

            p.setColor(Color.WHITE);
            tri.reset();
            tri.moveTo(w * 0.40f, h * 0.31f);
            tri.lineTo(w * 0.40f, h * 0.69f);
            tri.lineTo(w * 0.72f, h * 0.50f);
            tri.close();
            cv.drawPath(tri, p);
        }
    }

    void switchTab(int idx) {
        currentTab = idx;
        // 底部高亮
        for (int i = 0; i < 5; i++) {
            if (tabs[i] != null) tabs[i].setTextColor(i == idx ? C_ACC : C_SUB);
            if (tabIcons[i] != null) {
                Ic.set(tabIcons[i], i == 0 ? "g_home" : (i == 1 ? "g_dynamic"
                        : (i == 3 ? "g_mail" : "g_mine")), i == idx ? C_ACC : C_SUB);
            }
        }
        // 频道栏只在首页显示
        if (channelBar != null) {
            channelBar.setVisibility(idx == 0 ? View.VISIBLE : View.GONE);
        }
        content.removeAllViews();
        refreshTip = null;
        refreshing = false;
        if (idx == 0) {
            rows.clear();
            appliedTwoCol = Prefs.twoColumn(this);
            content.addView(newList(appliedTwoCol), new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            loadChannel();
        } else if (idx == 1) {
            rows.clear();
            content.addView(newList(false), new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            loadDynamic();
        } else if (idx == 3) {
            // 消息：直接进私信列表，回来后高亮仍在首页
            try {
                startActivity(new Intent(this, MsgActivity.class));
            } catch (Throwable e) {
                Toast.makeText(this, "打开消息失败：" + e.getMessage(), Toast.LENGTH_SHORT).show();
            }
            switchTab(0);
        } else if (idx == 4) {
            buildMine();
        }
    }

    /** 频道样式：选中的粉色加粗 */
    void refreshChannelStyle() {
        for (int i = 0; i < channels.length; i++) {
            if (channelViews[i] == null) continue;
            boolean on = i == currentChannel;
            channelViews[i].setTextColor(on ? C_ACC : C_SUB);
            channelViews[i].setTextSize(on ? 15.5f : 14.5f);
            channelViews[i].setTypeface(on ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
        }
    }

    void switchChannel(int ci) {
        if (ci == currentChannel) return;
        currentChannel = ci;
        refreshChannelStyle();
        if (currentTab == 0) loadChannel();
    }

    /** 按当前频道加载内容 */
    void loadChannel() {
        int rid = channelRid[currentChannel];
        if (rid == 0) { loadRecommend(false); return; }        // 推荐：混合流
        if (rid == -2) { loadPopular(); return; }              // 热门
        if (rid == -1) { loadLive(); return; }                 // 直播
        loadRanking(rid);                                      // 分区榜单
    }

    void showPublishMenu() {
        new android.app.AlertDialog.Builder(this)
                .setTitle("发布内容")
                .setMessage("第三方客户端暂不支持投稿。\n你可以进入动态页查看关注的人的最新内容。")
                .setPositiveButton("去看看动态", new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface d, int w) { switchTab(1); }
                })
                .setNegativeButton("取消", null)
                .show();
    }

    /** 列表 + 下拉刷新（刷新提示浮在列表上方，不参与 ListView 布局，避免 header 动态高度问题） */
    View newList(boolean twoCol) {
        final PullFrame wrap = new PullFrame(this);

        final ListView lv = new ListView(this);
        listView = lv;
        lv.setDivider(new ColorDrawable(Color.TRANSPARENT));
        lv.setDividerHeight(dp(twoCol ? 12 : 9));
        lv.setPadding(dp(10), dp(6), dp(10), dp(10));
        lv.setClipToPadding(false);
        lv.setCacheColorHint(Color.TRANSPARENT);
        lv.setSelector(new ColorDrawable(Color.TRANSPARENT));
        lv.setOverScrollMode(View.OVER_SCROLL_NEVER);
        lv.setAdapter(new FeedAdapter(this, rows, twoCol, new FeedAdapter.Listener() {
            @Override public void onItem(VideoItem item) { openItem(item); }
        }));
        lv.setOnItemClickListener(new android.widget.AdapterView.OnItemClickListener() {
            @Override public void onItemClick(android.widget.AdapterView<?> p,
                                              View v, int i, long id) {
                if (twoCol) return;   // 双列由卡片自身处理，避免行号与数据下标错位
                if (i < 0 || i >= rows.size()) return;
                openItem(rows.get(i));
            }
        });

        refreshTip = new TextView(this);
        refreshTip.setText("下拉刷新");
        refreshTip.setTextColor(C_SUB);
        refreshTip.setTextSize(12);
        refreshTip.setGravity(Gravity.CENTER);
        refreshTip.setPadding(0, dp(8), 0, dp(8));

        wrap.addView(lv, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        wrap.addView(refreshTip, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(40), Gravity.TOP));
        refreshTip.setTranslationY(-dp(40));
        refreshTip.setAlpha(0f);

        // 关键：手势不能挂在 ListView 上。双列卡片自己是 clickable，会消费 ACTION_DOWN，
        // ListView 的 OnTouchListener 拿不到按下点，pullStartY 永远是旧值 → 双列下拉刷新失效。
        // 改到外层容器的 dispatchTouchEvent 观察，所有事件都能拿到，且不消费、不影响滚动与点击。
        wrap.watcher = new PullFrame.Watcher() {
            @Override public void onTouch(MotionEvent ev) {
                switch (ev.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        pullStartY = ev.getY();
                        pullArmed = atTop();
                        break;
                    case MotionEvent.ACTION_MOVE: {
                        if (!pullArmed || refreshing || refreshTip == null) break;
                        // 双列卡片会吃掉 DOWN，拖动后列表可能已在滚动：一旦离开顶部就判定为滚动
                        if (!atTop()) { pullArmed = false; hideRefreshTip(); break; }
                        float dy = ev.getY() - pullStartY;
                        if (dy > 0) {
                            float max = dp(110);
                            float d = Math.min(dy, max);
                            refreshTip.animate().cancel();
                            refreshTip.setTranslationY(-dp(40) + d);
                            refreshTip.setAlpha(Math.min(1f, d / (max * 0.45f)));
                            refreshTip.setText(d > max * 0.55f ? "松开刷新" : "下拉刷新");
                        }
                        break;
                    }
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL: {
                        boolean trigger = pullArmed && !refreshing
                                && refreshTip != null && refreshTip.getAlpha() > 0.9f
                                && refreshTip.getTranslationY() > -dp(25);
                        pullArmed = false;
                        if (trigger) doRefresh();
                        else if (!refreshing) hideRefreshTip();
                        break;
                    }
                }
            }
        };

        return wrap;
    }

    boolean atTop() {
        if (listView == null) return false;
        if (listView.getChildCount() == 0) return true;
        return listView.getFirstVisiblePosition() == 0
                && listView.getChildAt(0).getTop() >= listView.getPaddingTop() - 2;
    }

    void doRefresh() {
        if (refreshing) return;
        refreshing = true;
        if (refreshTip != null) {
            refreshTip.setText("正在刷新…");
            refreshTip.animate().translationY(dp(6)).alpha(1f).setDuration(160).start();
        }
        if (currentTab == 0) {
            if (channelRid[currentChannel] == 0) loadRecommend(true);
            else loadChannel();
        } else if (currentTab == 1) loadDynamic();
        else refreshing = false;
    }

    void hideRefreshTip() {
        refreshing = false;
        if (refreshTip == null) return;
        refreshTip.animate().translationY(-dp(40)).alpha(0f).setDuration(200).start();
    }

    void addLoading() {
        rows.add(new VideoItem("", "加载中…", "", null));
        notifyData();
    }

    void setResult(ArrayList<VideoItem> got, String emptyTip) {
        rows.clear();
        rows.addAll(got);
        if (rows.isEmpty()) rows.add(new VideoItem("", emptyTip, "", null));
        notifyData();
    }

    void notifyData() {
        try {
            if (listView != null && listView.getAdapter() != null) {
                ((BaseAdapter) listView.getAdapter()).notifyDataSetChanged();
            }
        } catch (Throwable ignore) { }
    }

    /** 列表项统一入口：视频进播放页，UP 主进空间 */
    void openItem(VideoItem it) {
        if (it == null || it.isPlaceholder()) return;
        if (it.bvid.startsWith("up:")) {
            if (it.extra != null && !it.extra.isEmpty()) {
                Intent u = new Intent(this, UserActivity.class);
                u.putExtra("mid", it.extra);
                u.putExtra("name", it.title);
                u.putExtra("face", it.pic);
                startActivity(u);
            } else {
                Intent s = new Intent(this, SearchActivity.class);
                s.putExtra("keyword", it.bvid.substring(3));
                startActivity(s);
            }
            return;
        }
        Intent intent = new Intent(this, PlayActivity.class);
        intent.putExtra("bvid", it.bvid);
        // 【v4.1 提速】把列表已有的元数据带给播放页，省掉 pages() 串行请求
        intent.putExtra("cid", it.cid);
        intent.putExtra("aspect", it.aspect);
        intent.putExtra("ptitle", it.title);
        intent.putExtra("pdur", it.durSec);
        startActivity(intent);
    }

    // ------------------------------------------------------------ 推荐

    void loadRecommend(final boolean isRefresh) {
        if (!isRefresh) addLoading();
        // 刷新前的列表快照，用来判定「这一批是不是和刚才完全一样」
        final ArrayList<String> gotOld = new ArrayList<>();
        for (int i = 0; i < rows.size(); i++) {
            VideoItem it = rows.get(i);
            if (it != null && !it.isPlaceholder() && it.bvid != null
                    && !it.bvid.isEmpty() && !it.bvid.startsWith("up:")) {
                gotOld.add(it.bvid);
            }
        }
        new Thread(new Runnable() { @Override public void run() {
            final ArrayList<VideoItem> got = new ArrayList<>();
            final String[] err = {null};
            try {
                // 每次刷新自增种子：首页推荐流 + 热门随机页 + 随机分区榜单混合后打乱，
                // 不再固定拉 popular 第 1 页（那批内容几分钟内都不会变，正是「怎么刷都一样」的原因）
                int seed = Prefs.bumpRecSeed(MainActivity.this);
                JSONArray list = BiliApi.recommendMix(seed);
                // 极小概率抽到同一批：强制再换一次
                if (list == null || list.length() == 0
                        || sameBvids(list, gotOld)) {
                    list = BiliApi.recommendMix(seed + 131);
                }
                if (list != null) {
                    for (int i = 0; i < list.length(); i++) {
                        JSONObject o = list.getJSONObject(i);
                        String bv = o.optString("bvid", "");
                        if (bv.isEmpty()) continue;
                        String up = o.optJSONObject("owner") != null
                                ? o.getJSONObject("owner").optString("name", "") : "";
                        int dur = o.optInt("duration", 0);
                        long play = o.optJSONObject("stat") != null
                                ? o.getJSONObject("stat").optLong("view", 0) : 0;
                        StringBuilder sub = new StringBuilder();
                        if (!up.isEmpty()) sub.append(up);
                        if (play > 0) {
                            if (sub.length() > 0) sub.append("  ·  ");
                            sub.append(VideoItem.views(play)).append("播放");
                        }
                        if (dur > 0) {
                            if (sub.length() > 0) sub.append("  ·  ");
                            sub.append(VideoItem.dur(dur));
                        }
                        // 【v4.1 提速】带上列表接口已有的 cid / 宽高 / 时长，播放页可跳过 pages() 请求
                        long cid = o.optLong("cid", 0);
                        long durSec = o.optLong("duration", 0);
                        float aspect = 0f;
                        JSONObject dim = o.optJSONObject("dimension");
                        if (dim != null) {
                            int dw = dim.optInt("width", 0), dh = dim.optInt("height", 0);
                            int rot = dim.optInt("rotate", 0);
                            if (rot == 90 || rot == 270) { int t = dw; dw = dh; dh = t; }
                            if (dw > 0 && dh > 0) aspect = dw / (float) dh;
                        }
                        got.add(new VideoItem(bv,
                                BiliApi.cleanTitle(o.optString("title", "")),
                                sub.toString(), o.optString("pic", ""),
                                cid, aspect, durSec));
                    }
                }
            } catch (final Throwable e) {
                err[0] = e.getMessage();
            }
            ui.post(new Runnable() { @Override public void run() {
                if (currentTab != 0) { hideRefreshTip(); return; }
                setResult(got, "没有内容（" + (err[0] == null ? "空" : err[0]) + "）");
                hideRefreshTip();
                if (isRefresh) {
                    Toast.makeText(MainActivity.this,
                            got.isEmpty() ? "刷新失败，请稍后重试" : "已换一批 · " + got.size() + " 条",
                            Toast.LENGTH_SHORT).show();
                }
            } });
        } }).start();
    }

    /** 新一批与旧列表重复度 ≥85% 视为「没换」（bvid 命中率） */
    static boolean sameBvids(JSONArray list, ArrayList<String> old) {
        if (list == null || old == null || old.isEmpty() || list.length() == 0) return false;
        int hit = 0;
        for (int i = 0; i < list.length(); i++) {
            JSONObject o = list.optJSONObject(i);
            if (o == null) continue;
            if (old.contains(o.optString("bvid", ""))) hit++;
        }
        return hit >= Math.min(list.length(), old.size()) * 0.85f;
    }

    // ------------------------------------------------------------ 我的（个人主页）

    // 个人主页控件
    android.widget.ScrollView mineScroll;
    android.widget.ImageView mineAvatar;
    TextView mineName, mineLv, mineVip, mineCoins, mineUid, mineCacheLine;
    Button mineLoginBtn;
    final TextView[] mineStats = new TextView[3];
    final TextView[] mineStatLabels = new TextView[3];

    /** 圆角背景（纯代码，不引入 shape 资源） */
    static android.graphics.drawable.GradientDrawable roundBg(int color, float radDp, Activity a) {
        android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(radDp * a.getResources().getDisplayMetrics().density);
        return g;
    }

    /**
     * 【v4.9.8】「我的」页里的跳转行：设置 / 游戏厅 / 留声机 共用一套样式，
     * 保证三行的高度、圆角、箭头位置完全一致。
     */
    LinearLayout mineLinkRow(String icon, String title, String sub, int tint,
                             View.OnClickListener click) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setBackground(roundBg(C_CARD, 14, this));
        row.setPadding(dp(16), dp(13), dp(14), dp(13));
        row.setClickable(true);

        row.addView(Ic.view(this, icon, tint, 22),
                new LinearLayout.LayoutParams(dp(22), dp(22)));

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);

        TextView t = new TextView(this);
        t.setText(title);
        t.setTextColor(C_FG);
        t.setTextSize(15);
        col.addView(t);

        if (sub != null && !sub.isEmpty()) {
            TextView d = new TextView(this);
            d.setText(sub);
            d.setTextColor(Color.parseColor("#6f7581"));
            d.setTextSize(11);
            LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            dlp.topMargin = dp(3);
            col.addView(d, dlp);
        }

        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        clp.leftMargin = dp(14);
        row.addView(col, clp);

        TextView arrow = new TextView(this);
        arrow.setText("›");
        arrow.setTextColor(Color.parseColor("#6f7581"));
        arrow.setTextSize(22);
        row.addView(arrow);

        row.setOnClickListener(click);
        return row;
    }

    /**
     * 【v4.10.0】「我的」改为 B 站个人空间的样子：
     * 头图 + 压线大头像 + 粉丝/关注/获赞 + 昵称与徽章 + 等级进度 + 签名，
     * 下面是「主页 / 动态 / 投稿 / 收藏」与投稿网格，最后才是原有的功能入口。
     */
    void buildMine() {
        mineScroll = new android.widget.ScrollView(this);
        mineScroll.setFillViewport(true);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        mineScroll.addView(col, new android.widget.FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // ==================== 头图 ====================
        android.widget.FrameLayout banner = new android.widget.FrameLayout(this);
        banner.setBackgroundColor(DARK ? 0xFF20242C : 0xFFE8EBF1);

        // 没有头图接口，用本人头像放大做底（模糊感靠缩小后的拉伸与渐变遮罩实现）
        mineBanner = new android.widget.ImageView(this);
        mineBanner.setScaleType(android.widget.ImageView.ScaleType.CENTER_CROP);
        mineBanner.setAlpha(DARK ? 0.55f : 0.4f);
        banner.addView(mineBanner, new android.widget.FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        View fade = new View(this);
        fade.setBackground(new android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.BOTTOM_TOP,
                new int[]{C_BG, C_BG & 0x00FFFFFF, C_BG & 0x00FFFFFF}));
        banner.addView(fade, new android.widget.FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // 顶部条：右「搜索」+「更多」，左侧留空（这里就是首页，不需要返回）
        LinearLayout bannerTop = new LinearLayout(this);
        bannerTop.setOrientation(LinearLayout.HORIZONTAL);
        bannerTop.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
        bannerTop.setPadding(dp(10), dp(8), dp(10), 0);

        ImageView bSearch = Ic.view(this, "g_search", C_FG, 19);
        bSearch.setPadding(dp(8), dp(8), dp(8), dp(8));
        bSearch.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, SearchActivity.class));
            }
        });
        bannerTop.addView(bSearch, new LinearLayout.LayoutParams(dp(36), dp(36)));

        ImageView bMore = Ic.view(this, "more", C_FG, 19);
        bMore.setPadding(dp(8), dp(8), dp(8), dp(8));
        bMore.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showMineMore(); }
        });
        bannerTop.addView(bMore, new LinearLayout.LayoutParams(dp(36), dp(36)));
        banner.addView(bannerTop, new android.widget.FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        col.addView(banner, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(190)));

        // ==================== 头像 + 昵称（负 margin 压住头图下沿）====================
        LinearLayout profile = new LinearLayout(this);
        profile.setOrientation(LinearLayout.HORIZONTAL);
        profile.setPadding(dp(16), 0, dp(16), 0);

        mineAvatar = new android.widget.ImageView(this);
        mineAvatar.setScaleType(android.widget.ImageView.ScaleType.CENTER_CROP);
        mineAvatar.setBackgroundColor(DARK ? 0xFF2A2E37 : 0xFFDDE1E8);
        mineAvatar.setClipToOutline(true);
        mineAvatar.setOutlineProvider(new android.view.ViewOutlineProvider() {
            @Override public void getOutline(View v, android.graphics.Outline o) {
                o.setOval(0, 0, v.getWidth(), v.getHeight());
            }
        });
        // 头像外圈描边（和背景拉开层次）
        android.graphics.drawable.GradientDrawable ring = new android.graphics.drawable.GradientDrawable();
        ring.setShape(android.graphics.drawable.GradientDrawable.OVAL);
        ring.setColor(0x00000000);
        ring.setStroke(dp(2), C_BG);
        FrameLayout avatarWrap = new FrameLayout(this);
        avatarWrap.setBackground(ring);
        avatarWrap.setClipToOutline(true);
        avatarWrap.setOutlineProvider(new android.view.ViewOutlineProvider() {
            @Override public void getOutline(View v, android.graphics.Outline o) {
                o.setOval(0, 0, v.getWidth(), v.getHeight());
            }
        });
        avatarWrap.addView(mineAvatar, new android.widget.FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        LinearLayout.LayoutParams avp = new LinearLayout.LayoutParams(dp(86), dp(86));
        avp.topMargin = dp(-43);
        profile.addView(avatarWrap, avp);

        LinearLayout names = new LinearLayout(this);
        names.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        np.leftMargin = dp(14);
        np.topMargin = dp(4);
        profile.addView(names, np);

        LinearLayout nameRow = new LinearLayout(this);
        nameRow.setOrientation(LinearLayout.HORIZONTAL);
        nameRow.setGravity(Gravity.CENTER_VERTICAL);

        mineName = new TextView(this);
        mineName.setTextColor(C_FG);
        mineName.setTextSize(19);
        mineName.setTypeface(Typeface.DEFAULT_BOLD);
        mineName.setSingleLine(true);
        mineName.setEllipsize(android.text.TextUtils.TruncateAt.END);
        nameRow.addView(mineName, new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        mineVip = new TextView(this);
        mineVip.setTextColor(Color.WHITE);
        mineVip.setTextSize(9.5f);
        mineVip.setBackground(roundBg(C_ACC, 7, this));
        mineVip.setPadding(dp(6), dp(2), dp(6), dp(2));
        mineVip.setVisibility(View.GONE);
        LinearLayout.LayoutParams vp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        vp.leftMargin = dp(6);
        nameRow.addView(mineVip, vp);
        names.addView(nameRow);

        // 徽章行：粉丝团 / 成就勋章（占位样式，和截图一致）
        LinearLayout badgeRow = new LinearLayout(this);
        badgeRow.setOrientation(LinearLayout.HORIZONTAL);
        badgeRow.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams brp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        brp.topMargin = dp(5);
        names.addView(badgeRow, brp);

        badgeRow.addView(mineBadge("粉丝团"));
        badgeRow.addView(mineBadge("成就勋章"));

        // 三栏数据：粉丝 / 关注 / 获赞
        LinearLayout stats = new LinearLayout(this);
        stats.setOrientation(LinearLayout.HORIZONTAL);
        stats.setPadding(0, dp(10), 0, 0);
        String[] lab = {"粉丝", "关注", "获赞"};
        for (int i = 0; i < 3; i++) {
            LinearLayout one = new LinearLayout(this);
            one.setOrientation(LinearLayout.VERTICAL);
            one.setGravity(Gravity.CENTER_HORIZONTAL);

            mineStats[i] = new TextView(this);
            mineStats[i].setTextColor(C_FG);
            mineStats[i].setTextSize(17);
            mineStats[i].setTypeface(Typeface.DEFAULT_BOLD);
            mineStats[i].setGravity(Gravity.CENTER);
            mineStats[i].setText("—");
            one.addView(mineStats[i]);

            mineStatLabels[i] = new TextView(this);
            mineStatLabels[i].setTextColor(C_SUB);
            mineStatLabels[i].setTextSize(10.5f);
            mineStatLabels[i].setText(lab[i]);
            one.addView(mineStatLabels[i]);

            final int si = i;
            one.setClickable(true);
            one.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { openStat(si); }
            });
            stats.addView(one, new LinearLayout.LayoutParams(0,
                    ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        }
        names.addView(stats);

        // 「编辑资料」：B 站没有开放资料编辑接口，直接送到网页版
        TextView editBtn = new TextView(this);
        editBtn.setText("编辑资料");
        editBtn.setTextColor(C_ACC);
        editBtn.setTextSize(12);
        editBtn.setGravity(Gravity.CENTER);
        android.graphics.drawable.GradientDrawable eg =
                new android.graphics.drawable.GradientDrawable();
        eg.setShape(android.graphics.drawable.GradientDrawable.RECTANGLE);
        eg.setCornerRadius(dp(16));
        eg.setColor(0x00000000);
        eg.setStroke(dp(1), C_ACC);
        editBtn.setBackground(eg);
        LinearLayout.LayoutParams ebp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(32));
        ebp.topMargin = dp(10);
        names.addView(editBtn, ebp);
        editBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                String uid = BiliApi.loggedInUid();
                if (uid == null) { promptLoginOrOut(); return; }
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW,
                            android.net.Uri.parse("https://space.bilibili.com/" + uid)));
                } catch (Throwable e) {
                    Toast.makeText(MainActivity.this, "没有可用的浏览器", Toast.LENGTH_SHORT).show();
                }
            }
        });

        col.addView(profile, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // ==================== 等级进度 ====================
        LinearLayout lvRow = new LinearLayout(this);
        lvRow.setOrientation(LinearLayout.HORIZONTAL);
        lvRow.setGravity(Gravity.CENTER_VERTICAL);
        lvRow.setPadding(dp(16), dp(14), dp(16), 0);

        mineLv = new TextView(this);
        mineLv.setTextColor(Color.WHITE);
        mineLv.setTextSize(9.5f);
        mineLv.setTypeface(Typeface.DEFAULT_BOLD);
        mineLv.setBackground(roundBg(0xFFF0773C, 4, this));
        mineLv.setPadding(dp(5), dp(1), dp(5), dp(1));
        mineLv.setText("LV6");
        lvRow.addView(mineLv);

        FrameLayout barBox = new FrameLayout(this);
        LinearLayout.LayoutParams bbp = new LinearLayout.LayoutParams(
                0, dp(4), 1f);
        bbp.leftMargin = dp(8);
        lvRow.addView(barBox, bbp);

        View barBg = new View(this);
        barBg.setBackground(roundBg(DARK ? 0xFF2E333D : 0xFFDEE2E9, 2, this));
        barBox.addView(barBg, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(4)));

        mineExpBarFill = new View(this);
        mineExpBarFill.setBackground(roundBg(0xFFF0773C, 2, this));
        FrameLayout.LayoutParams fbp = new FrameLayout.LayoutParams(dp(0), dp(4));
        barBox.addView(mineExpBarFill, fbp);

        mineExp = new TextView(this);
        mineExp.setTextColor(C_SUB);
        mineExp.setTextSize(10);
        mineExp.setText("—");
        LinearLayout.LayoutParams ep = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        ep.leftMargin = dp(8);
        lvRow.addView(mineExp, ep);
        col.addView(lvRow);

        // ==================== 签名 ====================
        LinearLayout signRow = new LinearLayout(this);
        signRow.setOrientation(LinearLayout.HORIZONTAL);
        signRow.setPadding(dp(16), dp(10), dp(16), 0);

        mineSign = new TextView(this);
        mineSign.setTextColor(C_FG);
        mineSign.setTextSize(12.5f);
        mineSign.setLineSpacing(dp(2), 1f);
        mineSign.setText("这个人很神秘，什么都没有写");
        signRow.addView(mineSign, new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView detail = new TextView(this);
        detail.setText("详情");
        detail.setTextColor(0xFF6F7581);
        detail.setTextSize(11.5f);
        detail.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { showMineDetail(); }
        });
        signRow.addView(detail);

        col.addView(signRow);

        // IP 属地 / 学校（截图里这一行是灰色小字）
        mineUid = new TextView(this);
        mineUid.setTextColor(0xFF6F7581);
        mineUid.setTextSize(11);
        mineUid.setPadding(dp(16), dp(6), dp(16), 0);
        mineUid.setText("");
        col.addView(mineUid);

        // ==================== 分区 tab ====================
        LinearLayout tabsRow = new LinearLayout(this);
        tabsRow.setOrientation(LinearLayout.HORIZONTAL);
        tabsRow.setPadding(dp(6), dp(14), dp(6), 0);
        String[] tabNames2 = {"主页", "动态", "投稿", "收藏"};
        for (int i = 0; i < tabNames2.length; i++) {
            final int ti = i;
            LinearLayout one = new LinearLayout(this);
            one.setOrientation(LinearLayout.VERTICAL);
            one.setGravity(Gravity.CENTER_HORIZONTAL);
            one.setPadding(0, dp(6), 0, dp(8));

            TextView t = new TextView(this);
            t.setText(tabNames2[i]);
            t.setTextColor(i == 0 ? C_ACC : C_SUB);
            t.setTextSize(14.5f);
            if (i == 0) t.setTypeface(Typeface.DEFAULT_BOLD);
            one.addView(t);

            View underline = new View(this);
            underline.setBackground(roundBg(C_ACC, 2, this));
            LinearLayout.LayoutParams ulp = new LinearLayout.LayoutParams(dp(18), dp(3));
            ulp.topMargin = dp(5);
            underline.setVisibility(i == 0 ? View.VISIBLE : View.GONE);
            one.addView(underline, ulp);

            one.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    if (ti == 1) {
                        String u = BiliApi.loggedInUid();
                        if (u == null) { promptLoginOrOut(); return; }
                        Intent it = new Intent(MainActivity.this, DynamicsActivity.class);
                        it.putExtra("mid", u);
                        it.putExtra("name", mineName.getText().toString());
                        startActivity(it);
                    } else if (ti == 2) {
                        if (BiliApi.loggedInUid() == null) { promptLoginOrOut(); return; }
                        Intent it = new Intent(MainActivity.this, ShelfActivity.class);
                        it.putExtra("mode", "fav");
                        startActivity(it);
                    } else if (ti == 3) {
                        if (BiliApi.loggedInUid() == null) { promptLoginOrOut(); return; }
                        Intent it = new Intent(MainActivity.this, ShelfActivity.class);
                        it.putExtra("mode", "fav");
                        startActivity(it);
                    }
                }
            });
            tabsRow.addView(one, new LinearLayout.LayoutParams(0,
                    ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        }
        col.addView(tabsRow);

        View tabLine = new View(this);
        tabLine.setBackgroundColor(DARK ? 0xFF23262C : 0xFFE6E8EC);
        col.addView(tabLine, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(0.6f)));

        // ==================== 视频数 + 更多 ====================
        LinearLayout vHead = new LinearLayout(this);
        vHead.setOrientation(LinearLayout.HORIZONTAL);
        vHead.setGravity(Gravity.CENTER_VERTICAL);
        vHead.setPadding(dp(16), dp(14), dp(16), dp(8));

        mineVideoCount = new TextView(this);
        mineVideoCount.setTextColor(C_FG);
        mineVideoCount.setTextSize(14);
        mineVideoCount.setTypeface(Typeface.DEFAULT_BOLD);
        mineVideoCount.setText("视频 —");
        vHead.addView(mineVideoCount, new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView moreV = new TextView(this);
        moreV.setText("更多 ›");
        moreV.setTextColor(C_SUB);
        moreV.setTextSize(11.5f);
        vHead.addView(moreV);
        col.addView(vHead);

        // ==================== 投稿网格 ====================
        mineVideoBox = new LinearLayout(this);
        mineVideoBox.setOrientation(LinearLayout.VERTICAL);
        mineVideoBox.setPadding(dp(16), 0, dp(16), 0);
        col.addView(mineVideoBox, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView emptyV = new TextView(this);
        emptyV.setText("登录后显示你的投稿");
        emptyV.setTextColor(C_SUB);
        emptyV.setTextSize(12);
        emptyV.setGravity(Gravity.CENTER);
        emptyV.setPadding(0, dp(20), 0, dp(20));
        mineVideoBox.addView(emptyV);

        // ==================== 功能入口（原有能力全部保留）====================
        TextView fnTitle = new TextView(this);
        fnTitle.setText("功能");
        fnTitle.setTextColor(C_SUB);
        fnTitle.setTextSize(12);
        fnTitle.setTypeface(Typeface.DEFAULT_BOLD);
        fnTitle.setPadding(dp(18), dp(22), dp(18), dp(8));
        col.addView(fnTitle);

        LinearLayout entries = new LinearLayout(this);
        entries.setOrientation(LinearLayout.HORIZONTAL);
        entries.setBackground(roundBg(C_CARD, 14, this));
        entries.setPadding(0, dp(16), 0, dp(14));
        final String[] entryNames = {"离线缓存", "历史记录", "我的收藏", "稍后再看", "消息"};
        final String[] entryIcons = {"m_cache", "m_history", "m_fav", "m_later", "m_msg"};
        final String[] entryModes = {"cache", "history", "fav", "toview", "msg"};
        for (int i = 0; i < entryNames.length; i++) {
            final String mode = entryModes[i];
            LinearLayout one = new LinearLayout(this);
            one.setOrientation(LinearLayout.VERTICAL);
            one.setGravity(Gravity.CENTER);

            ImageView icon = Ic.view(this, entryIcons[i], Color.parseColor("#3fa9e8"), 26);
            one.addView(icon);

            TextView label = new TextView(this);
            label.setText(entryNames[i]);
            label.setTextColor(C_SUB);
            label.setTextSize(11);
            label.setGravity(Gravity.CENTER);
            label.setSingleLine(true);
            LinearLayout.LayoutParams lpp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lpp.topMargin = dp(6);
            one.addView(label, lpp);

            entries.addView(one, new LinearLayout.LayoutParams(0,
                    ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            one.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    if (BiliApi.loggedInUid() == null && !"cache".equals(mode)
                            && !"history".equals(mode)) {
                        Toast.makeText(MainActivity.this, "请先登录 B 站账号", Toast.LENGTH_SHORT).show();
                        promptLoginOrOut();
                        return;
                    }
                    if ("msg".equals(mode)) {
                        startActivity(new Intent(MainActivity.this, MsgActivity.class));
                        return;
                    }
                    Intent it = new Intent(MainActivity.this, ShelfActivity.class);
                    it.putExtra("mode", mode);
                    startActivity(it);
                }
            });
        }
        LinearLayout.LayoutParams ep2 = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        ep2.leftMargin = dp(14);
        ep2.rightMargin = dp(14);
        ep2.topMargin = dp(4);
        col.addView(entries, ep2);

        // ---- 设置 / 游戏厅 / 留声机 ----
        LinearLayout setRow = new LinearLayout(this);
        setRow.setOrientation(LinearLayout.HORIZONTAL);
        setRow.setGravity(Gravity.CENTER_VERTICAL);
        setRow.setBackground(roundBg(C_CARD, 14, this));
        setRow.setPadding(dp(16), dp(15), dp(14), dp(15));
        setRow.setClickable(true);
        setRow.addView(new SettingsActivity.HexIcon(this, SettingsActivity.HexIcon.SETTINGS),
                new LinearLayout.LayoutParams(dp(22), dp(22)));
        TextView setLabel = new TextView(this);
        setLabel.setText("设置");
        setLabel.setTextColor(C_FG);
        setLabel.setTextSize(15);
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        slp.leftMargin = dp(14);
        setRow.addView(setLabel, slp);
        TextView setArrow = new TextView(this);
        setArrow.setText("›");
        setArrow.setTextColor(Color.parseColor("#6f7581"));
        setArrow.setTextSize(22);
        setRow.addView(setArrow);
        setRow.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, SettingsActivity.class));
            }
        });

        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(14), 0, dp(14), 0);
        LinearLayout.LayoutParams setLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        setLp.topMargin = dp(10);
        box.addView(setRow, setLp);

        LinearLayout gameRow = mineLinkRow("g_game", "游戏厅", "十款经典小游戏 · 离线可玩",
                0xFFFB7299, new View.OnClickListener() {
                    @Override public void onClick(View v) {
                        try {
                            startActivity(new Intent(MainActivity.this, GameActivity.class));
                        } catch (Throwable e) {
                            Toast.makeText(MainActivity.this,
                                    "打开游戏厅失败：" + e.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    }
                });
        LinearLayout.LayoutParams grp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        grp.topMargin = dp(10);
        box.addView(gameRow, grp);

        LinearLayout musicRow = mineLinkRow("g_record", "留声机", "本地音乐 · 唤起 QQ 音乐",
                0xFF3FA9E8, new View.OnClickListener() {
                    @Override public void onClick(View v) {
                        try {
                            startActivity(new Intent(MainActivity.this, MusicActivity.class));
                        } catch (Throwable e) {
                            Toast.makeText(MainActivity.this,
                                    "打开留声机失败：" + e.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    }
                });
        LinearLayout.LayoutParams mrp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        mrp.topMargin = dp(10);
        box.addView(musicRow, mrp);
        col.addView(box);

        // ---- 缓存概览 ----
        mineCacheLine = new TextView(this);
        mineCacheLine.setTextColor(C_SUB);
        mineCacheLine.setTextSize(12);
        mineCacheLine.setPadding(dp(20), dp(14), dp(20), 0);
        mineCacheLine.setText("离线缓存：0 个视频（MP4，保存在 电影/BiliAudio）");
        col.addView(mineCacheLine, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // ---- 登录 / 退出 ----
        Button loginBtn = new Button(this);
        loginBtn.setText(BiliApi.loggedInUid() != null ? "退出登录" : "登录 / 注册 B 站账号");
        loginBtn.setTextColor(Color.WHITE);
        loginBtn.setBackground(roundBg(BiliApi.loggedInUid() != null
                ? (DARK ? Color.parseColor("#2c3038") : Color.parseColor("#D9DDE5")) : C_ACC, 10, this));
        loginBtn.setAllCaps(false);
        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { promptLoginOrOut(); }
        });
        mineLoginBtn = loginBtn;
        LinearLayout.LayoutParams lbp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lbp.topMargin = dp(16);
        lbp.leftMargin = dp(14);
        lbp.rightMargin = dp(14);
        col.addView(loginBtn, lbp);

        // ---- 崩溃日志 ----
        TextView diag = new TextView(this);
        diag.setText("崩溃日志");
        diag.setTextColor(Color.parseColor("#5c626d"));
        diag.setTextSize(11);
        diag.setGravity(Gravity.CENTER);
        diag.setPadding(0, dp(14), 0, dp(24));
        diag.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                String log = CrashHandler.readCrashLog(
                        getExternalFilesDir(null), getFilesDir());
                new AlertDialog.Builder(MainActivity.this)
                        .setTitle("崩溃日志")
                        .setMessage(log)
                        .setPositiveButton("知道了", null)
                        .show();
            }
        });
        col.addView(diag, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        content.addView(mineScroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        updateMineLocal();
        refreshMine();
    }

    /** 昵称下方的小徽章（粉丝团 / 成就勋章），描边胶囊样式 */
    TextView mineBadge(String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(C_SUB);
        t.setTextSize(9.5f);
        android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable();
        g.setShape(android.graphics.drawable.GradientDrawable.RECTANGLE);
        g.setCornerRadius(dp(7));
        g.setColor(0x00000000);
        g.setStroke(dp(1), DARK ? 0xFF3A3F48 : 0xFFD3D7DE);
        t.setBackground(g);
        t.setPadding(dp(6), dp(2), dp(6), dp(2));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.rightMargin = dp(6);
        t.setLayoutParams(p);
        return t;
    }

    /** 右上「更多」：把设置/消息/崩溃日志/关于收在这里 */
    void showMineMore() {
        final String[] items = {"设置", "消息", "崩溃日志", "刷新资料"};
        new AlertDialog.Builder(this)
                .setItems(items, new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int which) {
                        if (which == 0) {
                            startActivity(new Intent(MainActivity.this, SettingsActivity.class));
                        } else if (which == 1) {
                            startActivity(new Intent(MainActivity.this, MsgActivity.class));
                        } else if (which == 2) {
                            String log2 = CrashHandler.readCrashLog(
                                    getExternalFilesDir(null), getFilesDir());
                            new AlertDialog.Builder(MainActivity.this)
                                    .setTitle("崩溃日志").setMessage(log2)
                                    .setPositiveButton("知道了", null).show();
                        } else {
                            refreshMine();
                            Toast.makeText(MainActivity.this, "正在刷新…", Toast.LENGTH_SHORT).show();
                        }
                    }
                })
                .show();
    }

    /** 「详情」：账号资料弹窗 */
    void showMineDetail() {
        String uid = BiliApi.loggedInUid();
        if (uid == null) {
            promptLoginOrOut();
            return;
        }
        String info = "UID：" + uid
                + "\nB币：" + mineCoinsText
                + "\n签名：" + (mineSign != null ? mineSign.getText().toString() : "");
        new AlertDialog.Builder(this)
                .setTitle("账号详情")
                .setMessage(info)
                .setPositiveButton("知道了", null)
                .show();
    }

    /** 本地即可确定的部分：缓存数量 */
    void updateMineLocal() {
        if (mineCacheLine == null) return;
        int n = 0;
        try {
            n = getSharedPreferences("video_cache", MODE_PRIVATE)
                    .getStringSet("files", new java.util.HashSet<String>()).size();
        } catch (Throwable ignore) { }
        mineCacheLine.setText("离线缓存：" + n + " 个视频（MP4，保存在 电影/BiliAudio）");
    }

    /** 联网拉取用户资料；未登录则显示引导态 */
    void refreshMine() {
        if (mineName == null) return;
        updateMineLocal();
        final String uid = BiliApi.loggedInUid();
        if (mineLoginBtn != null) {
            mineLoginBtn.setText(uid != null ? "退出登录" : "登录 / 注册 B 站账号");
            mineLoginBtn.setBackground(roundBg(uid != null
                    ? (DARK ? Color.parseColor("#2c3038") : Color.parseColor("#D9DDE5"))
                    : C_ACC, 10, this));
            mineLoginBtn.setTextColor(uid != null && !DARK ? C_FG : Color.WHITE);
        }
        if (uid == null) {
            mineName.setText("未登录");
            mineVip.setVisibility(View.GONE);
            mineLv.setText("LV0");
            mineSign.setText("登录后同步头像、粉丝、投稿与收藏");
            mineUid.setText("");
            mineExp.setText("—");
            setExpBar(0f);
            for (int i = 0; i < 3; i++) mineStats[i].setText("—");
            mineAvatar.setImageBitmap(null);
            if (mineBanner != null) mineBanner.setImageBitmap(null);
            if (mineVideoCount != null) mineVideoCount.setText("视频 —");
            if (mineVideoBox != null) {
                mineVideoBox.removeAllViews();
                mineVideoBox.addView(mineEmptyTip("登录后显示你的投稿"));
            }
            return;
        }

        mineUid.setText("UID " + uid);
        new Thread(new Runnable() { @Override public void run() {
            final JSONObject[] card = {null};
            final JSONObject[] stat = {null};
            final JSONArray[] vids = {null};
            try { card[0] = BiliApi.userCard(uid); } catch (Throwable ignore) { }
            try { stat[0] = BiliApi.relationStat(uid); } catch (Throwable ignore) { }
            try { vids[0] = BiliApi.userVideos(uid, 1); } catch (Throwable ignore) { }

            ui.post(new Runnable() { @Override public void run() {
                if (currentTab != 4 || mineName == null) return;
                try {
                    String face = "";
                    if (card[0] != null) {
                        JSONObject c = card[0].optJSONObject("card");
                        if (c == null) c = card[0];
                        String nm = c.optString("name", "");
                        if (!nm.isEmpty()) mineName.setText(nm);
                        String sign = c.optString("sign", "");
                        mineSign.setText(sign.isEmpty() ? "这个人很神秘，什么都没有写" : sign);

                        face = c.optString("face", "");
                        if (!face.isEmpty()) {
                            if (face.startsWith("//")) face = "https:" + face;
                            String small = face.contains("@") ? face : face + "@160w_160h_1c.jpg";
                            String big = face.contains("@") ? face.split("@")[0] + "@480w_480h_1c.jpg" : face + "@480w_480h_1c.jpg";
                            ImgLoader.load(mineAvatar, small, dp(86), dp(86));
                            if (mineBanner != null) ImgLoader.load(mineBanner, big, dp(400), dp(200));
                        }

                        JSONObject li = c.optJSONObject("level_info");
                        int lv = li != null ? li.optInt("current_level", 0) : 0;
                        int cur = li != null ? li.optInt("current_exp", 0) : 0;
                        int next = li != null ? li.optInt("next_exp", 0) : 0;
                        mineLv.setText("LV" + Math.max(0, lv));
                        if (next > 0) {
                            mineExp.setText(cur + "/" + next);
                            setExpBar(cur / (float) next);
                        } else {
                            mineExp.setText(cur + "/—");
                            setExpBar(1f);
                        }

                        JSONObject vip = c.optJSONObject("vip");
                        boolean isVip = vip != null && (vip.optInt("status", 0) == 1
                                || vip.optInt("type", 0) > 0);
                        if (isVip) {
                            mineVip.setText("年度大会员");
                            mineVip.setVisibility(View.VISIBLE);
                        } else {
                            mineVip.setVisibility(View.GONE);
                        }

                        int like = card[0].optInt("like_num", 0);
                        int fans = card[0].optInt("follower", c.optInt("fans", 0));
                        mineStats[0].setText(VideoItem.views(fans));
                        mineStats[2].setText(VideoItem.views(like));

                        double money = c.optDouble("money", 0);
                        if (money <= 0) money = 0;
                        mineCoinsText = String.format("%.1f", money);
                    } else {
                        mineName.setText("UID " + uid);
                        mineSign.setText("资料获取失败（可能被风控，点右上「更多 → 刷新资料」重试）");
                    }

                    if (stat[0] != null) {
                        mineStats[1].setText(VideoItem.views(stat[0].optInt("following", 0)));
                        if (stat[0].optInt("follower", 0) > 0) {
                            mineStats[0].setText(VideoItem.views(stat[0].optInt("follower", 0)));
                        }
                    }

                    // 投稿网格
                    if (mineVideoBox != null) {
                        mineVideoBox.removeAllViews();
                        JSONArray v = vids[0];
                        if (v == null || v.length() == 0) {
                            mineVideoBox.addView(mineEmptyTip("还没有投稿"));
                            if (mineVideoCount != null) mineVideoCount.setText("视频 0");
                        } else {
                            if (mineVideoCount != null) {
                                mineVideoCount.setText("视频 " + v.length()
                                        + (v.length() >= 30 ? "+" : ""));
                            }
                            buildMineVideos(v);
                        }
                    }
                } catch (Throwable ignore) { }
            } });
        } }).start();
    }

    /** 等级进度条：按比例设宽度（父容器宽度在 layout 之后才准，所以 post 一次） */
    void setExpBar(final float t) {
        if (mineExpBarFill == null) return;
        mineExpBarFill.post(new Runnable() {
            @Override public void run() {
                View parent = (View) mineExpBarFill.getParent();
                int w = parent != null ? parent.getWidth() : 0;
                if (w <= 0) return;
                ViewGroup.LayoutParams lp = mineExpBarFill.getLayoutParams();
                float p = Math.max(0f, Math.min(1f, t));
                lp.width = Math.max(dp(2), (int) (w * p));
                mineExpBarFill.setLayoutParams(lp);
            }
        });
    }

    TextView mineEmptyTip(String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(C_SUB);
        t.setTextSize(12);
        t.setGravity(Gravity.CENTER);
        t.setPadding(0, dp(24), 0, dp(24));
        return t;
    }

    /** 投稿网格：两列，最多 6 个，卡片风格贴近 B 站空间页 */
    void buildMineVideos(JSONArray v) {
        int total = Math.min(6, v.length());
        int sw = getResources().getDisplayMetrics().widthPixels;
        int cardW = (sw - dp(16) * 2 - dp(9)) / 2;

        LinearLayout row = null;
        for (int i = 0; i < total; i++) {
            JSONObject o = v.optJSONObject(i);
            if (o == null) continue;
            if (i % 2 == 0) {
                row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                rp.topMargin = dp(9);
                mineVideoBox.addView(row, rp);
            }
            View card = mineVideoCard(o, cardW);
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(cardW,
                    ViewGroup.LayoutParams.WRAP_CONTENT);
            cp.rightMargin = (i % 2 == 0) ? dp(9) : 0;
            row.addView(card, cp);
        }
    }

    View mineVideoCard(JSONObject o, int cardW) {
        final String bvid = o.optString("bvid", "");
        final String title = o.optString("title", "");
        String pic = o.optString("pic", "");
        if (pic.startsWith("//")) pic = "https:" + pic;
        long play = o.optLong("play", 0);
        long danmaku = o.optLong("video_review", 0);
        long aid = o.optLong("aid", 0);
        String len = o.optString("length", "");

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setClickable(true);

        FrameLayout thumb = new FrameLayout(this);
        thumb.setClipToOutline(true);
        thumb.setOutlineProvider(new android.view.ViewOutlineProvider() {
            @Override public void getOutline(View v2, android.graphics.Outline out) {
                out.setRoundRect(0, 0, v2.getWidth(), v2.getHeight(), dp(8));
            }
        });
        ImageView img = new ImageView(this);
        img.setScaleType(android.widget.ImageView.ScaleType.CENTER_CROP);
        img.setBackgroundColor(DARK ? 0xFF2A2E36 : 0xFFDDE1E8);
        thumb.addView(img, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        if (!pic.isEmpty()) {
            ImgLoader.load(img, pic, cardW, cardW * 9 / 16);
        }

        // 底部信息条：左「▶播放 · 弹幕」，右「时长」
        LinearLayout meta = new LinearLayout(this);
        meta.setOrientation(LinearLayout.HORIZONTAL);
        meta.setGravity(Gravity.BOTTOM);
        meta.setBackground(new android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.BOTTOM_TOP,
                new int[]{0xCC000000, 0x00000000}));
        meta.setPadding(dp(5), dp(2), dp(5), dp(3));

        TextView pv = new TextView(this);
        pv.setText("▶ " + VideoItem.views(play) + "   " + VideoItem.views(danmaku));
        pv.setTextColor(0xFFFFFFFF);
        pv.setTextSize(9.5f);
        meta.addView(pv, new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView tl = new TextView(this);
        tl.setText(len);
        tl.setTextColor(0xFFFFFFFF);
        tl.setTextSize(9.5f);
        meta.addView(tl);

        thumb.addView(meta, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM));

        card.addView(thumb, new LinearLayout.LayoutParams(
                cardW, cardW * 9 / 16));

        TextView t = new TextView(this);
        t.setText(title);
        t.setTextColor(C_FG);
        t.setTextSize(12);
        t.setMaxLines(2);
        t.setEllipsize(android.text.TextUtils.TruncateAt.END);
        t.setLineSpacing(dp(1), 1f);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        tp.topMargin = dp(5);
        card.addView(t, tp);

        card.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (bvid.isEmpty()) return;
                Intent it = new Intent(MainActivity.this, PlayActivity.class);
                it.putExtra("bvid", bvid);
                it.putExtra("ptitle", title);
                startActivity(it);
            }
        });
        return card;
    }

    /** 三栏：0 粉丝 / 1 关注 / 2 获赞（获赞没有公开列表，点了给个提示） */
    void openStat(int idx) {
        String uid = BiliApi.loggedInUid();
        if (uid == null) {
            Toast.makeText(this, "请先登录 B 站账号", Toast.LENGTH_SHORT).show();
            promptLoginOrOut();
            return;
        }
        String name = mineName != null ? mineName.getText().toString() : "";
        if (idx == 2) {
            Toast.makeText(this, "获赞数来自作品累计，没有单独列表", Toast.LENGTH_SHORT).show();
            return;
        }
        Intent it = new Intent(this, RelationActivity.class);
        it.putExtra("mode", idx == 1 ? "following" : "followers");
        it.putExtra("mid", uid);
        it.putExtra("name", name);
        startActivity(it);
    }

    void promptLoginOrOut() {
        if (BiliApi.loggedInUid() != null) {
            new AlertDialog.Builder(this)
                    .setTitle("已登录 UID " + BiliApi.loggedInUid())
                    .setPositiveButton("退出登录", new android.content.DialogInterface.OnClickListener() {
                        @Override public void onClick(android.content.DialogInterface d, int w) {
                            BiliApi.clearLoginCookie();
                            getSharedPreferences("bili_login", MODE_PRIVATE).edit().clear().apply();
                            refreshLoginTop();
                            refreshMine();
                            Toast.makeText(MainActivity.this, "已退出", Toast.LENGTH_SHORT).show();
                        }
                    })
                    .setNegativeButton("取消", null).show();
        } else {
            new AlertDialog.Builder(this)
                    .setTitle("登录哔哩哔哩")
                    .setMessage("两种方式任选：\n\n· 验证码登录：手机号 + 短信验证码（B 站官方页面）\n· 二维码登录：用 B 站手机 App 扫码确认\n\n登录后可解锁 1080p 与 320k 音质")
                    .setPositiveButton("验证码登录", new android.content.DialogInterface.OnClickListener() {
                        @Override public void onClick(android.content.DialogInterface d, int w) {
                            startActivity(new Intent(MainActivity.this, WebViewLoginActivity.class));
                        }
                    })
                    .setNeutralButton("二维码登录", new android.content.DialogInterface.OnClickListener() {
                        @Override public void onClick(android.content.DialogInterface d, int w) {
                            startActivity(new Intent(MainActivity.this, LoginActivity.class));
                        }
                    })
                    .setNegativeButton("取消", null).show();
        }
    }

    // ------------------------------------------------------------ 顶部频道内容

    /** 把统一结构的视频 JSONArray 转成 rows（热门 / 分区榜 / 直播共用） */
    void fillFromJson(final JSONArray list, final String emptyTip, final int tabAtPost) {
        if (!refreshing) addLoading();
        new Thread(new Runnable() { @Override public void run() {
            final ArrayList<VideoItem> got = new ArrayList<>();
            final String[] err = {null};
            try {
                if (list != null) {
                    for (int i = 0; i < list.length(); i++) {
                        JSONObject o = list.optJSONObject(i);
                        if (o == null) continue;
                        String bv = o.optString("bvid", "");
                        if (bv.isEmpty()) bv = "av" + o.optLong("aid", 0);
                        if (bv.equals("av0")) continue;
                        String up = o.optJSONObject("owner") != null
                                ? o.getJSONObject("owner").optString("name", "") : "";
                        long play = o.optJSONObject("stat") != null
                                ? o.getJSONObject("stat").optLong("view", 0) : 0;
                        int dur = o.optInt("duration", 0);
                        StringBuilder sub = new StringBuilder();
                        if (!up.isEmpty()) sub.append("UP · ").append(up);
                        if (play > 0) {
                            if (sub.length() > 0) sub.append("  ·  ");
                            sub.append(VideoItem.views(play)).append("播放");
                        }
                        if (dur > 0) {
                            if (sub.length() > 0) sub.append("  ·  ");
                            sub.append(VideoItem.dur(dur));
                        }
                        got.add(new VideoItem(bv, BiliApi.cleanTitle(o.optString("title", "")),
                                sub.toString(), o.optString("pic", "")));
                    }
                }
            } catch (final Throwable e) { err[0] = e.getMessage(); }
            ui.post(new Runnable() { @Override public void run() {
                if (currentTab != tabAtPost) { hideRefreshTip(); return; }
                setResult(got, emptyTip + (err[0] == null ? "" : "（" + err[0] + "）"));
                hideRefreshTip();
            } });
        } }).start();
    }

    void loadPopular() {
        if (!refreshing) addLoading();
        final int ch = currentChannel;
        new Thread(new Runnable() { @Override public void run() {
            try {
                final JSONArray list = BiliApi.popular(1 + (int) (Math.random() * 5));
                ui.post(new Runnable() { @Override public void run() {
                    if (currentTab == 0 && currentChannel == ch) fillFromJson(list, "热门为空", 0);
                } });
            } catch (final Throwable e) {
                ui.post(new Runnable() { @Override public void run() {
                    if (currentTab == 0 && currentChannel == ch) {
                        rows.clear();
                        rows.add(new VideoItem("", "热门加载失败：" + e.getMessage(), "", null));
                        notifyData(); hideRefreshTip();
                    }
                } });
            }
        } }).start();
    }

    void loadRanking(final int rid) {
        if (!refreshing) addLoading();
        final int ch = currentChannel;
        new Thread(new Runnable() { @Override public void run() {
            try {
                final JSONArray list = BiliApi.ranking(rid);
                ui.post(new Runnable() { @Override public void run() {
                    if (currentTab == 0 && currentChannel == ch) fillFromJson(list, "该分区暂无内容", 0);
                } });
            } catch (final Throwable e) {
                ui.post(new Runnable() { @Override public void run() {
                    if (currentTab == 0 && currentChannel == ch) {
                        rows.clear();
                        rows.add(new VideoItem("", "分区加载失败：" + e.getMessage(), "", null));
                        notifyData(); hideRefreshTip();
                    }
                } });
            }
        } }).start();
    }

    /** 直播：直播流接口风控较重，拉起系统浏览器进入 B 站直播页 */
    void loadLive() {
        try {
            Intent in = new Intent(Intent.ACTION_VIEW,
                    android.net.Uri.parse("https://live.bilibili.com/"));
            startActivity(in);
        } catch (Throwable e) {
            Toast.makeText(this, "没有可用浏览器", Toast.LENGTH_SHORT).show();
        }
        // 频道切回推荐，避免停留在空白页
        currentChannel = 0;
        refreshChannelStyle();
        loadRecommend(false);
    }

    /** 动态：关注 UP 主的最新投稿（复用关注列表数据源） */
    void loadDynamic() {
        if (BiliApi.loggedInUid() == null) {
            rows.clear();
            rows.add(new VideoItem("", "未登录——先到「我的」页登录，再查看动态", "", null));
            notifyData();
            hideRefreshTip();
            return;
        }
        loadFollow();
    }

    // ------------------------------------------------------------ 关注

    void loadFollow() {
        if (BiliApi.loggedInUid() == null) {
            rows.add(new VideoItem("", "未登录——先到「我的」页登录，再查看关注", "", null));
            notifyData();
            hideRefreshTip();
            return;
        }
        if (!refreshing) addLoading();
        new Thread(new Runnable() { @Override public void run() {
            final ArrayList<VideoItem> got = new ArrayList<>();
            final String[] err = {null};
            try {
                JSONArray list = BiliApi.followings();
                if (list != null) {
                    for (int i = 0; i < list.length(); i++) {
                        JSONObject o = list.getJSONObject(i);
                        String uname = o.optString("uname", "");
                        if (uname.isEmpty()) continue;
                        String face = o.optString("face", "");
                        if (!face.isEmpty() && !face.contains("@")) face = face + "@160w_160h_1c.jpg";
                        String sign = o.optString("sign", "").trim();
                        VideoItem vi = new VideoItem("up:" + uname, uname,
                                sign.isEmpty() ? "点击查看 TA 的作品" : sign, face);
                        vi.extra = o.optString("mid", "");
                        got.add(vi);
                    }
                }
            } catch (final Throwable e) {
                err[0] = e.getMessage();
            }
            ui.post(new Runnable() { @Override public void run() {
                if (currentTab != 1) { hideRefreshTip(); return; }
                setResult(got, "关注列表为空（" + (err[0] == null ? "空" : err[0]) + "）");
                hideRefreshTip();
            } });
        } }).start();
    }
}
